import { describe, expect, it } from 'vitest'

import { AnchorChallenge } from './anchorChallenge'

describe('AnchorChallenge · 锚点限时战', () => {
  it('初始为空闲态，未开启时血量与倒计时均为 0', () => {
    const anchor = new AnchorChallenge()
    expect(anchor.status).toBe('idle')
    expect(anchor.bossHp).toBe(0)
    expect(anchor.remaining).toBe(0)
  })

  it('start 置为 active 并载入限时窗与 BOSS 血量', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    expect(anchor.status).toBe('active')
    expect(anchor.bossHp).toBe(5000)
    expect(anchor.remaining).toBe(100)
  })

  it('damageBoss 扣血；未归零前保持 active', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.damageBoss(1200)
    expect(anchor.bossHp).toBe(3800)
    expect(anchor.status).toBe('active')
  })

  it('BOSS 血量正好归零即 cleared', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.damageBoss(5000)
    expect(anchor.bossHp).toBe(0)
    expect(anchor.status).toBe('cleared')
  })

  it('过量伤害（overkill）钳到 0 并 cleared', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.damageBoss(9999)
    expect(anchor.bossHp).toBe(0)
    expect(anchor.status).toBe('cleared')
  })

  it('tick 多次累积推进倒计时', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.tick(30)
    anchor.tick(40)
    expect(anchor.remaining).toBe(30)
    expect(anchor.status).toBe('active')
  })

  it('剩余时间正好归零即 failed', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.tick(100)
    expect(anchor.remaining).toBe(0)
    expect(anchor.status).toBe('failed')
  })

  it('cleared 后 damageBoss / tick 均为 no-op', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.damageBoss(5000)

    anchor.tick(50)
    anchor.damageBoss(500)
    expect(anchor.status).toBe('cleared')
    expect(anchor.bossHp).toBe(0)
    expect(anchor.remaining).toBe(100)
  })

  it('failed 后 damageBoss / tick 均为 no-op', () => {
    const anchor = new AnchorChallenge()
    anchor.start(100, 5000)
    anchor.tick(100)

    anchor.damageBoss(5000)
    anchor.tick(10)
    expect(anchor.status).toBe('failed')
    expect(anchor.bossHp).toBe(5000)
    expect(anchor.remaining).toBe(0)
  })

  it('未 start 前（idle）damageBoss / tick 均为 no-op', () => {
    const anchor = new AnchorChallenge()
    anchor.damageBoss(5000)
    anchor.tick(10)
    expect(anchor.status).toBe('idle')
    expect(anchor.bossHp).toBe(0)
    expect(anchor.remaining).toBe(0)
  })
})
