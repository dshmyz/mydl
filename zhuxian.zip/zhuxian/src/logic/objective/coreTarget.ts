/**
 * 守护剑阵核心：一局的常规失败条件（设计文档 §二「守护目标 / 胜负规则」）。
 *
 * 只维护耐久值与「是否被击破」两个事实，不决定耐久上限——`maxHp` 一律由组装层传入
 * （数值层不在此臆造数值）。纯逻辑，不 import Phaser，可确定性步进。
 */

export class CoreTarget {
  readonly maxHp: number
  private hpValue: number

  constructor(maxHp: number) {
    this.maxHp = maxHp
    this.hpValue = maxHp
  }

  /** 当前耐久（只读） */
  get hp(): number {
    return this.hpValue
  }

  /** 是否已被击破（耐久归零，只读） */
  get destroyed(): boolean {
    return this.hpValue <= 0
  }

  /** 承受伤害：扣血并向下钳到 0，不产生负耐久 */
  takeDamage(amount: number): void {
    this.hpValue = Math.max(0, this.hpValue - amount)
  }
}
