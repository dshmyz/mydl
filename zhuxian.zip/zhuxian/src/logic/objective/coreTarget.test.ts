import { describe, expect, it } from 'vitest'

import { CoreTarget } from './coreTarget'

describe('CoreTarget · 守护剑阵核心', () => {
  it('以构造参数初始化耐久，未受创时未被击破', () => {
    const core = new CoreTarget(1000)
    expect(core.maxHp).toBe(1000)
    expect(core.hp).toBe(1000)
    expect(core.destroyed).toBe(false)
  })

  it('承伤按量扣血', () => {
    const core = new CoreTarget(1000)
    core.takeDamage(300)
    expect(core.hp).toBe(700)
    expect(core.destroyed).toBe(false)
  })

  it('耐久正好归零即被击破', () => {
    const core = new CoreTarget(1000)
    core.takeDamage(1000)
    expect(core.hp).toBe(0)
    expect(core.destroyed).toBe(true)
  })

  it('过量伤害（overkill）向下钳到 0，不出现负耐久', () => {
    const core = new CoreTarget(1000)
    core.takeDamage(2500)
    expect(core.hp).toBe(0)
    expect(core.destroyed).toBe(true)
  })

  it('多次承伤累积，击破后继续承伤仍保持归零', () => {
    const core = new CoreTarget(1000)
    core.takeDamage(400)
    core.takeDamage(600)
    expect(core.hp).toBe(0)
    expect(core.destroyed).toBe(true)

    core.takeDamage(500)
    expect(core.hp).toBe(0)
    expect(core.destroyed).toBe(true)
  })
})
