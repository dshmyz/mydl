/**
 * 锚点限时战：剧情锚点 BOSS 出现后的限时击杀结算（设计文档 §二「锚点限时 BOSS」/ §9.2）。
 *
 * 状态机 `idle → active → cleared | failed`：
 * - `active` 下 `damageBoss` 扣 BOSS 血量，归零即 `cleared`（限时击杀成功）；
 * - `active` 下 `tick` 倒计时，归零即 `failed`（超时，核心受剧情级重创）。
 * 进入 `cleared` / `failed` 后一切操作均为 no-op，保证结算确定。
 *
 * 限时窗与 BOSS 血量均由调用方传入（限时窗取值见数值文档 §2.2：40s TTK / 90–120s 窗），
 * 模块内不臆造时间窗或血量常量。
 */

export type AnchorStatus = 'idle' | 'active' | 'cleared' | 'failed'

export class AnchorChallenge {
  private state: AnchorStatus = 'idle'
  private bossHpValue = 0
  private remainingValue = 0

  /** 当前状态（只读） */
  get status(): AnchorStatus {
    return this.state
  }

  /** BOSS 剩余血量（只读） */
  get bossHp(): number {
    return this.bossHpValue
  }

  /** 剩余限时秒数（只读） */
  get remaining(): number {
    return this.remainingValue
  }

  /** 开启限时战：置为 active，并以调用方传入的血量 / 限时窗初始化 */
  start(limitSeconds: number, bossMaxHp: number): void {
    this.state = 'active'
    this.bossHpValue = bossMaxHp
    this.remainingValue = limitSeconds
  }

  /** 对 BOSS 造成伤害：仅 active 时生效；血量归零即 cleared */
  damageBoss(amount: number): void {
    if (this.state !== 'active') {
      return
    }
    this.bossHpValue = Math.max(0, this.bossHpValue - amount)
    if (this.bossHpValue <= 0) {
      this.state = 'cleared'
    }
  }

  /** 推进倒计时：仅 active 且正时长时生效；剩余归零即 failed */
  tick(dt: number): void {
    if (this.state !== 'active' || dt <= 0) {
      return
    }
    this.remainingValue -= dt
    if (this.remainingValue <= 0) {
      this.state = 'failed'
    }
  }
}
