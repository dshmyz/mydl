import { describe, expect, it } from 'vitest'

import { HeroLife } from './heroLife'

describe('HeroLife · 英雄死亡与复活', () => {
  it('初始存活，复活秒数由构造参数决定，计时与次数归零', () => {
    const hero = new HeroLife(8)
    expect(hero.reviveSeconds).toBe(8)
    expect(hero.isAlive).toBe(true)
    expect(hero.deathTimer).toBe(0)
    expect(hero.revives).toBe(0)
  })

  it('kill 置为死亡并以复活秒数启动倒计时', () => {
    const hero = new HeroLife(8)
    hero.kill()
    expect(hero.isAlive).toBe(false)
    expect(hero.deathTimer).toBe(8)
  })

  it('重复 kill 无害：不重置已推进的倒计时', () => {
    const hero = new HeroLife(8)
    hero.kill()
    hero.tick(3)
    hero.kill()
    expect(hero.isAlive).toBe(false)
    expect(hero.deathTimer).toBe(5)
  })

  it('tick 多次累积推进死亡倒计时', () => {
    const hero = new HeroLife(10)
    hero.kill()
    hero.tick(2)
    hero.tick(3)
    expect(hero.deathTimer).toBe(5)
    expect(hero.isAlive).toBe(false)
  })

  it('倒计时正好归零即复活', () => {
    const hero = new HeroLife(8)
    hero.kill()
    hero.tick(8)
    expect(hero.isAlive).toBe(true)
    expect(hero.deathTimer).toBe(0)
    expect(hero.revives).toBe(1)
  })

  it('过量 tick 仍只复活一次，计时归零', () => {
    const hero = new HeroLife(8)
    hero.kill()
    hero.tick(20)
    expect(hero.isAlive).toBe(true)
    expect(hero.deathTimer).toBe(0)
    expect(hero.revives).toBe(1)
  })

  it('复活计数随每次「死亡 → 复活」累加', () => {
    const hero = new HeroLife(5)
    hero.kill()
    hero.tick(5)
    hero.kill()
    hero.tick(5)
    expect(hero.revives).toBe(2)
    expect(hero.isAlive).toBe(true)
  })

  it('存活时 tick 无操作，死亡计时保持 0', () => {
    const hero = new HeroLife(8)
    hero.tick(100)
    expect(hero.isAlive).toBe(true)
    expect(hero.deathTimer).toBe(0)
    expect(hero.revives).toBe(0)
  })
})
