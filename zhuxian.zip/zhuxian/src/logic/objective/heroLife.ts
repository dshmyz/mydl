/**
 * 英雄生命：死亡与复活计时（设计文档 §二「英雄死亡」）。
 *
 * 阵亡后进入 `deathTimer` 倒计时，归零自动复活并累计复活次数；复活秒数由调用方传入
 * （队友救援 / 碧瑶复活技等外部机制后续可复用），模块内不臆造默认值。
 * 纯逻辑，不 import Phaser。
 */

export class HeroLife {
  readonly reviveSeconds: number
  private alive = true
  private deathTimerValue = 0
  private reviveCount = 0

  constructor(reviveSeconds: number) {
    this.reviveSeconds = reviveSeconds
  }

  /** 是否存活（只读） */
  get isAlive(): boolean {
    return this.alive
  }

  /** 剩余复活秒数（存活时为 0，只读） */
  get deathTimer(): number {
    return this.deathTimerValue
  }

  /** 累计复活次数（只读） */
  get revives(): number {
    return this.reviveCount
  }

  /** 阵亡：置为死亡并以复活秒数启动倒计时；已死亡时重复 kill 无害（不重置倒计时） */
  kill(): void {
    if (!this.alive) {
      return
    }
    this.alive = false
    this.deathTimerValue = this.reviveSeconds
  }

  /** 推进死亡倒计时：仅死亡态且正时长时生效；归零即复活 */
  tick(dt: number): void {
    if (this.alive || dt <= 0) {
      return
    }
    this.deathTimerValue -= dt
    if (this.deathTimerValue <= 0) {
      this.deathTimerValue = 0
      this.alive = true
      this.reviveCount += 1
    }
  }
}
