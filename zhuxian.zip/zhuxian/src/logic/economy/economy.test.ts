import { describe, expect, it } from 'vitest'

import { buildGameData } from '../../data/tables'
import type { DropSource } from '../../data/types/common'
import type { DropTableRow } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'
import {
  dropGold,
  LevelTracker,
  materialDropChance,
  minionXp,
  rollMaterial,
  sourceXp,
  Wallet,
  waveGold,
} from './economy'

const data = buildGameData()
const { economy, drops } = data

/** 从真实掉落表取行（避免臆造数值） */
function rowOf(source: DropSource): DropTableRow {
  const row = drops.find((d) => d.source === source)
  if (!row) {
    throw new Error(`掉落表缺少来源「${source}」`)
  }
  return row
}

/** 受控 RNG：按给定序列回放，耗尽后默认 0.5（参考 waveDirector.test.ts 思路） */
function stubRng(rolls: readonly number[] = []): RngLike {
  let cursor = 0
  const next = (): number => {
    const value = rolls[cursor] ?? 0.5
    cursor += 1
    return value
  }
  return {
    next,
    int: (min, max) => min + Math.floor(next() * (max - min + 1)),
    range: (min, max) => min + next() * (max - min),
    chance: (p) => next() < p,
    pick: <T>(items: readonly T[]): T => items[Math.floor(next() * items.length)] as T,
    weighted: <T>(entries: readonly (readonly [T, number])[]): T => entries[0]?.[0] as T,
    fork: () => stubRng([]),
  }
}

describe('Wallet · 双货币钱包', () => {
  it('初值默认为 0，可显式指定', () => {
    expect(new Wallet().gold).toBe(0)
    expect(new Wallet().spirit).toBe(0)
    expect(new Wallet({ gold: 10, spirit: 3 }).gold).toBe(10)
    expect(new Wallet({ gold: 10, spirit: 3 }).spirit).toBe(3)
  })

  it('入账累计并返回余额', () => {
    const wallet = new Wallet()
    expect(wallet.addGold(30)).toBe(30)
    expect(wallet.addGold(55)).toBe(85)
    expect(wallet.addSpirit(12)).toBe(12)
    expect(wallet.gold).toBe(85)
    expect(wallet.spirit).toBe(12)
  })

  it('canAfford 要求两种货币同时够', () => {
    const wallet = new Wallet({ gold: 25, spirit: 5 })
    expect(wallet.canAfford(25, 5)).toBe(true)
    expect(wallet.canAfford(26, 5)).toBe(false)
    expect(wallet.canAfford(25, 6)).toBe(false)
  })

  it('spend 成交时同时扣两种货币', () => {
    const wallet = new Wallet({ gold: 120, spirit: 15 })
    expect(wallet.spend(120, 15)).toBe(true)
    expect(wallet.gold).toBe(0)
    expect(wallet.spirit).toBe(0)
  })

  it('金币不足：整笔拒绝，灵石也不扣', () => {
    const wallet = new Wallet({ gold: 24, spirit: 15 })
    expect(wallet.spend(25, 5)).toBe(false)
    expect(wallet.gold).toBe(24)
    expect(wallet.spirit).toBe(15)
  })

  it('灵石不足：整笔拒绝，金币也不扣', () => {
    const wallet = new Wallet({ gold: 120, spirit: 4 })
    expect(wallet.spend(60, 5)).toBe(false)
    expect(wallet.gold).toBe(120)
    expect(wallet.spirit).toBe(4)
  })
})

describe('LevelTracker · 经验与升级曲线（数值文档 §8.4）', () => {
  it('初始 1 级、0 经验；需求对齐 need(L)=30×1.2^(L−1)', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.level).toBe(1)
    expect(tracker.xp).toBe(0)
    // L1→2 = 30、L2→3 = 36、L3→4 = 43（floor(30×1.2^(L−1))）
    expect(tracker.xpToNext).toBe(30)
  })

  it('经验不足时不升级', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(29)).toBe(0)
    expect(tracker.level).toBe(1)
    expect(tracker.xp).toBe(29)
  })

  it('单次跨过需求升 1 级，余经验保留', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(35)).toBe(1)
    expect(tracker.level).toBe(2)
    expect(tracker.xp).toBe(5)
    expect(tracker.xpToNext).toBe(36)
  })

  it('正好等于需求时升级，余经验为 0（边界）', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(30)).toBe(1)
    expect(tracker.level).toBe(2)
    expect(tracker.xp).toBe(0)
  })

  it('一次投入连续升多级（30+36+43=109 → 升 3 级）', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(109)).toBe(3)
    expect(tracker.level).toBe(4)
    expect(tracker.xp).toBe(0)
    expect(tracker.xpToNext).toBe(Math.floor(30 * 1.2 ** 3))
  })

  it('多次 gainXp 逐级累积', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(30)).toBe(1)
    expect(tracker.gainXp(36)).toBe(1)
    expect(tracker.level).toBe(3)
    expect(tracker.xp).toBe(0)
  })

  it('封顶在 maxLevel，溢出经验被丢弃且不再升级', () => {
    const tracker = new LevelTracker(economy.levelNeed, 3)
    expect(tracker.gainXp(1_000_000)).toBe(2)
    expect(tracker.level).toBe(3)
    expect(tracker.xp).toBe(0)
    // 满级后再喂经验 → 恒定 0，状态不变
    expect(tracker.gainXp(999)).toBe(0)
    expect(tracker.level).toBe(3)
    expect(tracker.xp).toBe(0)
  })

  it('用配置的 maxLevel 封顶（终局 L25）', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    tracker.gainXp(1_000_000)
    expect(tracker.level).toBe(data.level.maxLevel)
    expect(tracker.xp).toBe(0)
  })

  it('非正经验视为无操作', () => {
    const tracker = new LevelTracker(economy.levelNeed, data.level.maxLevel)
    expect(tracker.gainXp(0)).toBe(0)
    expect(tracker.gainXp(-10)).toBe(0)
    expect(tracker.level).toBe(1)
    expect(tracker.xp).toBe(0)
  })
})

describe('xp 公式 · 小怪 / 精英 / BOSS（数值文档 §8.4）', () => {
  it('minionXp = minionBase + tier×perTier', () => {
    expect(minionXp(1, economy.xp)).toBe(economy.xp.minionBase + 1 * economy.xp.perTier)
    expect(minionXp(1, economy.xp)).toBe(6)
    expect(minionXp(3, economy.xp)).toBe(10)
  })

  it('sourceXp：小怪 ×1 / 精英 ×eliteMul / BOSS ×bossMul', () => {
    // tier 1 基准 = 6
    expect(sourceXp('minion', 1, economy.xp)).toBe(6)
    expect(sourceXp('elite', 1, economy.xp)).toBe(6 * economy.xp.eliteMul)
    expect(sourceXp('elite', 1, economy.xp)).toBe(30)
    expect(sourceXp('waveBoss', 1, economy.xp)).toBe(6 * economy.xp.bossMul)
    expect(sourceXp('anchorBoss', 1, economy.xp)).toBe(6 * economy.xp.bossMul)
    expect(sourceXp('anchorBoss', 1, economy.xp)).toBe(120)
  })
})

describe('waveGold · 每波金币收入（数值文档 §8.1）', () => {
  it('按幕阶跃 30 / 55 / 85', () => {
    expect(waveGold('act1', economy)).toBe(economy.goldPerWave.act1)
    expect(waveGold('act1', economy)).toBe(30)
    expect(waveGold('act2', economy)).toBe(55)
    expect(waveGold('act3', economy)).toBe(85)
  })
})

describe('dropGold · 掉落金币 = int(goldBase) × goldMul × players（附录 C.1）', () => {
  it('小怪 ×1：roll 决定 base，再 ∝ 人数', () => {
    const row = rowOf('minion')
    // roll 0 → int(1,3)=1
    expect(dropGold(row, 1, stubRng([0]))).toBe(1 * row.goldMul * 1)
    // roll 0.99 → int(1,3)=3
    expect(dropGold(row, 1, stubRng([0.99]))).toBe(3 * row.goldMul * 1)
    // 人数放大：4 人 → base × players
    expect(dropGold(row, 4, stubRng([0]))).toBe(1 * row.goldMul * 4)
  })

  it('精英 ×5', () => {
    const row = rowOf('elite')
    expect(dropGold(row, 1, stubRng([0]))).toBe(1 * 5 * 1)
    expect(dropGold(row, 6, stubRng([0.99]))).toBe(3 * 5 * 6)
  })

  it('锚点 BOSS ×20', () => {
    const row = rowOf('anchorBoss')
    expect(dropGold(row, 1, stubRng([0.99]))).toBe(3 * 20 * 1)
    expect(dropGold(row, 2, stubRng([0.99]))).toBe(3 * 20 * 2)
  })

  it('roll 区间恒落在 goldBase 内', () => {
    const row = rowOf('minion')
    for (const roll of [0, 0.25, 0.5, 0.75, 0.99]) {
      const gold = dropGold(row, 1, stubRng([roll]))
      expect(gold).toBeGreaterThanOrEqual(row.goldBase[0])
      expect(gold).toBeLessThanOrEqual(row.goldBase[1])
    }
  })
})

describe('materialDropChance · -1 覆盖语义（数值文档 §8.3）', () => {
  it('materialChance = -1 时沿用按幕递减基础掉率', () => {
    const row = rowOf('minion')
    expect(row.materialChance).toBe(-1)
    expect(materialDropChance(row, 'act1', economy)).toBe(economy.materialDropChance.act1)
    expect(materialDropChance(row, 'act1', economy)).toBe(0.15)
    expect(materialDropChance(row, 'act2', economy)).toBe(0.11)
    expect(materialDropChance(row, 'act3', economy)).toBe(0.08)
    // 精英同为 -1，行为一致
    expect(materialDropChance(rowOf('elite'), 'act3', economy)).toBe(0.08)
  })

  it('行内非负覆盖值优先于 economy（锚点 BOSS 必掉 = 1）', () => {
    const row = rowOf('anchorBoss')
    expect(row.materialChance).toBe(1)
    expect(materialDropChance(row, 'act1', economy)).toBe(1)
    expect(materialDropChance(row, 'act3', economy)).toBe(1)
  })
})

describe('rollMaterial · 命中 / 未命中 / 空池', () => {
  it('锚点 BOSS 必掉命中，从 materialPool 取材料', () => {
    const row = rowOf('anchorBoss')
    const material = rollMaterial(row, 'act1', economy, stubRng([0.99]))
    expect(material).not.toBeNull()
    expect(row.materialPool).toContain(material as string)
  })

  it('概率未命中返回 null', () => {
    const row = rowOf('minion')
    // 幕一掉率 0.15，roll 0.9 远大于 → 未命中
    expect(rollMaterial(row, 'act1', economy, stubRng([0.9]))).toBeNull()
  })

  it('probability 命中时返回池中材料', () => {
    const row = rowOf('minion')
    // roll 0.1 < 0.15 → 命中；随后 pick 用 0.5 取池内元素
    const material = rollMaterial(row, 'act1', economy, stubRng([0.1, 0.5]))
    expect(material).not.toBeNull()
    expect(row.materialPool).toContain(material as string)
  })

  it('空材料池退化：直接返回 null（防御，不抛错）', () => {
    // 退化用例：构造一个空池行，模拟配置缺失（非经济数值来源）
    const emptyRow: DropTableRow = {
      source: 'minion',
      goldBase: [1, 3],
      goldMul: 1,
      spiritFlat: 0,
      materialChance: 1,
      materialPool: [],
    }
    expect(rollMaterial(emptyRow, 'act1', economy, stubRng([0.1]))).toBeNull()
  })
})
