/**
 * 经济与掉率 L6：双货币钱包、等级经验、掉落结算（数值文档 §8 / 主文档 附录 C.1–C.2）。
 *
 * 设计原则（数值文档 §8）：收入只够「按节奏合成」，合成是主消耗泵，
 * 收入 → 装备进度，杜绝囤积通胀。本模块只做**纯结算**——
 * 所有经济数值一律来自 `EconomyDef` / `DropTableRow`（配置层），此处不硬编码任何数字。
 *
 * 随机性全部经 `RngLike` 注入，保证同一 seed 下收入 / 掉落可复现。
 */

import type { ActId, DropSource } from '../../data/types/common'
import type { DropTableRow, EconomyDef } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'

/** 小怪经验公式参数的最小子集（= `EconomyDef['xp']` 的两项） */
export type MinionXpDef = Pick<EconomyDef['xp'], 'minionBase' | 'perTier'>

/** 升级需求曲线参数（= `EconomyDef['levelNeed']`） */
export interface LevelNeedDef {
  base: number
  growth: number
}

/** 钱包初值（省略即 0） */
export interface WalletInit {
  gold?: number
  spirit?: number
}

/**
 * 双货币钱包：金币（∝ 人数）+ 灵石（全局掉落）。
 *
 * 余额对外**只读暴露**（`gold` / `spirit` getter），变更只能经 `addGold` /
 * `addSpirit` / `spend` 三个受控入口，避免外部随意改账。
 */
export class Wallet {
  private goldAmount: number
  private spiritAmount: number

  constructor(init: WalletInit = {}) {
    this.goldAmount = init.gold ?? 0
    this.spiritAmount = init.spirit ?? 0
  }

  get gold(): number {
    return this.goldAmount
  }

  get spirit(): number {
    return this.spiritAmount
  }

  /** 入账金币，返回入账后余额 */
  addGold(amount: number): number {
    this.goldAmount += amount
    return this.goldAmount
  }

  /** 入账灵石，返回入账后余额 */
  addSpirit(amount: number): number {
    this.spiritAmount += amount
    return this.spiritAmount
  }

  /** 双币种余额是否都够一次开销 */
  canAfford(gold: number, spirit: number): boolean {
    return this.goldAmount >= gold && this.spiritAmount >= spirit
  }

  /** 双币种整笔扣款：任一不足则拒绝、不部分扣（返回是否成交） */
  spend(gold: number, spirit: number): boolean {
    if (!this.canAfford(gold, spirit)) {
      return false
    }
    this.goldAmount -= gold
    this.spiritAmount -= spirit
    return true
  }
}

/**
 * 等级追踪器：维护当前等级与经验，按 §8.4 曲线逐级结算。
 *
 * 每级需求 `need(L) = floor(base × growth^(L−1))`（数值文档 §8.4：need(L)=30×1.2^(L−1)）。
 */
export class LevelTracker {
  private currentLevel = 1
  private currentXp = 0

  constructor(
    private readonly need: LevelNeedDef,
    private readonly maxLevel: number,
  ) {}

  get level(): number {
    return this.currentLevel
  }

  get xp(): number {
    return this.currentXp
  }

  /** 升到下一级所需经验；满级时仍返回公式值，但 `gainXp` 不再使用它 */
  get xpToNext(): number {
    return Math.floor(this.need.base * this.need.growth ** (this.currentLevel - 1))
  }

  /**
   * 获得经验，返回本次升的级数。
   *
   * 令 `xp >= xpToNext` 时升级并减去需求，循环直至不足或封顶。
   * **封顶口径**：等级封顶 `maxLevel` 后不再升级；到达满级时**丢弃多余经验**
   * （`xp` 归零），因为满级后 XP 无任何产出，保留残余会产生「无兑现的隐性进度」，
   * 与 §8.5 通胀护栏的「无囤积收益」精神相悖（文档未明示，此为模块内取舍）。
   */
  gainXp(amount: number): number {
    if (amount <= 0 || this.currentLevel >= this.maxLevel) {
      return 0
    }
    this.currentXp += amount
    let gained = 0
    while (this.currentLevel < this.maxLevel && this.currentXp >= this.xpToNext) {
      this.currentXp -= this.xpToNext
      this.currentLevel += 1
      gained += 1
    }
    if (this.currentLevel >= this.maxLevel) {
      this.currentXp = 0
    }
    return gained
  }
}

/** 小怪经验：`XP = minionBase + tier × perTier`（数值文档 §8.4 / 附录 C.1） */
export function minionXp(tier: number, xp: MinionXpDef): number {
  return xp.minionBase + tier * xp.perTier
}

/**
 * 按掉落来源折算经验：小怪 ×1 / 精英 ×eliteMul / BOSS ×bossMul
 * （数值文档 §8.4：精英 ×5、BOSS ×20；波次 BOSS 与锚点 BOSS 同乘 bossMul）。
 */
export function sourceXp(source: DropSource, tier: number, xpRule: EconomyDef['xp']): number {
  const base = minionXp(tier, xpRule)
  switch (source) {
    case 'minion':
      return base
    case 'elite':
      return base * xpRule.eliteMul
    case 'waveBoss':
    case 'anchorBoss':
      return base * xpRule.bossMul
  }
}

/** 单波金币收入（按幕阶跃，数值文档 §8.1） */
export function waveGold(act: ActId, economy: EconomyDef): number {
  return economy.goldPerWave[act]
}

/**
 * 单次掉落金币：`int(goldBase) × goldMul × players`
 * （主文档 附录 C.1：小怪基础 1–3 且 ∝ 人数，倍率按来源递增）。
 */
export function dropGold(row: DropTableRow, players: number, rng: RngLike): number {
  return rng.int(row.goldBase[0], row.goldBase[1]) * row.goldMul * players
}

/**
 * 材料掉率：`row.materialChance >= 0` 时用行内覆盖值，否则（-1）沿用
 * `economy.materialDropChance` 的按幕递减基础掉率（数值文档 §8.3）。
 */
export function materialDropChance(row: DropTableRow, act: ActId, economy: EconomyDef): number {
  return row.materialChance >= 0 ? row.materialChance : economy.materialDropChance[act]
}

/**
 * 材料掉落 roll：按 `materialDropChance` 判定命中后，从 `row.materialPool`
 * 等概率取一个材料 id，否则返回 null。
 *
 * 退化处理：`materialPool` 为空时无可掉之物，直接返回 null（且不消耗随机数），
 * 避免 `rng.pick` 对空数组抛错——配置层应保证非空池，此处仅作防御。
 */
export function rollMaterial(
  row: DropTableRow,
  act: ActId,
  economy: EconomyDef,
  rng: RngLike,
): string | null {
  if (row.materialPool.length === 0) {
    return null
  }
  if (!rng.chance(materialDropChance(row, act, economy))) {
    return null
  }
  return rng.pick(row.materialPool)
}
