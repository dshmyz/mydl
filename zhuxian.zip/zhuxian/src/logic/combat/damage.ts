/**
 * 伤害引擎：数值文档 §3.1 六步公式 + §3.4 上限护栏。
 *
 * 纯函数：给定攻守双方、伤害类型、倍率与 RNG，产出可复现的伤害分解。
 * 不发散副作用——吸血 / 击杀 / 护盾吸收等由调用方（技能 / 战斗引擎）处理。
 *
 * 执行顺序（与文档一致）：
 *  1) 闪避判定 → 2) base = (法术 ? SP : ATK) × RATE → 3) dmgMult 增伤修正
 *  → 4) 暴击修正 → 5) 减伤 defRed（真实伤害为 0）→ 6) max(1, floor(...))
 *
 * 注意面板口径：会心 / 闪避属性以**百分数**存储（如 crit=45 表示 45%），
 * 而护栏 `limits.critMax / dodgeMax` 为**小数**（0.6 / 0.25），比较前需 ÷100。
 */

import type { DamageType, Stats, Tier } from '../../data/types/common'
import type { LimitsDef, TierArmorKDef } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'
import type { ModifierSet } from '../modifier/modifierSet'

/** 参与伤害结算的攻方视角（属性 + 容器） */
export interface DamageActor {
  /** 结算后属性（含成长倍率与修饰，见 ModifierSet.resolveStats） */
  stats: Stats
  modifiers: ModifierSet
}

/** 守方视角：额外声明护甲档位以取得减伤系数 K */
export interface DamageTarget extends DamageActor {
  /** 护甲档（数值文档 §3.3：K 挂档位不挂单位） */
  tier: Tier
  /** 减伤系数 K 覆写（默认 1.0；锚点 BOSS = 1.2 表示更硬） */
  armorKMult?: number
}

export interface DamageParams {
  attacker: DamageActor
  defender: DamageTarget
  damageType: DamageType
  /** 技能倍率 RATE；普攻 = 1.0 */
  rate: number
  rng: RngLike
  /** 档位 → 护甲 K 表（数值文档 §3.3） */
  armorK: ReadonlyMap<Tier, TierArmorKDef>
  limits: LimitsDef
}

/** 伤害分解（便于测试断言与伤害数字展示） */
export interface DamageBreakdown {
  dodged: boolean
  crit: boolean
  /** 基础伤害 base = (法术 ? SP : ATK) × RATE */
  base: number
  /** 增伤修正 dmgMult */
  dmgMult: number
  /** 暴击倍率（未暴击 = 1） */
  critMult: number
  /** 减伤率 defRed */
  defRed: number
  /** 最终伤害 */
  damage: number
}

export function computeDamage(params: DamageParams): DamageBreakdown {
  const { attacker, defender, damageType, rate, rng, armorK, limits } = params

  const base = (damageType === 'magic' ? attacker.stats.sp : attacker.stats.atk) * rate

  // 第 3 步：增伤修正 = 1 + Σ增伤 − Σ减伤修正（含叠层增伤），clamp 0.5 ~ 2.5
  const dmgMult = clamp(
    1 +
      attacker.modifiers.outgoingBonus() +
      attacker.modifiers.stackDamageBonus() -
      defender.modifiers.incomingReduction(),
    limits.dmgMultMin,
    limits.dmgMultMax,
  )

  const defRed = computeDefRed(defender, damageType, armorK, limits)

  // 第 1 步：闪避（面板百分数 ÷100，再按 25% 上限钳制）
  const dodgeChance = clamp(defender.stats.dodge / 100, 0, limits.dodgeMax)
  if (rng.chance(dodgeChance)) {
    return { dodged: true, crit: false, critMult: 1, base, dmgMult, defRed, damage: 0 }
  }

  // 第 4 步：暴击（会心 ≤ 60%、暴击伤害 ≤ 2.5）
  const critChance = clamp(attacker.stats.crit / 100, 0, limits.critMax)
  const crit = rng.chance(critChance)
  const critMult = crit ? Math.min(attacker.stats.critDmg, limits.critDmgMax) : 1

  // 第 6 步：max(1, floor(...))，物理 / 法术最低 1
  const damage = Math.max(1, Math.floor(base * dmgMult * critMult * (1 - defRed)))
  return { dodged: false, crit, critMult, base, dmgMult, defRed, damage }
}

/** 第 5 步：减伤率 = DEF / (DEF + K)，真实伤害为 0，硬上限 75% */
function computeDefRed(
  defender: DamageTarget,
  damageType: DamageType,
  armorK: ReadonlyMap<Tier, TierArmorKDef>,
  limits: LimitsDef,
): number {
  if (damageType === 'real') {
    return 0
  }
  const entry = armorK.get(defender.tier)
  if (!entry) {
    throw new Error(`伤害引擎：缺少档位 T${defender.tier} 的护甲 K 定义`)
  }
  const def = Math.max(0, defender.stats.def)
  const k = entry.k * (defender.armorKMult ?? 1)
  return Math.min(def / (def + k), limits.defRedMax)
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max)
}
