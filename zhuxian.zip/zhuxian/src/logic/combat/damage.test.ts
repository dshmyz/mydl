import { describe, expect, it } from 'vitest'

import { limits, tierArmorK } from '../../data/tables/numeric'
import type { DamageType, Stats, Tier } from '../../data/types/common'
import type { TierArmorKDef } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'
import { ModifierSet } from '../modifier/modifierSet'
import { computeDamage, type DamageActor, type DamageTarget } from './damage'

const armorK: ReadonlyMap<Tier, TierArmorKDef> = new Map(tierArmorK.map((entry) => [entry.tier, entry]))

/** 受控 RNG：按顺序吐出预设 roll，默认 1（必不命中闪避 / 暴击） */
function stubRng(rolls: readonly number[] = []): RngLike {
  let cursor = 0
  const next = (): number => {
    const value = rolls[cursor] ?? 1
    cursor += 1
    return value
  }
  return {
    next,
    int: (min) => min,
    range: (min) => min,
    chance: (p) => next() < p,
    pick: <T>(items: readonly T[]): T => items[0] as T,
    weighted: <T>(entries: readonly (readonly [T, number])[]): T => entries[0]?.[0] as T,
    fork: () => stubRng([]),
  }
}

/** 英雄面板（N1 开局，数值文档 §2.3） */
function heroStats(overrides: Partial<Stats> = {}): Stats {
  return {
    hp: 800,
    mp: 200,
    atk: 45,
    sp: 45,
    def: 12,
    spd: 300,
    dodge: 0,
    crit: 0,
    critDmg: 1.5,
    ...overrides,
  }
}

/** 小怪面板（N1，数值文档 §2.3） */
function minionStats(overrides: Partial<Stats> = {}): Stats {
  return {
    hp: 32,
    mp: 0,
    atk: 18,
    sp: 18,
    def: 7,
    spd: 220,
    dodge: 0,
    crit: 0,
    critDmg: 1,
    ...overrides,
  }
}

function actor(stats: Stats): DamageActor {
  return { stats, modifiers: new ModifierSet() }
}

function target(stats: Stats, tier: Tier, armorKMult?: number): DamageTarget {
  return { stats, modifiers: new ModifierSet(), tier, armorKMult }
}

interface HitOptions {
  damageType?: DamageType
  rate?: number
  rolls?: readonly number[]
}

/** 便捷调用：默认物理普攻（rate 1.0）、无暴击无闪避 */
function hit(attacker: DamageActor, defender: DamageTarget, options: HitOptions = {}) {
  return computeDamage({
    attacker,
    defender,
    damageType: options.damageType ?? 'physical',
    rate: options.rate ?? 1,
    rng: stubRng(options.rolls),
    armorK,
    limits,
  })
}

describe('computeDamage · 六步公式（数值文档 §3.1）', () => {
  it('第 5 步减伤：小怪 DEF 7 + T1 K 28 → 减伤 20%', () => {
    const result = hit(actor(heroStats()), target(minionStats(), 1))
    expect(result.defRed).toBeCloseTo(7 / (7 + 28), 10)
    expect(result.damage).toBe(36) // floor(45 × 0.8)
    expect(result.base).toBe(45)
    expect(result.dmgMult).toBe(1)
    expect(result.crit).toBe(false)
    expect(result.dodged).toBe(false)
  })

  it('第 2 步基础伤害：法术取 SP、物理取 ATK、真实取 ATK 且无视减伤', () => {
    const mage = hit(actor(heroStats({ sp: 100, atk: 45 })), target(minionStats(), 1), {
      damageType: 'magic',
    })
    expect(mage.base).toBe(100)

    const real = hit(actor(heroStats()), target(minionStats({ def: 96 }), 6), {
      damageType: 'real',
    })
    expect(real.defRed).toBe(0)
    expect(real.base).toBe(45)
    expect(real.damage).toBe(45)
  })

  it('第 3 步增伤修正：Σ增伤（damageDealtMul / 叠层）− Σ减伤修正', () => {
    const atk = actor(heroStats())
    atk.modifiers.add({ kind: 'damageDealtMul', value: 1.2, duration: 5 }, 'buff')
    atk.modifiers.add(
      { kind: 'stackDamage', stackId: 'moqi', perStack: 0.03, maxStacks: 5, duration: 8 },
      'zxf_r',
    )
    atk.modifiers.add(
      { kind: 'stackDamage', stackId: 'moqi', perStack: 0.03, maxStacks: 5, duration: 8 },
      'zxf_r',
    ) // 2 层 → +0.06

    const def = target(minionStats(), 1)
    def.modifiers.add({ kind: 'damageTakenMul', value: 0.9, duration: 5 }, 'shield')

    const result = hit(atk, def)
    expect(result.dmgMult).toBeCloseTo(1 + 0.2 + 0.06 - 0.1, 10)
  })

  it('第 4 步暴击：命中时用 critDmg 倍率', () => {
    const atk = actor(heroStats({ crit: 45, critDmg: 2 }))
    const normal = hit(atk, target(minionStats(), 1), { rolls: [1, 1] })
    expect(normal.crit).toBe(false)
    expect(normal.critMult).toBe(1)

    const crit = hit(atk, target(minionStats(), 1), { rolls: [1, 0.1] })
    expect(crit.crit).toBe(true)
    expect(crit.critMult).toBe(2)
    expect(crit.damage).toBe(72) // floor(45 × 2 × 0.8)
  })

  it('第 6 步取整：max(1, floor(...)) 杜绝 0 伤害', () => {
    const weak = hit(actor(heroStats({ atk: 1 })), target(minionStats({ def: 999 }), 1), { rate: 0.1 })
    expect(weak.damage).toBe(1)
  })

  it('第 1 步闪避：命中判定成功后伤害为 0', () => {
    const def = target(minionStats({ dodge: 10 }), 1)
    expect(hit(actor(heroStats()), def, { rolls: [0.05] }).dodged).toBe(true)
    expect(hit(actor(heroStats()), def, { rolls: [0.05] }).damage).toBe(0)
    expect(hit(actor(heroStats()), def, { rolls: [0.2] }).dodged).toBe(false)
  })
})

describe('computeDamage · 上限护栏（数值文档 §3.4 / §9.1）', () => {
  it('减伤率硬上限 75%', () => {
    const result = hit(actor(heroStats()), target(minionStats({ def: 10000 }), 1))
    expect(result.defRed).toBe(limits.defRedMax)
  })

  it('闪避率按 25% 上限钳制（面板为百分数）', () => {
    const def = target(minionStats({ dodge: 50 }), 1)
    expect(hit(actor(heroStats()), def, { rolls: [0.2] }).dodged).toBe(true)
    expect(hit(actor(heroStats()), def, { rolls: [0.3] }).dodged).toBe(false)
  })

  it('会心率按 60% 上限钳制、暴击伤害按 2.5 上限钳制', () => {
    const atk = actor(heroStats({ crit: 90, critDmg: 3 }))
    // 0.55 < 0.6 命中暴击；倍率被压到 2.5
    const result = hit(atk, target(minionStats(), 1), { rolls: [1, 0.55] })
    expect(result.crit).toBe(true)
    expect(result.critMult).toBe(limits.critDmgMax)
    // 0.7 > 0.6 不暴击
    expect(hit(atk, target(minionStats(), 1), { rolls: [1, 0.7] }).crit).toBe(false)
  })

  it('增伤修正 clamp 到 [0.5, 2.5]', () => {
    const buff = actor(heroStats())
    buff.modifiers.add({ kind: 'damageDealtMul', value: 5, duration: 5 }, 'over')
    expect(hit(buff, target(minionStats(), 1)).dmgMult).toBe(limits.dmgMultMax)

    const debuffed = target(minionStats(), 1)
    // 受伤 ×0.4 → Σ减伤修正 0.6 → 1 − 0.6 = 0.4，被钳到下限
    debuffed.modifiers.add({ kind: 'damageTakenMul', value: 0.4, duration: 5 }, 'over')
    expect(hit(actor(heroStats()), debuffed).dmgMult).toBe(limits.dmgMultMin)
  })

  it('armorKMult 覆写 K（锚点 BOSS = 1.2 更硬）', () => {
    const result = hit(actor(heroStats()), target(minionStats({ def: 12 }), 1, 1.2))
    expect(result.defRed).toBeCloseTo(12 / (12 + 28 * 1.2), 10)
  })

  it('缺失档位 K 表时抛错（配置错误 fail fast）', () => {
    const empty = new Map<Tier, TierArmorKDef>()
    expect(() =>
      computeDamage({
        attacker: actor(heroStats()),
        defender: target(minionStats(), 1),
        damageType: 'physical',
        rate: 1,
        rng: stubRng(),
        armorK: empty,
        limits,
      }),
    ).toThrow()
  })
})

describe('computeDamage · N1 手感标尺（数值文档 §3.5）', () => {
  it('英雄打小怪：减伤 20% → 有效 DPS 48 → TTK ≈ 0.67s', () => {
    const result = hit(actor(heroStats()), target(minionStats(), 1))
    expect(result.defRed).toBeCloseTo(0.2, 10)
    // 英雄单体等效 DPS ≈ 60（普攻 45×1.3 ≈ 58 叠 Q）
    const effectiveDps = 60 * (1 - result.defRed)
    const ttk = 32 / effectiveDps
    expect(ttk).toBeGreaterThanOrEqual(0.65)
    expect(ttk).toBeLessThanOrEqual(1.0)
    expect(ttk).toBeCloseTo(0.667, 3)
  })

  it('6 只小怪围殴英雄：减伤 30% → 有效 DPS 75.6 → TTL ≈ 10.6s', () => {
    const result = hit(actor(minionStats()), target(heroStats(), 1))
    expect(result.defRed).toBeCloseTo(0.3, 10)
    const effectiveDps = 6 * 18 * (1 - result.defRed)
    const ttl = 800 / effectiveDps
    expect(ttl).toBeGreaterThanOrEqual(10)
    expect(ttl).toBeLessThanOrEqual(12)
    expect(ttl).toBeCloseTo(10.58, 2)
  })
})
