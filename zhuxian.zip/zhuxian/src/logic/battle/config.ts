/**
 * 战斗编排的运行时参数（M1 原型）。
 *
 * 这些值与「数值体系」的**公式/锚点**不同：公式与锚点已定稿（`data/tables/numeric.ts`），
 * 而此处是文档未登记、必须由手感实测确定的**展开参数**（地图尺寸、核心耐久、复活秒数、
 * 索敌冗余、刷怪散布、准备倒计时等）。统一集中在 `DEFAULT_BATTLE_CONFIG`，验收后回填数值文档
 * （见附录 F.3 第 21 步）。
 *
 * 已定的口径不在此重复：波次准备 60–90s、锚点准备 90s、锚点限时窗 90–120s（附录 D.5）
 * 通过 `wave` 字段显式传入，不散落在逻辑各处。
 */

import type { ActId } from '../../data/types/common'
import type { Bounds, Vec2 } from './spatial'
import type { WaveSchedulerConfig } from './waveScheduler'

export interface BattleFieldConfig {
  /** 战场边界（格） */
  bounds: Bounds
  /** 怪物刷怪点（出生区中心） */
  spawn: Vec2
  /** 剑阵核心位置 */
  core: Vec2
  /** 英雄出生位置 */
  heroSpawn: Vec2
}

export interface BattleConfig {
  seed: number
  /** 玩家人数（波次缩放输入，§6） */
  players: number
  /** 逻辑固定步长（秒） */
  dt: number
  /** 当前幕（M1 固定 act1） */
  act: ActId
  /** 本局英雄 id */
  heroId: string

  field: BattleFieldConfig

  /** 剑阵核心耐久上限（原型值；M1 实测：配 5s 复活可守住，见数值文档 §9.6） */
  coreMaxHp: number
  /**
   * 英雄阵亡复活秒数（原型值，M1 实测调参）。
   * 15s 的「阵亡 → 复活」空窗会让核心承伤超预算、锚点战必失守；实测 ≤6s 静态 headless bot
   * 方可通关，取 5s 留余量（通关时核心剩 42%、限时窗余 34s）。详见数值文档 §9.6。
   */
  heroReviveSeconds: number
  /** 英雄普攻距离（格，原型值） */
  heroAttackRange: number
  /** 英雄真气每秒回复（原型值；数值文档未登记回复机制） */
  heroMpRegenPerSecond: number
  /** 怪物索敌冗余（格）：在攻击距离基础上额外察觉英雄的范围 */
  aggroBonus: number
  /** 刷怪 / 召唤落位散布半径（格） */
  spawnSpread: number

  /** 波次排程参数；人数由 `players` 统一提供，故此处不再重复声明 */
  wave: Omit<WaveSchedulerConfig, 'players'>
}

/** M1 纵向切片默认参数 */
export const DEFAULT_BATTLE_CONFIG: BattleConfig = {
  seed: 20261013,
  players: 1,
  dt: 1 / 30,
  act: 'act1',
  heroId: 'zhangxiaofan',

  field: {
    bounds: { min: { x: 0, y: 0 }, max: { x: 24, y: 12 } },
    spawn: { x: 21, y: 6 },
    core: { x: 2, y: 6 },
    heroSpawn: { x: 9, y: 6 },
  },

  coreMaxHp: 3000,
  heroReviveSeconds: 5,
  heroAttackRange: 1,
  heroMpRegenPerSecond: 5,
  aggroBonus: 2.5,
  spawnSpread: 1.2,

  wave: {
    prepSeconds: 60,
    minPrepSeconds: 15,
    anchorPrepSeconds: 90,
    anchorWindowSeconds: 90,
    anchorKillThreshold: 70,
    anchorBossId: 'heishui_xuanshe',
  },
}
