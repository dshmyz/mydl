import { describe, expect, it } from 'vitest'
import type { Stats } from '../../data/types/common'
import { Unit } from './unit'

const base: Stats = {
  hp: 800,
  mp: 200,
  atk: 45,
  sp: 45,
  def: 12,
  spd: 300,
  dodge: 0,
  crit: 5,
  critDmg: 1.5,
}

function makeHero(over: Partial<ConstructorParameters<typeof Unit>[0]> = {}) {
  return new Unit({
    id: 'h1',
    kind: 'hero',
    defId: 'zhangxiaofan',
    name: '张小凡',
    baseStats: base,
    position: { x: 0, y: 0 },
    tier: 1,
    attackSpeed: 1.3,
    attackRange: 1,
    damageType: 'physical',
    maxMp: 200,
    ...over,
  })
}

describe('Unit · 构造与属性', () => {
  it('无修饰时 stats 即基础属性', () => {
    const u = makeHero()
    expect(u.stats).toEqual(base)
  })

  it('气血初始化为最大气血', () => {
    const u = makeHero()
    expect(u.hp).toBe(800)
    expect(u.maxHp).toBe(800)
  })

  it('attackInterval = 1 / 攻速', () => {
    const u = makeHero()
    expect(u.attackInterval).toBeCloseTo(1 / 1.3, 10)
  })

  it('移速换算为格/秒，且随减速百分比联动', () => {
    const u = makeHero()
    expect(u.moveSpeed).toBeCloseTo(3, 10)
    u.modifiers.add({ kind: 'statMod', stat: 'spd', mode: 'percent', value: -0.5 })
    expect(u.moveSpeed).toBeCloseTo(1.5, 10)
  })

  it('默认朝向 +x、存活、1 级玉清', () => {
    const u = makeHero()
    expect(u.facing).toEqual({ x: 1, y: 0 })
    expect(u.alive).toBe(true)
    expect(u.level).toBe(1)
    expect(u.rank).toBe('yuqing')
  })

  it('英雄持有 state，怪物按 kind 判定 boss / elite', () => {
    const boss = new Unit({
      id: 'b1',
      kind: 'boss',
      defId: 'heishui_xuanshe',
      name: '黑水玄蛇',
      baseStats: base,
      position: { x: 5, y: 0 },
      tier: 1,
      attackSpeed: 0.8,
      attackRange: 1.6,
      damageType: 'physical',
      maxMp: 0,
    })
    expect(boss.isBoss).toBe(true)
    expect(boss.isElite).toBe(false)
  })

  it('statMod 百分比改写最终属性与最大气血', () => {
    const u = makeHero()
    u.modifiers.add({ kind: 'statMod', stat: 'hp', mode: 'percent', value: 0.25 })
    expect(u.stats.hp).toBe(1000)
    expect(u.maxHp).toBe(1000)
  })
})

describe('Unit · 时间推进', () => {
  it('tick 推进技能冷却与限时修饰', () => {
    const u = makeHero()
    u.modifiers.add({ kind: 'damageTakenMul', value: 0.9, duration: 1 })
    u.skillState?.setCooldown('zxf_q', 2)
    u.tick(0.5)
    expect(u.skillState?.cooldownRemaining('zxf_q')).toBeCloseTo(1.5, 10)
    expect(u.modifiers.active.length).toBe(1)
    u.tick(0.6)
    expect(u.modifiers.active.length).toBe(0)
  })

  it('tick 递减普攻计时且不为负', () => {
    const u = makeHero()
    u.attackTimer = 0.5
    u.tick(0.2)
    expect(u.attackTimer).toBeCloseTo(0.3, 10)
    u.tick(1)
    expect(u.attackTimer).toBe(0)
  })
})

describe('Unit · 状态变更', () => {
  it('setBaseStats 保持气血比例', () => {
    const u = makeHero()
    u.hp = 400
    u.setBaseStats({ ...base, hp: 1600 })
    expect(u.maxHp).toBe(1600)
    expect(u.hp).toBe(800)
  })

  it('recompute 基础属性按境界 / 等级缩放并保比例', () => {
    const u = makeHero()
    u.hp = 400
    u.setBaseStats({ ...base, hp: 1600, atk: 90 })
    expect(u.maxHp).toBe(1600)
    expect(u.stats.atk).toBe(90)
    expect(u.hp).toBe(800)
  })
})
