/**
 * 波次排程：把「准备 → 刷怪 → 清场」循环与锚点触发编排为可确定性步进的状态机。
 *
 * 状态：`prep`（准备倒计时）→ `combat`（战斗中，敌人清空即结束）
 *      → 满足锚点条件则 `anchorPrep`（90s 准备）→ `anchor`（限时战，等待外部结算）
 *      → `done`（M1 一局止于锚点一）。
 *
 * 事件在**进入准备阶段**时 roll 一次（主文档 E.3），其时序修正作用于本轮准备倒计时；
 * 区间进度由**累计击杀**驱动（对齐 §3.1「锚点由累计条件触发」），到达阈值即进度封顶。
 *
 * 只产出命令（刷怪 / 金币 / 锚点 BOSS），不直接改动战场 —— 落位与结算由编排层处理。
 */

import type { ActId } from '../../data/types/common'
import type { GameData } from '../../data/types/gameData'
import type { EventDef } from '../../data/types/waves'
import type { RngLike } from '../core/rng'
import { waveGold } from '../economy/economy'
import type { EventDirector } from '../events/eventDirector'
import type { SpawnGroup, WaveDirector, WavePlan } from '../waves/waveDirector'

export type WavePhase = 'prep' | 'combat' | 'anchorPrep' | 'anchor' | 'done'

/** 排程参数（M1 原型取值见 `battle/config.ts`，验收后回填数值文档） */
export interface WaveSchedulerConfig {
  players: number
  /** 常规波次准备倒计时（秒） */
  prepSeconds: number
  /** 事件提前后的准备下限（秒） */
  minPrepSeconds: number
  /** 锚点前准备倒计时（秒，附录 D.5：90s） */
  anchorPrepSeconds: number
  /** 锚点限时窗（秒，附录 D.5：90–120s） */
  anchorWindowSeconds: number
  /** 触发锚点的累计击杀阈值（附录 D.5「累计击杀达标」） */
  anchorKillThreshold: number
  /** 锚点 BOSS 怪物 id */
  anchorBossId: string
}

export interface WaveSchedulerDeps {
  data: GameData
  director: WaveDirector
  events: EventDirector
  rng: RngLike
  config: WaveSchedulerConfig
  /** 当前幕（M1 固定 act1） */
  act: ActId
}

/** 战场回读给排程器的只读事实 */
export interface WaveState {
  /** 当前存活敌人数 */
  enemiesAlive: number
  /** 本局累计击杀数 */
  totalKills: number
}

/** 排程器产出的命令（由编排层执行） */
export type WaveCommand =
  | { kind: 'spawn'; plan: WavePlan }
  | { kind: 'gold'; amount: number }
  | { kind: 'anchorSpawn'; group: SpawnGroup; windowSeconds: number }

export class WaveScheduler {
  private phaseValue: WavePhase = 'prep'
  private wave = 0
  private prep = 0
  private templateId = ''
  private eventValue: EventDef | null = null
  private timingDeltaValue = 0

  constructor(private readonly deps: WaveSchedulerDeps) {
    this.enterPrep()
  }

  get phase(): WavePhase {
    return this.phaseValue
  }

  /** 当前波号（准备中或战斗中） */
  get waveNumber(): number {
    return this.wave
  }

  /** 本轮准备的剩余秒数 */
  get prepRemaining(): number {
    return this.prep
  }

  /** 本波注入的事件（无则 null） */
  get currentEvent(): EventDef | null {
    return this.eventValue
  }

  /** 本波事件的时序修正（秒，负 = 提前 / 正 = 延后） */
  get currentTimingDelta(): number {
    return this.timingDeltaValue
  }

  /** 当前波次模板 id */
  get currentTemplateId(): string {
    return this.templateId
  }

  /** 区间内进度 u ∈ [0,1]：随累计击杀线性爬升，达锚点阈值封顶 */
  progress(totalKills: number): number {
    const { anchorKillThreshold } = this.deps.config
    const raw = anchorKillThreshold > 0 ? totalKills / anchorKillThreshold : 1
    return Math.min(1, Math.max(0, raw))
  }

  /** 推进排程一帧，返回本帧应执行的命令 */
  step(dt: number, state: WaveState): WaveCommand[] {
    switch (this.phaseValue) {
      case 'prep':
        return this.stepPrep(dt, state)
      case 'combat':
        return this.stepCombat(state)
      case 'anchorPrep':
        return this.stepAnchorPrep(dt)
      case 'anchor':
      case 'done':
        return []
    }
  }

  /** 锚点已结算（限时击杀成败由编排层判定），本局排程结束 */
  resolveAnchor(): void {
    this.phaseValue = 'done'
  }

  private stepPrep(dt: number, state: WaveState): WaveCommand[] {
    this.prep -= dt
    if (this.prep > 0) {
      return []
    }
    const plan = this.deps.director.plan({
      templateId: this.templateId,
      act: this.deps.act,
      progress: this.progress(state.totalKills),
      players: this.deps.config.players,
      rng: this.deps.rng,
    })
    this.phaseValue = 'combat'
    return [
      { kind: 'spawn', plan },
      { kind: 'gold', amount: waveGold(this.deps.act, this.deps.data.economy) },
    ]
  }

  private stepCombat(state: WaveState): WaveCommand[] {
    if (state.enemiesAlive > 0) {
      return []
    }
    if (state.totalKills >= this.deps.config.anchorKillThreshold) {
      this.phaseValue = 'anchorPrep'
      this.prep = this.deps.config.anchorPrepSeconds
      return []
    }
    this.enterPrep()
    return []
  }

  private stepAnchorPrep(dt: number): WaveCommand[] {
    this.prep -= dt
    if (this.prep > 0) {
      return []
    }
    const group = this.deps.director.anchorBoss(
      this.deps.config.anchorBossId,
      this.deps.config.players,
      this.deps.act,
    )
    this.phaseValue = 'anchor'
    return [{ kind: 'anchorSpawn', group, windowSeconds: this.deps.config.anchorWindowSeconds }]
  }

  /** 进入下一波准备：取模板 → roll 事件 → 用时序修正设定倒计时 */
  private enterPrep(): void {
    this.wave += 1
    this.phaseValue = 'prep'
    this.templateId = this.deps.director.pickTemplate(
      this.deps.act,
      this.deps.rng,
      this.templateId === '' ? undefined : this.templateId,
    )
    const roll = this.deps.events.roll(this.templateId, this.deps.act, this.deps.rng)
    this.eventValue = roll.event
    this.timingDeltaValue = roll.timingDelta
    this.prep = Math.max(
      this.deps.config.minPrepSeconds,
      this.deps.config.prepSeconds + roll.timingDelta,
    )
  }
}
