/**
 * 战斗空间几何（纯函数，确定性）。
 *
 * 逻辑层以「格」为单位描述位置，表现层再按像素比例换算 —— 保证逻辑与渲染分辨率解耦
 * （技术架构 §十一）。本模块只做点 / 距离 / 方向 / 扇形判定，不含任何单位状态。
 */

export interface Vec2 {
  x: number
  y: number
}

/** 坐标矩形边界（用于把击退 / 移动钳入战场） */
export interface Bounds {
  min: Vec2
  max: Vec2
}

/**
 * 欧氏距离。
 *
 * 不用 `Math.hypot`：TSTL 无该内建实现（编译报 unsupported）。逻辑层以「格」为单位，
 * 坐标量级小、无溢出风险，故用 `sqrt(x²+y²)` 等价替代——同样保持确定性。
 */
function hypot(x: number, y: number): number {
  return Math.sqrt(x * x + y * y)
}

export function distance(a: Vec2, b: Vec2): number {
  return hypot(a.x - b.x, a.y - b.y)
}

/** 归一化为单位向量；零向量返回零向量（避免 NaN） */
export function normalize(v: Vec2): Vec2 {
  const len = hypot(v.x, v.y)
  if (len === 0) {
    return { x: 0, y: 0 }
  }
  return { x: v.x / len, y: v.y / len }
}

/** 沿 `dir`（不要求已归一化）移动 `dist` 距离后的落点 */
export function offset(from: Vec2, dir: Vec2, dist: number): Vec2 {
  const d = normalize(dir)
  return { x: from.x + d.x * dist, y: from.y + d.y * dist }
}

/**
 * 朝 `target` 移动至多 `maxStep`：未达则精确落点，超过则走满步长。
 * 步长非正或已重合时不动。
 */
export function stepToward(from: Vec2, target: Vec2, maxStep: number): Vec2 {
  if (maxStep <= 0) {
    return { x: from.x, y: from.y }
  }
  const dist = distance(from, target)
  if (dist <= maxStep) {
    return { x: target.x, y: target.y }
  }
  return offset(from, { x: target.x - from.x, y: target.y - from.y }, maxStep)
}

/** 距离是否 ≤ range（含边界） */
export function inRange(a: Vec2, b: Vec2, range: number): boolean {
  return distance(a, b) <= range
}

/** 把点钳入矩形边界 */
export function clampToBounds(p: Vec2, bounds: Bounds): Vec2 {
  return {
    x: Math.min(Math.max(p.x, bounds.min.x), bounds.max.x),
    y: Math.min(Math.max(p.y, bounds.min.y), bounds.max.y),
  }
}

/**
 * 扇形命中判定：目标位于 `origin` 沿 `facing` 方向、张角 `±halfAngleDeg`、半径 `range` 的扇内。
 * 目标与原点重合（距离 0）视为命中。
 */
export function inCone(
  origin: Vec2,
  facing: Vec2,
  target: Vec2,
  range: number,
  halfAngleDeg: number,
): boolean {
  const toTarget = { x: target.x - origin.x, y: target.y - origin.y }
  const dist = hypot(toTarget.x, toTarget.y)
  if (dist > range) {
    return false
  }
  if (dist === 0) {
    return true
  }
  const dir = normalize(facing)
  if (dir.x === 0 && dir.y === 0) {
    return false
  }
  const cos = (toTarget.x * dir.x + toTarget.y * dir.y) / dist
  const clamped = Math.min(1, Math.max(-1, cos))
  return Math.acos(clamped) <= (halfAngleDeg * Math.PI) / 180
}
