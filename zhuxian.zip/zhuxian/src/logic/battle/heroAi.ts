/**
 * Headless 英雄 AI：从 `Battle` 的只读视图逐帧推导一帧 `HeroIntent`（移动 + 施法）。
 *
 * 纯逻辑、无状态、不 import Phaser，也不改动战斗编排 —— 只「读」战场事实并产出玩家输入意图。
 * 供 headless 模拟（缩短版一局护栏）复用；真实玩家的操控由表现层接管（同一 `HeroIntent` 接口）。
 *
 * 决策口径（M1 简化，够用即可）：
 *  - 移动：有敌人则逼近至普攻射程内并停步；无敌人则回防英雄出生点。
 *  - 施法优先级：气血告急先自保（E）→ 群体技（R）→ 扇形技（W）→ 单体技（Q）。
 *    仅当技能就绪且最近敌人在其作用范围内时释放；地面技（aoeGround）瞄准最近敌人。
 *  - 扇形技依赖朝向，故用 `inCone` 校验当前朝向确实能罩住目标，避免背身空放。
 */

import type { GameDataIndex } from '../../data/indexes'
import type { SkillKey } from '../../data/types/common'
import type { HeroDef } from '../../data/types/units'
import { SkillEngine, type ResolvedSkill } from '../skills/skillEngine'
import type { Battle, HeroIntent } from './battle'
import { CONE_HALF_ANGLE_DEG, nearestUnit } from './combat'
import { distance, inCone, inRange, normalize, type Vec2 } from './spatial'
import type { Unit } from './unit'

/** 默认自保阈值：气血比例 ≤ 50% 时优先施放护体技 */
export const DEFAULT_GUARD_HP_RATIO = 0.5

export interface HeroAiOptions {
  /** 气血比例低于此值且护体技就绪时优先自保（默认 `DEFAULT_GUARD_HP_RATIO`） */
  guardHpRatio?: number
}

/** 输出技优先级：群体 → 扇形 → 单体 */
const OFFENSIVE_ORDER: readonly SkillKey[] = ['R', 'W', 'Q']

/** 本帧英雄意图：`battle` 只读视图 + `index` 技能定义 → `HeroIntent` */
export function decideHeroIntent(
  battle: Battle,
  index: GameDataIndex,
  options: HeroAiOptions = {},
): HeroIntent {
  const hero = battle.hero
  const heroDef = index.hero.get(battle.config.heroId)
  if (!hero.alive || !heroDef) {
    return {}
  }

  const engine = new SkillEngine(index)
  const target = nearestUnit(hero.position, battle.units)
  const guardHpRatio = options.guardHpRatio ?? DEFAULT_GUARD_HP_RATIO

  const intent: HeroIntent = {}
  const choice = chooseSkill(engine, heroDef, hero, target, guardHpRatio)
  if (choice) {
    intent.cast = choice.key
    if (choice.aim) {
      intent.aim = choice.aim
    }
  }

  const move = chooseMove(hero.position, target, battle.config.field.heroSpawn, hero.attackRange)
  if (move) {
    intent.moveDir = move
  }

  return intent
}

interface SkillChoice {
  key: SkillKey
  /** 地面范围技（aoeGround）的落点 */
  aim?: Vec2
}

function chooseSkill(
  engine: SkillEngine,
  heroDef: HeroDef,
  hero: Unit,
  target: Unit | null,
  guardHpRatio: number,
): SkillChoice | null {
  if (hero.maxHp > 0 && hero.hp / hero.maxHp <= guardHpRatio) {
    if (readySkill(engine, heroDef, hero, 'E')) {
      return { key: 'E' }
    }
  }

  if (!target) {
    return null
  }
  for (const key of OFFENSIVE_ORDER) {
    const resolved = readySkill(engine, heroDef, hero, key)
    if (resolved && inReach(hero, resolved, target)) {
      return resolved.shape === 'aoeGround'
        ? { key, aim: { x: target.position.x, y: target.position.y } }
        : { key }
    }
  }
  return null
}

/** 技能就绪（境界 / 冷却 / 真气均通过）时返回其解析参数，否则 null */
function readySkill(
  engine: SkillEngine,
  heroDef: HeroDef,
  hero: Unit,
  key: SkillKey,
): ResolvedSkill | null {
  const skillId = heroDef.skills[key]
  return engine.canCast(skillId, hero.skillState, hero.rank) === null
    ? engine.resolve(skillId, hero.rank)
    : null
}

/**
 * 最近敌人是否落在技能作用范围内（按形态判定）。
 *
 * `self` 形态在此引擎里不选任何伤害目标（`selectTargets` 返回空），属纯自身增益，
 * 由 `chooseSkill` 的自保分支单独处理，故此处恒不「命中」。
 * `aoeGround` 无射程约束，瞄准最近敌人即可。
 */
function inReach(caster: Unit, resolved: ResolvedSkill, target: Unit): boolean {
  switch (resolved.shape) {
    case 'self':
      return false
    case 'single':
      return inRange(caster.position, target.position, resolved.range ?? caster.attackRange)
    case 'cone':
      return inCone(
        caster.position,
        caster.facing,
        target.position,
        resolved.radius ?? resolved.range ?? caster.attackRange,
        CONE_HALF_ANGLE_DEG,
      )
    case 'aoeSelf':
      return inRange(caster.position, target.position, resolved.radius ?? caster.attackRange)
    case 'aoeGround':
      return true
  }
}

/** 有敌人则逼近至普攻射程内；无敌人则回防出生点；已在位则不动（返回 null） */
function chooseMove(from: Vec2, target: Unit | null, guard: Vec2, stopRange: number): Vec2 | null {
  const to = target ? target.position : guard
  const stop = target ? stopRange : 0
  if (distance(from, to) <= stop) {
    return null
  }
  return normalize({ x: to.x - from.x, y: to.y - from.y })
}
