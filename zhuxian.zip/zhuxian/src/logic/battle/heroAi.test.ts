import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { loadGameData } from '../../data/load'
import type { GameData } from '../../data/types/gameData'
import type { SkillDef } from '../../data/types/units'
import { EventDirector } from '../events/eventDirector'
import { Battle } from './battle'
import { DEFAULT_BATTLE_CONFIG, type BattleConfig } from './config'
import { decideHeroIntent } from './heroAi'
import type { Unit } from './unit'

const { data, index } = loadGameData()

/** 关闭随机事件：让准备时长与波次内容完全确定 */
const noEvents = new EventDirector(index, {
  injectionChance: { act1: 0, act2: 0, act3: 0 },
  pityWaves: 3,
  pityStep: 0.5,
  pityMaxMul: 2,
})

/** 配置补丁：`field` / `wave` 支持深层覆盖 */
type BattleConfigPatch = Omit<Partial<BattleConfig>, 'field' | 'wave'> & {
  field?: Partial<BattleConfig['field']>
  wave?: Partial<BattleConfig['wave']>
}

function make(over: BattleConfigPatch = {}, gameData: GameData = data, gameIndex = index): Battle {
  const config: BattleConfig = {
    ...DEFAULT_BATTLE_CONFIG,
    ...over,
    field: { ...DEFAULT_BATTLE_CONFIG.field, ...over.field },
    wave: { ...DEFAULT_BATTLE_CONFIG.wave, ...over.wave },
  }
  return new Battle({ data: gameData, index: gameIndex, config, events: noEvents })
}

/** 推进若干秒（把排程推到刷怪阶段） */
function advance(battle: Battle, seconds: number): void {
  const dt = battle.config.dt
  const steps = Math.round(seconds / dt)
  for (let i = 0; i < steps && battle.status === 'running'; i += 1) {
    battle.step(dt)
  }
}

/** 造一个已刷出怪物的战场 */
function spawned(over: BattleConfigPatch = {}): Battle {
  const battle = make({ ...over, wave: { prepSeconds: 1, minPrepSeconds: 0, ...over.wave } })
  advance(battle, 1.5)
  if (battle.units.length === 0) {
    throw new Error('测试前置：波次未刷出怪物')
  }
  return battle
}

/**
 * 只保留首个怪物作为唯一可索敌目标：把其余怪物挪到地图角落，避免落位随机导致
 * 「最近敌人」不唯一，使位置类断言稳定。
 */
function isolate(battle: Battle): Unit {
  const [target, ...rest] = battle.units
  if (!target) {
    throw new Error('测试前置：战场无怪物')
  }
  const corner = battle.config.field.bounds.max
  for (const unit of rest) {
    unit.position = { x: corner.x, y: corner.y }
  }
  return target
}

describe('HeroAi · 移动决策', () => {
  it('无敌人时回防英雄出生点，不放技能', () => {
    const battle = make() // 默认 60s 准备，不刷怪
    battle.hero.position = { x: 15, y: 6 }
    const intent = decideHeroIntent(battle, index)
    expect(intent.moveDir?.x).toBeLessThan(0) // heroSpawn.x = 9 < 15
    expect(intent.cast).toBeUndefined()
  })

  it('敌人超出普攻范围时朝敌人逼近', () => {
    const battle = spawned()
    const intent = decideHeroIntent(battle, index)
    expect(intent.moveDir?.x).toBeGreaterThan(0) // 怪物自 +x 出生
  })

  it('敌人进入普攻范围后原地不动', () => {
    const battle = spawned()
    const target = isolate(battle)
    battle.hero.position = { x: target.position.x - 0.5, y: target.position.y }
    const intent = decideHeroIntent(battle, index)
    expect(intent.moveDir).toBeUndefined()
  })
})

describe('HeroAi · 技能释放', () => {
  /** 把英雄贴到目标身侧（左侧 1 格），朝向由用例自行设定 */
  function beside(battle: Battle, target: Unit): void {
    battle.hero.position = { x: target.position.x - 1, y: target.position.y }
  }

  it('就绪且敌在射程内时释放 Q（禁用更高优先级的 W 以隔离）', () => {
    const battle = spawned()
    const target = isolate(battle)
    beside(battle, target)
    battle.hero.skillState.setCooldown('zxf_w', 10)
    expect(decideHeroIntent(battle, index).cast).toBe('Q')
  })

  it('扇形技仅当目标落在当前朝向的扇内才释放', () => {
    const battle = spawned()
    const target = isolate(battle)
    beside(battle, target)
    battle.hero.skillState.setCooldown('zxf_q', 5) // 隔离 W：Q 冷却中

    battle.hero.facing = { x: -1, y: 0 } // 背对目标（目标在 +x）
    expect(decideHeroIntent(battle, index).cast).toBeUndefined()

    battle.hero.facing = { x: 1, y: 0 } // 面向目标
    expect(decideHeroIntent(battle, index).cast).toBe('W')
  })

  it('技能冷却 / 真气不足时不释放', () => {
    const battle = spawned()
    const target = isolate(battle)
    beside(battle, target)
    battle.hero.facing = { x: -1, y: 0 } // 排除 W（扇外）

    battle.hero.skillState.setCooldown('zxf_q', 5)
    expect(decideHeroIntent(battle, index).cast).toBeUndefined()

    const lowMp = spawned()
    const lowTarget = isolate(lowMp)
    beside(lowMp, lowTarget)
    lowMp.hero.facing = { x: -1, y: 0 }
    lowMp.hero.skillState.mp = 0
    expect(decideHeroIntent(lowMp, index).cast).toBeUndefined()
  })

  it('气血告急时优先自保（E 优先于输出技）', () => {
    const battle = spawned()
    const target = isolate(battle)
    beside(battle, target)
    battle.hero.facing = { x: 1, y: 0 }
    battle.hero.hp = battle.hero.maxHp * 0.3
    expect(decideHeroIntent(battle, index).cast).toBe('E')
  })

  it('R 需上清解锁，突破后方可释放', () => {
    const battle = spawned()
    const target = isolate(battle)
    battle.hero.position = { ...target.position } // 贴身，落在 R 作用半径内
    expect(decideHeroIntent(battle, index).cast).not.toBe('R') // 玉清：境界不足

    battle.hero.rank = 'shangqing'
    expect(decideHeroIntent(battle, index).cast).toBe('R')
  })

  it('地面范围技（aoeGround）瞄准最近敌人', () => {
    const aoeSkill: SkillDef = {
      id: 'test_aoe',
      owner: 'zhangxiaofan',
      key: 'Q',
      name: '测试·地面范围技',
      damageType: 'physical',
      rate: 1,
      cooldown: 0,
      mpCost: 0,
      shape: 'aoeGround',
      radius: 2,
      effects: [],
    }
    const patchedData: GameData = {
      ...data,
      skills: [...data.skills.filter((s) => s.id !== 'zxf_q'), aoeSkill],
      heroes: data.heroes.map((h) =>
        h.id === 'zhangxiaofan' ? { ...h, skills: { ...h.skills, Q: 'test_aoe' } } : h,
      ),
    }
    const patchedIndex = buildIndex(patchedData)
    const battle = make({ wave: { prepSeconds: 1, minPrepSeconds: 0 } }, patchedData, patchedIndex)
    advance(battle, 1.5)
    const target = isolate(battle)

    const intent = decideHeroIntent(battle, patchedIndex)
    expect(intent.cast).toBe('Q')
    expect(intent.aim).toEqual({ x: target.position.x, y: target.position.y })
  })
})

describe('HeroAi · 边界', () => {
  it('英雄阵亡时不产生意图', () => {
    const battle = make()
    battle.hero.alive = false
    expect(decideHeroIntent(battle, index)).toEqual({})
  })
})
