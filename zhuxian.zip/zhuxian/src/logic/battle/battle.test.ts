import { describe, expect, it } from 'vitest'

import { recipeKey } from '../../data/indexes'
import { loadGameData } from '../../data/load'
import type { RecipeDef } from '../../data/types/equipment'
import type { GameData } from '../../data/types/gameData'
import { EventDirector } from '../events/eventDirector'
import { Battle, type BattleEvent, type HeroIntent } from './battle'
import { DEFAULT_BATTLE_CONFIG, type BattleConfig } from './config'

const { data, index } = loadGameData()

/**
 * 等级锁定数据：把升级需求抬到不可达，隔离「突破倍率」类断言对等级成长的依赖。
 * 仅用于需要精确断言面板数值（如境界倍率）的用例。
 */
const levelLockedData: GameData = {
  ...data,
  economy: { ...data.economy, levelNeed: { base: 1e9, growth: 1.2 } },
}

/** 测试用临时爆发修饰来源：让英雄足以秒杀锚点 BOSS，避免单测依赖真实数值平衡 */
const TEST_BURST_SOURCE = 'test:burst'

/** 升档配方（法宝线 T1→T2，数值文档 §8.2） */
function weaponRecipe(): RecipeDef {
  const recipe = index.recipe.get(recipeKey('weapon', 1))
  if (!recipe) {
    throw new Error('缺少法宝线 T1→T2 配方')
  }
  return recipe
}

/** 关闭随机事件：让准备时长与波次内容完全确定（便于断言） */
const noEvents = new EventDirector(index, {
  injectionChance: { act1: 0, act2: 0, act3: 0 },
  pityWaves: 3,
  pityStep: 0.5,
  pityMaxMul: 2,
})

/** 配置补丁：`field` / `wave` 支持深层覆盖（浅 `Partial` 无法只改嵌套里的个别字段） */
type BattleConfigPatch = Omit<Partial<BattleConfig>, 'field' | 'wave'> & {
  field?: Partial<BattleConfig['field']>
  wave?: Partial<BattleConfig['wave']>
}

function make(over: BattleConfigPatch = {}, gameData: GameData = data): Battle {
  const config: BattleConfig = {
    ...DEFAULT_BATTLE_CONFIG,
    ...over,
    field: { ...DEFAULT_BATTLE_CONFIG.field, ...over.field },
    wave: { ...DEFAULT_BATTLE_CONFIG.wave, ...over.wave },
  }
  return new Battle({ data: gameData, index, config, events: noEvents })
}

/** 以固定步长推进 `seconds` 秒；一局结束后（非 running）提前停止，模拟 headless 运行 */
function advance(battle: Battle, seconds: number, intent: HeroIntent = {}): void {
  const dt = battle.config.dt
  const steps = Math.round(seconds / dt)
  for (let i = 0; i < steps && battle.status === 'running'; i += 1) {
    battle.step(dt, intent)
  }
}

describe('Battle · 构造初值', () => {
  it('英雄开局属性 / 资源 / 排程初态', () => {
    const b = make()
    expect(b.status).toBe('running')
    expect(b.hero.defId).toBe('zhangxiaofan')
    expect(b.hero.level).toBe(1)
    expect(b.hero.rank).toBe('yuqing')
    expect(b.hero.maxHp).toBe(800)
    expect(b.hero.stats.atk).toBe(45)
    expect(b.hero.position).toEqual(b.config.field.heroSpawn)
    expect(b.core.hp).toBe(b.core.maxHp)
    expect(b.kills).toBe(0)
    expect(b.units).toHaveLength(0)
    expect(b.gold).toBe(0)
    expect(b.items).toEqual(['weapon_t1'])
    expect(b.scheduler.phase).toBe('prep')
    expect(b.scheduler.waveNumber).toBe(1)
    expect(b.canBreakthrough()).toBe(false)
  })
})

describe('Battle · 波次循环与刷怪', () => {
  it('准备倒计时结束刷出怪物、发放波次金币', () => {
    const b = make({ wave: { prepSeconds: 2, minPrepSeconds: 0 } })
    advance(b, 1)
    expect(b.units).toHaveLength(0)
    expect(b.scheduler.phase).toBe('prep')

    // 事件缓冲每帧开头清空，故逐帧步进到刷怪那一帧并当帧捕获事件
    const dt = b.config.dt
    let events: readonly BattleEvent[] = []
    for (let i = 0; i < 200 && b.scheduler.phase === 'prep'; i += 1) {
      events = b.step(dt)
    }
    expect(b.scheduler.phase).toBe('combat')
    expect(b.units.length).toBeGreaterThan(0)
    expect(b.gold).toBe(30)
    expect(events.some((e) => e.kind === 'spawn')).toBe(true)
  })

  it('怪物朝剑阵核心推进', () => {
    const b = make({ wave: { prepSeconds: 1, minPrepSeconds: 0 } })
    advance(b, 1.1)
    const monster = b.units[0]
    expect(monster).toBeDefined()
    const startX = monster?.position.x ?? 0
    advance(b, 1)
    expect(monster?.position.x).toBeLessThan(startX)
  })

  it('清场后进入下一波准备', () => {
    const b = make({ wave: { prepSeconds: 1, minPrepSeconds: 0 } })
    advance(b, 20)
    expect(b.scheduler.waveNumber).toBeGreaterThan(1)
  })
})

describe('Battle · 英雄战斗与成长', () => {
  it('自动普攻击杀小怪，累计击杀并获得掉落金币与经验', () => {
    const b = make({ wave: { prepSeconds: 1, minPrepSeconds: 0 } })
    advance(b, 60)
    expect(b.kills).toBeGreaterThan(0)
    expect(b.gold).toBeGreaterThan(30)
    expect(b.hero.level).toBeGreaterThan(1)
  })

  it('释放 Q 扣除真气并挂上吸血修饰，并产出 cast 事件（表现层技能可视化依据）', () => {
    const b = make()
    const events = b.step(b.config.dt, { cast: 'Q' })
    expect(b.hero.modifiers.lifestealPercent()).toBeCloseTo(0.15, 6)
    expect(b.hero.skillState.mp).toBe(180)
    expect(events).toContainEqual({ kind: 'cast', casterId: 'hero', skillId: 'zxf_q' })
  })

  it('英雄阵亡后按复活秒数复活并回满气血', () => {
    // 复活期取较长值：让残余怪物在复活前已抵达核心（脱离复活点索敌范围），隔离「回满气血」断言
    const b = make({ heroReviveSeconds: 5, wave: { prepSeconds: 1, minPrepSeconds: 0 } })
    advance(b, 1.1)
    b.hero.hp = 1
    let died = false
    for (let i = 0; i < 3000 && !died; i += 1) {
      b.step(b.config.dt)
      died = !b.heroLife.isAlive
    }
    expect(died).toBe(true)
    expect(b.hero.alive).toBe(false)

    advance(b, 5.5)
    expect(b.heroLife.isAlive).toBe(true)
    expect(b.hero.alive).toBe(true)
    expect(b.hero.hp).toBe(b.hero.maxHp)
    expect(b.heroLife.revives).toBe(1)
  })
})

describe('Battle · 守护核心与失败条件', () => {
  it('怪物攻击核心造成耐久损失', () => {
    // 英雄移出战道（偏离怪物行进路径），使怪物能直抵核心而非被途中击杀
    const b = make({
      field: { ...DEFAULT_BATTLE_CONFIG.field, heroSpawn: { x: 9, y: 11.5 } },
      wave: { prepSeconds: 1, minPrepSeconds: 0 },
    })
    advance(b, 16)
    expect(b.core.hp).toBeLessThan(b.core.maxHp)
    expect(b.status).toBe('running')
  })

  it('核心耐久归零即判负', () => {
    const b = make({
      coreMaxHp: 20,
      field: { ...DEFAULT_BATTLE_CONFIG.field, heroSpawn: { x: 9, y: 11.5 } },
      wave: { prepSeconds: 1, minPrepSeconds: 0 },
    })
    advance(b, 40)
    expect(b.status).toBe('defeat')
    expect(b.core.destroyed).toBe(true)
  })
})

describe('Battle · 锚点一与突破', () => {
  /**
   * 让英雄足以一击秒杀锚点 BOSS（击杀同时扣减限时战血量）。
   *
   * 用**修饰**而非改 `baseStats`：升级会经 `refreshHeroGrowth` 重算基线，改基线会被覆盖；
   * 修饰则不受升级影响。普攻距离取 2 格（> BOSS 攻击距离 1.6），使英雄能在 BOSS 停步前反击。
   */
  function anchorReady(lockLevel = false): Battle {
    const b = make(
      {
        heroAttackRange: 2,
        wave: { prepSeconds: 1, minPrepSeconds: 0, anchorKillThreshold: 3, anchorPrepSeconds: 0.5 },
      },
      lockLevel ? levelLockedData : data,
    )
    b.hero.modifiers.add(
      { kind: 'statMod', stat: 'atk', mode: 'flat', value: 100000 },
      TEST_BURST_SOURCE,
      { maxHp: b.hero.maxHp },
    )
    return b
  }

  it('累计击杀达标后生成锚点 BOSS，限时击杀即通关', () => {
    const b = anchorReady()
    advance(b, 60)
    expect(b.status).toBe('anchorCleared')
    expect(b.challenge.status).toBe('cleared')
    expect(b.canBreakthrough()).toBe(true)
  })

  it('锚点限时窗耗尽 → 核心重创且锚点失守', () => {
    const b = make({
      coreMaxHp: 10000,
      wave: {
        prepSeconds: 1,
        minPrepSeconds: 0,
        anchorKillThreshold: 3,
        anchorPrepSeconds: 0.5,
        anchorWindowSeconds: 1,
      },
    })
    advance(b, 40)
    expect(b.status).toBe('anchorFailed')
    // 剧情级重创：扣除核心上限的 50%
    expect(b.core.hp).toBe(5000)
    expect(b.units.some((u) => u.kind === 'boss')).toBe(false)
  })

  it('通关后可突破上清，气血 / 攻击按境界倍率提升', () => {
    // 锁定等级（保持 1 级 L=1），使面板数值只反映境界 R 倍率
    const b = anchorReady(true)
    advance(b, 60)
    // 移除测试爆发修饰，恢复英雄真实攻击面板再做倍率断言
    b.hero.modifiers.removeBySource(TEST_BURST_SOURCE)
    expect(b.hero.level).toBe(1)
    expect(b.breakthrough()).toBe(true)
    expect(b.hero.rank).toBe('shangqing')
    // 1 级 L 倍率 = 1，上清 R 倍率 = 1.25
    expect(b.hero.maxHp).toBe(1000)
    expect(b.hero.stats.atk).toBe(Math.floor(45 * 1.25))
    // 渡劫机会已在本次突破中消费：M1 单锚点对应单次大突破，不可再突破
    expect(b.canBreakthrough()).toBe(false)
    expect(b.breakthrough()).toBe(false)
  })
})

describe('Battle · 合成与装备', () => {
  it('材料与金币充足时合成升档并装备，攻击随装备提升', () => {
    const b = make()
    const recipe = weaponRecipe()
    const atkBefore = b.hero.stats.atk

    expect(b.canCraft(recipe)).toBe(false)
    b.gold = recipe.gold
    b.materials.set(recipe.materialId, recipe.materialCount)
    expect(b.canCraft(recipe)).toBe(true)

    expect(b.craftAndEquip(recipe)).toBe(true)
    expect(b.gold).toBe(0)
    expect(b.materials.get(recipe.materialId)).toBe(0)
    // 来源 T1 装备被消耗，产物 T2 入包
    expect(b.items).toEqual(['weapon_t2'])
    // T2 法宝承担 +16.3% 攻击（下品品质系数 ×1.0 起）
    expect(b.hero.stats.atk).toBeGreaterThan(atkBefore)
    expect(b.hero.stats.atk).toBeGreaterThanOrEqual(45 * 1.163)
  })
})
