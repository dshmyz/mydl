import { describe, expect, it } from 'vitest'
import type { Stats, Tier } from '../../data/types/common'
import type { LimitsDef, TierArmorKDef } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'
import { SkillEngine } from '../skills/skillEngine'
import { loadGameData } from '../../data/load'
import { Unit } from './unit'
import { applySkill, resolveAttack, selectTargets, type CombatContext } from './combat'

const { index } = loadGameData()
const skillEngine = new SkillEngine(index)

const armorK = new Map<Tier, TierArmorKDef>([
  [1, { tier: 1, standardDef: 12, k: 28 }],
])
const limits: LimitsDef = {
  defRedMax: 0.75,
  dodgeMax: 0.25,
  critMax: 0.6,
  critDmgMax: 2.5,
  dmgMultMin: 0.5,
  dmgMultMax: 2.5,
  maxOnScreenMinions: 40,
  materialStorageCap: 20,
  maxT6PerRun: 2,
}
const bounds = { min: { x: -100, y: -100 }, max: { x: 100, y: 100 } }

/** 固定随机数的桩 RNG：0.99 恒定 → 不闪避、不暴击 */
function stubRng(nextValue: number): RngLike {
  return {
    next: () => nextValue,
    int: (min) => min,
    range: (min) => min,
    chance: (p) => nextValue < p,
    pick: (items) => items[0] as never,
    weighted: (entries) => entries[0]?.[0] as never,
    fork: () => stubRng(nextValue),
  }
}

function ctx(over: Partial<CombatContext> = {}): CombatContext {
  return { armorK, limits, rng: stubRng(0.99), bounds, ...over }
}

const flat: Stats = {
  hp: 1000,
  mp: 0,
  atk: 100,
  sp: 100,
  def: 0,
  spd: 0,
  dodge: 0,
  crit: 0,
  critDmg: 1.5,
}

function unit(over: Partial<ConstructorParameters<typeof Unit>[0]> = {}): Unit {
  return new Unit({
    id: 'u',
    kind: 'minion',
    defId: 'wolf',
    name: '狼妖',
    baseStats: flat,
    position: { x: 0, y: 0 },
    tier: 1,
    attackSpeed: 1,
    attackRange: 1,
    damageType: 'physical',
    maxMp: 0,
    ...over,
  })
}

describe('combat · resolveAttack 伤害落地', () => {
  it('无防御无暴击时伤害 = ATK × RATE', () => {
    const attacker = unit({ id: 'a' })
    const defender = unit({ id: 'd' })
    const out = resolveAttack(attacker, defender, ctx())
    expect(out.breakdown.damage).toBe(100)
    expect(out.dealt).toBe(100)
    expect(defender.hp).toBe(900)
  })

  it('护盾先吸收，溢出部分才扣气血', () => {
    const attacker = unit({ id: 'a' })
    const defender = unit({ id: 'd' })
    defender.modifiers.add({ kind: 'shield', percentOfMaxHp: 0.03, duration: 5 }, 's', {
      maxHp: defender.maxHp,
    })
    const out = resolveAttack(attacker, defender, ctx())
    expect(out.absorbed).toBe(30)
    expect(out.dealt).toBe(70)
    expect(defender.hp).toBe(930)
  })

  it('吸血按实际扣气血量回复攻击者', () => {
    const attacker = unit({ id: 'a' })
    attacker.hp = 500
    attacker.modifiers.add({ kind: 'lifesteal', percent: 0.15 })
    const out = resolveAttack(attacker, unit({ id: 'd' }), ctx())
    expect(out.lifesteal).toBe(15)
    expect(attacker.hp).toBe(515)
  })

  it('伤害致死时置零并标记存活状态', () => {
    const attacker = unit({ id: 'a' })
    const defender = unit({ id: 'd' })
    defender.hp = 40
    const out = resolveAttack(attacker, defender, ctx())
    expect(out.killed).toBe(true)
    expect(defender.hp).toBe(0)
    expect(defender.alive).toBe(false)
  })

  it('减伤乘区联动：受伤乘数 0.5 时伤害减半', () => {
    const attacker = unit({ id: 'a' })
    const defender = unit({ id: 'd' })
    defender.modifiers.add({ kind: 'damageTakenMul', value: 0.5, duration: 5 })
    const out = resolveAttack(attacker, defender, ctx())
    expect(out.breakdown.dmgMult).toBeCloseTo(0.5, 10)
    expect(out.breakdown.damage).toBe(50)
  })
})

describe('combat · selectTargets 目标选取', () => {
  const caster = unit({ id: 'c', position: { x: 0, y: 0 }, attackRange: 3 })
  const near = unit({ id: 'near', position: { x: 1, y: 0 } })
  const side = unit({ id: 'side', position: { x: 0, y: 2 } })
  const back = unit({ id: 'back', position: { x: -2, y: 0 } })
  const enemies = [near, side, back]

  it('single 取射程内最近者', () => {
    const r = skillEngine.resolve('zxf_q', 'yuqing')
    const targets = selectTargets(caster, r, enemies)
    expect(targets.map((t) => t.id)).toEqual(['near'])
  })

  it('cone 仅命中前方张角内目标', () => {
    const r = skillEngine.resolve('zxf_w', 'yuqing')
    const targets = selectTargets(caster, r, enemies)
    expect(targets.map((t) => t.id)).toEqual(['near'])
  })

  it('aoeSelf 命中半径内全部敌人', () => {
    const r = skillEngine.resolve('zxf_r', 'shangqing')
    const targets = selectTargets(caster, r, enemies)
    expect(targets.map((t) => t.id).sort()).toEqual(['back', 'near', 'side'])
  })

  it('self 形态不产生伤害目标', () => {
    const r = skillEngine.resolve('zxf_e', 'yuqing')
    expect(selectTargets(caster, r, enemies)).toEqual([])
  })

  it('aoeGround 需给出落点才选取目标', () => {
    const r = skillEngine.resolve('zxf_r', 'shangqing')
    const ground = { ...r, shape: 'aoeGround' as const, radius: 1.5 }
    expect(selectTargets(caster, ground, enemies).map((t) => t.id)).toEqual([])
    expect(selectTargets(caster, ground, enemies, { x: 0, y: 2 }).map((t) => t.id)).toEqual(['side'])
  })

  it('忽略已阵亡单位', () => {
    const dead = unit({ id: 'dead', position: { x: 1, y: 0 }, attackRange: 3 })
    dead.alive = false
    const r = skillEngine.resolve('zxf_q', 'yuqing')
    const targets = selectTargets(caster, r, [dead, near])
    expect(targets.map((t) => t.id)).toEqual(['near'])
  })
})

describe('combat · applySkill 技能效果落地', () => {
  it('zxf_r：AoE 命中 + 施法者叠「魔气」，重复施法叠层', () => {
    const caster = unit({ id: 'c', position: { x: 0, y: 0 } })
    const m1 = unit({ id: 'm1', position: { x: 1, y: 0 } })
    const m2 = unit({ id: 'm2', position: { x: 2, y: 0 } })
    const r = skillEngine.resolve('zxf_r', 'shangqing')
    const out = applySkill(caster, r, ctx(), [m1, m2], { spawn: () => unit() })
    expect(out.hits.length).toBe(2)
    expect(caster.modifiers.stacksOf('moqi')).toBe(1)
    applySkill(caster, r, ctx(), [m1, m2], { spawn: () => unit() })
    expect(caster.modifiers.stacksOf('moqi')).toBe(2)
  })

  it('zxf_e：护盾与减伤挂到自身', () => {
    const caster = unit({ id: 'c', baseStats: { ...flat, hp: 800 } })
    const r = skillEngine.resolve('zxf_e', 'yuqing')
    applySkill(caster, r, ctx(), [], { spawn: () => unit() })
    expect(caster.modifiers.shieldTotal()).toBeCloseTo(160, 6)
    expect(caster.modifiers.damageMultiplier()).toBeCloseTo(0.92, 10)
  })

  it('zxf_w：前方扇形命中并击退', () => {
    const caster = unit({ id: 'c', position: { x: 0, y: 0 } })
    const target = unit({ id: 't', position: { x: 2, y: 0 } })
    const r = skillEngine.resolve('zxf_w', 'yuqing')
    applySkill(caster, r, ctx(), [target], { spawn: () => unit() })
    expect(target.position.x).toBeCloseTo(4, 6)
  })

  it('hx_coil：范围定身作为减益挂到目标', () => {
    const boss = unit({ id: 'boss', position: { x: 0, y: 0 } })
    const hero = unit({ id: 'hero', position: { x: 1, y: 0 } })
    const r = skillEngine.resolve('hx_coil', 'yuqing')
    applySkill(boss, r, ctx(), [hero], { spawn: () => unit() })
    expect(hero.modifiers.isRooted()).toBe(true)
  })

  it('hx_rage：自增益 + 召唤', () => {
    const boss = unit({ id: 'boss', position: { x: 0, y: 0 }, baseStats: { ...flat, spd: 200 } })
    const spawned: string[] = []
    const r = skillEngine.resolve('hx_rage', 'yuqing')
    const out = applySkill(boss, r, ctx(), [], {
      spawn: (monsterId) => {
        spawned.push(monsterId)
        return unit({ id: `s${spawned.length}` })
      },
    })
    expect(boss.modifiers.damageMultiplier()).toBeCloseTo(1, 10)
    expect(boss.stats.spd).toBeGreaterThan(0)
    expect(out.summons.length).toBe(2)
    expect(spawned).toEqual(['small_snake', 'small_snake'])
  })
})

describe('combat · 使用真实配置的锚点 BOSS 招式', () => {
  it('hx_breath 对目标施加减速减益', () => {
    const boss = unit({ id: 'boss', position: { x: 0, y: 0 } })
    const hero = unit({ id: 'hero', position: { x: 1, y: 0 }, baseStats: { ...flat, spd: 100 } })
    const r = skillEngine.resolve('hx_breath', 'yuqing')
    applySkill(boss, r, ctx(), [hero], { spawn: () => unit() })
    expect(hero.stats.spd).toBeLessThan(hero.baseStats.spd)
  })
})
