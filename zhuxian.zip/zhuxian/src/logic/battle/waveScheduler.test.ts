import { describe, expect, it } from 'vitest'
import { loadGameData } from '../../data/load'
import type { RngLike } from '../core/rng'
import { EventDirector, type EventSystemConfig } from '../events/eventDirector'
import { WaveDirector } from '../waves/waveDirector'
import { WaveScheduler, type WaveSchedulerConfig } from './waveScheduler'

const { data, index } = loadGameData()

/** 恒定 next()=0 的桩 RNG：模板取首个、事件必中且提前、精英位取 0 */
function zeroRng(): RngLike {
  return {
    next: () => 0,
    int: (min) => min,
    range: (min) => min,
    chance: (p) => 0 < p,
    pick: (items) => items[0] as never,
    weighted: (entries) => entries[0]?.[0] as never,
    fork: () => zeroRng(),
  }
}

/** 事件必中（注入概率 100%），便于确定性断言事件修正 */
const alwaysInject: EventSystemConfig = {
  injectionChance: { act1: 1, act2: 1, act3: 1 },
  pityWaves: 3,
  pityStep: 0.5,
  pityMaxMul: 2,
}

const config: WaveSchedulerConfig = {
  players: 1,
  prepSeconds: 60,
  minPrepSeconds: 15,
  anchorPrepSeconds: 90,
  anchorWindowSeconds: 90,
  anchorKillThreshold: 70,
  anchorBossId: 'heishui_xuanshe',
}

function make(configOver: Partial<WaveSchedulerConfig> = {}, eventConfig = alwaysInject) {
  return new WaveScheduler({
    data,
    director: new WaveDirector(data, index),
    events: new EventDirector(index, eventConfig),
    rng: zeroRng(),
    config: { ...config, ...configOver },
    act: 'act1',
  })
}

describe('WaveScheduler · 准备阶段', () => {
  it('开局处于第 1 波准备，事件提前使倒计时应声缩短', () => {
    const s = make()
    expect(s.phase).toBe('prep')
    expect(s.waveNumber).toBe(1)
    // 60 - 事件提前 30 = 30
    expect(s.prepRemaining).toBeCloseTo(30, 6)
    expect(s.currentEvent?.id).toBe('beast_timing')
    expect(s.currentTimingDelta).toBe(-30)
  })

  it('倒计时未结束不产出刷新命令', () => {
    const s = make()
    expect(s.step(10, { enemiesAlive: 0, totalKills: 0 })).toEqual([])
    expect(s.phase).toBe('prep')
  })

  it('倒计时结束产出刷怪与金币命令', () => {
    const s = make()
    s.step(10, { enemiesAlive: 0, totalKills: 0 })
    const cmds = s.step(20, { enemiesAlive: 0, totalKills: 0 })
    expect(s.phase).toBe('combat')
    const spawn = cmds.find((c) => c.kind === 'spawn')
    const gold = cmds.find((c) => c.kind === 'gold')
    expect(spawn).toBeDefined()
    expect(gold).toBeDefined()
    if (spawn?.kind === 'spawn') {
      expect(spawn.plan.templateId).toBe('E1')
      expect(spawn.plan.groups[0]?.monsterId).toBe('wolf')
      expect(spawn.plan.groups[0]?.count).toBe(8)
    }
    if (gold?.kind === 'gold') {
      expect(gold.amount).toBe(30)
    }
  })

  it('倒计时不会超下限（事件提前量受 minPrepSeconds 约束）', () => {
    const s = make({ prepSeconds: 20, minPrepSeconds: 15 })
    // 20 - 30 → 钳到 15
    expect(s.prepRemaining).toBeCloseTo(15, 6)
  })
})

describe('WaveScheduler · 波次推进', () => {
  it('战斗中敌人清空 → 进入下一波准备', () => {
    const s = make()
    s.step(30, { enemiesAlive: 0, totalKills: 0 }) // 进入 combat
    expect(s.phase).toBe('combat')
    s.step(1, { enemiesAlive: 3, totalKills: 8 }) // 仍有敌人
    expect(s.phase).toBe('combat')
    s.step(1, { enemiesAlive: 0, totalKills: 8 })
    expect(s.phase).toBe('prep')
    expect(s.waveNumber).toBe(2)
  })

  it('区间进度随累计击杀爬升，锚点前封顶', () => {
    const s = make()
    expect(s.progress(0)).toBe(0)
    expect(s.progress(35)).toBeCloseTo(0.5, 6)
    expect(s.progress(70)).toBe(1)
    expect(s.progress(200)).toBe(1)
  })
})

describe('WaveScheduler · 锚点', () => {
  it('累计击杀达阈值后进入锚点准备，倒计时结束产出锚点 BOSS', () => {
    const s = make()
    s.step(30, { enemiesAlive: 0, totalKills: 0 }) // combat
    s.step(1, { enemiesAlive: 0, totalKills: 70 }) // 达标
    expect(s.phase).toBe('anchorPrep')
    expect(s.prepRemaining).toBeCloseTo(90, 6)

    const cmds = s.step(90, { enemiesAlive: 0, totalKills: 70 })
    expect(s.phase).toBe('anchor')
    const anchor = cmds.find((c) => c.kind === 'anchorSpawn')
    expect(anchor).toBeDefined()
    if (anchor?.kind === 'anchorSpawn') {
      expect(anchor.group.monsterId).toBe('heishui_xuanshe')
      expect(anchor.group.isBoss).toBe(true)
      expect(anchor.windowSeconds).toBe(90)
      // 1 人基准：11000 ÷ 4 × 1 × 0.8 = 2200
      expect(anchor.group.stats.hp).toBeCloseTo(2200, 6)
    }
  })

  it('未达阈值则继续常规波次', () => {
    const s = make()
    s.step(30, { enemiesAlive: 0, totalKills: 0 })
    s.step(1, { enemiesAlive: 0, totalKills: 69 })
    expect(s.phase).toBe('prep')
  })

  it('结算锚点后进入完成态，不再产出命令', () => {
    const s = make()
    s.step(30, { enemiesAlive: 0, totalKills: 0 })
    s.step(1, { enemiesAlive: 0, totalKills: 70 })
    s.step(90, { enemiesAlive: 0, totalKills: 70 })
    expect(s.phase).toBe('anchor')
    s.resolveAnchor()
    expect(s.phase).toBe('done')
    expect(s.step(100, { enemiesAlive: 0, totalKills: 70 })).toEqual([])
  })
})
