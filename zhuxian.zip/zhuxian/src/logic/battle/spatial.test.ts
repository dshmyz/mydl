import { describe, expect, it } from 'vitest'
import {
  clampToBounds,
  distance,
  inCone,
  inRange,
  normalize,
  offset,
  stepToward,
} from './spatial'

describe('spatial · 基础几何', () => {
  it('distance 计算两点欧氏距离', () => {
    expect(distance({ x: 0, y: 0 }, { x: 3, y: 4 })).toBe(5)
  })

  it('distance 对同点为 0', () => {
    expect(distance({ x: 2, y: 2 }, { x: 2, y: 2 })).toBe(0)
  })

  it('normalize 归一化为单位向量', () => {
    const n = normalize({ x: 3, y: 4 })
    expect(Math.hypot(n.x, n.y)).toBeCloseTo(1, 10)
    expect(n.x).toBeCloseTo(0.6, 10)
  })

  it('normalize 对零向量返回零向量（不产生 NaN）', () => {
    expect(normalize({ x: 0, y: 0 })).toEqual({ x: 0, y: 0 })
  })

  it('offset 按方向与距离平移', () => {
    expect(offset({ x: 1, y: 1 }, { x: 1, y: 0 }, 2)).toEqual({ x: 3, y: 1 })
  })
})

describe('spatial · 移动', () => {
  it('stepToward 未超过步长时精确落点', () => {
    expect(stepToward({ x: 0, y: 0 }, { x: 1, y: 0 }, 5)).toEqual({ x: 1, y: 0 })
  })

  it('stepToward 超过步长时只走一步', () => {
    const p = stepToward({ x: 0, y: 0 }, { x: 10, y: 0 }, 2)
    expect(p).toEqual({ x: 2, y: 0 })
  })

  it('stepToward 同点时不移动', () => {
    expect(stepToward({ x: 4, y: 4 }, { x: 4, y: 4 }, 3)).toEqual({ x: 4, y: 4 })
  })

  it('stepToward 非正步长不移动', () => {
    expect(stepToward({ x: 0, y: 0 }, { x: 10, y: 0 }, 0)).toEqual({ x: 0, y: 0 })
  })
})

describe('spatial · 范围判定', () => {
  it('inRange 含边界', () => {
    expect(inRange({ x: 0, y: 0 }, { x: 3, y: 4 }, 5)).toBe(true)
    expect(inRange({ x: 0, y: 0 }, { x: 3, y: 4 }, 4.9)).toBe(false)
  })

  it('clampToBounds 把点钳入矩形', () => {
    const b = { min: { x: 0, y: 0 }, max: { x: 10, y: 10 } }
    expect(clampToBounds({ x: -3, y: 12 }, b)).toEqual({ x: 0, y: 10 })
    expect(clampToBounds({ x: 5, y: 5 }, b)).toEqual({ x: 5, y: 5 })
  })

  it('inCone：正前方且在半径内命中', () => {
    expect(inCone({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 3, y: 0.5 }, 5, 30)).toBe(true)
  })

  it('inCone：超出半径不命中', () => {
    expect(inCone({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 6, y: 0 }, 5, 30)).toBe(false)
  })

  it('inCone：角度超出半张角不命中', () => {
    // 目标在 90° 方向（正上方），半张角 30° → 不命中
    expect(inCone({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 0, y: 3 }, 5, 30)).toBe(false)
  })

  it('inCone：正后方不命中', () => {
    expect(inCone({ x: 0, y: 0 }, { x: 1, y: 0 }, { x: -3, y: 0 }, 5, 30)).toBe(false)
  })

  it('inCone：同点（重合）视为命中', () => {
    expect(inCone({ x: 1, y: 1 }, { x: 1, y: 0 }, { x: 1, y: 1 }, 5, 30)).toBe(true)
  })
})
