/**
 * 战斗结算：普攻命中 / 目标选取 / 技能效果落地（纯逻辑，确定性）。
 *
 * 复用 `combat/damage.ts` 的 L1 伤害公式，本模块只负责「谁打谁、造成什么后果」：
 *  - `resolveAttack`：一次伤害的完整落地（护盾吸收 → 扣气血 → 击杀 → 吸血）。
 *  - `selectTargets`：按技能形态（单体 / 扇形 / 自身范围 / 地面范围）从战场选目标。
 *  - `applySkill`：伤害 + 按**极性**分发持久效果（增益挂施法者 / 减益挂目标）+ 瞬时效果。
 *
 * 目标选取依赖空间位置，故放在此处而非 `skillEngine`（后者只管能不能放、放什么）。
 */

import type { DamageType, Tier } from '../../data/types/common'
import type { LimitsDef, TierArmorKDef } from '../../data/types/numeric'
import type { RngLike } from '../core/rng'
import { computeDamage, type DamageBreakdown } from '../combat/damage'
import { effectPolarity } from '../modifier/effects'
import type { ResolvedSkill } from '../skills/skillEngine'
import { distance, inCone, inRange, offset, type Bounds, type Vec2 } from './spatial'
import type { Unit } from './unit'

/** 扇形半张角（度）：总张角 60° 的前方扇（M1 原型参数，待手感调优） */
export const CONE_HALF_ANGLE_DEG = 30

/** 战斗结算所需的共享依赖（由编排层注入，保证可复现） */
export interface CombatContext {
  armorK: ReadonlyMap<Tier, TierArmorKDef>
  limits: LimitsDef
  rng: RngLike
  /** 战场边界（击退 / 位移钳制用） */
  bounds: Bounds
}

/** 一次伤害的落地结果 */
export interface AttackOutcome {
  breakdown: DamageBreakdown
  /** 被护盾吸收的伤害 */
  absorbed: number
  /** 实际扣除的气血 */
  dealt: number
  /** 攻击者经吸血回复的气血 */
  lifesteal: number
  killed: boolean
}

/** 召唤回调：由编排层创建单位（本模块不构造单位） */
export interface SkillHooks {
  spawn: (monsterId: string, position: Vec2) => Unit
}

export interface SkillSummon {
  monsterId: string
  unit: Unit
}

/** 一次技能命中：目标与其伤害落地结果配对（便于编排层做锚点扣血 / 表现反馈） */
export interface SkillHit {
  target: Unit
  outcome: AttackOutcome
}

export interface SkillCastResult {
  hits: SkillHit[]
  summons: SkillSummon[]
}

/**
 * 一次伤害的完整落地：公式结算 → 护盾吸收 → 扣气血 → 击杀判定 → 吸血回复。
 *
 * @param rate 技能倍率（普攻传 1）；`damageType` 缺省取攻击者自身伤害类型
 */
export function resolveAttack(
  attacker: Unit,
  defender: Unit,
  ctx: CombatContext,
  rate = 1,
  damageType?: DamageType,
): AttackOutcome {
  const breakdown = computeDamage({
    attacker: { stats: attacker.stats, modifiers: attacker.modifiers },
    defender: {
      stats: defender.stats,
      modifiers: defender.modifiers,
      tier: defender.tier,
      armorKMult: defender.armorKMult,
    },
    damageType: damageType ?? attacker.damageType,
    rate,
    rng: ctx.rng,
    armorK: ctx.armorK,
    limits: ctx.limits,
  })

  const { absorbed, overflow } = defender.modifiers.absorb(breakdown.damage)
  const before = defender.hp
  defender.hp = Math.max(0, before - overflow)
  const dealt = before - defender.hp
  if (defender.hp <= 0) {
    defender.alive = false
  }

  let lifesteal = 0
  const percent = attacker.modifiers.lifestealPercent()
  if (percent > 0 && dealt > 0) {
    lifesteal = dealt * percent
    attacker.heal(lifesteal)
  }

  return { breakdown, absorbed, dealt, lifesteal, killed: !defender.alive }
}

/** 距 `origin` 最近的存活单位（距离相同取 id 字典序最小，保证确定性） */
export function nearestUnit(origin: Vec2, units: readonly Unit[]): Unit | null {
  let best: Unit | null = null
  let bestDist = Number.POSITIVE_INFINITY
  for (const unit of units) {
    if (!unit.alive) {
      continue
    }
    const d = distance(unit.position, origin)
    if (d < bestDist || (d === bestDist && best !== null && unit.id < best.id)) {
      best = unit
      bestDist = d
    }
  }
  return best
}

/** 按技能形态选取伤害目标；`aim` 仅地面范围（aoeGround）形态需要 */
export function selectTargets(
  caster: Unit,
  resolved: ResolvedSkill,
  enemies: readonly Unit[],
  aim?: Vec2,
): Unit[] {
  switch (resolved.shape) {
    case 'self':
      return []
    case 'single': {
      const range = resolved.range ?? caster.attackRange
      const inReach = enemies.filter((e) => e.alive && inRange(caster.position, e.position, range))
      const nearest = nearestUnit(caster.position, inReach)
      return nearest ? [nearest] : []
    }
    case 'cone': {
      const radius = resolved.radius ?? resolved.range ?? caster.attackRange
      return enemies.filter(
        (e) =>
          e.alive &&
          inCone(caster.position, caster.facing, e.position, radius, CONE_HALF_ANGLE_DEG),
      )
    }
    case 'aoeSelf': {
      const radius = resolved.radius ?? caster.attackRange
      return enemies.filter((e) => e.alive && inRange(caster.position, e.position, radius))
    }
    case 'aoeGround': {
      if (!aim) {
        return []
      }
      const radius = resolved.radius ?? caster.attackRange
      return enemies.filter((e) => e.alive && inRange(aim, e.position, radius))
    }
  }
}

/**
 * 释放技能：选取目标 → 逐个结算伤害 → 分发效果。
 *
 * 效果分发规则（与 `effects.ts` 极性判定一致，不写特殊逻辑）：
 *  - 持久·增益 → 施法者自身；持久·减益 → 每个命中目标；
 *  - 瞬时·治疗 → 施法者；瞬时·击退 → 每个命中目标；瞬时·召唤 → 环绕施法者生成。
 */
export function applySkill(
  caster: Unit,
  resolved: ResolvedSkill,
  ctx: CombatContext,
  enemies: readonly Unit[],
  hooks: SkillHooks,
  aim?: Vec2,
): SkillCastResult {
  const targets = selectTargets(caster, resolved, enemies, aim)
  const source = resolved.skill.id

  const hits: SkillHit[] = []
  if (resolved.damageType) {
    for (const target of targets) {
      hits.push({ target, outcome: resolveAttack(caster, target, ctx, resolved.rate, resolved.damageType) })
    }
  }

  for (const spec of resolved.persistent) {
    const polarity = effectPolarity(spec)
    if (polarity === 'buff') {
      caster.modifiers.addAll([spec], source, { maxHp: caster.maxHp })
    } else if (polarity === 'debuff') {
      for (const target of targets) {
        target.modifiers.addAll([spec], source, { maxHp: target.maxHp })
      }
    }
  }

  const summons: SkillSummon[] = []
  for (const spec of resolved.instant) {
    switch (spec.kind) {
      case 'heal':
        caster.heal(spec.flat ?? (spec.percentOfMaxHp ?? 0) * caster.maxHp)
        break
      case 'knockback':
        for (const target of targets) {
          target.displaceAway(caster.position, spec.distance, ctx.bounds)
        }
        break
      case 'summon':
        for (let i = 0; i < spec.count; i += 1) {
          const angle = (2 * Math.PI * i) / Math.max(1, spec.count)
          const at = offset(caster.position, { x: Math.cos(angle), y: Math.sin(angle) }, 0.6)
          summons.push({ monsterId: spec.monsterId, unit: hooks.spawn(spec.monsterId, at) })
        }
        break
      default:
        // heal / knockback / summon 已穷尽；此处仅为类型收窄兜底
        break
    }
  }

  return { hits, summons }
}
