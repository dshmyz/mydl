/**
 * 战斗单位：英雄 / 小怪 / 精英 / BOSS 的统一运行时表示。
 *
 * 只承载**状态**（属性、气血、位置、朝向、计时、修饰容器），不含 AI 与空间查询 ——
 * 目标选取、移动决策、技能释放分别由 `battle` / `combat` 处理，保持职责单一。
 *
 * 属性分两层：`baseStats`（英雄 = 成长 L×R 后的基线；怪物 = 波次导演产出的生成属性）
 * 与 `ModifierSet`（装备 / 增益 / 减益）。`stats` 为二者结算后的最终面板。
 *
 * 纯逻辑，不 import Phaser。
 */

import type { DamageType, Rank, Stats, Tier } from '../../data/types/common'
import { ModifierSet } from '../modifier/modifierSet'
import { SkillState } from '../skills/skillState'
import { clampToBounds, offset, stepToward, type Bounds, type Vec2 } from './spatial'

export type UnitKind = 'hero' | 'minion' | 'elite' | 'boss'

/**
 * 移速换算：`spd`（速度单位 / 秒）→ 格 / 秒。
 *
 * 数值层 `spd`（英雄 300 / 小怪 220）与空间层「格」是两套刻度，此处给出换算比例。
 * 关键：移速随 `statMod` 百分比（减速 / 加速）联动，故用 getter 从 `stats.spd` 取。
 */
export const SPEED_UNITS_PER_GRID = 100

export interface UnitInit {
  id: string
  kind: UnitKind
  /** 定义 id（英雄 id / 怪物 id），供掉落与表现层查表 */
  defId: string
  name: string
  /** 成长后的基线属性（英雄）或生成属性（怪物） */
  baseStats: Stats
  position: Vec2
  tier: Tier
  /** 攻击速度（次 / 秒） */
  attackSpeed: number
  /** 攻击距离（格） */
  attackRange: number
  damageType: DamageType
  armorKMult?: number
  flying?: boolean
  /** BOSS 招式技能 id 列表 */
  skillIds?: string[]
  maxMp?: number
  mp?: number
  /** 英雄等级（默认 1） */
  level?: number
  /** 英雄境界（默认玉清） */
  rank?: Rank
}

export class Unit {
  readonly id: string
  readonly kind: UnitKind
  readonly defId: string
  name: string

  /** 成长 / 生成后的基线属性；英雄升级 / 突破时经 `setBaseStats` 更新 */
  baseStats: Stats
  position: Vec2
  facing: Vec2 = { x: 1, y: 0 }

  readonly modifiers = new ModifierSet()
  readonly skillState: SkillState

  hp: number
  alive = true

  readonly tier: Tier
  readonly armorKMult: number
  readonly flying: boolean
  readonly attackRange: number
  readonly damageType: DamageType
  readonly attackInterval: number
  readonly skillIds: readonly string[]

  /** 普攻剩余冷却（秒）；≤0 即可出手 */
  attackTimer = 0

  /** 阶段触发型招式（trigger='phase'）是否已触发 */
  readonly phaseTriggered = new Set<string>()

  level: number
  rank: Rank

  constructor(init: UnitInit) {
    this.id = init.id
    this.kind = init.kind
    this.defId = init.defId
    this.name = init.name
    this.baseStats = { ...init.baseStats }
    this.position = { ...init.position }
    this.tier = init.tier
    this.armorKMult = init.armorKMult ?? 1
    this.flying = init.flying ?? false
    this.attackRange = init.attackRange
    this.damageType = init.damageType
    this.attackInterval = 1 / init.attackSpeed
    this.skillIds = init.skillIds ?? []
    this.level = init.level ?? 1
    this.rank = init.rank ?? 'yuqing'

    const maxMp = init.maxMp ?? init.baseStats.mp
    this.skillState = new SkillState({ mp: init.mp ?? maxMp, maxMp })
    this.hp = this.maxHp
  }

  /** 最终属性面板：基线 × 修饰（含成长 / 装备 / 增益） */
  get stats(): Stats {
    return this.modifiers.resolveStats(this.baseStats)
  }

  get maxHp(): number {
    return this.stats.hp
  }

  /** 移速（格 / 秒）：随 `statMod` 百分比联动 */
  get moveSpeed(): number {
    return this.stats.spd / SPEED_UNITS_PER_GRID
  }

  get isBoss(): boolean {
    return this.kind === 'boss'
  }

  get isElite(): boolean {
    return this.kind === 'elite'
  }

  /**
   * 更新基线属性（英雄升级 / 突破时调用），并按原气血比例迁移当前气血，
   * 避免升级后「血越升越亏」的观感问题。
   */
  setBaseStats(next: Stats): void {
    const ratio = this.maxHp > 0 ? this.hp / this.maxHp : 1
    this.baseStats = { ...next }
    this.hp = this.maxHp * ratio
  }

  /** 朝目标移动至多 `maxStep`，并同步朝向 */
  moveToward(target: Vec2, maxStep: number, bounds: Bounds): void {
    this.face(target)
    this.position = clampToBounds(stepToward(this.position, target, maxStep), bounds)
  }

  /** 沿 `direction`（不要求归一化）移动至多 `distance`，**不改变朝向**（玩家主动位移用） */
  moveBy(direction: Vec2, distance: number, bounds: Bounds): void {
    const from = this.position
    const target = { x: from.x + direction.x, y: from.y + direction.y }
    this.position = clampToBounds(stepToward(from, target, distance), bounds)
  }

  /** 朝指定方向位移（击退），并同步朝向 */
  displaceAway(from: Vec2, dist: number, bounds: Bounds): void {
    const dir = { x: this.position.x - from.x, y: this.position.y - from.y }
    this.position = clampToBounds(offset(this.position, dir, dist), bounds)
  }

  face(target: Vec2): void {
    const dx = target.x - this.position.x
    const dy = target.y - this.position.y
    if (dx !== 0 || dy !== 0) {
      this.facing = { x: dx, y: dy }
    }
  }

  /** 回复气血（不超过上限） */
  heal(amount: number): void {
    this.hp = Math.min(this.maxHp, this.hp + amount)
  }

  /** 推进限时修饰、技能冷却与普攻计时 */
  tick(dt: number): void {
    this.modifiers.tick(dt)
    this.skillState.tick(dt)
    if (this.attackTimer > 0) {
      this.attackTimer = Math.max(0, this.attackTimer - dt)
    }
  }
}
