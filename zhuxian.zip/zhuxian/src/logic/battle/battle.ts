/**
 * 战斗编排：把波次排程、单位 AI、战斗结算与成长经济串成一局**可确定性步进**的模拟。
 *
 * 职责边界（技术架构 §十一：逻辑层不依赖表现层）：
 *  - 本模块只维护逻辑事实并产出 `BattleEvent`（供表现层播放反馈），不触碰任何渲染。
 *  - 所有随机性来自按 seed 派生的子流（伤害 / 掉落 / 落位各自独立），保证同 seed 可复现。
 *
 * 一局的生命周期（M1 纵向切片）：准备 → 刷怪 → 清场 → …… → 累计击杀达阈值 →
 * 锚点准备 → **锚点一限时战** → 通关（`anchorCleared`）或失守（`anchorFailed`）；
 * 剑阵核心耐久归零即 `defeat`。通关后可突破上清（M1 止步于此，后续幕次在 M2 展开）。
 *
 * 资源（金币 / 灵石 / 材料 / 装备）在 M1 以本模块公开字段承载：所有入账一律来自战斗掉落与
 * 波次收入，唯一出账口是 `craftAndEquip`，避免与 `Wallet` / `CraftBag` 形成双账本。
 */

import type {
  DropSource,
  EffectSpec,
  Quality,
  Rank,
  SkillKey,
} from '../../data/types/common'
import type { GameDataIndex } from '../../data/indexes'
import type { GameData } from '../../data/types/gameData'
import type { RecipeDef } from '../../data/types/equipment'
import type { HeroDef, MonsterDef } from '../../data/types/units'
import type { RankDef } from '../../data/types/numeric'
import { Rng, type RngLike } from '../core/rng'
import { CraftEngine, type CraftBag, type CraftedItem } from '../crafting/craftEngine'
import { dropGold, LevelTracker, rollMaterial, sourceXp } from '../economy/economy'
import { EventDirector } from '../events/eventDirector'
import { resolveGrowthStats } from '../growth/growth'
import { AnchorChallenge } from '../objective/anchorChallenge'
import { CoreTarget } from '../objective/coreTarget'
import { HeroLife } from '../objective/heroLife'
import { SkillEngine, type ResolvedSkill } from '../skills/skillEngine'
import { WaveDirector, type SpawnGroup, type WavePlan } from '../waves/waveDirector'
import {
  applySkill,
  nearestUnit,
  resolveAttack,
  type AttackOutcome,
  type CombatContext,
} from './combat'
import { clampToBounds, inRange, offset, type Bounds, type Vec2 } from './spatial'
import { Unit, type UnitKind } from './unit'
import { WaveScheduler } from './waveScheduler'
import type { BattleConfig } from './config'

export type BattleStatus = 'running' | 'defeat' | 'anchorCleared' | 'anchorFailed'

/** 本帧的英雄操作意图（由玩家输入或 headless AI 提供） */
export interface HeroIntent {
  /** 移动方向（不要求归一化；缺省 = 原地不动） */
  moveDir?: Vec2
  /** 本帧尝试释放的技能键位 */
  cast?: SkillKey
  /** 地面范围技（aoeGround）的落点 */
  aim?: Vec2
}

/** 表现形式反馈事件：编排层只产出事实，播放交由表现层 */
export type BattleEvent =
  | { kind: 'spawn'; unitId: string }
  | { kind: 'cast'; casterId: string; skillId: string }
  | { kind: 'damage'; sourceId: string; targetId: string; amount: number; crit: boolean; dodged: boolean }
  | { kind: 'kill'; unitId: string; defId: string; gold: number; material: string | null }
  | { kind: 'coreDamage'; amount: number; hp: number }
  | { kind: 'gold'; amount: number }
  | { kind: 'heroDeath' }
  | { kind: 'heroRevive' }
  | { kind: 'anchorStart' }
  | { kind: 'anchorCleared' }
  | { kind: 'anchorFailed' }
  | { kind: 'craft'; defId: string; quality: Quality }
  | { kind: 'breakthrough'; rank: Rank }

export interface BattleDeps {
  data: GameData
  index: GameDataIndex
  config: BattleConfig
  /** 允许注入事件导演（测试用固定事件策略；缺省走默认配置） */
  events?: EventDirector
}

export class Battle {
  readonly config: BattleConfig
  readonly hero: Unit
  readonly core: CoreTarget
  readonly heroLife: HeroLife
  readonly challenge: AnchorChallenge
  readonly scheduler: WaveScheduler

  // —— 资源账本（仅经战斗掉落入账，仅经 craftAndEquip 出账）——
  gold = 0
  spirit = 0
  readonly materials = new Map<string, number>()
  /** 已拥有的装备 defId（同一 id 可重复；M1 简化：持有即视为可装备） */
  readonly items: string[] = []

  private readonly data: GameData
  private readonly index: GameDataIndex
  private readonly heroDef: HeroDef
  private readonly bounds: Bounds
  private readonly skillEngine: SkillEngine
  private readonly craftEngine: CraftEngine
  private readonly director: WaveDirector
  private readonly levelTracker: LevelTracker
  private readonly damageRng: RngLike
  private readonly lootRng: RngLike
  private readonly spawnRng: RngLike

  private readonly unitList: Unit[] = []
  private readonly eventBuffer: BattleEvent[] = []
  private statusValue: BattleStatus = 'running'
  private killsValue = 0
  private timeValue = 0
  private nextUnitId = 0
  private anchorBossUnitId: string | null = null
  /** 待消费的渡劫机会：每次锚点通关授予一次，突破后消费（三锚点对应三次大突破） */
  private pendingBreakthrough = false

  constructor(deps: BattleDeps) {
    this.data = deps.data
    this.index = deps.index
    this.config = deps.config
    this.bounds = deps.config.field.bounds
    this.skillEngine = new SkillEngine(deps.index)
    this.craftEngine = new CraftEngine(deps.data, deps.index)
    this.director = new WaveDirector(deps.data, deps.index)

    this.levelTracker = new LevelTracker(deps.data.economy.levelNeed, deps.data.level.maxLevel)

    // 逻辑流按用途拆分子流：伤害与掉落 / 落位互不干扰，保证各自可复现
    const root = new Rng(deps.config.seed)
    this.damageRng = root.fork(1)
    this.lootRng = root.fork(2)
    this.spawnRng = root.fork(3)

    this.scheduler = new WaveScheduler({
      data: deps.data,
      director: this.director,
      events: deps.events ?? new EventDirector(deps.index),
      rng: root,
      config: { players: deps.config.players, ...deps.config.wave },
      act: deps.config.act,
    })

    this.core = new CoreTarget(deps.config.coreMaxHp)
    this.heroLife = new HeroLife(deps.config.heroReviveSeconds)
    this.challenge = new AnchorChallenge()

    this.heroDef = this.requireHero(deps.config.heroId)
    this.hero = this.createHero()
    this.equipStartingGear()
  }

  // —— 只读视图 ——

  /** 战场上存活的敌人（阵亡单位在当帧结算时移除） */
  get units(): readonly Unit[] {
    return this.unitList
  }

  get kills(): number {
    return this.killsValue
  }

  get status(): BattleStatus {
    return this.statusValue
  }

  /** 已推进的模拟时长（秒） */
  get time(): number {
    return this.timeValue
  }

  /** 本帧产生的事件（每帧开头清空） */
  get events(): readonly BattleEvent[] {
    return this.eventBuffer
  }

  // —— 主循环 ——

  /**
   * 推进一帧。
   *
   * 顺序：单位计时 → 英雄行动 → 怪物行动 → 阵亡结算 → 波次命令 → 锚点结算 → 失败判定。
   * 阵亡结算刻意排在波次命令之前，使「清场」能立即被排程器观察到。
   */
  step(dt: number, intent: HeroIntent = {}): readonly BattleEvent[] {
    this.eventBuffer.length = 0
    if (this.statusValue !== 'running') {
      return this.eventBuffer
    }
    this.timeValue += dt

    this.hero.tick(dt)
    for (const monster of this.unitList) {
      monster.tick(dt)
    }

    this.updateHero(dt, intent)
    // 快照迭代：英雄 / BOSS 招式可能在本帧插入召唤物，避免边遍历边扩列表
    for (const monster of [...this.unitList]) {
      this.updateMonster(monster, dt)
    }

    this.resolveDeaths()
    this.runScheduler(dt)
    this.updateAnchor(dt)
    this.checkDefeat()

    return this.eventBuffer
  }

  // —— 合成与突破 ——

  canCraft(recipe: RecipeDef): boolean {
    return this.craftEngine.canCraft(recipe, this.bag()) === null
  }

  /** 合成升档：扣资源 → 产物入包 → 立即装备该线；任一条件不足则整体失败 */
  craftAndEquip(recipe: RecipeDef): boolean {
    const result = this.craftEngine.craft(recipe, this.bag(), this.lootRng)
    if (!result.ok) {
      return false
    }
    this.gold = result.bag.gold
    this.spirit = result.bag.spirit
    this.materials.clear()
    for (const [id, count] of result.bag.materials) {
      this.materials.set(id, count)
    }
    // `craft` 的产物不与资源袋合并，故在此显式入包
    this.items.length = 0
    this.items.push(...result.bag.items, result.item.defId)
    this.equipItem(result.item)
    this.eventBuffer.push({ kind: 'craft', defId: result.item.defId, quality: result.item.quality })
    return true
  }

  /** 尚有未消费的渡劫机会且存在更高境界时可突破 */
  canBreakthrough(): boolean {
    return this.pendingBreakthrough && this.nextRank(this.hero.rank) !== null
  }

  /** 突破至下一境界：消费渡劫机会并重算成长属性（解锁更高的 L×R 基准） */
  breakthrough(): boolean {
    const next = this.nextRank(this.hero.rank)
    if (!this.pendingBreakthrough || next === null) {
      return false
    }
    this.pendingBreakthrough = false
    this.hero.rank = next
    this.refreshHeroGrowth()
    this.eventBuffer.push({ kind: 'breakthrough', rank: next })
    return true
  }

  // —— 英雄 ——

  private updateHero(dt: number, intent: HeroIntent): void {
    if (!this.heroLife.isAlive) {
      this.heroLife.tick(dt)
      if (this.heroLife.isAlive) {
        this.reviveHero()
      }
      return
    }

    this.hero.skillState.restore(this.config.heroMpRegenPerSecond * dt)

    if (intent.moveDir && !this.hero.modifiers.isRooted()) {
      this.hero.moveBy(intent.moveDir, this.hero.moveSpeed * dt, this.bounds)
    }
    if (intent.cast !== undefined) {
      this.castHeroSkill(intent.cast, intent.aim)
    }
    this.heroAutoAttack()
  }

  /** 英雄普攻：射程内最近敌人（出手前自动面向目标，保证扇形技能朝向正确） */
  private heroAutoAttack(): void {
    if (this.hero.attackTimer > 0) {
      return
    }
    const target = nearestUnit(this.hero.position, this.unitList)
    if (!target || !inRange(this.hero.position, target.position, this.hero.attackRange)) {
      return
    }
    this.hero.face(target.position)
    const outcome = resolveAttack(this.hero, target, this.combatContext())
    this.hero.attackTimer = this.hero.attackInterval
    this.noteAttack(this.hero, target, outcome)
  }

  private castHeroSkill(key: SkillKey, aim?: Vec2): void {
    const skillId = this.heroDef.skills[key]
    const result = this.skillEngine.cast(skillId, this.hero.skillState, this.hero.rank)
    if (!result.ok) {
      return
    }
    const enemies = this.hero.alive ? this.unitList : []
    this.resolveCast(this.hero, result.outcome, enemies, aim)
  }

  private reviveHero(): void {
    this.hero.alive = true
    this.hero.hp = this.hero.maxHp
    this.hero.position = { ...this.config.field.heroSpawn }
    this.eventBuffer.push({ kind: 'heroRevive' })
  }

  // —— 怪物 ——

  private updateMonster(monster: Unit, dt: number): void {
    if (!monster.alive) {
      return
    }
    this.updateMonsterSkills(monster)

    const hero = this.hero.alive ? this.hero : null
    if (hero && inRange(monster.position, hero.position, monster.attackRange)) {
      monster.face(hero.position)
      if (monster.attackTimer <= 0) {
        const outcome = resolveAttack(monster, hero, this.combatContext())
        monster.attackTimer = monster.attackInterval
        this.noteAttack(monster, hero, outcome)
      }
      return
    }
    if (hero && inRange(monster.position, hero.position, monster.attackRange + this.config.aggroBonus)) {
      if (!monster.modifiers.isRooted()) {
        monster.moveToward(hero.position, monster.moveSpeed * dt, this.bounds)
      }
      return
    }

    // 未索敌到英雄 → 直扑剑阵核心
    const core = this.config.field.core
    monster.face(core)
    if (inRange(monster.position, core, monster.attackRange)) {
      if (monster.attackTimer <= 0) {
        this.damageCore(Math.floor(monster.stats.atk))
        monster.attackTimer = monster.attackInterval
      }
      return
    }
    if (!monster.modifiers.isRooted()) {
      monster.moveToward(core, monster.moveSpeed * dt, this.bounds)
    }
  }

  /**
   * BOSS 招式：`trigger='phase'` 的招式按气血阈值触发一次，其余按冷却释放。
   *
   * 冷却类招式需英雄在其作用范围内才释放，避免远距离空放（不改变数值，只影响观感与节奏）。
   */
  private updateMonsterSkills(monster: Unit): void {
    const def = this.index.monster.get(monster.defId)
    if (!def?.skills) {
      return
    }
    for (const skillId of def.skills) {
      const skill = this.index.skill.get(skillId)
      if (!skill) {
        continue
      }
      if (skill.trigger === 'phase') {
        if (monster.phaseTriggered.has(skillId)) {
          continue
        }
        const threshold = skill.triggerThreshold ?? 0
        if (monster.maxHp > 0 && monster.hp / monster.maxHp > threshold) {
          continue
        }
        monster.phaseTriggered.add(skillId)
        this.castMonsterSkill(monster, skillId)
        continue
      }
      const reach = skill.range ?? skill.radius ?? 0
      if (!this.hero.alive || !inRange(monster.position, this.hero.position, reach)) {
        continue
      }
      if (this.skillEngine.canCast(skillId, monster.skillState, monster.rank) === null) {
        this.castMonsterSkill(monster, skillId)
      }
    }
  }

  private castMonsterSkill(monster: Unit, skillId: string): void {
    const result = this.skillEngine.cast(skillId, monster.skillState, monster.rank)
    if (!result.ok) {
      return
    }
    const enemies = this.hero.alive ? [this.hero] : []
    this.resolveCast(monster, result.outcome, enemies)
  }

  // —— 结算 ——

  private resolveCast(
    caster: Unit,
    resolved: ResolvedSkill,
    enemies: readonly Unit[],
    aim?: Vec2,
  ): void {
    // 释放成功即产出事实（无论是否命中），表现层据此播放技能特效
    this.eventBuffer.push({ kind: 'cast', casterId: caster.id, skillId: resolved.skill.id })
    // M1 召唤仅服务于敌方 BOSS：召唤物落敌方阵营（英雄召唤技在 M2 引入时需按阵营分列）
    const result = applySkill(caster, resolved, this.combatContext(), enemies, {
      spawn: (monsterId, position) => this.spawnSummon(monsterId, position),
    }, aim)
    for (const hit of result.hits) {
      this.noteAttack(caster, hit.target, hit.outcome)
    }
  }

  /** 记录一次命中：产出表现事件，并在命中锚点 BOSS 时同步限时战血量 */
  private noteAttack(attacker: Unit, target: Unit, outcome: AttackOutcome): void {
    this.eventBuffer.push({
      kind: 'damage',
      sourceId: attacker.id,
      targetId: target.id,
      amount: outcome.dealt,
      crit: outcome.breakdown.crit,
      dodged: outcome.breakdown.dodged,
    })
    if (target.id === this.anchorBossUnitId) {
      this.challenge.damageBoss(outcome.dealt)
    }
  }

  private damageCore(amount: number): void {
    this.core.takeDamage(amount)
    this.eventBuffer.push({ kind: 'coreDamage', amount, hp: this.core.hp })
  }

  /** 阵亡结算：英雄转入复活计时；怪物移出战场并按来源掉落 */
  private resolveDeaths(): void {
    if (!this.hero.alive && this.heroLife.isAlive) {
      this.heroLife.kill()
      this.eventBuffer.push({ kind: 'heroDeath' })
    }

    let writeIndex = 0
    for (const unit of this.unitList) {
      if (unit.alive) {
        this.unitList[writeIndex] = unit
        writeIndex += 1
        continue
      }
      this.killsValue += 1
      this.grantDrops(unit)
    }
    this.unitList.length = writeIndex
  }

  /** 掉落结算：金币 ∝ 人数、灵石按来源、经验累加、材料按幕掉率（受储物袋上限约束） */
  private grantDrops(unit: Unit): void {
    const source = this.dropSourceOf(unit)
    const row = this.index.drop.get(source)
    if (!row) {
      return
    }
    const gold = dropGold(row, this.config.players, this.lootRng)
    this.gold += gold
    this.spirit += row.spiritFlat

    const material = rollMaterial(row, this.config.act, this.data.economy, this.lootRng)
    if (material) {
      this.addMaterial(material, 1)
    }

    const gained = this.levelTracker.gainXp(sourceXp(source, unit.tier, this.data.economy.xp))
    if (gained > 0) {
      this.hero.level = this.levelTracker.level
      this.refreshHeroGrowth()
    }

    this.eventBuffer.push({ kind: 'kill', unitId: unit.id, defId: unit.defId, gold, material })
  }

  private dropSourceOf(unit: Unit): DropSource {
    if (unit.kind === 'boss') {
      return unit.id === this.anchorBossUnitId ? 'anchorBoss' : 'waveBoss'
    }
    return unit.kind === 'elite' ? 'elite' : 'minion'
  }

  private addMaterial(materialId: string, count: number): void {
    const cap = this.data.limits.materialStorageCap
    const current = this.materials.get(materialId) ?? 0
    this.materials.set(materialId, Math.min(cap, current + count))
  }

  // —— 波次与锚点 ——

  private runScheduler(dt: number): void {
    const commands = this.scheduler.step(dt, {
      enemiesAlive: this.unitList.length,
      totalKills: this.killsValue,
    })
    for (const command of commands) {
      switch (command.kind) {
        case 'spawn':
          this.spawnPlan(command.plan)
          break
        case 'gold':
          this.gold += command.amount
          this.eventBuffer.push({ kind: 'gold', amount: command.amount })
          break
        case 'anchorSpawn':
          this.startAnchor(command.group, command.windowSeconds)
          break
      }
    }
  }

  private spawnPlan(plan: WavePlan): void {
    for (const group of plan.groups) {
      for (let i = 0; i < group.count; i += 1) {
        this.spawnMonster(group, this.spawnPosition())
      }
    }
  }

  /** 召唤物：与波次同强度口径（区间基线 × 怪系数），落位由调用方给出 */
  private spawnSummon(monsterId: string, position: Vec2): Unit {
    const group = this.director.spawn(monsterId, {
      act: this.config.act,
      progress: this.progress(),
      players: this.config.players,
      count: 1,
    })
    return this.spawnMonster(group, position)
  }

  private spawnMonster(group: SpawnGroup, position: Vec2): Unit {
    const monster = this.createMonster(group, position)
    this.unitList.push(monster)
    this.eventBuffer.push({ kind: 'spawn', unitId: monster.id })
    return monster
  }

  private startAnchor(group: SpawnGroup, windowSeconds: number): void {
    const boss = this.spawnMonster(group, this.spawnPosition())
    this.anchorBossUnitId = boss.id
    this.challenge.start(windowSeconds, boss.maxHp)
    this.eventBuffer.push({ kind: 'anchorStart' })
  }

  private updateAnchor(dt: number): void {
    const status = this.challenge.status
    if (status === 'cleared') {
      this.onAnchorCleared()
      return
    }
    if (status !== 'active') {
      return
    }
    this.challenge.tick(dt)
    // 经局部量判断：`tick` 后需重新读取状态，不能沿用外层窄化（active 可能已转 failed）
    if (this.challenge.status === 'failed') {
      this.onAnchorFailed()
    }
  }

  private onAnchorCleared(): void {
    if (this.statusValue !== 'running') {
      return
    }
    this.statusValue = 'anchorCleared'
    this.pendingBreakthrough = true
    this.scheduler.resolveAnchor()
    this.eventBuffer.push({ kind: 'anchorCleared' })
  }

  /** 锚点失守：核心受剧情级重创（扣除上限的 50%），BOSS 撤离，本局终止 */
  private onAnchorFailed(): void {
    if (this.statusValue !== 'running') {
      return
    }
    this.damageCore(Math.floor(this.core.maxHp * 0.5))
    this.removeAnchorBoss()
    this.scheduler.resolveAnchor()
    this.statusValue = this.core.destroyed ? 'defeat' : 'anchorFailed'
    this.eventBuffer.push({ kind: 'anchorFailed' })
  }

  private removeAnchorBoss(): void {
    const index = this.unitList.findIndex((unit) => unit.id === this.anchorBossUnitId)
    if (index >= 0) {
      this.unitList.splice(index, 1)
    }
    this.anchorBossUnitId = null
  }

  private checkDefeat(): void {
    if (this.core.destroyed && this.statusValue === 'running') {
      this.statusValue = 'defeat'
    }
  }

  // —— 构造与成长 ——

  private createHero(): Unit {
    const stats = resolveGrowthStats(this.heroDef.base, 1, this.data.level, this.rankDef('yuqing'))
    return new Unit({
      id: 'hero',
      kind: 'hero',
      defId: this.heroDef.id,
      name: this.heroDef.name,
      baseStats: stats,
      position: { ...this.config.field.heroSpawn },
      tier: this.heroDef.startTier,
      attackSpeed: this.data.derivation.heroAttackSpeed,
      attackRange: this.config.heroAttackRange,
      damageType: 'physical',
      armorKMult: this.heroDef.armorKMult,
      maxMp: this.heroDef.base.mp,
      mp: this.heroDef.base.mp,
      level: 1,
      rank: 'yuqing',
    })
  }

  /** 开局法宝：取英雄起始档位的法宝线装备（M1 固定凡品，无随机词条） */
  private equipStartingGear(): void {
    const start = this.data.equipment.find(
      (e) => e.line === 'weapon' && e.tier === this.heroDef.startTier,
    )
    if (!start) {
      return
    }
    const item: CraftedItem = {
      defId: start.id,
      line: start.line,
      tier: start.tier,
      quality: 'lower',
      affixes: [],
    }
    this.items.push(start.id)
    this.equipItem(item)
  }

  /**
   * 装备落地：主属性按品质系数放大后挂到 `equip:<线>` 来源，词条挂到 `affix:<词条>` 来源。
   * 同线重装先按来源清理旧修饰，再挂新的，避免叠加。
   */
  private equipItem(item: CraftedItem): void {
    const source = `equip:${item.line}`
    this.hero.modifiers.removeBySource(source)
    const def = this.index.equipment.get(item.defId)
    const statMul = this.index.quality.get(item.quality)?.statMul ?? 1
    if (def) {
      const specs: EffectSpec[] = def.mainStats.map((main) => ({
        kind: 'statMod',
        stat: main.stat,
        mode: main.mode,
        value: main.value * statMul,
      }))
      this.hero.modifiers.addAll(specs, source, { maxHp: this.hero.maxHp })
    }
    for (const affixId of item.affixes) {
      const affix = this.index.affix.get(affixId)
      if (affix) {
        this.hero.modifiers.add(affix.effect, `affix:${affixId}`, { maxHp: this.hero.maxHp })
      }
    }
  }

  /** 英雄升 / 突破时重算 L×R 基线（装备与临时修饰由 ModifierSet 另行叠加） */
  private refreshHeroGrowth(): void {
    const stats = resolveGrowthStats(
      this.heroDef.base,
      this.hero.level,
      this.data.level,
      this.rankDef(this.hero.rank),
    )
    this.hero.setBaseStats(stats)
  }

  private createMonster(group: SpawnGroup, position: Vec2): Unit {
    const def: MonsterDef | undefined = this.index.monster.get(group.monsterId)
    const kind: UnitKind = group.isBoss ? 'boss' : group.isElite ? 'elite' : 'minion'
    this.nextUnitId += 1
    return new Unit({
      id: `m${this.nextUnitId}`,
      kind,
      defId: group.monsterId,
      name: group.name,
      baseStats: { ...group.stats },
      position: { ...position },
      tier: group.tier,
      attackSpeed: group.attackSpeed,
      attackRange: group.range,
      damageType: 'physical',
      armorKMult: group.armorKMult,
      flying: group.flying,
      skillIds: def?.skills ?? [],
      maxMp: 0,
      mp: 0,
      level: 1,
      rank: 'yuqing',
    })
  }

  /** 刷怪 / 召唤落位：出生区中心周围确定性散布（独立子流，不扰动伤害与掉落） */
  private spawnPosition(): Vec2 {
    const angle = this.spawnRng.range(0, Math.PI * 2)
    const radius = this.spawnRng.range(0, this.config.spawnSpread)
    const dir = { x: Math.cos(angle), y: Math.sin(angle) }
    return clampToBounds(offset(this.config.field.spawn, dir, radius), this.bounds)
  }

  // —— 杂项 ——

  private progress(): number {
    return this.scheduler.progress(this.killsValue)
  }

  private combatContext(): CombatContext {
    return {
      armorK: this.index.tierArmorK,
      limits: this.data.limits,
      rng: this.damageRng,
      bounds: this.bounds,
    }
  }

  private bag(): CraftBag {
    return {
      gold: this.gold,
      spirit: this.spirit,
      materials: new Map(this.materials),
      items: [...this.items],
    }
  }

  private nextRank(rank: Rank): Rank | null {
    const order = [...this.index.rank.keys()]
    const at = order.indexOf(rank)
    if (at < 0) {
      return null
    }
    return order[at + 1] ?? null
  }

  private rankDef(rank: Rank): RankDef {
    const def = this.index.rank.get(rank)
    if (!def) {
      throw new Error(`战斗编排：缺少境界「${rank}」定义`)
    }
    return def
  }

  private requireHero(heroId: string): HeroDef {
    const def = this.index.hero.get(heroId)
    if (!def) {
      throw new Error(`战斗编排：未知英雄「${heroId}」`)
    }
    return def
  }
}
