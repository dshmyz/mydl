/**
 * 成长曲线 L2：等级 / 境界（数值文档 §4.2–§4.5）。
 *
 * 叠加方式为**乘法**：`最终 = 基础 × L倍率 × R倍率 × E倍率`。
 * 其中 E（装备）由装备系统以百分比修饰的形式挂在 ModifierSet 上（§7.1），
 * 故本模块只负责 **L × R** 这条底盘，装备贡献交由属性结算处理，避免重复计入。
 *
 * 英雄 DEF 不参与 L/R 缩放（§2.4：DEF = 同档标准 DEF，由道袍 / 冠巾护甲提供）；
 * 真气 / 移速 / 会心 / 闪避 / 暴伤同理由装备以固定值或百分点补充。
 */

import type { LevelDef, RankDef } from '../../data/types/numeric'
import type { Stats } from '../../data/types/common'

/**
 * 等级倍率：从 1 级升到 `level` 级的累计增幅。
 *
 * 分段递增为**递减式**（§4.4）：早期升级快、后期慢；超出 maxLevel 后封顶，
 * 低于 1 级按 1 级处理（保证恒 ≥ 1）。
 */
export function levelMultiplier(level: number, levelDef: LevelDef): number {
  const target = Math.min(Math.max(1, Math.floor(level)), levelDef.maxLevel)
  let mul = 1
  for (let step = 1; step < target; step += 1) {
    const segment = levelDef.segments.find((s) => step >= s.fromLevel && step < s.toLevel)
    mul *= 1 + (segment?.perLevelPct ?? 0)
  }
  return mul
}

/** 技能点：每 `skillPointEvery` 级 1 点（§4.4） */
export function skillPointsFor(level: number, levelDef: LevelDef): number {
  const target = Math.min(Math.max(1, Math.floor(level)), levelDef.maxLevel)
  return Math.floor(target / levelDef.skillPointEvery)
}

/**
 * 结算成长后属性：HP / ATK / SP 乘 L×R，其余属性保持基线。
 *
 * 结果向下取整（对齐「属性显示向下取整」的数值口径）。
 * 装备与临时修饰由 `ModifierSet.resolveStats()` 在此基础上叠加。
 */
export function resolveGrowthStats(
  base: Stats,
  level: number,
  levelDef: LevelDef,
  rank: RankDef,
): Stats {
  const mul = levelMultiplier(level, levelDef)
  const stats: Stats = { ...base }
  stats.hp = Math.floor(base.hp * mul * rank.hpMul)
  stats.atk = Math.floor(base.atk * mul * rank.atkMul)
  stats.sp = Math.floor(base.sp * mul * rank.atkMul)
  return stats
}
