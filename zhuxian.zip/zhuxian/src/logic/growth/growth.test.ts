import { describe, expect, it } from 'vitest'

import { eCurve, level, nodes, ranks } from '../../data/tables/numeric'
import type { Stats } from '../../data/types/common'
import { levelMultiplier, resolveGrowthStats, skillPointsFor } from './growth'

/** 张小凡 N1 开局面板（数值文档 §2.3） */
function base(): Stats {
  return { hp: 800, mp: 200, atk: 45, sp: 45, def: 12, spd: 300, dodge: 0, crit: 5, critDmg: 1.5 }
}

function rank(id: 'yuqing' | 'shangqing' | 'taiqing') {
  const found = ranks.find((r) => r.id === id)
  if (!found) {
    throw new Error(`缺少境界 ${id}`)
  }
  return found
}

function eMul(tier: number, key: 'hpMul' | 'atkMul'): number {
  const row = eCurve.find((e) => e.tier === tier)
  if (!row) {
    throw new Error(`缺少 E 曲线 T${tier}`)
  }
  return row[key]
}

function node(id: string) {
  const found = nodes.find((n) => n.id === id)
  if (!found) {
    throw new Error(`缺少节点 ${id}`)
  }
  return found
}

describe('levelMultiplier · 等级曲线（数值文档 §4.4）', () => {
  it('1 级为 1（基准）', () => {
    expect(levelMultiplier(1, level)).toBe(1)
  })

  it('节点等级倍率对齐 L2 §4.7', () => {
    expect(levelMultiplier(7, level)).toBeCloseTo(1.459, 2)
    expect(levelMultiplier(9, level)).toBeCloseTo(1.654, 2)
    expect(levelMultiplier(15, level)).toBeCloseTo(2.093, 2)
    expect(levelMultiplier(20, level)).toBeCloseTo(2.486, 2)
    expect(levelMultiplier(25, level)).toBeCloseTo(2.677, 2)
  })

  it('递减式增幅累计等于登记的 totalMul', () => {
    expect(levelMultiplier(25, level)).toBeCloseTo(level.totalMul, 2)
  })

  it('单调不减，且超出上限后封顶', () => {
    let prev = 0
    for (let l = 1; l <= level.maxLevel; l += 1) {
      const mul = levelMultiplier(l, level)
      expect(mul).toBeGreaterThanOrEqual(prev)
      prev = mul
    }
    expect(levelMultiplier(30, level)).toBe(levelMultiplier(level.maxLevel, level))
    expect(levelMultiplier(0, level)).toBe(1)
  })
})

describe('skillPointsFor · 技能点（数值文档 §4.4）', () => {
  it('每 2 级 1 点，25 级共 12 点', () => {
    expect(skillPointsFor(1, level)).toBe(0)
    expect(skillPointsFor(2, level)).toBe(1)
    expect(skillPointsFor(3, level)).toBe(1)
    expect(skillPointsFor(25, level)).toBe(12)
    expect(skillPointsFor(99, level)).toBe(12)
  })
})

describe('resolveGrowthStats · 等级 × 境界（数值文档 §4.2）', () => {
  it('HP / ATK / SP 按 L×R 缩放，其余属性不变', () => {
    const mul = levelMultiplier(9, level)
    const stats = resolveGrowthStats(base(), 9, level, rank('shangqing'))
    expect(stats.hp).toBe(Math.floor(800 * mul * 1.25))
    expect(stats.atk).toBe(Math.floor(45 * mul * 1.25))
    expect(stats.sp).toBe(Math.floor(45 * mul * 1.25))
    expect(stats.def).toBe(12)
    expect(stats.mp).toBe(200)
    expect(stats.spd).toBe(300)
    expect(stats.crit).toBe(5)
    expect(stats.critDmg).toBe(1.5)
  })

  it('不修改传入的基础属性', () => {
    const b = base()
    resolveGrowthStats(b, 25, level, rank('taiqing'))
    expect(b.hp).toBe(800)
  })
})

describe('growth × E 曲线 · 与 L0 包络一致（数值文档 §4.8）', () => {
  it('N6 终局（25 级 / 太清 / T6）命中 L0 端点', () => {
    const g = resolveGrowthStats(base(), 25, level, rank('taiqing'))
    const hp = g.hp * eMul(6, 'hpMul')
    const atk = g.atk * eMul(6, 'atkMul')
    const n6 = node('N6')
    // 与 L0 端点偏差 ≤ 2%
    expect(Math.abs(hp - n6.heroHp) / n6.heroHp).toBeLessThan(0.02)
    expect(Math.abs(atk - n6.heroAtk) / n6.heroAtk).toBeLessThan(0.02)
  })

  it('N3 一锚后（9 级 / 上清 / T2）落在容差内', () => {
    const g = resolveGrowthStats(base(), 9, level, rank('shangqing'))
    const hp = g.hp * eMul(2, 'hpMul')
    const atk = g.atk * eMul(2, 'atkMul')
    const n3 = node('N3')
    expect(Math.abs(hp - n3.heroHp) / n3.heroHp).toBeLessThan(0.05)
    expect(Math.abs(atk - n3.heroAtk) / n3.heroAtk).toBeLessThan(0.05)
  })
})
