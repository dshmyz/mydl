/**
 * 效果分类：把 `EffectSpec` 分成「持久型」与「瞬时型」两类，并判定其极性。
 *
 * - **持久型**（statMod / damageTakenMul / damageDealtMul / stackDamage / root / shield / lifesteal）
 *   由 `ModifierSet` 挂载、计时、汇总。
 * - **瞬时型**（heal / knockback / summon）施加即结算，不进入容器，
 *   由技能 / 战斗引擎即时处理。
 *
 * 极性用于「驱散」：负面效果（debuff）可被驱散技移除。
 */

import type { EffectSpec } from '../../data/types/common'

/** 瞬时效果：施加即结算 */
export type InstantEffect = Extract<EffectSpec, { kind: 'heal' | 'knockback' | 'summon' }>

/** 持久效果：进入 Modifier 容器 */
export type PersistentEffect = Exclude<EffectSpec, InstantEffect>

/** 效果极性：增益 / 减益 / 中立 */
export type EffectPolarity = 'buff' | 'debuff' | 'neutral'

export function isInstantEffect(spec: EffectSpec): spec is InstantEffect {
  return spec.kind === 'heal' || spec.kind === 'knockback' || spec.kind === 'summon'
}

export interface PartitionedEffects {
  persistent: PersistentEffect[]
  instant: InstantEffect[]
}

/** 按类型拆分效果列表，保持各自原顺序 */
export function partitionEffects(specs: readonly EffectSpec[]): PartitionedEffects {
  const persistent: PersistentEffect[] = []
  const instant: InstantEffect[] = []
  for (const spec of specs) {
    if (isInstantEffect(spec)) {
      instant.push(spec)
    } else {
      persistent.push(spec)
    }
  }
  return { persistent, instant }
}

/**
 * 判定效果极性。
 *
 * 采用「由数值符号反推」的约定，不新增配置字段：
 *  - statMod：value > 0 增益 / < 0 减益
 *  - damageTakenMul：> 1 易伤（减益）/ < 1 减伤（增益）
 *  - damageDealtMul：> 1 增伤（增益）/ < 1 削弱（减益）
 *  - stackDamage：perStack > 0 增益 / < 0 减益
 *  - root 恒为减益；lifesteal / shield / heal 恒为增益
 *  - knockback / summon 为中立（位移与召唤本身不构成正负 buff）
 */
export function effectPolarity(spec: EffectSpec): EffectPolarity {
  switch (spec.kind) {
    case 'statMod':
      return spec.value > 0 ? 'buff' : spec.value < 0 ? 'debuff' : 'neutral'
    case 'damageTakenMul':
      return spec.value > 1 ? 'debuff' : spec.value < 1 ? 'buff' : 'neutral'
    case 'damageDealtMul':
      return spec.value > 1 ? 'buff' : spec.value < 1 ? 'debuff' : 'neutral'
    case 'stackDamage':
      return spec.perStack > 0 ? 'buff' : spec.perStack < 0 ? 'debuff' : 'neutral'
    case 'root':
      return 'debuff'
    case 'lifesteal':
    case 'shield':
    case 'heal':
      return 'buff'
    case 'knockback':
    case 'summon':
      return 'neutral'
  }
}
