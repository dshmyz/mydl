import { describe, expect, it } from 'vitest'

import type { Stats } from '../../data/types/common'
import { ModifierSet } from './modifierSet'

/** N1 开局（1 人基准）英雄面板，数值文档 §2.3 */
function base(): Stats {
  return { hp: 800, mp: 200, atk: 45, sp: 45, def: 12, spd: 300, dodge: 0, crit: 5, critDmg: 1.5 }
}

describe('ModifierSet · 属性结算', () => {
  it('resolveStats：percent 作用于基础值后再叠加 flat', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.2 }, 'equip:weapon')
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10 }, 'equip:weapon')
    const stats = set.resolveStats(base())
    expect(stats.atk).toBeCloseTo(45 * 1.2 + 10)
    // 未修饰属性保持原值
    expect(stats.hp).toBe(800)
    expect(stats.critDmg).toBe(1.5)
  })

  it('同属性不同来源叠加', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'def', mode: 'flat', value: 6 }, 'robe')
    set.add({ kind: 'statMod', stat: 'def', mode: 'flat', value: 4 }, 'crown')
    expect(set.resolveStats(base()).def).toBe(22)
  })

  it('同来源同属性重复施加只刷新不叠加', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10, duration: 3 }, 'skill')
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10, duration: 3 }, 'skill')
    expect(set.active).toHaveLength(1)
    expect(set.resolveStats(base()).atk).toBe(55)
  })

  it('resolveStats 不修改传入的基础属性', () => {
    const set = new ModifierSet()
    const b = base()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.5 }, 'x')
    set.resolveStats(b)
    expect(b.atk).toBe(45)
  })
})

describe('ModifierSet · 计时与过期', () => {
  it('限时修饰到期后自动移除', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'spd', mode: 'percent', value: -0.2, duration: 2 }, 'boss')
    set.tick(1)
    expect(set.active).toHaveLength(1)
    expect(set.resolveStats(base()).spd).toBeCloseTo(240)
    set.tick(1)
    expect(set.active).toHaveLength(0)
    expect(set.resolveStats(base()).spd).toBe(300)
  })

  it('省略 duration 视为永久，永不因 tick 过期', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.1 }, 'equip')
    set.tick(9999)
    expect(set.active).toHaveLength(1)
  })

  it('同来源重复施加会刷新持续时间', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10, duration: 3 }, 'skill')
    set.tick(2)
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10, duration: 3 }, 'skill')
    set.tick(2) // 若不刷新则此刻已过期
    expect(set.active).toHaveLength(1)
  })

  it('tick(0) 不改变任何状态', () => {
    const set = new ModifierSet()
    set.add({ kind: 'root', duration: 1 }, 'boss')
    const before = set.active[0]?.remaining
    set.tick(0)
    expect(set.active[0]?.remaining).toBe(before)
  })
})

describe('ModifierSet · 移除与驱散', () => {
  it('removeBySource 移除该来源全部修饰并返回数量', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10 }, 'equip:A')
    set.add({ kind: 'statMod', stat: 'def', mode: 'flat', value: 5 }, 'equip:A')
    set.add({ kind: 'statMod', stat: 'def', mode: 'flat', value: 5 }, 'equip:B')
    expect(set.removeBySource('equip:A')).toBe(2)
    expect(set.active).toHaveLength(1)
    expect(set.resolveStats(base()).atk).toBe(45)
    expect(set.resolveStats(base()).def).toBe(17)
  })

  it('dispel 按极性移除减益，增益不受影响', () => {
    const set = new ModifierSet()
    set.add({ kind: 'statMod', stat: 'spd', mode: 'percent', value: -0.2, duration: 2 }, 'boss')
    set.add({ kind: 'root', duration: 1.5 }, 'boss')
    set.add({ kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.2, duration: 5 }, 'self')
    // 首个减益为减速
    expect(set.dispel('debuff', 1)).toHaveLength(1)
    expect(set.active).toHaveLength(2)
    expect(set.isRooted()).toBe(true)
    // 余下减益为定身
    expect(set.dispel('debuff')).toHaveLength(1)
    expect(set.isRooted()).toBe(false)
    // 增益仍在
    expect(set.active).toHaveLength(1)
    expect(set.active[0]?.polarity).toBe('buff')
  })

  it('remove 按 id 移除单个修饰；未知 id 返回 false', () => {
    const set = new ModifierSet()
    const a = set.add({ kind: 'statMod', stat: 'atk', mode: 'flat', value: 10 }, 'x')
    const b = set.add({ kind: 'statMod', stat: 'def', mode: 'flat', value: 10 }, 'y')
    expect(set.remove(a.id)).toBe(true)
    expect(set.remove(b.id)).toBe(true)
    expect(set.remove(b.id)).toBe(false)
    expect(set.active).toHaveLength(0)
  })

  it('clear 清空全部修饰', () => {
    const set = new ModifierSet()
    set.add({ kind: 'root', duration: 1 }, 'boss')
    set.add({ kind: 'shield', flat: 50, duration: 1 }, 'self')
    set.clear()
    expect(set.active).toHaveLength(0)
    expect(set.shieldTotal()).toBe(0)
    expect(set.isRooted()).toBe(false)
  })

  it('isRooted 反映定身状态', () => {
    const set = new ModifierSet()
    expect(set.isRooted()).toBe(false)
    set.add({ kind: 'root', duration: 1.5 }, 'boss')
    expect(set.isRooted()).toBe(true)
    set.tick(1.5)
    expect(set.isRooted()).toBe(false)
  })
})

describe('ModifierSet · 叠层增伤', () => {
  const moqi = {
    kind: 'stackDamage',
    stackId: 'moqi',
    perStack: 0.03,
    maxStacks: 5,
    duration: 8,
  } as const

  it('逐次叠加至上限并刷新持续时间', () => {
    const set = new ModifierSet()
    for (let i = 0; i < 3; i += 1) {
      set.add(moqi, 'zxf_r')
    }
    expect(set.stacksOf('moqi')).toBe(3)
    expect(set.stackDamageBonus()).toBeCloseTo(0.09)
    expect(set.active).toHaveLength(1)

    for (let i = 0; i < 10; i += 1) {
      set.add(moqi, 'zxf_r')
    }
    expect(set.stacksOf('moqi')).toBe(5)
    expect(set.stackDamageBonus()).toBeCloseTo(0.15)
    expect(set.active).toHaveLength(1)
  })

  it('不同 stackId 互不影响', () => {
    const set = new ModifierSet()
    set.add(moqi, 'zxf_r')
    set.add({ ...moqi, stackId: 'shaqi', perStack: 0.05 }, 'other')
    expect(set.stacksOf('moqi')).toBe(1)
    expect(set.stacksOf('shaqi')).toBe(1)
    expect(set.stacksOf('unknown')).toBe(0)
    expect(set.stackDamageBonus()).toBeCloseTo(0.08)
  })

  it('叠层到期清零', () => {
    const set = new ModifierSet()
    set.add(moqi, 'zxf_r')
    set.add(moqi, 'zxf_r')
    set.tick(8)
    expect(set.stacksOf('moqi')).toBe(0)
    expect(set.stackDamageBonus()).toBe(0)
    expect(set.active).toHaveLength(0)
  })
})

describe('ModifierSet · 伤害乘区', () => {
  it('汇总增伤与减伤修正', () => {
    const set = new ModifierSet()
    set.add({ kind: 'damageDealtMul', value: 1.2, duration: 5 }, 'buff:1')
    set.add({ kind: 'damageDealtMul', value: 1.1, duration: 5 }, 'buff:2')
    set.add({ kind: 'damageTakenMul', value: 0.92, duration: 5 }, 'shield')
    expect(set.outgoingBonus()).toBeCloseTo(0.3)
    expect(set.incomingReduction()).toBeCloseTo(0.08)
    // dmgMult = 1 + Σ增伤 − Σ减伤修正（数值文档 §3.1 第 3 步）
    expect(set.damageMultiplier()).toBeCloseTo(1.22)
  })

  it('无修饰时增伤与减伤均为 0', () => {
    const set = new ModifierSet()
    expect(set.outgoingBonus()).toBe(0)
    expect(set.incomingReduction()).toBe(0)
    expect(set.damageMultiplier()).toBe(1)
  })

  it('lifesteal 汇总吸血百分比', () => {
    const set = new ModifierSet()
    set.add({ kind: 'lifesteal', percent: 0.15 }, 'weapon')
    set.add({ kind: 'lifesteal', percent: 0.05 }, 'ring')
    expect(set.lifestealPercent()).toBeCloseTo(0.2)
  })
})

describe('ModifierSet · 护盾', () => {
  it('按固定值建立护盾池并逐次吸收', () => {
    const set = new ModifierSet()
    set.add({ kind: 'shield', flat: 100, duration: 5 }, 'zxf_e')
    expect(set.shieldTotal()).toBe(100)

    const first = set.absorb(60)
    expect(first.absorbed).toBe(60)
    expect(first.overflow).toBe(0)
    expect(set.shieldTotal()).toBe(40)

    const second = set.absorb(50)
    expect(second.absorbed).toBe(40)
    expect(second.overflow).toBe(10)
    expect(set.shieldTotal()).toBe(0)
    expect(set.active).toHaveLength(0)
  })

  it('支持按最大气血百分比：percentOfMaxHp × maxHp', () => {
    const set = new ModifierSet()
    set.add({ kind: 'shield', percentOfMaxHp: 0.2, duration: 5 }, 'zxf_e', { maxHp: 800 })
    expect(set.shieldTotal()).toBeCloseTo(160)
  })

  it('无护盾时伤害全部溢出', () => {
    const set = new ModifierSet()
    const r = set.absorb(30)
    expect(r.absorbed).toBe(0)
    expect(r.overflow).toBe(30)
  })

  it('护盾到期后移除', () => {
    const set = new ModifierSet()
    set.add({ kind: 'shield', flat: 100, duration: 5 }, 'zxf_e')
    set.tick(5)
    expect(set.shieldTotal()).toBe(0)
    expect(set.active).toHaveLength(0)
  })

  it('多个护盾按施加顺序依次吸收', () => {
    const set = new ModifierSet()
    set.add({ kind: 'shield', flat: 30, duration: 5 }, 'a')
    set.add({ kind: 'shield', flat: 30, duration: 5 }, 'b')
    expect(set.shieldTotal()).toBe(60)
    const r = set.absorb(40)
    expect(r.absorbed).toBe(40)
    expect(set.shieldTotal()).toBe(20)
  })
})

describe('ModifierSet · 瞬时效果拦截', () => {
  it('add 拒绝瞬时效果（应由引擎即时结算）', () => {
    const set = new ModifierSet()
    expect(() => set.add({ kind: 'heal', flat: 10 }, 'x')).toThrow()
    expect(() => set.add({ kind: 'knockback', distance: 1 }, 'x')).toThrow()
    expect(() => set.add({ kind: 'summon', monsterId: 'm', count: 1 }, 'x')).toThrow()
  })
})
