import { describe, expect, it } from 'vitest'

import type { EffectSpec } from '../../data/types/common'
import { effectPolarity, isInstantEffect, partitionEffects } from './effects'

describe('effects 分类与极性', () => {
  it('isInstantEffect 仅对 heal / knockback / summon 为真', () => {
    const instants: EffectSpec[] = [
      { kind: 'heal', flat: 50 },
      { kind: 'knockback', distance: 2 },
      { kind: 'summon', monsterId: 'small_snake', count: 2 },
    ]
    const persists: EffectSpec[] = [
      { kind: 'lifesteal', percent: 0.15 },
      { kind: 'shield', flat: 100, duration: 5 },
      { kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.2, duration: 3 },
      { kind: 'damageTakenMul', value: 0.92, duration: 5 },
      { kind: 'damageDealtMul', value: 1.1, duration: 5 },
      { kind: 'stackDamage', stackId: 'moqi', perStack: 0.03, maxStacks: 5, duration: 8 },
      { kind: 'root', duration: 1.5 },
    ]
    for (const spec of instants) {
      expect(isInstantEffect(spec)).toBe(true)
    }
    for (const spec of persists) {
      expect(isInstantEffect(spec)).toBe(false)
    }
  })

  it('partitionEffects 拆分持久 / 瞬时效果且保持原顺序', () => {
    const specs: EffectSpec[] = [
      { kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.2, duration: 3 },
      { kind: 'heal', flat: 50 },
      { kind: 'root', duration: 1 },
      { kind: 'summon', monsterId: 'm', count: 1 },
    ]
    const { persistent, instant } = partitionEffects(specs)
    expect(persistent.map((s) => s.kind)).toEqual(['statMod', 'root'])
    expect(instant.map((s) => s.kind)).toEqual(['heal', 'summon'])
  })

  it('effectPolarity 判定增益 / 减益 / 中立', () => {
    // 减益：负属性、定身、易伤、削弱
    expect(
      effectPolarity({ kind: 'statMod', stat: 'spd', mode: 'percent', value: -0.2, duration: 2 }),
    ).toBe('debuff')
    expect(effectPolarity({ kind: 'root', duration: 1 })).toBe('debuff')
    expect(effectPolarity({ kind: 'damageTakenMul', value: 1.2, duration: 1 })).toBe('debuff')
    expect(effectPolarity({ kind: 'damageDealtMul', value: 0.8, duration: 1 })).toBe('debuff')
    expect(
      effectPolarity({ kind: 'stackDamage', stackId: 'm', perStack: -0.03, maxStacks: 5, duration: 1 }),
    ).toBe('debuff')
    // 增益：正属性、减伤、增伤、吸血、护盾、治疗
    expect(effectPolarity({ kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.2 })).toBe('buff')
    expect(effectPolarity({ kind: 'damageTakenMul', value: 0.92, duration: 1 })).toBe('buff')
    expect(effectPolarity({ kind: 'damageDealtMul', value: 1.2, duration: 1 })).toBe('buff')
    expect(effectPolarity({ kind: 'lifesteal', percent: 0.1 })).toBe('buff')
    expect(effectPolarity({ kind: 'shield', flat: 10, duration: 1 })).toBe('buff')
    expect(effectPolarity({ kind: 'heal', flat: 10 })).toBe('buff')
    // 中立：位移 / 召唤
    expect(effectPolarity({ kind: 'knockback', distance: 2 })).toBe('neutral')
    expect(effectPolarity({ kind: 'summon', monsterId: 'm', count: 1 })).toBe('neutral')
  })
})
