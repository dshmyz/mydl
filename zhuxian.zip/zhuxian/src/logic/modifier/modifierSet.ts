/**
 * Modifier 容器：挂载 / 计时 / 叠加 / 驱散 / 属性结算。
 *
 * 技能、装备词条、BOSS 招式产生的**持久型**效果（见 `effects.ts`）统一进入本容器，
 * 不写任何特殊逻辑（主文档 §6.7「加技能 = 加效果组合，不写新系统」）。
 *
 * 语义约定（与 `EffectSpec` 注释一致）：
 *  - `duration` 省略 = 永久：不因 `tick` 过期，只能由来源移除（`removeBySource`）或 `clear` 清除。
 *  - 同来源同判别的重复施加 → **刷新**持续时间（不叠加，避免同技能连点线性变强）。
 *  - `stackDamage` 例外：按 `stackId` 跨来源累积叠层，上限 `maxStacks`。
 */

import type { EffectSpec, StatKey, Stats } from '../../data/types/common'
import { effectPolarity, isInstantEffect, type EffectPolarity, type PersistentEffect } from './effects'

/** 全部属性键（运行时遍历用，顺序与数值文档 §2.1 一致） */
export const STAT_KEYS: readonly StatKey[] = [
  'hp',
  'mp',
  'atk',
  'sp',
  'def',
  'spd',
  'dodge',
  'crit',
  'critDmg',
]

const PERMANENT = Number.POSITIVE_INFINITY

/** 修饰实例 */
export interface ModifierInstance {
  id: number
  spec: PersistentEffect
  /** 来源标识（如 'zxf_e' / 'equip:weapon' / 'boss_rage'），用于按来源批量移除 */
  source: string
  /** 剩余秒数；Infinity = 永久 */
  remaining: number
  /** 叠层数（仅 stackDamage 有意义，其余恒为 1） */
  stacks: number
  polarity: EffectPolarity
}

/** 护盾吸收结果 */
export interface AbsorbResult {
  /** 被护盾吸收的伤害 */
  absorbed: number
  /** 穿透护盾、需由气血承担的伤害 */
  overflow: number
}

export interface AddOptions {
  /** 施法者最大气血（供 percentOfMaxHp 类护盾换算；缺省则该部分视作 0） */
  maxHp?: number
}

/** 结算用的属性修饰增量（flat 固定值 / percent 百分比） */
export interface StatBonuses {
  flat: Partial<Record<StatKey, number>>
  percent: Partial<Record<StatKey, number>>
}

/**
 * 属性结算：`final = base × (1 + Σpercent) + Σflat`。
 *
 * 与数值文档 §7.1 一致：HP / ATK / SP 走百分比（`Σ装备% = E − 1`），
 * 护甲 / 会心 / 闪避 / 移速 / 真气走固定值（不入 E 曲线）。
 */
export function applyStatBonuses(base: Stats, bonuses: StatBonuses): Stats {
  const result = { ...base }
  for (const key of STAT_KEYS) {
    const percent = bonuses.percent[key] ?? 0
    const flat = bonuses.flat[key] ?? 0
    result[key] = base[key] * (1 + percent) + flat
  }
  return result
}

export class ModifierSet {
  private readonly instances: ModifierInstance[] = []
  /** 判别键 → 实例：用于同键刷新 */
  private readonly byKey = new Map<string, ModifierInstance>()
  /** 实例 id → 判别键：用于移除时同步清理索引 */
  private readonly keyById = new Map<number, string>()
  /** 护盾实例 id → 剩余吸收量 */
  private readonly shieldPool = new Map<number, number>()
  private nextId = 0

  /** 当前全部有效修饰（只读视图） */
  get active(): readonly ModifierInstance[] {
    return this.instances
  }

  /**
   * 挂载一个持久型效果。
   *
   * @throws 传入瞬时型效果（heal / knockback / summon）时抛错——它们应由引擎即时结算
   */
  add(spec: EffectSpec, source = 'unknown', options: AddOptions = {}): ModifierInstance {
    if (isInstantEffect(spec)) {
      throw new Error(
        `ModifierSet.add: ${spec.kind} 为瞬时效果，请先经 partitionEffects 交由引擎即时结算`,
      )
    }

    const key = instanceKey(spec, source)
    if (key !== null) {
      const existing = this.byKey.get(key)
      if (existing) {
        return this.refresh(existing, spec)
      }
    }

    const instance: ModifierInstance = {
      id: (this.nextId += 1),
      spec,
      source,
      remaining: durationOf(spec),
      stacks: 1,
      polarity: effectPolarity(spec),
    }
    this.instances.push(instance)
    if (key !== null) {
      this.byKey.set(key, instance)
      this.keyById.set(instance.id, key)
    }
    if (spec.kind === 'shield') {
      this.shieldPool.set(instance.id, shieldAmount(spec, options.maxHp ?? 0))
    }
    return instance
  }

  /** 批量挂载持久型效果（忽略瞬时型，由调用方先行 partition） */
  addAll(specs: readonly EffectSpec[], source = 'unknown', options: AddOptions = {}): void {
    for (const spec of specs) {
      if (!isInstantEffect(spec)) {
        this.add(spec, source, options)
      }
    }
  }

  /** 推进时间：限时修饰到期即移除；永久修饰不受影响 */
  tick(dt: number): void {
    if (dt === 0) {
      return
    }
    for (let i = this.instances.length - 1; i >= 0; i -= 1) {
      const instance = this.instances[i]
      if (!instance || instance.remaining === PERMANENT) {
        continue
      }
      instance.remaining -= dt
      if (instance.remaining <= 0) {
        this.removeAt(i)
      }
    }
  }

  /** 按 id 移除单个修饰 */
  remove(id: number): boolean {
    const index = this.instances.findIndex((instance) => instance.id === id)
    if (index < 0) {
      return false
    }
    this.removeAt(index)
    return true
  }

  /** 按来源移除全部修饰，返回移除数量 */
  removeBySource(source: string): number {
    let removed = 0
    for (let i = this.instances.length - 1; i >= 0; i -= 1) {
      if (this.instances[i]?.source === source) {
        this.removeAt(i)
        removed += 1
      }
    }
    return removed
  }

  /**
   * 驱散：按极性移除修饰，至多 maxCount 个（默认全部）。
   *
   * 常见用途：治疗 / 净化技移除敌方施加的负面效果（`dispel('debuff')`）。
   */
  dispel(polarity: 'buff' | 'debuff', maxCount = Number.POSITIVE_INFINITY): ModifierInstance[] {
    const removed: ModifierInstance[] = []
    for (let i = 0; i < this.instances.length && removed.length < maxCount; ) {
      const instance = this.instances[i]
      if (instance && instance.polarity === polarity) {
        removed.push(instance)
        this.removeAt(i)
      } else {
        i += 1
      }
    }
    return removed
  }

  /** 清空全部修饰与护盾 */
  clear(): void {
    this.instances.length = 0
    this.byKey.clear()
    this.keyById.clear()
    this.shieldPool.clear()
  }

  // —— 属性结算 ——

  /** 汇总属性修饰增量 */
  statBonuses(): StatBonuses {
    const flat: Partial<Record<StatKey, number>> = {}
    const percent: Partial<Record<StatKey, number>> = {}
    for (const instance of this.instances) {
      const spec = instance.spec
      if (spec.kind !== 'statMod') {
        continue
      }
      const bucket = spec.mode === 'flat' ? flat : percent
      bucket[spec.stat] = (bucket[spec.stat] ?? 0) + spec.value
    }
    return { flat, percent }
  }

  /** 结算最终属性（不改动传入的基础属性） */
  resolveStats(base: Stats): Stats {
    return applyStatBonuses(base, this.statBonuses())
  }

  // —— 伤害乘区 ——

  /** Σ增伤（damageDealtMul 的 value − 1 之和） */
  outgoingBonus(): number {
    let sum = 0
    for (const instance of this.instances) {
      if (instance.spec.kind === 'damageDealtMul') {
        sum += instance.spec.value - 1
      }
    }
    return sum
  }

  /** Σ减伤修正（damageTakenMul 的 1 − value 之和） */
  incomingReduction(): number {
    let sum = 0
    for (const instance of this.instances) {
      if (instance.spec.kind === 'damageTakenMul') {
        sum += 1 - instance.spec.value
      }
    }
    return sum
  }

  /** 本容器视角的增伤修正 `1 + Σ增伤 − Σ减伤修正`（未 clamp，护栏由伤害引擎施加） */
  damageMultiplier(): number {
    return 1 + this.outgoingBonus() - this.incomingReduction()
  }

  // —— 特效查询 ——

  /** 吸血百分比合计 */
  lifestealPercent(): number {
    let sum = 0
    for (const instance of this.instances) {
      if (instance.spec.kind === 'lifesteal') {
        sum += instance.spec.percent
      }
    }
    return sum
  }

  /** 指定叠层 id 的当前层数 */
  stacksOf(stackId: string): number {
    for (const instance of this.instances) {
      if (instance.spec.kind === 'stackDamage' && instance.spec.stackId === stackId) {
        return instance.stacks
      }
    }
    return 0
  }

  /** 叠层增伤合计 `Σ perStack × stacks` */
  stackDamageBonus(): number {
    let sum = 0
    for (const instance of this.instances) {
      if (instance.spec.kind === 'stackDamage') {
        sum += instance.spec.perStack * instance.stacks
      }
    }
    return sum
  }

  /** 是否处于定身状态 */
  isRooted(): boolean {
    return this.instances.some((instance) => instance.spec.kind === 'root')
  }

  /** 护盾剩余吸收量合计 */
  shieldTotal(): number {
    let sum = 0
    for (const remaining of this.shieldPool.values()) {
      sum += remaining
    }
    return sum
  }

  /** 以护盾吸收伤害：按施加顺序消耗护盾池，返回吸收量与溢出量 */
  absorb(damage: number): AbsorbResult {
    let remaining = Math.max(0, damage)
    let absorbed = 0
    const shieldIds = this.instances
      .filter((instance) => instance.spec.kind === 'shield')
      .map((instance) => instance.id)

    for (const id of shieldIds) {
      if (remaining <= 0) {
        break
      }
      const pool = this.shieldPool.get(id) ?? 0
      const take = Math.min(pool, remaining)
      absorbed += take
      remaining -= take
      if (pool - take <= 0) {
        this.remove(id)
      } else {
        this.shieldPool.set(id, pool - take)
      }
    }
    return { absorbed, overflow: remaining }
  }

  // —— 内部 ——

  /** 刷新已有实例：stackDamage 累加叠层，其余更新参数并重置计时 */
  private refresh(existing: ModifierInstance, spec: PersistentEffect): ModifierInstance {
    if (spec.kind === 'stackDamage' && existing.spec.kind === 'stackDamage') {
      existing.stacks = Math.min(existing.stacks + 1, spec.maxStacks)
    }
    existing.spec = spec
    existing.remaining = durationOf(spec)
    existing.polarity = effectPolarity(spec)
    return existing
  }

  private removeAt(index: number): void {
    const instance = this.instances[index]
    if (!instance) {
      return
    }
    this.instances.splice(index, 1)
    this.shieldPool.delete(instance.id)
    const key = this.keyById.get(instance.id)
    if (key !== undefined) {
      // 仅当该键仍指向被移除的实例时才清理，避免误删刷新后的索引
      if (this.byKey.get(key) === instance) {
        this.byKey.delete(key)
      }
      this.keyById.delete(instance.id)
    }
  }
}

/** 效果持续时间；省略 duration = 永久 */
function durationOf(spec: PersistentEffect): number {
  switch (spec.kind) {
    case 'statMod':
      return spec.duration ?? PERMANENT
    case 'lifesteal':
      // 吸血无 duration 字段：来自装备等来源时视为永久，来源移除即失效
      return PERMANENT
    case 'damageTakenMul':
    case 'damageDealtMul':
    case 'stackDamage':
    case 'root':
    case 'shield':
      return spec.duration
  }
}

/** 护盾初始吸收量 */
function shieldAmount(spec: Extract<PersistentEffect, { kind: 'shield' }>, maxHp: number): number {
  return (spec.percentOfMaxHp ?? 0) * maxHp + (spec.flat ?? 0)
}

/**
 * 判别键：同键重复施加即「刷新」而非叠加。
 *
 *  - `statMod` 以 来源 + 属性 + 模式 为键（同装备的两条同名属性合并）
 *  - `stackDamage` 以 `stackId` 为键（叠层跨来源共享，如「魔气」）
 *  - `shield` 返回 null：多个护盾各自独立，不合并
 *  - 其余以 种类 + 来源 为键
 */
function instanceKey(spec: PersistentEffect, source: string): string | null {
  switch (spec.kind) {
    case 'statMod':
      return `statMod|${source}|${spec.stat}|${spec.mode}`
    case 'stackDamage':
      return `stackDamage|${spec.stackId}`
    case 'damageTakenMul':
    case 'damageDealtMul':
    case 'root':
    case 'lifesteal':
      return `${spec.kind}|${source}`
    case 'shield':
      return null
  }
}
