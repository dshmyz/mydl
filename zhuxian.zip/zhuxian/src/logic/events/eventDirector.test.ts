import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { buildGameData } from '../../data/tables'
import type { EventDef, WaveTemplateDef } from '../../data/types/waves'
import type { RngLike } from '../core/rng'
import { DEFAULT_EVENT_CONFIG, EventDirector, type EventSystemConfig } from './eventDirector'

/** 受控 RNG */
function stubRng(rolls: readonly number[] = []): RngLike {
  let cursor = 0
  const next = (): number => {
    const value = rolls[cursor] ?? 1
    cursor += 1
    return value
  }
  return {
    next,
    int: (min, max) => min + Math.floor(next() * (max - min + 1)),
    range: (min, max) => min + next() * (max - min),
    chance: (p) => next() < p,
    pick: <T>(items: readonly T[]): T => items[0] as T,
    weighted: <T>(entries: readonly (readonly [T, number])[]): T => entries[0]?.[0] as T,
    fork: () => stubRng([]),
  }
}

const base = buildGameData()
const index = buildIndex(base)

/** 在真实配置上追加一个「稀有 + 幕二起」事件并挂到 E1，用于验证冷却 / 幕门控 / 保底 */
function withExtraEvent(): { index: ReturnType<typeof buildIndex>; rare: EventDef } {
  const rare: EventDef = {
    id: 'rare_test',
    name: '稀有测试事件',
    rarity: 'rare',
    weight: 2,
    cooldown: 0,
    minAct: 'act2',
    effect: { kind: 'waveTiming', earlySeconds: 10, lateSeconds: 10 },
  }
  const templates: WaveTemplateDef[] = base.waveTemplates.map((t) =>
    t.id === 'E1' ? { ...t, eventHooks: [...t.eventHooks, rare.id] } : t,
  )
  const data = { ...base, events: [...base.events, rare], waveTemplates: templates }
  return { index: buildIndex(data), rare }
}

const forceChance: EventSystemConfig = {
  ...DEFAULT_EVENT_CONFIG,
  injectionChance: { act1: 1, act2: 1, act3: 1 },
}

describe('EventDirector · 注入判定（主文档 附录 E.3）', () => {
  it('未命中注入概率时不触发事件', () => {
    const director = new EventDirector(index)
    const roll = director.roll('E1', 'act1', stubRng([0.99]))
    expect(roll.event).toBeNull()
    expect(roll.timingDelta).toBe(0)
  })

  it('命中后按权重抽出事件，时序修正取提前 / 延后之一', () => {
    const director = new EventDirector(index, forceChance)
    const late = director.roll('E1', 'act1', stubRng([0, 0.5, 0.9]))
    expect(late.event?.id).toBe('beast_timing')
    expect(late.timingDelta).toBe(45) // 0.9 ≥ 0.5 → 延后

    const director2 = new EventDirector(index, forceChance)
    const early = director2.roll('E1', 'act1', stubRng([0, 0.5, 0.1]))
    expect(early.timingDelta).toBe(-30) // 0.1 < 0.5 → 提前
  })
})

describe('EventDirector · 冷却窗口', () => {
  it('命中后 N 波内不再抽到同类事件', () => {
    const director = new EventDirector(index, forceChance)
    const first = director.roll('E1', 'act1', stubRng([0, 0.5, 0.9]))
    expect(first.event?.id).toBe('beast_timing')
    // 冷却 6 波 → 第 2..7 波不可用，第 8 波恢复
    for (let wave = 2; wave <= 7; wave += 1) {
      expect(director.roll('E1', 'act1', stubRng([0, 0.5, 0.9])).event).toBeNull()
    }
    expect(director.roll('E1', 'act1', stubRng([0, 0.5, 0.9])).event?.id).toBe('beast_timing')
  })
})

describe('EventDirector · 幕门控', () => {
  it('未达 minAct 的事件不可抽取', () => {
    const { index: custom, rare } = withExtraEvent()
    const director = new EventDirector(custom, forceChance)
    expect(director.available('E1', 'act1').some((e) => e.id === rare.id)).toBe(false)
    expect(director.available('E1', 'act2').some((e) => e.id === rare.id)).toBe(true)
  })

  it('模板未挂载的事件不可抽取', () => {
    const { index: custom } = withExtraEvent()
    const director = new EventDirector(custom, forceChance)
    // E2 未挂载 rare_test
    expect(director.available('E2', 'act2').some((e) => e.id === 'rare_test')).toBe(false)
  })
})

describe('EventDirector · 保底加权', () => {
  it('稀有 / 史诗事件连续 N 波未出后权重递增，封顶 2 倍', () => {
    const { index: custom, rare } = withExtraEvent()
    // 注入概率置 0：只推进波号，不触发事件
    const director = new EventDirector(custom, {
      ...DEFAULT_EVENT_CONFIG,
      injectionChance: { act1: 0, act2: 0, act3: 0 },
      pityWaves: 3,
    })
    expect(director.effectiveWeight(rare)).toBe(2)
    for (let i = 0; i < 3; i += 1) {
      director.roll('E1', 'act1', stubRng([]))
    }
    expect(director.effectiveWeight(rare)).toBe(3) // ×1.5
    for (let i = 0; i < 3; i += 1) {
      director.roll('E1', 'act1', stubRng([]))
    }
    expect(director.effectiveWeight(rare)).toBe(4) // ×2 封顶
    for (let i = 0; i < 9; i += 1) {
      director.roll('E1', 'act1', stubRng([]))
    }
    expect(director.effectiveWeight(rare)).toBe(4)
  })

  it('普通事件不吃保底加权', () => {
    const director = new EventDirector(index, {
      ...DEFAULT_EVENT_CONFIG,
      injectionChance: { act1: 0, act2: 0, act3: 0 },
    })
    for (let i = 0; i < 10; i += 1) {
      director.roll('E1', 'act1', stubRng([]))
    }
    const common = base.events[0]
    expect(common).toBeDefined()
    expect(director.effectiveWeight(common as EventDef)).toBe(common?.weight ?? 0)
  })
})
