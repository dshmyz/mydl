/**
 * 事件导演：为每一波判定「是否注入随机事件」并给出时序修正。
 *
 * M1 仅「兽潮提前 / 滞后」类时序事件（主文档 附录 E.1–E.4）：
 *  - 命中注入概率后，从该模板 `eventHooks` ∩ 可用事件（幕门控 + 冷却）中按权重抽取；
 *  - 稀有 / 史诗事件吃「保底加权」：连续 N 波未出后权重按步长递增，封顶 `pityMaxMul` 倍；
 *  - 时序修正负值 = 提前、正值 = 延后（作用于下一波倒计时）。
 *
 * 注入概率 / 保底参数在数据层未登记，以可注入的 `EventSystemConfig` 承载，
 * 默认值取自主文档 附录 E.3。
 */

import type { GameDataIndex } from '../../data/indexes'
import type { ActId, Rarity } from '../../data/types/common'
import type { EventDef } from '../../data/types/waves'
import type { RngLike } from '../core/rng'

/** 幕次先后序（用于 minAct 门控比较） */
const ACT_ORDER: readonly ActId[] = ['act1', 'act2', 'act3']

/** 参与保底加权的稀有度 */
const PITY_RARITIES: readonly Rarity[] = ['rare', 'epic']

/** 事件系统参数（主文档 附录 E.3） */
export interface EventSystemConfig {
  /** 逐幕注入概率（每波命中后才会抽事件） */
  injectionChance: Record<ActId, number>
  /** 保底步进窗口（连续 N 波未出即进一档） */
  pityWaves: number
  /** 每档权重增幅 */
  pityStep: number
  /** 保底权重倍数上限 */
  pityMaxMul: number
}

/** 默认参数：act2 取 act1/act3 的线性插值 */
export const DEFAULT_EVENT_CONFIG: EventSystemConfig = {
  injectionChance: { act1: 0.35, act2: 0.425, act3: 0.5 },
  pityWaves: 3,
  pityStep: 0.5,
  pityMaxMul: 2,
}

/** 一次抽取结果：事件（可能为空）+ 时序修正（秒，负=提前 / 正=延后） */
export interface EventRoll {
  event: EventDef | null
  timingDelta: number
}

export class EventDirector {
  /** 已推进的波次数（每次 roll 自增 1） */
  private wave = 0
  private readonly lastFired = new Map<string, number>()
  private readonly config: EventSystemConfig

  constructor(
    private readonly index: GameDataIndex,
    config: EventSystemConfig = DEFAULT_EVENT_CONFIG,
  ) {
    this.config = config
  }

  /** 推进一波并判定事件；未注入 / 无可用事件时返回空事件与 0 时序修正 */
  roll(templateId: string, act: ActId, rng: RngLike): EventRoll {
    this.wave += 1
    const chance = this.config.injectionChance[act] ?? 0
    if (rng.next() >= chance) {
      return { event: null, timingDelta: 0 }
    }
    const pool = this.available(templateId, act)
    if (pool.length === 0) {
      return { event: null, timingDelta: 0 }
    }
    const event = this.select(pool, rng)
    this.lastFired.set(event.id, this.wave)
    const { earlySeconds, lateSeconds } = event.effect
    const timingDelta = rng.next() < 0.5 ? -earlySeconds : lateSeconds
    return { event, timingDelta }
  }

  /** 该模板当前可用的事件（template hooks ∩ 幕门控 ∩ 冷却） */
  available(templateId: string, act: ActId): EventDef[] {
    const template = this.index.template.get(templateId)
    if (!template) {
      return []
    }
    return template.eventHooks
      .map((id) => this.index.event.get(id))
      .filter((event): event is EventDef => event !== undefined && this.isAvailable(event, act))
  }

  /** 事件的当前有效权重（稀有 / 史诗吃保底，普通事件恒为登记权重） */
  effectiveWeight(event: EventDef): number {
    if (!PITY_RARITIES.includes(event.rarity)) {
      return event.weight
    }
    const last = this.lastFired.get(event.id) ?? 0
    const steps = Math.floor((this.wave - last) / this.config.pityWaves)
    const mul = Math.min(1 + steps * this.config.pityStep, this.config.pityMaxMul)
    return event.weight * mul
  }

  private isAvailable(event: EventDef, act: ActId): boolean {
    if (ACT_ORDER.indexOf(event.minAct) > ACT_ORDER.indexOf(act)) {
      return false
    }
    const last = this.lastFired.get(event.id)
    return last === undefined || this.wave - last > event.cooldown
  }

  /** 按有效权重手动加权抽取（消耗一次 rng.next） */
  private select(pool: readonly EventDef[], rng: RngLike): EventDef {
    const entries = pool.map((event) => [event, this.effectiveWeight(event)] as const)
    const total = entries.reduce((sum, [, weight]) => sum + weight, 0)
    let roll = rng.next() * total
    for (const [event, weight] of entries) {
      roll -= weight
      if (roll < 0) {
        return event
      }
    }
    // 浮点误差兜底：返回最后一项
    return (entries[entries.length - 1] as readonly [EventDef, number])[0]
  }
}
