/**
 * 技能引擎：境界门控 + 冷却 / 真气校验 + 效果解析。
 *
 * 只负责「能不能放、放了之后有哪些效果」，不决定命中目标集合——
 * 目标选取依赖空间位置，交由战斗编排层按 `shape / radius / range` 处理。
 * 效果全部是 `EffectSpec` 原语（主文档 §6.7），拆分为持久（进 ModifierSet）
 * 与瞬时（治疗 / 击退 / 召唤，由调用方即时结算）两类。
 */

import type { GameDataIndex } from '../../data/indexes'
import type { DamageType, EffectSpec, Rank, TargetShape } from '../../data/types/common'
import type { SkillDef } from '../../data/types/units'
import { partitionEffects, type InstantEffect, type PersistentEffect } from '../modifier/effects'
import type { SkillState } from './skillState'

/** 释放被拒的原因 */
export type CastRejection = 'unknown' | 'rank' | 'cooldown' | 'mp'

/** 技能在当前境界下解析出的实际参数（含境界强化覆写） */
export interface ResolvedSkill {
  skill: SkillDef
  /** 生效倍率（含境界强化） */
  rate: number
  /** 生效效果（基础 + 境界强化附加） */
  effects: EffectSpec[]
  persistent: PersistentEffect[]
  instant: InstantEffect[]
  shape: TargetShape
  radius?: number
  range?: number
  damageType?: DamageType
  mpCost: number
  cooldown: number
}

export type CastResult =
  | { ok: true; outcome: ResolvedSkill }
  | { ok: false; reason: CastRejection }

export class SkillEngine {
  constructor(private readonly index: GameDataIndex) {}

  /** 境界解锁：`requiresRank` 为空则恒可释放；否则当前境界需 ≥ 所需境界（按 ranks 表顺序） */
  isUnlocked(skillId: string, rank: Rank): boolean {
    const skill = this.index.skill.get(skillId)
    if (!skill) {
      return false
    }
    return this.meetsRank(skill, rank)
  }

  /** 解析技能在当前境界下的参数 */
  resolve(skillId: string, rank: Rank): ResolvedSkill {
    const skill = this.index.skill.get(skillId)
    if (!skill) {
      throw new Error(`技能引擎：未知技能「${skillId}」`)
    }
    const upgrade = skill.upgrades?.find((u) => u.rank === rank)
    const effects: EffectSpec[] = [...skill.effects, ...(upgrade?.extraEffects ?? [])]
    const { persistent, instant } = partitionEffects(effects)
    return {
      skill,
      rate: upgrade?.rate ?? skill.rate ?? 1,
      effects,
      persistent,
      instant,
      shape: skill.shape,
      radius: skill.radius,
      range: skill.range,
      damageType: skill.damageType,
      mpCost: skill.mpCost,
      cooldown: skill.cooldown,
    }
  }

  /** 校验可释放性：返回拒绝原因，可释放时为 null */
  canCast(skillId: string, state: SkillState, rank: Rank): CastRejection | null {
    const skill = this.index.skill.get(skillId)
    if (!skill) {
      return 'unknown'
    }
    if (!this.meetsRank(skill, rank)) {
      return 'rank'
    }
    if (!state.isReady(skillId)) {
      return 'cooldown'
    }
    if (state.mp < skill.mpCost) {
      return 'mp'
    }
    return null
  }

  /** 释放：通过校验后扣真气、进入冷却，返回解析后的效果 */
  cast(skillId: string, state: SkillState, rank: Rank): CastResult {
    const skill = this.index.skill.get(skillId)
    if (!skill) {
      return { ok: false, reason: 'unknown' }
    }
    if (!this.meetsRank(skill, rank)) {
      return { ok: false, reason: 'rank' }
    }
    if (!state.isReady(skillId)) {
      return { ok: false, reason: 'cooldown' }
    }
    if (!state.spend(skill.mpCost)) {
      return { ok: false, reason: 'mp' }
    }
    state.setCooldown(skillId, skill.cooldown)
    return { ok: true, outcome: this.resolve(skillId, rank) }
  }

  private meetsRank(skill: SkillDef, rank: Rank): boolean {
    if (!skill.requiresRank) {
      return true
    }
    const order = [...this.index.rank.keys()]
    const current = order.indexOf(rank)
    const required = order.indexOf(skill.requiresRank)
    return current >= 0 && required >= 0 && current >= required
  }
}
