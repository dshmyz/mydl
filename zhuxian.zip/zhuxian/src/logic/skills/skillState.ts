/**
 * 技能的运行时状态：真气与冷却。
 *
 * 与技能「定义」（`SkillDef`）分离：定义是只读配置，状态是每个单位各自的实例。
 * 冷却以「剩余秒数」存储，随固定步进 `tick` 递减；归零即视为就绪。
 */

export interface SkillStateInit {
  mp: number
  maxMp: number
}

export class SkillState {
  mp: number
  readonly maxMp: number
  private readonly cooldowns = new Map<string, number>()

  constructor(init: SkillStateInit) {
    this.mp = init.mp
    this.maxMp = init.maxMp
  }

  /** 剩余冷却秒数（未冷却为 0） */
  cooldownRemaining(skillId: string): number {
    return this.cooldowns.get(skillId) ?? 0
  }

  isReady(skillId: string): boolean {
    return this.cooldownRemaining(skillId) <= 0
  }

  setCooldown(skillId: string, seconds: number): void {
    if (seconds > 0) {
      this.cooldowns.set(skillId, seconds)
    }
  }

  /** 推进冷却；非正时长视为无操作 */
  tick(dt: number): void {
    if (dt <= 0) {
      return
    }
    for (const [skillId, remaining] of this.cooldowns) {
      const next = remaining - dt
      if (next <= 0) {
        this.cooldowns.delete(skillId)
      } else {
        this.cooldowns.set(skillId, next)
      }
    }
  }

  /** 扣真气；不足则返回 false 且不改变状态 */
  spend(cost: number): boolean {
    if (this.mp < cost) {
      return false
    }
    this.mp -= cost
    return true
  }

  /** 回复真气（不超过上限） */
  restore(amount: number): void {
    this.mp = Math.min(this.maxMp, this.mp + amount)
  }
}
