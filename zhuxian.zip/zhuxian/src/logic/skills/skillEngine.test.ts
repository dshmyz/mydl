import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { buildGameData } from '../../data/tables'
import type { Rank } from '../../data/types/common'
import { SkillState } from './skillState'
import { SkillEngine } from './skillEngine'

const data = buildGameData()
const index = buildIndex(data)
const engine = new SkillEngine(index)

describe('SkillState · 真气与冷却', () => {
  it('初始化真气与冷却表', () => {
    const state = new SkillState({ mp: 100, maxMp: 200 })
    expect(state.mp).toBe(100)
    expect(state.maxMp).toBe(200)
    expect(state.cooldownRemaining('zxf_q')).toBe(0)
    expect(state.isReady('zxf_q')).toBe(true)
  })

  it('setCooldown / tick 递减，归零后清零', () => {
    const state = new SkillState({ mp: 100, maxMp: 200 })
    state.setCooldown('zxf_q', 5)
    expect(state.cooldownRemaining('zxf_q')).toBe(5)
    state.tick(2)
    expect(state.cooldownRemaining('zxf_q')).toBeCloseTo(3)
    state.tick(3)
    expect(state.cooldownRemaining('zxf_q')).toBe(0)
    expect(state.isReady('zxf_q')).toBe(true)
  })

  it('冷却相互独立', () => {
    const state = new SkillState({ mp: 100, maxMp: 200 })
    state.setCooldown('zxf_q', 5)
    state.setCooldown('zxf_e', 18)
    state.tick(5)
    expect(state.isReady('zxf_q')).toBe(true)
    expect(state.isReady('zxf_e')).toBe(false)
  })

  it('spend 扣真气且不允许透支', () => {
    const state = new SkillState({ mp: 30, maxMp: 200 })
    expect(state.spend(20)).toBe(true)
    expect(state.mp).toBe(10)
    expect(state.spend(20)).toBe(false)
    expect(state.mp).toBe(10)
  })
})

describe('SkillEngine · 境界门控', () => {
  it('R 技在玉清境锁定，上清境解锁', () => {
    expect(engine.isUnlocked('zxf_r', 'yuqing')).toBe(false)
    expect(engine.isUnlocked('zxf_r', 'shangqing')).toBe(true)
    expect(engine.isUnlocked('zxf_r', 'taiqing')).toBe(true)
    expect(engine.isUnlocked('zxf_q', 'yuqing')).toBe(true)
  })

  it('锁定技能不可释放（reason=rank）', () => {
    const state = new SkillState({ mp: 200, maxMp: 200 })
    const result = engine.cast('zxf_r', state, 'yuqing')
    expect(result).toEqual({ ok: false, reason: 'rank' })
    expect(state.mp).toBe(200)
    expect(state.isReady('zxf_r')).toBe(true)
  })
})

describe('SkillEngine · 冷却与真气', () => {
  it('释放成功扣除真气并进入冷却', () => {
    const state = new SkillState({ mp: 200, maxMp: 200 })
    const result = engine.cast('zxf_q', state, 'yuqing')
    expect(result.ok).toBe(true)
    expect(state.mp).toBe(180) // mpCost 20
    expect(state.cooldownRemaining('zxf_q')).toBe(5)
  })

  it('冷却中再次释放被拒（reason=cooldown）', () => {
    const state = new SkillState({ mp: 200, maxMp: 200 })
    engine.cast('zxf_q', state, 'yuqing')
    expect(engine.cast('zxf_q', state, 'yuqing')).toEqual({ ok: false, reason: 'cooldown' })
  })

  it('真气不足被拒（reason=mp），且不扣真气不设冷却', () => {
    const state = new SkillState({ mp: 10, maxMp: 200 })
    expect(engine.cast('zxf_q', state, 'yuqing')).toEqual({ ok: false, reason: 'mp' })
    expect(state.mp).toBe(10)
    expect(state.isReady('zxf_q')).toBe(true)
  })

  it('未知技能被拒（reason=unknown）', () => {
    const state = new SkillState({ mp: 200, maxMp: 200 })
    expect(engine.cast('nope', state, 'yuqing')).toEqual({ ok: false, reason: 'unknown' })
  })
})

describe('SkillEngine · 效果解析', () => {
  it('R 技在上清境为基础倍率，太清境强化倍率并附加治疗', () => {
    const shangqing = engine.resolve('zxf_r', 'shangqing')
    expect(shangqing.rate).toBe(1.6)
    expect(shangqing.effects.some((e) => e.kind === 'heal')).toBe(false)

    const taiqing = engine.resolve('zxf_r', 'taiqing')
    expect(taiqing.rate).toBe(2.0)
    expect(taiqing.effects.some((e) => e.kind === 'heal')).toBe(true)
  })

  it('持久 / 瞬时效果按类型拆分', () => {
    const state = new SkillState({ mp: 200, maxMp: 200 })
    const e = engine.cast('zxf_e', state, 'yuqing')
    if (!e.ok) {
      throw new Error('zxf_e 应可释放')
    }
    expect(e.outcome.persistent.map((p) => p.kind).sort()).toEqual(['damageTakenMul', 'shield'])
    expect(e.outcome.instant).toHaveLength(0)

    const boss = engine.resolve('hx_rage', 'yuqing')
    expect(boss.persistent.every((p) => p.kind === 'statMod')).toBe(true)
    expect(boss.instant.map((i) => i.kind)).toEqual(['summon'])
  })

  it('技能携带作用形态与距离 / 半径', () => {
    const skill = engine.resolve('zxf_w', 'yuqing')
    expect(skill.shape).toBe('cone')
    expect(skill.radius).toBe(2.5)
    expect(skill.range).toBe(2.5)
  })
})

describe('SkillEngine · 境界顺序来自配置', () => {
  it('resolvedRank 的解锁判断遵循 ranks 表顺序而非硬编码', () => {
    const order: Rank[] = data.ranks.map((r) => r.id)
    expect(order.indexOf('yuqing')).toBeLessThan(order.indexOf('shangqing'))
    expect(order.indexOf('shangqing')).toBeLessThan(order.indexOf('taiqing'))
    // 太清可继续释放 R
    const state = new SkillState({ mp: 200, maxMp: 200 })
    expect(engine.cast('zxf_r', state, 'taiqing').ok).toBe(true)
  })
})
