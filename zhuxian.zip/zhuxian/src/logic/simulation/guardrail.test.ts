import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { buildGameData } from '../../data/tables'
import type { IntervalDef } from '../../data/types/numeric'
import {
  buildGuardrailReport,
  classify,
  heroTtl,
  minionTtk,
  RHYTHM_BANDS,
  type GuardrailRow,
} from './guardrail'

const data = buildGameData()
const index = buildIndex(data)

function nodeOf(id: string) {
  const found = data.nodes.find((n) => n.id === id)
  if (!found) {
    throw new Error(`缺少节点 ${id}`)
  }
  return found
}

function intervalOf(id: 'I' | 'II' | 'III'): IntervalDef {
  const found = data.intervals.find((i) => i.id === id)
  if (!found) {
    throw new Error(`缺少区间 ${id}`)
  }
  return found
}

/** 该档位的护甲 K（缺表即失败，与伤害引擎 fail fast 同源） */
function armorKOf(tier: number): number {
  const row = index.tierArmorK.get(tier as 1 | 2 | 3 | 4 | 5 | 6)
  if (!row) {
    throw new Error(`缺少档位 T${tier} 的护甲 K`)
  }
  return row.k
}

/** 小怪 DEF = 同档标准 DEF × defRatio（数值文档 §2.4） */
function standardDefOf(tier: number): number {
  const row = index.tierArmorK.get(tier as 1 | 2 | 3 | 4 | 5 | 6)
  if (!row) {
    throw new Error(`缺少档位 T${tier} 的标准 DEF`)
  }
  return row.standardDef
}

describe('minionTtk / heroTtl · 纯函数（数值文档 §3.1 减伤 / §3.5 手感）', () => {
  it('英雄打小怪的 TTK = 小怪HP / (ATK×攻速×(1−defRed))', () => {
    const minionHp = 32
    const minionDef = 7.2 // T1 标准 DEF 12 × 0.6
    const k = 28
    const ttk = minionTtk({ minionHp, heroAtk: 45, heroAttackSpeed: 1.3, minionDef, k })
    const defRed = minionDef / (minionDef + k)
    const expected = minionHp / (45 * 1.3 * (1 - defRed))
    expect(ttk).toBeCloseTo(expected, 10)
  })

  it('6 只小怪围殴英雄的 TTL = 英雄HP / (数量×ATK×(1−defRed))', () => {
    const ttl = heroTtl({ heroHp: 800, minionAtk: 18, minionCount: 6, heroDef: 12, k: 28 })
    const defRed = 12 / (12 + 28) // 0.3
    expect(defRed).toBeCloseTo(0.3, 10)
    expect(ttl).toBeCloseTo(800 / (6 * 18 * (1 - defRed)), 10)
    expect(ttl).toBeCloseTo(10.582, 3)
  })

  it('减伤率受 75% 硬上限约束（同源护栏常量）', () => {
    // DEF 巨大时 defRed 被钳到 limits.defRedMax = 0.75 → DPS 为 ATK×攻速×0.25
    const ttk = minionTtk({ minionHp: 100, heroAtk: 100, heroAttackSpeed: 1, minionDef: 1e9, k: 1 })
    expect(ttk).toBeCloseTo(100 / (100 * 1 * 0.25), 10)
  })
})

describe('classify · 节奏带判定（数值文档 §9.2）', () => {
  const band = RHYTHM_BANDS.minion // 目标 0.65–1.0s，容差 ±20% → [0.52, 1.2]

  it('带内返回 in', () => {
    expect(classify(0.8, band)).toBe('in')
    expect(classify(0.65, band)).toBe('in')
    expect(classify(1.0, band)).toBe('in')
  })

  it('容差扩边后的边界（含）仍为 in', () => {
    expect(classify(0.65 * 0.8, band)).toBe('in') // 下界 0.52
    expect(classify(1.0 * 1.2, band)).toBe('in') // 上界 1.2
  })

  it('带外返回 out', () => {
    expect(classify(0.51, band)).toBe('out')
    expect(classify(1.21, band)).toBe('out')
    expect(classify(2, band)).toBe('out')
  })

  it('节奏带常量表覆盖 §9.2 七类对象', () => {
    expect(Object.keys(RHYTHM_BANDS)).toEqual([
      'minion',
      'elite',
      'waveBoss',
      'wildBoss',
      'anchorBoss',
      'heroTtlMinions',
      'heroTtlAnchor',
    ])
    expect(RHYTHM_BANDS.heroTtlMinions.target).toEqual([10, 12])
  })
})

describe('buildGuardrailReport · 6 节点 × 3 区间 × N（数值文档 §9.3）', () => {
  const rows = buildGuardrailReport(data, index)

  it('产出 108 行（6 × 3 × 6）', () => {
    expect(rows).toHaveLength(108)
    const combos = new Set(rows.map((r) => `${r.nodeId}|${r.intervalId}|${r.players}`))
    expect(combos.size).toBe(108)
  })

  it('所有 TTK / TTL 均为有限正数', () => {
    for (const row of rows) {
      expect(Number.isFinite(row.minionTtk)).toBe(true)
      expect(Number.isFinite(row.heroTtl)).toBe(true)
      expect(row.minionTtk).toBeGreaterThan(0)
      expect(row.heroTtl).toBeGreaterThan(0)
    }
  })

  it('N=1 的 minionTtk 与纯函数口径一致（区间中段 u=0.5）', () => {
    const node = nodeOf('N1')
    const interval = intervalOf('I')
    const row = rows.find(
      (r): r is GuardrailRow => r.nodeId === 'N1' && r.intervalId === 'I' && r.players === 1,
    )
    if (!row) {
      throw new Error('缺少 N1 / 区间Ⅰ / 1 人 行')
    }
    const tier = 1 // tierAt(I, 0.5) = T1
    const minionDef = standardDefOf(tier) * data.derivation.minion.defRatio
    const k = armorKOf(tier)
    const mid = interval.hp[0] * Math.sqrt(interval.hp[1] / interval.hp[0]) // u=0.5 几何插值
    const expected = minionTtk({
      minionHp: mid,
      heroAtk: node.heroAtk,
      heroAttackSpeed: data.derivation.heroAttackSpeed,
      minionDef,
      k,
    })
    expect(row.minionTtk).toBeCloseTo(expected, 10)
  })

  it('heroTtl 与人数 N 无关（伤害不随人数缩放，数值文档 §6.4）', () => {
    const forNodeAndInterval = rows
      .filter((r) => r.nodeId === 'N4' && r.intervalId === 'III')
      .map((r) => r.heroTtl)
    expect(new Set(forNodeAndInterval).size).toBe(1)
  })

  it('群怪 HP 按人数 hpMul 缩放 → 队伍 TTK 随 N 单调不减（6 人 ≈ 1 人的 hpMul(6)/6）', () => {
    const group = rows
      .filter((r) => r.nodeId === 'N2' && r.intervalId === 'II')
      .sort((a, b) => a.players - b.players)
    const ttks = group.map((r) => r.minionTtk)
    // (hpMul(N) / N) 单调递减：1 → 2.82/6
    for (let i = 1; i < ttks.length; i += 1) {
      expect(ttks[i]).toBeLessThan(ttks[i - 1] as number)
    }
    const ttk1 = ttks[0] as number
    const ttk6 = ttks[5] as number
    expect(ttk6 / ttk1).toBeCloseTo(2.82 / 6, 2)
  })
})

describe('N1 锚点 · 护栏验收（数值文档 §3.5 / §9.2）', () => {
  const node = nodeOf('N1')
  const interval = intervalOf('I')
  const tier = 1
  const k = armorKOf(tier)
  const minionDef = standardDefOf(tier) * data.derivation.minion.defRatio

  // 1 人 / 区间Ⅰ u=0：端点严格落在 N1（HP 32 / ATK 18），对齐 §3.5 worked example
  const ttk = minionTtk({
    minionHp: interval.hp[0],
    heroAtk: node.heroAtk,
    heroAttackSpeed: data.derivation.heroAttackSpeed,
    minionDef,
    k,
  })
  const ttl = heroTtl({
    heroHp: node.heroHp,
    minionAtk: interval.atk[0],
    minionCount: 6,
    heroDef: node.heroDef,
    k,
  })

  it('minionTtk ≈ 0.67s（±5%）且落在小怪节奏带 0.65–1.0s 内', () => {
    const target = 0.67
    expect(Math.abs(ttk - target) / target).toBeLessThanOrEqual(0.05)
    expect(classify(ttk, RHYTHM_BANDS.minion)).toBe('in')
  })

  it('heroTtl ≈ 10.6s（±5%）且落在英雄 TTL 节奏带 10–12s 内', () => {
    const target = 10.6
    expect(Math.abs(ttl - target) / target).toBeLessThanOrEqual(0.05)
    expect(classify(ttl, RHYTHM_BANDS.heroTtlMinions)).toBe('in')
  })

  it('N1 锚点通过 headless 节奏护栏（M1 验收 ≥1 条绿）', () => {
    expect(classify(ttk, RHYTHM_BANDS.minion)).toBe('in')
    expect(classify(ttl, RHYTHM_BANDS.heroTtlMinions)).toBe('in')
  })
})
