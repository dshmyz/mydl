import { describe, expect, it } from 'vitest'

import { recipeKey } from '../../data/indexes'
import { loadGameData } from '../../data/load'
import type { RecipeDef } from '../../data/types/equipment'
import { Battle } from '../battle/battle'
import { DEFAULT_BATTLE_CONFIG, type BattleConfig } from '../battle/config'
import { decideHeroIntent } from '../battle/heroAi'
import { EventDirector } from '../events/eventDirector'
import { ANCHOR_REFERENCE_PLAYERS, WaveDirector } from '../waves/waveDirector'

const { data, index } = loadGameData()

/** 关闭随机事件：让准备时长与波次内容完全确定（同 seed 可复现） */
const noEvents = new EventDirector(index, {
  injectionChance: { act1: 0, act2: 0, act3: 0 },
  pityWaves: 3,
  pityStep: 0.5,
  pityMaxMul: 2,
})

/** 测试用临时爆发修饰来源：模拟「限时窗内击杀」，隔离单测对真实数值平衡的依赖 */
const TEST_BURST_SOURCE = 'test:burst'

/** 缩短版一局的模拟时长上限（秒），避免推进缺陷导致用例挂起 */
const RUN_BUDGET_SECONDS = 1200

/** 锚点一 BOSS id（主文档 附录 F.1） */
const ANCHOR_BOSS_ID = 'heishui_xuanshe'

/** 1 人锚点一 BOSS（真实生成链路产物，供链路与数值护栏交叉核对） */
const SOLO_ANCHOR_BOSS = new WaveDirector(data, index).anchorBoss(ANCHOR_BOSS_ID, 1)

/** 锚点限时窗（秒，附录 D.5） */
const ANCHOR_WINDOW_SECONDS = DEFAULT_BATTLE_CONFIG.wave.anchorWindowSeconds

/** 配置补丁：`field` / `wave` 支持深层覆盖（浅 `Partial` 无法只改嵌套里的个别字段） */
type BattleConfigPatch = Omit<Partial<BattleConfig>, 'field' | 'wave'> & {
  field?: Partial<BattleConfig['field']>
  wave?: Partial<BattleConfig['wave']>
}

function make(over: BattleConfigPatch = {}): Battle {
  const config: BattleConfig = {
    ...DEFAULT_BATTLE_CONFIG,
    ...over,
    field: { ...DEFAULT_BATTLE_CONFIG.field, ...over.field },
    wave: { ...DEFAULT_BATTLE_CONFIG.wave, ...over.wave },
  }
  return new Battle({ data, index, config, events: noEvents })
}

/** 法宝线 T1→T2 升档配方（数值文档 §8.2） */
function weaponRecipe(): RecipeDef {
  const recipe = index.recipe.get(recipeKey('weapon', 1))
  if (!recipe) {
    throw new Error('缺少法宝线 T1→T2 配方')
  }
  return recipe
}

/**
 * 用 headless 英雄 AI 驱动缩短版一局，返回可断言的过程事实。
 *
 * 过程约定（模拟玩家的一局操作）：
 *  - 每帧产出一份 `HeroIntent`（移动 + 施法），逐帧步进 `Battle`；
 *  - 合成材料足够时立即合成并装备（法宝线 T1→T2）；
 *  - 锚点一 BOSS 出现（限时战 `active`）后挂上爆发修饰秒杀，模拟「限时窗内击杀」。
 */
interface RunFacts {
  waves: number
  kills: number
  anchorReached: boolean
  crafted: boolean
  heroDeaths: number
  /** 锚点一 BOSS 的初始 HP（供数值护栏核对，来自真实生成链路） */
  anchorBossHp: number
}

function playShortRun(): { battle: Battle; facts: RunFacts } {
  const recipe = weaponRecipe()
  // 核心耐久抬高为**测试脚手架**：把「静态 bot 因无回复机制反复阵亡」对推进的干扰隔离掉，
  // 让用例只验证「开局 → 锚点一 → 突破」的链路本身，而不绑定尚未调参的原型耐久值。
  const battle = make({
    coreMaxHp: 1_000_000,
    // 测试脚手架：锚点 BOSS 攻击距离 1.6，取 2 让英雄能在其停步前反击（同 battle.test.ts 口径）
    heroAttackRange: 2,
    wave: {
      prepSeconds: 2,
      minPrepSeconds: 0,
      anchorPrepSeconds: 1,
      anchorWindowSeconds: 90,
      anchorKillThreshold: 70,
    },
  })

  const dt = battle.config.dt
  const maxSteps = Math.round(RUN_BUDGET_SECONDS / dt)
  let anchorReached = false
  let crafted = false
  let anchorBossHp = 0

  for (let i = 0; i < maxSteps && battle.status === 'running'; i += 1) {
    battle.step(dt, decideHeroIntent(battle, index))

    if (!anchorReached && battle.challenge.status === 'active') {
      anchorReached = true
      anchorBossHp = battle.challenge.bossHp
      // 已知偏差（如实记录，不掩盖）：锚点 BOSS 以「4 人基准」登记，而 headless bot 站桩不走位、
      // 且设计无任何气血回复机制（唯一恢复手段是阵亡→复活满血），单人静态 bot无法在其攻击节奏下
      // 存活到自然击杀。故此处用修饰爆杀来模拟「玩家在限时窗内完成击杀」，只收敛链路，不校验数值平衡。
      battle.hero.modifiers.add(
        { kind: 'statMod', stat: 'atk', mode: 'flat', value: 100000 },
        TEST_BURST_SOURCE,
        { maxHp: battle.hero.maxHp },
      )
    }

    if (!crafted && battle.canCraft(recipe)) {
      crafted = battle.craftAndEquip(recipe)
    }
  }

  return {
    battle,
    facts: {
      waves: battle.scheduler.waveNumber,
      kills: battle.kills,
      anchorReached,
      crafted,
      heroDeaths: battle.heroLife.revives,
      anchorBossHp,
    },
  }
}

describe('Battle · 缩短版一局（headless AI 驱动，附录 F.3 第 20 步）', () => {
  const { battle, facts } = playShortRun()

  it('AI 自开局推进到锚点一：达到累计击杀阈值并开启限时战', () => {
    expect(facts.anchorReached).toBe(true)
    expect(facts.kills).toBeGreaterThanOrEqual(70)
    // 设计目标 ≈8–10 波到锚点一（附录 F.3 第 20 步）；留少量余量以容忍模板池调整
    expect(facts.waves).toBeGreaterThanOrEqual(6)
    expect(facts.waves).toBeLessThanOrEqual(12)
  })

  it('法宝线 T1→T2 在局内依需合成并装备（F.1 装备闭环）', () => {
    expect(facts.crafted).toBe(true)
    expect(battle.items).toContain('weapon_t2')
  })

  it('限时击杀锚点一 BOSS → 通关并授予渡劫机会', () => {
    // 局内生成的 BOSS 血量与数值护栏同口径（1 人锚点 BOSS），证明链路未偏离生成规则
    expect(facts.anchorBossHp).toBeCloseTo(SOLO_ANCHOR_BOSS.stats.hp, 6)
    expect(battle.status).toBe('anchorCleared')
    expect(battle.challenge.status).toBe('cleared')
    expect(battle.canBreakthrough()).toBe(true)
  })

  it('通关后可突破上清，解锁 R 且渡劫机会被消费', () => {
    expect(battle.breakthrough()).toBe(true)
    expect(battle.hero.rank).toBe('shangqing')
    expect(battle.canBreakthrough()).toBe(false)
    expect(battle.breakthrough()).toBe(false)
  })
})

describe('锚点一数值护栏 · 限时窗内可杀（附录 F.4 / 数值文档 §2.2）', () => {
  const boss = SOLO_ANCHOR_BOSS

  it('1 人锚点 BOSS HP = 4 人基准 ÷4 ×机制乘数', () => {
    // targetHp4p 11000 ÷ 4 人基准 × bossMul(1) × 机制乘数 mid(0.8) = 2200
    const expected =
      (11000 / ANCHOR_REFERENCE_PLAYERS) * 1 * data.mechanismMul.mid
    expect(boss.stats.hp).toBeCloseTo(expected, 6)
    expect(boss.stats.hp).toBeCloseTo(2200, 6)
  })

  it('N1 英雄 DPS × 限时窗 ≥ 1 人锚点 BOSS HP（限时窗内可杀）', () => {
    const node = data.nodes.find((n) => n.id === 'N1')
    const armor = index.tierArmorK.get(boss.tier)
    if (!node || !armor) {
      throw new Error('缺少 N1 节点或锚点 BOSS 档位护甲定义')
    }
    // 与伤害引擎同口径的减伤：defRed = DEF / (DEF + K×armorKMult)，带上限（数值文档 §3.1/§3.4）
    const k = armor.k * boss.armorKMult
    const defRed = Math.min(boss.stats.def / (boss.stats.def + k), data.limits.defRedMax)
    const heroDps = node.heroAtk * data.derivation.heroAttackSpeed * (1 - defRed)

    expect(heroDps * ANCHOR_WINDOW_SECONDS).toBeGreaterThanOrEqual(boss.stats.hp)
    // 等价表述：单人 TTK 落在限时窗内
    expect(boss.stats.hp / heroDps).toBeLessThanOrEqual(ANCHOR_WINDOW_SECONDS)
  })
})

/**
 * 真实配置（**零脚手架**）下一局：静态 headless bot 必须自主完成
 * 「开局 → 锚点一限时击杀 → 上清突破」，即附录 F.4「完整可玩」的验收本身。
 *
 * 与上面 `playShortRun` 的区别：不抬高核心耐久、不放宽攻击距离、不加爆发修饰，
 * 参数全部取 `DEFAULT_BATTLE_CONFIG` 的实测调参值 —— 用来守「原型展开参数」的调参结果。
 */
function playFullRunReal(): { battle: Battle; facts: RunFacts } {
  const recipe = weaponRecipe()
  const battle = make()
  const dt = battle.config.dt
  const maxSteps = Math.round(RUN_BUDGET_SECONDS / dt)
  let anchorReached = false
  let crafted = false
  let anchorBossHp = 0

  for (let i = 0; i < maxSteps && battle.status === 'running'; i += 1) {
    battle.step(dt, decideHeroIntent(battle, index))

    if (!anchorReached && battle.challenge.status === 'active') {
      anchorReached = true
      anchorBossHp = battle.challenge.bossHp
    }
    if (!crafted && battle.canCraft(recipe)) {
      crafted = battle.craftAndEquip(recipe)
    }
  }

  return {
    battle,
    facts: {
      waves: battle.scheduler.waveNumber,
      kills: battle.kills,
      anchorReached,
      crafted,
      heroDeaths: battle.heroLife.revives,
      anchorBossHp,
    },
  }
}

describe('Battle · 真实配置一局（零脚手架，附录 F.4 完整可玩）', () => {
  const { battle, facts } = playFullRunReal()

  it('静态 bot 自主推进到锚点一并开启限时战', () => {
    expect(facts.anchorReached).toBe(true)
    expect(facts.kills).toBeGreaterThanOrEqual(70)
  })

  it('核心未被击破，锚点一限时击杀成功', () => {
    expect(battle.core.destroyed).toBe(false)
    expect(battle.status).toBe('anchorCleared')
    expect(battle.challenge.status).toBe('cleared')
  })

  it('法宝线 T1→T2 在局内依需合成并装备', () => {
    expect(facts.crafted).toBe(true)
    expect(battle.items).toContain('weapon_t2')
  })

  it('通关后可突破上清，解锁 R 且渡劫机会被消费', () => {
    expect(battle.canBreakthrough()).toBe(true)
    expect(battle.breakthrough()).toBe(true)
    expect(battle.hero.rank).toBe('shangqing')
    expect(battle.canBreakthrough()).toBe(false)
  })
})
