/**
 * Headless 护栏模拟子集（数值体系 L7 · TTK / TTL 节奏带）。
 *
 * 目的：把「目标节奏标尺」（§2.2）收敛为可自动校验的区间，并在启动 / CI 阶段
 * 跑「6 节点 × 3 区间 × N∈1..6」矩阵，产出 TTK / TTL 偏差报告（§9.3）。
 *
 * 纯净性：本模块是**纯逻辑**，不 import Phaser，也不发副作用；输入只有配置表与索引。
 *
 * —— 模型口径（确定性期望值，不含 RNG）——
 * 1) 减伤 `defRed(def, K) = clamp(def / (def + K), 0, limits.defRedMax)`，K 挂档位（§3.3）。
 *    与 `combat/damage.ts` 第 5 步**同源**：该实现为模块私有（未导出），此处按同口径复刻，
 *    并复用同一批护栏常量（`limits.defRedMax`）。
 * 2) 小怪 DEF = `tierArmorK(tier).standardDef × derivation.minion.defRatio`（同档标准 DEF ×0.6，§2.4）。
 * 3) 英雄单体 DPS（对单只小怪）= `heroAtk × derivation.heroAttackSpeed × (1 − defRed(minionDef, K))`。
 * 4) `minionTtk = minionHp / heroDps`。
 * 5) `heroTtl = heroHp / (minionCount × minionAtk × (1 − defRed(heroDef, K)))`，minionCount = 6（§2.2 围殴口径）。
 * 6) 人数维度 N∈1..6：群怪 HP 按 population.hpMul 缩放，英雄方按 N 人 →
 *    队伍 TTK = `(minionHp × hpMul(N)) / (N × heroDps)`；英雄 TTL 与 N 无关
 *    （伤害 dmgMul 恒 1.0，压力只由数量 / 血量承担 —— §6.2/§6.4）。
 *
 * 复现锚：N1 基线（1 人 / 区间Ⅰ u=0）应落 `minionTtk ≈ 0.67s` / `heroTtl ≈ 10.6s`（§3.5）。
 */

import type { GameDataIndex } from '../../data/indexes'
import type { IntervalId } from '../../data/types/common'
import type { GameData } from '../../data/types/gameData'
import { intervalStatsAt, tierAt } from '../waves/waveDirector'
import { limits } from '../../data/tables/numeric'

/** 围殴基准数量：§2.2「英雄 TTL（6 只同阶小怪围殴）」 */
export const MINION_GANG_COUNT = 6

/** 区间内取样点：取中段（u = 0.5）作为该区间的代表强度（§5.2 中段取样锚） */
const INTERVAL_SAMPLE_U = 0.5

/**
 * 减伤率：`DEF / (DEF + K)`，硬上限 `limits.defRedMax`（§3.1 第 5 步 / §3.4）。
 * 与 damage.ts 私有实现同源；K 由调用方按档位给出。
 */
function defRed(def: number, k: number): number {
  const safeDef = Math.max(0, def)
  return Math.min(safeDef / (safeDef + k), limits.defRedMax)
}

/** `minionTtk` 显式入参（便于单测：所有值外传，不依赖全局表） */
export interface MinionTtkParams {
  /** 小怪气血 */
  minionHp: number
  /** 英雄攻击（物理面板 ATK） */
  heroAtk: number
  /** 英雄攻速（次 / 秒） */
  heroAttackSpeed: number
  /** 小怪防御 */
  minionDef: number
  /** 该档位减伤系数 K（tierArmorK(tier).k） */
  k: number
}

/** 英雄单体击杀单只小怪所需时间（秒） */
export function minionTtk(params: MinionTtkParams): number {
  const { minionHp, heroAtk, heroAttackSpeed, minionDef, k } = params
  const dps = heroAtk * heroAttackSpeed * (1 - defRed(minionDef, k))
  return minionHp / dps
}

/** `heroTtl` 显式入参（便于单测） */
export interface HeroTtlParams {
  /** 英雄气血 */
  heroHp: number
  /** 小怪攻击 */
  minionAtk: number
  /** 围殴小怪数量（默认见 MINION_GANG_COUNT） */
  minionCount: number
  /** 英雄防御 */
  heroDef: number
  /** 该档位减伤系数 K（挂攻击方所在档位，§3.3） */
  k: number
}

/** 英雄被 `minionCount` 只小怪围殴时的存活时间（秒） */
export function heroTtl(params: HeroTtlParams): number {
  const { heroHp, minionAtk, minionCount, heroDef, k } = params
  const incomingDps = minionCount * minionAtk * (1 - defRed(heroDef, k))
  return heroHp / incomingDps
}

/** 目标节奏带：`target` 为目标区间（秒），`tolerance` 为相对容差（0.2 = ±20%） */
export interface RhythmBand {
  target: readonly [number, number]
  tolerance: number
}

/** §9.2 目标节奏带 + 容差（可校验区间的常量表） */
export const RHYTHM_BANDS = {
  minion: { target: [0.65, 1.0], tolerance: 0.2 },
  elite: { target: [3, 4], tolerance: 0.25 },
  waveBoss: { target: [12, 20], tolerance: 0.25 },
  wildBoss: { target: [20, 40], tolerance: 0.3 },
  anchorBoss: { target: [40, 40], tolerance: 0.2 },
  heroTtlMinions: { target: [10, 12], tolerance: 0.2 },
  heroTtlAnchor: { target: [3, 5], tolerance: 0.25 },
} as const satisfies Record<string, RhythmBand>

/**
 * 判定取值是否落在节奏带内。
 * 容差按相对比例扩展区间端点：`[target₀×(1−tol), target₁×(1+tol)]`，边界含。
 */
export function classify(value: number, band: RhythmBand): 'in' | 'out' {
  const lower = band.target[0] * (1 - band.tolerance)
  const upper = band.target[1] * (1 + band.tolerance)
  return value >= lower && value <= upper ? 'in' : 'out'
}

/** 报告行：某节点 × 某区间 × 某人数下的节奏指标 */
export interface GuardrailRow {
  nodeId: string
  intervalId: IntervalId
  players: number
  minionTtk: number
  heroTtl: number
}

/**
 * 遍历「6 节点 × 3 区间 × N∈1..6」（=108 行）产出节奏报告。
 *
 * - 英雄取该节点（AnchorNodeDef 的 heroHp / heroAtk / heroDef）；
 * - 怪物取该区间中段（`intervalStatsAt(u=0.5)`），档位用 `tierAt(u=0.5)`；
 * - 群怪 HP 随人数 `hpMul(N)` 缩放、英雄方按 N 人平摊输出（口径见模块头注释）。
 */
export function buildGuardrailReport(data: GameData, index: GameDataIndex): GuardrailRow[] {
  const rows: GuardrailRow[] = []
  const maxPlayers = Math.max(...index.population.keys())

  for (const node of data.nodes) {
    for (const interval of data.intervals) {
      const mid = intervalStatsAt(interval, INTERVAL_SAMPLE_U)
      const tier = tierAt(interval, INTERVAL_SAMPLE_U)
      const armor = index.tierArmorK.get(tier)
      if (!armor) {
        throw new Error(`护栏模拟：缺少档位 T${tier} 的护甲 K 定义`)
      }
      const minionDef = armor.standardDef * data.derivation.minion.defRatio
      const heroSingleDps =
        node.heroAtk * data.derivation.heroAttackSpeed * (1 - defRed(minionDef, armor.k))

      // 英雄 TTL 与 N 无关：伤害 dmgMul 恒 1.0（§6.4），只由节点英雄面板 × 区间小怪 ATK 决定
      const ttl = heroTtl({
        heroHp: node.heroHp,
        minionAtk: mid.atk,
        minionCount: MINION_GANG_COUNT,
        heroDef: node.heroDef,
        k: armor.k,
      })

      for (let n = 1; n <= maxPlayers; n += 1) {
        const pop = index.population.get(n)
        if (!pop) {
          throw new Error(`护栏模拟：人数缩放表缺少 N=${n} 行`)
        }
        // 队伍 TTK：群怪总池 ∝ N（hpMul × countMul = N），故单只是 1 人的 hpMul 倍 / N 人输出
        const teamTtk = (mid.hp * pop.hpMul) / (n * heroSingleDps)
        rows.push({
          nodeId: node.id,
          intervalId: interval.id,
          players: n,
          minionTtk: teamTtk,
          heroTtl: ttl,
        })
      }
    }
  }

  return rows
}
