import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { buildGameData } from '../../data/tables'
import type { Quality } from '../../data/types/common'
import type { RecipeDef } from '../../data/types/equipment'
import type { GameData } from '../../data/types/gameData'
import type { RngLike } from '../core/rng'
import { CraftEngine, type CraftBag } from './craftEngine'

const data = buildGameData()
const index = buildIndex(data)
const engine = new CraftEngine(data, index)

/** 受控 RNG：按给定序列消费 `next()`（用尽后取 0）；weighted / pick 亦基于 next() 推导 */
function stubRng(rolls: readonly number[] = []): RngLike {
  let cursor = 0
  const next = (): number => {
    const value = rolls[cursor] ?? 0
    cursor += 1
    return value
  }
  return {
    next,
    int: (min, max) => min + Math.floor(next() * (max - min + 1)),
    range: (min, max) => min + next() * (max - min),
    chance: (p) => next() < p,
    pick: <T>(items: readonly T[]): T => {
      if (items.length === 0) {
        throw new Error('pick: 不能从空数组中抽取')
      }
      return items[Math.floor(next() * items.length)] as T
    },
    weighted: <T>(entries: readonly (readonly [T, number])[]): T => {
      const total = entries.reduce((sum, [, w]) => sum + Math.max(0, w), 0)
      let roll = next() * total
      for (const [item, weight] of entries) {
        roll -= Math.max(0, weight)
        if (roll < 0) {
          return item
        }
      }
      return entries[entries.length - 1]?.[0] as T
    },
    fork: () => stubRng([]),
  }
}

/** 用覆盖后的数据重建引擎（用于构造异常 / 退化场景） */
function engineWith(override: Partial<GameData>): CraftEngine {
  const custom: GameData = { ...data, ...override }
  return new CraftEngine(custom, buildIndex(custom))
}

function recipeOf(line: RecipeDef['line'], fromTier: RecipeDef['fromTier']): RecipeDef {
  const found = data.recipes.find((r) => r.line === line && r.fromTier === fromTier)
  if (!found) {
    throw new Error(`缺少配方 ${line} T${fromTier}`)
  }
  return found
}

/** M1 唯一配方：法宝 T1→T2 */
const recipe = recipeOf('weapon', 1)

function bag(overrides: Partial<CraftBag> = {}): CraftBag {
  return {
    gold: 100,
    spirit: 10,
    materials: new Map([['bat_wing_shard', 2]]),
    items: ['weapon_t1'],
    ...overrides,
  }
}

describe('CraftEngine · canCraft 拒绝路径', () => {
  it('配置表中不存在的配方 → unknownRecipe', () => {
    const unknown: RecipeDef = {
      line: 'robe',
      fromTier: 1,
      toTier: 2,
      gold: 1,
      spirit: 0,
      materialId: 'nope',
      materialCount: 1,
      requiresSourceItem: false,
    }
    expect(engine.canCraft(unknown, bag())).toBe('unknownRecipe')
  })

  it('目标档装备缺失 → noRecipeTarget', () => {
    const noTarget = engineWith({
      equipment: data.equipment.filter((e) => e.id !== 'weapon_t2'),
    })
    expect(noTarget.canCraft(recipe, bag())).toBe('noRecipeTarget')
  })

  it('金币不足 → gold', () => {
    expect(engine.canCraft(recipe, bag({ gold: recipe.gold - 1 }))).toBe('gold')
  })

  it('灵石不足 → spirit', () => {
    const spiritRecipe: RecipeDef = { ...recipe, spirit: 5 }
    const costly = engineWith({ recipes: [spiritRecipe] })
    expect(costly.canCraft(spiritRecipe, bag({ spirit: 4 }))).toBe('spirit')
  })

  it('材料不足 → material', () => {
    const low = bag({ materials: new Map([[recipe.materialId, recipe.materialCount - 1]]) })
    expect(engine.canCraft(recipe, low)).toBe('material')
  })

  it('缺少来源装备 → sourceItem', () => {
    expect(engine.canCraft(recipe, bag({ items: [] }))).toBe('sourceItem')
  })

  it('资源齐备时可合成 → null', () => {
    expect(engine.canCraft(recipe, bag())).toBeNull()
  })
})

describe('CraftEngine · 合成成功', () => {
  it('正确产出目标档装备，并扣除金币 / 灵石 / 材料 / 来源装备', () => {
    const input = bag()
    const result = engine.craft(recipe, input, stubRng())
    if (!result.ok) {
      throw new Error(`应合成成功，实际被拒：${result.reason}`)
    }
    expect(result.item.defId).toBe('weapon_t2')
    expect(result.item.line).toBe('weapon')
    expect(result.item.tier).toBe(2)

    expect(result.bag.gold).toBe(100 - recipe.gold)
    expect(result.bag.spirit).toBe(10 - recipe.spirit)
    expect(result.bag.materials.get(recipe.materialId)).toBe(0)
    expect(result.bag.items).toEqual([])
  })

  it('不改动入参资源袋（不可变风格）', () => {
    const input = bag()
    engine.craft(recipe, input, stubRng())
    expect(input.gold).toBe(100)
    expect(input.spirit).toBe(10)
    expect(input.materials.get(recipe.materialId)).toBe(2)
    expect(input.items).toEqual(['weapon_t1'])
  })

  it('仅消耗一件来源装备，其余保留', () => {
    const input = bag({ items: ['weapon_t1', 'weapon_t1', 'weapon_t2'] })
    const result = engine.craft(recipe, input, stubRng())
    if (!result.ok) {
      throw new Error('应合成成功')
    }
    expect(result.bag.items).toEqual(['weapon_t1', 'weapon_t2'])
  })

  it('被拒时不改变任何资源（返回 reason）', () => {
    const input = bag({ gold: 0 })
    expect(engine.craft(recipe, input, stubRng())).toEqual({ ok: false, reason: 'gold' })
    expect(input.gold).toBe(0)
  })
})

describe('CraftEngine · 品质边界（附录 C.1：下 60% / 中 30% / 上 10%）', () => {
  const cases: readonly (readonly [number, Quality])[] = [
    [0, 'lower'],
    [0.599, 'lower'],
    [0.6, 'middle'],
    [0.899, 'middle'],
    [0.9, 'upper'],
    [0.999, 'upper'],
  ]

  for (const [roll, expected] of cases) {
    it(`roll=${roll} → ${expected}`, () => {
      const result = engine.craft(recipe, bag(), stubRng([roll]))
      if (!result.ok) {
        throw new Error('应合成成功')
      }
      expect(result.item.quality).toBe(expected)
    })
  }
})

describe('CraftEngine · 词条数量随品质（§6.8：1 / 2 / 3 条）', () => {
  const cases: readonly (readonly [number, number])[] = [
    [0.1, 1], // 下品
    [0.7, 2], // 中品
    [0.95, 3], // 上品
  ]

  for (const [roll, count] of cases) {
    it(`roll=${roll} → 词条 ${count} 条`, () => {
      const result = engine.craft(recipe, bag(), stubRng([roll]))
      if (!result.ok) {
        throw new Error('应合成成功')
      }
      expect(result.item.affixes).toHaveLength(count)
    })
  }
})

describe('CraftEngine · 词条互不重复且来自本线词条池', () => {
  it('上品 3 条词条两两不同，均来自法宝线', () => {
    const result = engine.craft(recipe, bag(), stubRng([0.95]))
    if (!result.ok) {
      throw new Error('应合成成功')
    }
    const affixes = result.item.affixes
    expect(new Set(affixes).size).toBe(affixes.length)
    const pool = new Set(data.affixes.filter((a) => a.line === 'weapon').map((a) => a.id))
    for (const id of affixes) {
      expect(pool.has(id)).toBe(true)
    }
  })
})

describe('CraftEngine · 词条池退化行为', () => {
  it('词条池为空 → 无词条（失败退化为空数组）', () => {
    const empty = engineWith({ affixes: [] })
    const result = empty.craft(recipe, bag(), stubRng([0.95]))
    if (!result.ok) {
      throw new Error('应合成成功')
    }
    expect(result.item.affixes).toEqual([])
  })

  it('词条池不足 affixCount → 取全部', () => {
    const two = engineWith({ affixes: data.affixes.filter((a) => a.line === 'weapon').slice(0, 2) })
    const result = two.craft(recipe, bag(), stubRng([0.95]))
    if (!result.ok) {
      throw new Error('应合成成功')
    }
    expect(result.item.affixes).toHaveLength(2)
  })
})
