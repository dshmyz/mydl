/**
 * 合成引擎：横向升档（主文档 §6.4）+ 品质 / 词条 roll（§6.8、附录 C.1 / C.4）。
 *
 * 只负责「能不能合成、合成后产出什么」，不触碰 UI 与存档。
 * 所有随机性来自注入的 `RngLike`，同一 seed 下结果可完全复现。
 *
 * 资源袋（`CraftBag`）与产物均为纯数据；合成成功时返回**新的**资源袋，
 * 绝不改动入参（不可变风格）。
 */

import { recipeKey, type GameDataIndex } from '../../data/indexes'
import type { EquipLine, Quality, Tier } from '../../data/types/common'
import type { EquipmentDef, RecipeDef } from '../../data/types/equipment'
import type { GameData } from '../../data/types/gameData'
import type { RngLike } from '../core/rng'

/** 资源袋：合成消耗与产出的载体 */
export interface CraftBag {
  gold: number
  spirit: number
  /** 材料持有量，按 materialId 计数 */
  materials: Map<string, number>
  /** 已拥有的装备 defId 列表（同一 id 可重复 = 多件） */
  items: string[]
}

/** 合成被拒的原因 */
export type CraftRejection =
  | 'gold'
  | 'spirit'
  | 'material'
  | 'sourceItem'
  | 'noRecipeTarget'
  | 'unknownRecipe'

/** 合成产物：掉落即定型的装备实例 */
export interface CraftedItem {
  defId: string
  line: EquipLine
  tier: Tier
  quality: Quality
  /** 已 roll 定的词条 id（互不重复） */
  affixes: string[]
}

export type CraftResult =
  | { ok: true; item: CraftedItem; bag: CraftBag }
  | { ok: false; reason: CraftRejection }

/** 品质掉落权重（主文档 C.1 / 数值文档 §7.4）：下品 60% / 中品 30% / 上品 10% */
export const QUALITY_DROP_WEIGHTS: Readonly<Record<Quality, number>> = {
  lower: 0.6,
  middle: 0.3,
  upper: 0.1,
}

export class CraftEngine {
  constructor(
    private readonly data: GameData,
    private readonly index: GameDataIndex,
  ) {}

  /** 校验可合成性：返回拒绝原因，可合成时为 null */
  canCraft(recipe: RecipeDef, bag: CraftBag): CraftRejection | null {
    if (!this.index.recipe.has(recipeKey(recipe.line, recipe.fromTier))) {
      return 'unknownRecipe'
    }
    if (!this.findEquipment(recipe.line, recipe.toTier)) {
      return 'noRecipeTarget'
    }
    if (bag.gold < recipe.gold) {
      return 'gold'
    }
    if (bag.spirit < recipe.spirit) {
      return 'spirit'
    }
    if ((bag.materials.get(recipe.materialId) ?? 0) < recipe.materialCount) {
      return 'material'
    }
    if (recipe.requiresSourceItem && !this.hasSourceItem(recipe.line, recipe.fromTier, bag)) {
      return 'sourceItem'
    }
    return null
  }

  /** 合成：校验通过后扣除资源、roll 品质与词条，返回**新的**资源袋与产物 */
  craft(recipe: RecipeDef, bag: CraftBag, rng: RngLike): CraftResult {
    const rejection = this.canCraft(recipe, bag)
    if (rejection !== null) {
      return { ok: false, reason: rejection }
    }
    const target = this.findEquipment(recipe.line, recipe.toTier)
    if (!target) {
      return { ok: false, reason: 'noRecipeTarget' }
    }

    const quality = this.rollQuality(rng)
    const affixCount = this.index.quality.get(quality)?.affixCount ?? 0
    const affixes = this.rollAffixes(recipe.line, affixCount, rng)

    // 扣除材料（不可变：复制后再改）
    const materials = new Map(bag.materials)
    materials.set(recipe.materialId, (materials.get(recipe.materialId) ?? 0) - recipe.materialCount)

    // 扣除来源装备：移除一件同线、档位为 fromTier 的装备
    const items = [...bag.items]
    if (recipe.requiresSourceItem) {
      const source = this.findEquipment(recipe.line, recipe.fromTier)
      const sourceAt = source ? items.indexOf(source.id) : -1
      if (sourceAt >= 0) {
        items.splice(sourceAt, 1)
      }
    }

    return {
      ok: true,
      item: {
        defId: target.id,
        line: target.line,
        tier: target.tier,
        quality,
        affixes,
      },
      bag: {
        gold: bag.gold - recipe.gold,
        spirit: bag.spirit - recipe.spirit,
        materials,
        items,
      },
    }
  }

  /**
   * 品质 roll：按 QUALITY_DROP_WEIGHTS 的累计区间划分——[0, lower) 下品 /
   * [lower, lower+middle) 中品 / 其余上品（附录 C.1）。
   *
   * 直接消费 `next()` 而非 `weighted()`：权重之和在浮点下不精确等于 1，
   * 用累计阈值可保证边界与文档口径严格一致（roll=0.6 落入中品、0.9 落入上品）。
   */
  private rollQuality(rng: RngLike): Quality {
    const { lower, middle } = QUALITY_DROP_WEIGHTS
    const roll = rng.next()
    if (roll < lower) {
      return 'lower'
    }
    if (roll < lower + middle) {
      return 'middle'
    }
    return 'upper'
  }

  /**
   * 词条 roll：从本线词条池中**不重复**抽取 count 条（抽一条即从池中摘除）；
   * 池不足时取全部，池为空时返回空数组（退化行为，不报错）。
   */
  private rollAffixes(line: EquipLine, count: number, rng: RngLike): string[] {
    if (count <= 0) {
      return []
    }
    const remaining = this.data.affixes.filter((a) => a.line === line).map((a) => a.id)
    const picked: string[] = []
    while (picked.length < count && remaining.length > 0) {
      const chosen = rng.pick(remaining)
      remaining.splice(remaining.indexOf(chosen), 1)
      picked.push(chosen)
    }
    return picked
  }

  /** 按 线 + 档位 查装备定义（index.equipment 按 id 索引，故此处遍历 data.equipment） */
  private findEquipment(line: EquipLine, tier: Tier): EquipmentDef | undefined {
    return this.data.equipment.find((e) => e.line === line && e.tier === tier)
  }

  /** 是否拥有与配方同线、档位为 fromTier 的来源装备 */
  private hasSourceItem(line: EquipLine, fromTier: Tier, bag: CraftBag): boolean {
    const source = this.findEquipment(line, fromTier)
    return source !== undefined && bag.items.includes(source.id)
  }
}
