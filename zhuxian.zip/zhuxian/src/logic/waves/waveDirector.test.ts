import { describe, expect, it } from 'vitest'

import { buildIndex } from '../../data/indexes'
import { buildGameData } from '../../data/tables'
import type { RngLike } from '../core/rng'
import { intervalStatsAt, tierAt, WaveDirector } from './waveDirector'

const data = buildGameData()
const index = buildIndex(data)
const director = new WaveDirector(data, index)

/** 受控 RNG */
function stubRng(rolls: readonly number[] = []): RngLike {
  let cursor = 0
  const next = (): number => {
    const value = rolls[cursor] ?? 1
    cursor += 1
    return value
  }
  return {
    next,
    int: (min, max) => min + Math.floor(next() * (max - min + 1)),
    range: (min, max) => min + next() * (max - min),
    chance: (p) => next() < p,
    pick: <T>(items: readonly T[]): T => items[0] as T,
    weighted: <T>(entries: readonly (readonly [T, number])[]): T => entries[0]?.[0] as T,
    fork: () => stubRng([]),
  }
}

function intervalOf(id: 'I' | 'II' | 'III') {
  const found = data.intervals.find((i) => i.id === id)
  if (!found) {
    throw new Error(`缺少区间 ${id}`)
  }
  return found
}

describe('intervalStatsAt · 区间内几何插值（数值文档 §5.1）', () => {
  it('区间Ⅰ 取样点对齐 §5.2（35/19、43/22、52/24）', () => {
    const i = intervalOf('I')
    // §5.2 是取整后的速查表（u≈0.83 实测取 5/6），§5.1 几何公式为权威 → 允许 ±1 取整误差
    const samples: readonly (readonly [number, number, number])[] = [
      [1 / 6, 35, 19],
      [1 / 2, 43, 22],
      [5 / 6, 52, 24],
    ]
    for (const [u, hp, atk] of samples) {
      const stats = intervalStatsAt(i, u)
      expect(Math.abs(stats.hp - hp)).toBeLessThanOrEqual(1)
      expect(Math.abs(stats.atk - atk)).toBeLessThanOrEqual(1)
    }
  })

  it('区间Ⅱ / Ⅲ 取样点对齐 §5.2', () => {
    const ii = intervalOf('II')
    expect(intervalStatsAt(ii, 1 / 6).hp).toBeCloseTo(70, 0)
    expect(intervalStatsAt(ii, 1 / 2).atk).toBeCloseTo(38, 0)
    expect(intervalStatsAt(ii, 5 / 6).hp).toBeCloseTo(146, 0)

    const iii = intervalOf('III')
    expect(intervalStatsAt(iii, 1 / 2).hp).toBeCloseTo(287, 0)
    expect(intervalStatsAt(iii, 5 / 6).atk).toBeCloseTo(102, 0)
  })

  it('端点严格落在 L0 锚点', () => {
    const i = intervalOf('I')
    expect(intervalStatsAt(i, 0)).toEqual({ hp: 32, atk: 18 })
    expect(intervalStatsAt(i, 1)).toEqual({ hp: 58, atk: 26 })
  })
})

describe('tierAt · 区间内就近取档（数值文档 §5.1）', () => {
  it('区间Ⅰ 恒 T1，终点取 T2', () => {
    const i = intervalOf('I')
    expect(tierAt(i, 0)).toBe(1)
    expect(tierAt(i, 0.5)).toBe(1)
    expect(tierAt(i, 0.99)).toBe(1)
    expect(tierAt(i, 1)).toBe(2)
  })

  it('区间Ⅱ 前半 T2 / 后半 T3；区间Ⅲ 前半 T4 / 后半 T5', () => {
    const ii = intervalOf('II')
    expect(tierAt(ii, 0.25)).toBe(2)
    expect(tierAt(ii, 0.6)).toBe(3)
    const iii = intervalOf('III')
    expect(tierAt(iii, 0.25)).toBe(4)
    expect(tierAt(iii, 0.9)).toBe(5)
  })
})

describe('WaveDirector · 波次编排（L3 插值 + L4 人数缩放）', () => {
  it('1 人基准：E1 数量 = 模板原值，属性按 L3 插值', () => {
    const plan = director.plan({ templateId: 'E1', act: 'act1', progress: 0.5, players: 1 })
    expect(plan.interval).toBe('I')
    const wolf = plan.groups[0]
    expect(wolf?.monsterId).toBe('wolf')
    expect(wolf?.count).toBe(8)
    expect(wolf?.stats.hp).toBeCloseTo(43, 0)
    expect(wolf?.stats.atk).toBeCloseTo(22, 0)
    expect(wolf?.tier).toBe(1)
    // 小怪 DEF = 标准 DEF × 0.6（数值文档 §2.4）
    expect(wolf?.stats.def).toBeCloseTo(12 * 0.6, 5)
  })

  it('6 人缩放：数量 ×countMul、群怪 HP ×hpMul、伤害不变', () => {
    const one = director.plan({ templateId: 'E1', act: 'act1', progress: 0.5, players: 1 })
    const six = director.plan({ templateId: 'E1', act: 'act1', progress: 0.5, players: 6 })
    const wolf1 = one.groups[0]
    const wolf6 = six.groups[0]
    expect(wolf6?.count).toBe(Math.round(8 * 2.14))
    expect(wolf6?.stats.hp).toBeCloseTo((wolf1?.stats.hp ?? 0) * 2.82, 3)
    // 伤害恒定 ×1.0（数值文档 §6.4）
    expect(wolf6?.stats.atk).toBeCloseTo(wolf1?.stats.atk ?? 0, 5)
  })

  it('同屏小怪总数受护栏约束（≤ 40）', () => {
    for (const templateId of ['E1', 'E2', 'E3']) {
      const plan = director.plan({ templateId, act: 'act1', progress: 1, players: 6 })
      expect(plan.totalCount).toBeLessThanOrEqual(data.limits.maxOnScreenMinions)
    }
  })

  it('精英位按模板 min/max roll 并随人数缩放', () => {
    // roll = 0.99 → int(0,1) = 1 → ×2.14 → 2
    const plan = director.plan({
      templateId: 'E3',
      act: 'act1',
      progress: 0.5,
      players: 6,
      rng: stubRng([0.99]),
    })
    const bat = plan.groups[0]
    const elite = plan.groups.find((g) => g.isElite)
    expect(bat?.monsterId).toBe('bat')
    expect(elite?.count).toBe(2)
    // 精英 HP = 区间基线 × mul.hp(6) × 人数 hpMul(2.82)，与基线同源（比值断言避免四舍五入误差）
    const base = intervalStatsAt(intervalOf('I'), 0.5).hp
    expect(elite?.stats.hp).toBeCloseTo(base * 6 * 2.82, 3)
  })

  it('模板层与幕不符时抛错', () => {
    expect(() => director.plan({ templateId: 'E1', act: 'act2', progress: 0.5, players: 1 })).toThrow()
  })

  it('匿名模板抛错', () => {
    expect(() =>
      director.plan({ templateId: 'ZZ', act: 'act1', progress: 0.5, players: 1 }),
    ).toThrow()
  })
})

describe('WaveDirector · 模板池随机', () => {
  it('只从该幕模板池中抽取，且不重复上一个', () => {
    const pool = data.waveTemplates.filter((t) => t.layer === 'act1').map((t) => t.id)
    const first = director.pickTemplate('act1', stubRng([]))
    expect(pool).toContain(first)
    const second = director.pickTemplate('act1', stubRng([]), first)
    expect(pool).toContain(second)
    expect(second).not.toBe(first)
  })
})

describe('WaveDirector · 锚点 BOSS（数值文档 §2.5 / §5.4 / §6.1）', () => {
  it('HP = 4 人基准 ×机制乘数 ÷4 ×N，ATK 取区间终点 ×系数', () => {
    const n1 = director.anchorBoss('heishui_xuanshe', 1)
    expect(n1.count).toBe(1)
    expect(n1.isBoss).toBe(true)
    // 11000 × 0.8 ÷ 4 × 1 = 2200
    expect(n1.stats.hp).toBeCloseTo(2200, 5)
    // 区间Ⅰ终点 ATK 26 × 6 = 156
    expect(n1.stats.atk).toBeCloseTo(156, 5)
    expect(n1.tier).toBe(1)
    expect(n1.armorKMult).toBe(1.2)

    // N=4 回到 L0 的 4 人基准 × 机制乘数 = 8800
    expect(director.anchorBoss('heishui_xuanshe', 4).stats.hp).toBeCloseTo(8800, 5)
  })

  it('非锚点 BOSS 抛错', () => {
    expect(() => director.anchorBoss('wolf', 1)).toThrow()
  })
})

describe('WaveDirector · 单体刷新（召唤复用）', () => {
  it('小玄蛇取区间终点基线 ×12，与锚点同源', () => {
    const group = director.spawn('small_snake', { act: 'act1', progress: 1, players: 1 })
    // 区间Ⅰ终点 hp 58 × mul.hp 12 = 696
    expect(group.stats.hp).toBeCloseTo(58 * 12, 5)
    expect(group.count).toBe(1)
    expect(group.isBoss).toBe(false)
  })

  it('数量按 countMul 缩放', () => {
    const group = director.spawn('small_snake', {
      act: 'act1',
      progress: 1,
      players: 4,
      count: 2,
    })
    expect(group.count).toBe(Math.round(2 * 1.8))
    expect(group.stats.hp).toBeCloseTo(58 * 12 * 2.23, 3)
  })
})

describe('WaveDirector · 人数钳制', () => {
  it('人数越界时钳到 [1, 6]', () => {
    const zero = director.plan({ templateId: 'E1', act: 'act1', progress: 0.5, players: 0 })
    expect(zero.groups[0]?.count).toBe(8)
    const huge = director.plan({ templateId: 'E1', act: 'act1', progress: 0.5, players: 99 })
    expect(huge.groups[0]?.count).toBe(Math.round(8 * 2.14))
  })
})
