/**
 * 波次导演：把「模板 + 幕 + 区间进度 + 人数」编排为可生成的怪物批次。
 *
 * - 强度按 **L3 区间内几何插值**（数值文档 §5.1）：端点严格落在 L0 锚点，中段平滑。
 * - 数量 / 血量按 **L4 三通道人数缩放**（§6.2）：群怪 hpMul = N^(1−α) 且 countMul = N^α，
 *   伤害恒 1.0；单体 BOSS 走 bossMul = N。
 * - 怪物属性 = 区间基线 × 该怪物的相对系数（`MonsterDef.mul`），不把强度绑死波号。
 *
 * 只产出数据（不涉及渲染坐标）：落位由表现层 / 战斗编排层处理。
 */

import type { GameDataIndex } from '../../data/indexes'
import type { ActId, IntervalId, Stats, Tier } from '../../data/types/common'
import type { GameData } from '../../data/types/gameData'
import type { IntervalDef, PopulationRow } from '../../data/types/numeric'
import type { MonsterDef } from '../../data/types/units'
import type { RngLike } from '../core/rng'

/** 锚点 BOSS / 野区 BOSS 的 HP 以「全队 4 人等效」为基准（数值文档 §6.1） */
export const ANCHOR_REFERENCE_PLAYERS = 4

/** 区间内的强度取样值 */
export interface IntervalStats {
  hp: number
  atk: number
}

/** 区间内按几何插值取小怪 HP / ATK（端点严格落在 L0 锚点） */
export function intervalStatsAt(interval: IntervalDef, u: number): IntervalStats {
  const t = clamp01(u)
  return {
    hp: interval.hp[0] * Math.pow(interval.hp[1] / interval.hp[0], t),
    atk: interval.atk[0] * Math.pow(interval.atk[1] / interval.atk[0], t),
  }
}

/** 区间内就近取档：区间Ⅰ恒 T1；后半段逐级上移，终点即锚点档位（数值文档 §5.1） */
export function tierAt(interval: IntervalDef, u: number): Tier {
  const [from, to] = interval.armorTier
  const tier = from + Math.floor(clamp01(u) * (to - from))
  return Math.min(tier, to) as Tier
}

/** 一批同类怪物 */
export interface SpawnGroup {
  monsterId: string
  name: string
  count: number
  isElite: boolean
  isBoss: boolean
  stats: Stats
  tier: Tier
  armorKMult: number
  attackSpeed: number
  range: number
  flying: boolean
}

export interface WavePlan {
  templateId: string
  interval: IntervalId
  tier: Tier
  progress: number
  players: number
  groups: SpawnGroup[]
  /** 同屏小怪总数（含精英，不含 BOSS），供护栏检查 */
  totalCount: number
}

export interface WaveRequest {
  templateId: string
  act: ActId
  /** 区间内进度 u ∈ [0,1] */
  progress: number
  players: number
  /** 缺省时精英位取模板下限（不 roll） */
  rng?: RngLike
}

/** 单体刷新请求（供召唤 / 锚点外的临时刷怪复用，与 `plan()` 同一强度口径） */
export interface MonsterSpawnRequest {
  act: ActId
  /** 区间内进度 u ∈ [0,1] */
  progress: number
  players: number
  /** 1 人基准数量，按 countMul 缩放（默认 1） */
  count?: number
  /** 显式档位覆盖（缺省按区间进度取档） */
  tier?: Tier
  isElite?: boolean
  isBoss?: boolean
}

export class WaveDirector {
  private readonly maxPlayers: number

  constructor(
    private readonly data: GameData,
    private readonly index: GameDataIndex,
  ) {
    this.maxPlayers = Math.max(...index.population.keys())
  }

  /** 从该幕模板池中随机取一个（可排除上一个，避免连播同模板） */
  pickTemplate(act: ActId, rng: RngLike, exclude?: string): string {
    const pool = this.data.waveTemplates.filter((t) => t.layer === act)
    if (pool.length === 0) {
      throw new Error(`波次导演：幕「${act}」没有可用模板`)
    }
    const candidates = pool.filter((t) => t.id !== exclude)
    return rng.pick(candidates.length > 0 ? candidates : pool).id
  }

  /** 编排一波：模板构成 × L3 强度 × L4 人数缩放 */
  plan(request: WaveRequest): WavePlan {
    const template = this.index.template.get(request.templateId)
    if (!template) {
      throw new Error(`波次导演：未知模板「${request.templateId}」`)
    }
    if (template.layer !== request.act) {
      throw new Error(
        `波次导演：模板「${template.id}」属于 ${template.layer}，与幕「${request.act}」不符`,
      )
    }
    const interval = this.intervalForAct(request.act)
    const players = this.clampPlayers(request.players)
    const pop = this.populationRow(players)
    const base = intervalStatsAt(interval, request.progress)
    const tier = tierAt(interval, request.progress)

    const groups: SpawnGroup[] = []
    let totalCount = 0

    for (const group of template.groups) {
      const monster = this.requireMonster(group.monsterId)
      const count = Math.max(1, Math.round(group.count * pop.countMul))
      // 群怪 HP 走 hpMul 通道、ATK 恒 ×1（数值文档 §6.4）
      const hp = base.hp * monster.mul.hp * pop.hpMul
      const atk = base.atk * monster.mul.atk
      groups.push(this.spawnGroup(monster, count, hp, atk, tier, false, false))
      totalCount += count
    }

    if (template.elite) {
      const { min, max, monsterId } = template.elite
      const monster = this.requireMonster(monsterId)
      const rolled = request.rng ? request.rng.int(min, max) : min
      const count = Math.round(rolled * pop.countMul)
      if (count > 0) {
        const hp = base.hp * monster.mul.hp * pop.hpMul
        const atk = base.atk * monster.mul.atk
        groups.push(this.spawnGroup(monster, count, hp, atk, tier, true, false))
        totalCount += count
      }
    }

    return {
      templateId: template.id,
      interval: interval.id,
      tier,
      progress: clamp01(request.progress),
      players,
      groups,
      totalCount,
    }
  }

  /**
   * 生成指定怪物的一批（召唤物 / 临时刷新）。
   *
   * 与 `plan()` 同一强度口径：区间基线 × 该怪相对系数 × 群怪血量通道（`hpMul`）。
   */
  spawn(monsterId: string, request: MonsterSpawnRequest): SpawnGroup {
    const monster = this.requireMonster(monsterId)
    const interval = this.intervalForAct(request.act)
    const pop = this.populationRow(this.clampPlayers(request.players))
    const base = intervalStatsAt(interval, request.progress)
    const tier = request.tier ?? tierAt(interval, request.progress)
    const count = Math.max(1, Math.round((request.count ?? 1) * pop.countMul))
    const hp = base.hp * monster.mul.hp * pop.hpMul
    const atk = base.atk * monster.mul.atk
    return this.spawnGroup(
      monster,
      count,
      hp,
      atk,
      tier,
      request.isElite ?? false,
      request.isBoss ?? false,
    )
  }

  /**
   * 生成锚点 BOSS（限时战目标）。
   * HP = 4 人基准目标 × 机制乘数 ÷4 ×N；ATK 取区间终点 ×该怪系数。
   */
  anchorBoss(monsterId: string, players: number, act: ActId = 'act1'): SpawnGroup {
    const monster = this.requireMonster(monsterId)
    if (monster.class !== 'anchorBoss' || monster.targetHp4p === undefined) {
      throw new Error(`波次导演：怪物「${monsterId}」不是已登记 targetHp4p 的锚点 BOSS`)
    }
    const interval = this.intervalForAct(act)
    const pop = this.populationRow(this.clampPlayers(players))
    const base = intervalStatsAt(interval, 1)
    const tier = monster.tierOverride ?? tierAt(interval, 1)
    const mechanism = this.data.mechanismMul[monster.mechanism ?? 'none']
    // 单体 BOSS：HP 走 bossMul 通道（= N），不使用群怪 hpMul（数值文档 §6.4）
    const hp =
      (monster.targetHp4p / ANCHOR_REFERENCE_PLAYERS) * pop.bossMul * mechanism
    const atk = base.atk * monster.mul.atk
    return this.spawnGroup(monster, 1, hp, atk, tier, false, true)
  }

  private spawnGroup(
    monster: MonsterDef,
    count: number,
    hp: number,
    atk: number,
    tier: Tier,
    isElite: boolean,
    isBoss: boolean,
  ): SpawnGroup {
    const minionDef = this.tierArmorK(tier).standardDef * this.data.derivation.minion.defRatio
    const stats: Stats = {
      hp,
      mp: 0,
      atk,
      sp: atk,
      def: minionDef * monster.mul.def,
      spd: this.data.derivation.minion.spd * monster.mul.spd,
      dodge: 0,
      crit: 0,
      critDmg: 1,
    }
    return {
      monsterId: monster.id,
      name: monster.name,
      count,
      isElite,
      isBoss,
      stats,
      tier,
      armorKMult: monster.armorKMult ?? 1,
      attackSpeed: monster.attackSpeed,
      range: monster.range,
      flying: monster.flying ?? false,
    }
  }

  private intervalForAct(act: ActId): IntervalDef {
    const interval = this.data.intervals.find((i) => i.act === act)
    if (!interval) {
      throw new Error(`波次导演：幕「${act}」没有对应的强度区间`)
    }
    return interval
  }

  private populationRow(players: number): PopulationRow {
    const row = this.index.population.get(players)
    if (!row) {
      throw new Error(`波次导演：人数缩放表缺少 N=${players} 行`)
    }
    return row
  }

  private tierArmorK(tier: Tier) {
    const row = this.index.tierArmorK.get(tier)
    if (!row) {
      throw new Error(`波次导演：缺少档位 T${tier} 的护甲 K 定义`)
    }
    return row
  }

  private requireMonster(monsterId: string): MonsterDef {
    const monster = this.index.monster.get(monsterId)
    if (!monster) {
      throw new Error(`波次导演：未知怪物「${monsterId}」`)
    }
    return monster
  }

  private clampPlayers(players: number): number {
    const n = Math.round(players)
    return Math.min(Math.max(1, n), this.maxPlayers)
  }
}

function clamp01(value: number): number {
  return Math.min(Math.max(value, 0), 1)
}
