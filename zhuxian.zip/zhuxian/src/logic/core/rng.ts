/**
 * 确定性随机数生成器（mulberry32）。
 *
 * 逻辑层全部随机性必须来自此接口，保证：
 *  - 同一 seed 下整局演进可完全复现（手感测试 / 护栏模拟可重跑）；
 *  - 表现层可传入独立子流（`fork`），不污染逻辑流。
 */
export interface RngLike {
  /** 均匀分布 [0, 1) */
  next(): number
  /** 闭区间整数 [min, max] */
  int(min: number, max: number): number
  /** 半开区间浮点 [min, max) */
  range(min: number, max: number): number
  /** 以概率 p 命中 */
  chance(p: number): boolean
  /** 从数组等概率取一个元素 */
  pick<T>(items: readonly T[]): T
  /** 按权重抽取；权重为 0 的项不会被选中 */
  weighted<T>(entries: readonly (readonly [T, number])[]): T
  /** 派生独立子流（不消耗当前流状态） */
  fork(salt: number): RngLike
}

/**
 * 32 位回绕原语。
 *
 * 为什么不用 `>>> / | / & / ^ / Math.imul`：这些写法依赖 JS 的 ToUint32 / ToInt32 语义，
 * 而 **TSTL 在 `luaTarget: 5.3` 下把 `>>>` 直接编译成 Lua 原生 `>>`**（64 位算术右移），
 * 且 Lua 5.3 没有 `bit32` 库——于是 `x >>> 0` 在 Lua 里退化成恒等，状态不再回绕，
 * `next()` 会越界返回 >1 的值。`Math.imul` 更是直接被 TSTL 判为 unsupported。
 *
 * 因此这里改用**只依赖 `+ - * / %` 与取整**的等价写法：mulberry32 的全部运算只要求
 * 「按 2^32 取模后的位模式」，而这些写法在 JS（IEEE double，值域 ≤ 2^33，精确）与
 * Lua（64 位整数，同值域精确）下**逐位一致**，从而 vitest 与地图内跑出同一条随机流。
 */

const UINT32_RANGE = 4294967296

/** 折到 [0, 2^32)：JS `x >>> 0` 的等价物，且对负数也安全 */
function toUint32(x: number): number {
  return Math.floor((((x % UINT32_RANGE) + UINT32_RANGE) % UINT32_RANGE))
}

/** 逻辑右移：输入按无符号解释（非负），除以 2 的幂是精确运算 */
function shiftRight(x: number, bits: number): number {
  return Math.floor(x / 2 ** bits)
}

/** 按位异或（输入输出均按无符号 32 位解释） */
function xor32(a: number, b: number): number {
  return toUint32(a ^ b)
}

/** 按位或（输入输出均按无符号 32 位解释） */
function or32(a: number, b: number): number {
  return toUint32(a | b)
}

/** 32 位乘法（等价 `Math.imul` 的位模式）：16 位拆分，避免乘积溢出精确整数范围 */
function mul32(a: number, b: number): number {
  const aLow = a % 65536
  const aHigh = Math.floor(a / 65536) % 65536
  const bLow = b % 65536
  const bHigh = Math.floor(b / 65536) % 65536
  const low = aLow * bLow
  const cross = (aHigh * bLow + aLow * bHigh) % 65536
  return toUint32(low + cross * 65536)
}

/** 整数混合，用于把 seed 与 salt 揉成一个新 seed */
function mixSeed(seed: number, salt: number): number {
  let h = xor32(seed, mul32(toUint32(salt + 1), 0x9e3779b9))
  h = mul32(xor32(h, shiftRight(h, 16)), 0x85ebca6b)
  h = mul32(xor32(h, shiftRight(h, 13)), 0xc2b2ae35)
  return xor32(h, shiftRight(h, 16))
}

export class Rng implements RngLike {
  private state: number
  private readonly seed: number

  constructor(seed: number) {
    this.seed = toUint32(seed)
    this.state = this.seed
  }

  private nextUint(): number {
    this.state = toUint32(this.state + 0x6d2b79f5)
    let t = this.state
    t = mul32(xor32(t, shiftRight(t, 15)), or32(t, 1))
    t = xor32(t, toUint32(t + mul32(xor32(t, shiftRight(t, 7)), or32(t, 61))))
    return xor32(t, shiftRight(t, 14))
  }

  next(): number {
    return this.nextUint() / 4294967296
  }

  int(min: number, max: number): number {
    return min + Math.floor(this.next() * (max - min + 1))
  }

  range(min: number, max: number): number {
    return min + this.next() * (max - min)
  }

  chance(p: number): boolean {
    return this.next() < p
  }

  pick<T>(items: readonly T[]): T {
    if (items.length === 0) {
      throw new Error('Rng.pick: 不能从空数组中抽取')
    }
    return items[Math.floor(this.next() * items.length)] as T
  }

  weighted<T>(entries: readonly (readonly [T, number])[]): T {
    const total = entries.reduce((sum, [, w]) => sum + Math.max(0, w), 0)
    if (total <= 0) {
      throw new Error('Rng.weighted: 总权重必须为正数')
    }
    let roll = this.next() * total
    for (const [item, weight] of entries) {
      roll -= Math.max(0, weight)
      if (roll < 0) {
        return item
      }
    }
    // 浮点误差兜底：返回最后一个正权重项
    for (let i = entries.length - 1; i >= 0; i -= 1) {
      const entry = entries[i] as readonly [T, number]
      if (entry[1] > 0) {
        return entry[0]
      }
    }
    throw new Error('Rng.weighted: 无可选正权重项')
  }

  fork(salt: number): Rng {
    return new Rng(mixSeed(this.seed, salt))
  }
}
