import { describe, expect, it } from 'vitest'

import { Rng } from './rng'

describe('Rng', () => {
  it('同一 seed 产出完全相同的序列（确定性）', () => {
    const a = new Rng(12345)
    const b = new Rng(12345)
    const seqA = Array.from({ length: 32 }, () => a.next())
    const seqB = Array.from({ length: 32 }, () => b.next())
    expect(seqA).toEqual(seqB)
  })

  it('不同 seed 产出不同序列', () => {
    const a = new Rng(1)
    const b = new Rng(2)
    expect(a.next()).not.toBe(b.next())
  })

  it('next() 落在 [0,1)', () => {
    const rng = new Rng(7)
    for (let i = 0; i < 1000; i += 1) {
      const v = rng.next()
      expect(v).toBeGreaterThanOrEqual(0)
      expect(v).toBeLessThan(1)
    }
  })

  it('int(min,max) 落在闭区间且能取到两端', () => {
    const rng = new Rng(99)
    const seen = new Set<number>()
    for (let i = 0; i < 2000; i += 1) {
      const v = rng.int(1, 4)
      expect(Number.isInteger(v)).toBe(true)
      expect(v).toBeGreaterThanOrEqual(1)
      expect(v).toBeLessThanOrEqual(4)
      seen.add(v)
    }
    expect(seen).toEqual(new Set([1, 2, 3, 4]))
  })

  it('range(min,max) 落在 [min,max)', () => {
    const rng = new Rng(11)
    for (let i = 0; i < 500; i += 1) {
      const v = rng.range(2, 5)
      expect(v).toBeGreaterThanOrEqual(2)
      expect(v).toBeLessThan(5)
    }
  })

  it('chance(0) 恒 false，chance(1) 恒 true', () => {
    const rng = new Rng(3)
    for (let i = 0; i < 200; i += 1) {
      expect(rng.chance(0)).toBe(false)
      expect(rng.chance(1)).toBe(true)
    }
  })

  it('weighted 按权重抽取，权重为 0 的项不会被选中', () => {
    const rng = new Rng(2024)
    const counts = { a: 0, b: 0, c: 0 }
    for (let i = 0; i < 3000; i += 1) {
      const r = rng.weighted([
        ['a', 0],
        ['b', 1],
        ['c', 3],
      ] as const)
      counts[r] += 1
    }
    expect(counts.a).toBe(0)
    // c 权重是 b 的 3 倍，抽样应显著高于 b
    expect(counts.c).toBeGreaterThan(counts.b * 2)
  })

  it('weighted 权重全为 0 / 空列表时抛错', () => {
    const rng = new Rng(1)
    expect(() => rng.weighted([['a', 0]] as const)).toThrow()
    expect(() => rng.weighted([] as const)).toThrow()
  })

  it('fork(salt) 产生独立且确定的子流', () => {
    const a = new Rng(42).fork(1)
    const b = new Rng(42).fork(1)
    const c = new Rng(42).fork(2)
    expect(Array.from({ length: 5 }, () => a.next())).toEqual(
      Array.from({ length: 5 }, () => b.next()),
    )
    expect(a.next()).not.toBe(c.next())
  })

  it('fork 不消耗父流状态', () => {
    const parent = new Rng(42)
    const first = parent.next()
    const parent2 = new Rng(42)
    parent2.fork(7)
    expect(parent2.next()).toBe(first)
  })

  it('pick 只返回数组中的元素', () => {
    const rng = new Rng(5)
    const arr = [10, 20, 30] as const
    for (let i = 0; i < 50; i += 1) {
      expect(arr).toContain(rng.pick(arr))
    }
  })
})
