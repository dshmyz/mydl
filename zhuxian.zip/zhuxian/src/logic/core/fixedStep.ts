/**
 * 固定时间步进控制器。
 *
 * 把不稳定的真实帧间隔（渲染帧率）转换为稳定的逻辑步长：
 * 逻辑层永远以 `dt` 为步长被整数次调用，因此逻辑演进与渲染帧率解耦、可复现。
 * 渲染侧用 `alpha`（本帧余量占一个 dt 的比例）做位置插值，避免抖动。
 */

/** 浮点取整补偿，1 纳秒，远小于任何有意义的逻辑时长 */
const EPSILON = 1e-9

export interface StepPlan {
  /** 本次应执行的固定步次数 */
  steps: number
  /** 插值系数 ∈ [0,1)，= 累加器余量 / dt */
  alpha: number
}

export class FixedStepController {
  readonly dt: number
  readonly maxStepsPerFrame: number

  private acc = 0

  /**
   * @param dt 逻辑固定步长（秒），如 1/30
   * @param maxStepsPerFrame 单帧最多推进步数，超出部分丢弃（防死亡螺旋）
   */
  constructor(dt: number, maxStepsPerFrame = 5) {
    if (!(dt > 0)) {
      throw new Error(`FixedStepController: dt 必须为正数，收到 ${dt}`)
    }
    if (!Number.isInteger(maxStepsPerFrame) || maxStepsPerFrame < 1) {
      throw new Error(`FixedStepController: maxStepsPerFrame 必须为正整数，收到 ${maxStepsPerFrame}`)
    }
    this.dt = dt
    this.maxStepsPerFrame = maxStepsPerFrame
  }

  /** 累计一帧真实耗时，返回本帧应执行的步数与插值系数 */
  accumulate(realDeltaSeconds: number): StepPlan {
    if (realDeltaSeconds > 0) {
      this.acc += realDeltaSeconds
    }
    // 上限钳制：保留不超过 maxStepsPerFrame 个步长的积压，防止追帧雪崩
    this.acc = Math.min(this.acc, this.dt * this.maxStepsPerFrame)

    // 浮点补偿：`dt × maxSteps` 与 `dt` 的除法可能产生 2.9999996 这类误差，
    // 加一个纳秒级 EPS 再取整，保证「恰好 k 个 dt」稳定推进 k 步。
    const steps = Math.floor((this.acc + EPSILON) / this.dt)
    if (steps > 0) {
      this.acc = Math.max(0, this.acc - steps * this.dt)
    }

    return { steps, alpha: this.alpha }
  }

  /** 累加器余量（秒） */
  get accumulator(): number {
    return this.acc
  }

  /** 插值系数 ∈ [0,1) */
  get alpha(): number {
    return this.acc / this.dt
  }

  reset(): void {
    this.acc = 0
  }
}
