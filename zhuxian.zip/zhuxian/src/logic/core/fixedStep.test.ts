import { describe, expect, it } from 'vitest'

import { FixedStepController } from './fixedStep'

const DT = 1 / 30

describe('FixedStepController', () => {
  it('恰好一个 dt 推进一步，余量为 0', () => {
    const clock = new FixedStepController(DT)
    const plan = clock.accumulate(DT)
    expect(plan.steps).toBe(1)
    expect(plan.alpha).toBeCloseTo(0, 10)
  })

  it('2.5 个 dt 推进 2 步，余量 alpha ≈ 0.5', () => {
    const clock = new FixedStepController(DT)
    const plan = clock.accumulate(DT * 2.5)
    expect(plan.steps).toBe(2)
    expect(plan.alpha).toBeCloseTo(0.5, 10)
  })

  it('0 或负的 delta 不推进', () => {
    const clock = new FixedStepController(DT)
    expect(clock.accumulate(0).steps).toBe(0)
    expect(clock.accumulate(-1).steps).toBe(0)
    expect(clock.accumulator).toBe(0)
  })

  it('余量跨帧累积（小 delta 攒够一个 dt 才推进）', () => {
    const clock = new FixedStepController(DT)
    expect(clock.accumulate(0.01).steps).toBe(0)
    const plan = clock.accumulate(0.03)
    expect(plan.steps).toBe(1)
    // 0.01 + 0.03 - 1/30 ≈ 0.0067
    expect(clock.accumulator).toBeCloseTo(0.04 - DT, 10)
  })

  it('alpha 恒落在 [0,1)', () => {
    const clock = new FixedStepController(DT)
    for (const delta of [0.001, 0.017, 0.033, 0.05, 0.09, 0.4]) {
      const alpha = clock.accumulate(delta).alpha
      expect(alpha).toBeGreaterThanOrEqual(0)
      expect(alpha).toBeLessThan(1)
    }
  })

  it('单帧步数受 maxStepsPerFrame 限制，防死亡螺旋', () => {
    const clock = new FixedStepController(DT, 3)
    const plan = clock.accumulate(1.0)
    expect(plan.steps).toBe(3)
    // 溢出被丢弃，累加器不得留下超过一个 dt 的积压
    expect(clock.accumulator).toBeLessThan(DT)
  })

  it('reset 清空累加器', () => {
    const clock = new FixedStepController(DT)
    clock.accumulate(DT * 0.9)
    expect(clock.accumulator).toBeGreaterThan(0)
    clock.reset()
    expect(clock.accumulator).toBe(0)
  })

  it('相同 delta 序列产出相同步进计划（确定性）', () => {
    const deltas = [0.012, 0.031, 0.008, 0.05, 0.02, 0.02]
    const run = () => {
      const clock = new FixedStepController(DT)
      return deltas.map((d) => clock.accumulate(d).steps)
    }
    expect(run()).toEqual(run())
  })
})
