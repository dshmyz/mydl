import type { GameDataIndex } from '../indexes'
import type { GameData } from '../types/gameData'
import type { SkillKey } from '../types/common'
import type { EffectSpec } from '../types/common'

import { addError, expectTrue, type ValidationIssue } from './issues'

/** 工具：收集所有效果原语（含境界强化的附加效果） */
function collectEffects(effects: readonly EffectSpec[], extras?: EffectSpec[][]): EffectSpec[] {
  return [...effects, ...(extras ?? []).flatMap((e) => e)]
}

function assertUniqueIds(
  issues: ValidationIssue[],
  rule: string,
  table: string,
  ids: readonly string[],
): void {
  const seen = new Set<string>()
  for (const id of ids) {
    if (seen.has(id)) {
      addError(issues, rule, `${table} 存在重复 id「${id}」`)
    }
    seen.add(id)
  }
}

/** 各表主键唯一 */
export function checkUniqueIds(data: GameData, issues: ValidationIssue[]): void {
  assertUniqueIds(issues, 'ref.uniqueId', 'heroes', data.heroes.map((h) => h.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'skills', data.skills.map((s) => s.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'monsters', data.monsters.map((m) => m.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'waveTemplates', data.waveTemplates.map((t) => t.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'events', data.events.map((e) => e.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'materials', data.materials.map((m) => m.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'equipment', data.equipment.map((e) => e.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'affixes', data.affixes.map((a) => a.id))
  assertUniqueIds(issues, 'ref.uniqueId', 'nodes', data.nodes.map((n) => n.id))
}

/** 引用完整性（数值文档 校验规则 的「引用完整性」项） */
export function checkReferences(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  // 技能持有者
  for (const skill of data.skills) {
    if (!index.hero.has(skill.owner) && !index.monster.has(skill.owner)) {
      addError(
        issues,
        'ref.skillOwner',
        `技能「${skill.id}」的 owner「${skill.owner}」既不是英雄也不是怪物`,
      )
    }
  }

  // 英雄技能键位 ↔ 技能表双向一致
  for (const hero of data.heroes) {
    for (const key of Object.keys(hero.skills) as SkillKey[]) {
      const skillId = hero.skills[key]
      const skill = index.skill.get(skillId)
      if (!skill) {
        addError(issues, 'ref.heroSkill', `英雄「${hero.id}」的 ${key} 指向不存在的技能「${skillId}」`)
        continue
      }
      if (skill.owner !== hero.id) {
        addError(
          issues,
          'ref.heroSkill',
          `英雄「${hero.id}」的 ${key} 技能「${skillId}」owner 为「${skill.owner}」，不一致`,
        )
      }
      if (skill.key !== key) {
        addError(
          issues,
          'ref.heroSkill',
          `英雄「${hero.id}」的 ${key} 技能「${skillId}」标注键位为「${skill.key}」，不一致`,
        )
      }
    }
  }

  // 怪物招式
  for (const monster of data.monsters) {
    for (const skillId of monster.skills ?? []) {
      const skill = index.skill.get(skillId)
      if (!skill) {
        addError(issues, 'ref.monsterSkill', `怪物「${monster.id}」引用了不存在的技能「${skillId}」`)
      } else if (skill.owner !== monster.id) {
        addError(
          issues,
          'ref.monsterSkill',
          `怪物「${monster.id}」的技能「${skillId}」owner 为「${skill.owner}」，不一致`,
        )
      }
    }
  }

  // 波次模板引用
  for (const template of data.waveTemplates) {
    for (const group of template.groups) {
      expectTrue(
        issues,
        'ref.waveGroup',
        index.monster.has(group.monsterId),
        `模板「${template.id}」引用了不存在的怪物「${group.monsterId}」`,
      )
    }
    if (template.elite) {
      expectTrue(
        issues,
        'ref.waveElite',
        index.monster.has(template.elite.monsterId),
        `模板「${template.id}」的精英引用了不存在的怪物「${template.elite.monsterId}」`,
      )
    }
    for (const eventId of template.eventHooks) {
      expectTrue(
        issues,
        'ref.eventHook',
        index.event.has(eventId),
        `模板「${template.id}」挂载了不存在的事件「${eventId}」`,
      )
    }
    for (const monsterId of template.waveBossPool) {
      expectTrue(
        issues,
        'ref.waveBossPool',
        index.monster.has(monsterId),
        `模板「${template.id}」的波次 BOSS 池含不存在的怪物「${monsterId}」`,
      )
    }
  }

  // 配方 / 掉落引用的材料
  for (const recipe of data.recipes) {
    expectTrue(
      issues,
      'ref.recipeMaterial',
      index.material.has(recipe.materialId),
      `配方 ${recipe.line} T${recipe.fromTier}→T${recipe.toTier} 引用了不存在的材料「${recipe.materialId}」`,
    )
    if (recipe.scrollId) {
      addError(
        issues,
        'ref.recipeScroll',
        `配方 ${recipe.line} T${recipe.fromTier}→T${recipe.toTier} 声明了卷轴「${recipe.scrollId}」，但 M1 未定义卷轴表`,
      )
    }
  }
  for (const row of data.drops) {
    for (const materialId of row.materialPool) {
      expectTrue(
        issues,
        'ref.dropMaterial',
        index.material.has(materialId),
        `掉落来源「${row.source}」的材料池含不存在的材料「${materialId}」`,
      )
    }
  }

  // 召唤目标必须存在
  const summoners: { owner: string; effect: EffectSpec }[] = []
  for (const skill of data.skills) {
    for (const effect of collectEffects(
      skill.effects,
      (skill.upgrades ?? []).map((u) => u.extraEffects ?? []),
    )) {
      summoners.push({ owner: `技能「${skill.id}」`, effect })
    }
  }
  for (const affix of data.affixes) {
    summoners.push({ owner: `词条「${affix.id}」`, effect: affix.effect })
  }
  for (const { owner, effect } of summoners) {
    if (effect.kind === 'summon') {
      expectTrue(
        issues,
        'ref.summonTarget',
        index.monster.has(effect.monsterId),
        `${owner} 召唤了不存在的怪物「${effect.monsterId}」`,
      )
    }
  }
}

/** 配方无环（数值文档 校验规则 / 主文档 §6.13） */
export function checkRecipeAcyclic(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  const seen = new Set<string>()
  for (const recipe of data.recipes) {
    expectTrue(
      issues,
      'recipe.tierOrder',
      recipe.fromTier < recipe.toTier,
      `配方 ${recipe.line} T${recipe.fromTier}→T${recipe.toTier} 档位未递增（fromTier 必须 < toTier）`,
    )
    const key = `${recipe.line}:${recipe.fromTier}`
    if (seen.has(key)) {
      addError(issues, 'recipe.duplicate', `同线同起始档存在重复配方：${key}`)
    }
    seen.add(key)

    const material = index.material.get(recipe.materialId)
    if (material && material.line && material.line !== recipe.line) {
      addError(
        issues,
        'recipe.materialLine',
        `配方 ${key} 使用材料「${material.id}」（${material.line} 线），与配方线不一致`,
      )
    }
    // 材料的目标档必须与配方目标档一致
    if (material && material.toTier !== recipe.toTier) {
      addError(
        issues,
        'recipe.materialTier',
        `配方 ${key} 目标档 T${recipe.toTier}，但材料「${material.id}」的目标档为 T${material.toTier}`,
      )
    }
  }
}

/** 机制分组不重复 + BOSS 必登记机制（主文档 附录 B 配置约束） */
export function checkMechanismGrouping(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  for (const monster of data.monsters) {
    if (monster.class === 'waveBoss' || monster.class === 'anchorBoss') {
      expectTrue(
        issues,
        'mechanism.bossRegistered',
        monster.mechanism !== undefined && monster.mechanism !== 'none',
        `BOSS「${monster.id}」未登记机制档位（主文档 附录 B 要求每只 BOSS 至少命中一种机制）`,
      )
      expectTrue(
        issues,
        'mechanism.bossTypes',
        (monster.mechanismType?.length ?? 0) > 0,
        `BOSS「${monster.id}」未登记机制类型标签（mechanismType）`,
      )
    }
  }

  for (const template of data.waveTemplates) {
    const ids = [
      ...template.groups.map((g) => g.monsterId),
      ...(template.elite ? [template.elite.monsterId] : []),
      ...template.waveBossPool,
    ]
    const used = new Map<string, string>()
    for (const id of ids) {
      const monster = index.monster.get(id)
      for (const tag of monster?.mechanismType ?? []) {
        const previous = used.get(tag)
        if (previous) {
          addError(
            issues,
            'mechanism.duplicate',
            `模板「${template.id}」内机制「${tag}」重复：${previous} 与 ${id}`,
          )
        } else {
          used.set(tag, id)
        }
      }
    }
  }
}
