/**
 * 启动校验的公共类型。
 *
 * 分级（对齐数值文档 §9.5）：
 *  - `error`：结构 / 引用 / 硬上限越界 → **fail fast 阻断**
 *  - `warn` ：节奏带 / 经验对齐等调参类偏差 → **报告**，不阻断
 */
export interface ValidationIssue {
  rule: string
  severity: 'error' | 'warn'
  message: string
}

export interface ValidationResult {
  errors: ValidationIssue[]
  warnings: ValidationIssue[]
}

export class ConfigError extends Error {
  readonly issues: readonly ValidationIssue[]

  constructor(issues: readonly ValidationIssue[]) {
    super(
      `配置校验失败（${issues.length} 项）:\n` +
        issues.map((issue) => `  · [${issue.rule}] ${issue.message}`).join('\n'),
    )
    this.name = 'ConfigError'
    this.issues = issues
  }
}

export function addError(issues: ValidationIssue[], rule: string, message: string): void {
  issues.push({ rule, severity: 'error', message })
}

export function addWarn(issues: ValidationIssue[], rule: string, message: string): void {
  issues.push({ rule, severity: 'warn', message })
}

/** 断言辅助：条件不成立时压入一条 error */
export function expectTrue(
  issues: ValidationIssue[],
  rule: string,
  condition: boolean,
  message: string,
): boolean {
  if (!condition) {
    addError(issues, rule, message)
  }
  return condition
}

/** 相对偏差（|actual − expected| / expected） */
export function relError(actual: number, expected: number): number {
  if (expected === 0) {
    return actual === 0 ? 0 : Number.POSITIVE_INFINITY
  }
  return Math.abs(actual - expected) / Math.abs(expected)
}
