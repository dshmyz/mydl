import type { GameDataIndex } from '../indexes'
import type { Tier } from '../types/common'
import type { GameData } from '../types/gameData'

import { addError, expectTrue, relError, type ValidationIssue } from './issues'

const ALL_TIERS: readonly Tier[] = [1, 2, 3, 4, 5, 6]

/** 区间 → 端点节点 id（数值文档 §5.1：Ⅰ=N1→N2，Ⅱ=N2→N4，Ⅲ=N4→N6） */
const INTERVAL_NODES: Record<string, readonly [string, string]> = {
  I: ['N1', 'N2'],
  II: ['N2', 'N4'],
  III: ['N4', 'N6'],
}

/** 校验规则 2：档位 K 表完整 */
export function checkTierArmorKComplete(data: GameData, issues: ValidationIssue[]): void {
  for (const tier of ALL_TIERS) {
    expectTrue(
      issues,
      'k.complete',
      data.tierArmorK.filter((r) => r.tier === tier).length === 1,
      `档位 K 表缺少或多出 T${tier} 行`,
    )
  }
}

/** 校验规则 1：K = 2.33 × 标准 DEF，且同档互殴减伤率 ∈ [25%, 35%] */
export function checkArmorKDerivation(data: GameData, issues: ValidationIssue[]): void {
  for (const row of data.tierArmorK) {
    const ratio = row.k / row.standardDef
    expectTrue(
      issues,
      'k.derivation',
      relError(ratio, 2.33) <= 0.03,
      `T${row.tier} 的 K(${row.k}) / 标准DEF(${row.standardDef}) = ${ratio.toFixed(3)}，应约为 2.33`,
    )
    const defRed = row.standardDef / (row.standardDef + row.k)
    expectTrue(
      issues,
      'k.defRedBand',
      defRed >= 0.25 && defRed <= 0.35,
      `T${row.tier} 同档互殴减伤率 ${(defRed * 100).toFixed(1)}% 越界（应 ∈ [25%, 35%]）`,
    )
  }
}

/** 校验规则 3：节点派生式一致性（英雄 DEF = 标准 DEF；小怪 DEF = 标准 DEF × 比例；精英 = 小怪 × 系数） */
export function checkNodeDerivation(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  const { eliteMul, minion } = data.derivation
  for (const node of data.nodes) {
    const tierRow = index.tierArmorK.get(node.tier)
    if (!tierRow) {
      continue
    }
    expectTrue(
      issues,
      'node.heroDef',
      node.heroDef === tierRow.standardDef,
      `节点 ${node.id} 英雄 DEF ${node.heroDef} ≠ 标准 DEF ${tierRow.standardDef}（${node.tier} 档）`,
    )
    const expectMinionDef = Math.round(tierRow.standardDef * minion.defRatio)
    expectTrue(
      issues,
      'node.minionDef',
      Math.abs(node.minionDef - expectMinionDef) <= 1,
      `节点 ${node.id} 小怪 DEF ${node.minionDef} 与 标准DEF×比例 的期望 ${expectMinionDef} 偏差过大`,
    )
    expectTrue(
      issues,
      'node.eliteHp',
      relError(node.eliteHp, node.minionHp * eliteMul.hp) <= 0.15,
      `节点 ${node.id} 精英 HP ${node.eliteHp} 与 小怪×${eliteMul.hp} 的期望 ${(node.minionHp * eliteMul.hp).toFixed(0)} 偏差 > 15%`,
    )
    expectTrue(
      issues,
      'node.eliteAtk',
      relError(node.eliteAtk, node.minionAtk * eliteMul.atk) <= 0.15,
      `节点 ${node.id} 精英 ATK ${node.eliteAtk} 与 小怪×${eliteMul.atk} 的期望 ${(node.minionAtk * eliteMul.atk).toFixed(0)} 偏差 > 15%`,
    )
  }
}

/** 校验规则 8：区间起止严格对齐 L0 锚点，护甲档与节点一致 */
export function checkIntervalConsistency(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  for (const interval of data.intervals) {
    const nodeIds = INTERVAL_NODES[interval.id]
    if (!nodeIds) {
      addError(issues, 'interval.unknown', `区间「${interval.id}」未登记端点节点映射`)
      continue
    }
    const start = index.node.get(nodeIds[0])
    const end = index.node.get(nodeIds[1])
    if (!start || !end) {
      addError(issues, 'interval.missingNode', `区间「${interval.id}」的端点节点 ${nodeIds.join('/')} 缺失`)
      continue
    }
    expectTrue(
      issues,
      'interval.hpEndpoint',
      interval.hp[0] === start.minionHp && interval.hp[1] === end.minionHp,
      `区间「${interval.id}」HP 端点 [${interval.hp.join(', ')}] 与节点 ${nodeIds.join('→')} 的 [${start.minionHp}, ${end.minionHp}] 不一致`,
    )
    expectTrue(
      issues,
      'interval.atkEndpoint',
      interval.atk[0] === start.minionAtk && interval.atk[1] === end.minionAtk,
      `区间「${interval.id}」ATK 端点 [${interval.atk.join(', ')}] 与节点 ${nodeIds.join('→')} 的 [${start.minionAtk}, ${end.minionAtk}] 不一致`,
    )
    expectTrue(
      issues,
      'interval.armorTier',
      interval.armorTier[0] === start.tier && interval.armorTier[1] === end.tier,
      `区间「${interval.id}」护甲档 [${interval.armorTier.join(', ')}] 与节点档位 [${start.tier}, ${end.tier}] 不一致`,
    )
  }
}

/** 硬上限（数值文档 §3.4 / §9.1）与数值形态 */
export function checkHardLimits(data: GameData, issues: ValidationIssue[]): void {
  const { limits } = data
  expectTrue(issues, 'limits.values', limits.defRedMax === 0.75 && limits.critMax === 0.6 && limits.dodgeMax === 0.25 && limits.critDmgMax === 2.5,
    `护卫常量被改动：defRedMax=${limits.defRedMax} critMax=${limits.critMax} dodgeMax=${limits.dodgeMax} critDmgMax=${limits.critDmgMax}`)

  for (const hero of data.heroes) {
    // 英雄面板的会心 / 闪避以百分数登记（5 = 5%），而 limits 中的上限是小数，故先换算再比较
    expectTrue(issues, 'limits.heroCrit', hero.base.crit / 100 <= limits.critMax,
      `英雄「${hero.id}」会心 ${hero.base.crit}% 超过上限 ${limits.critMax * 100}%`)
    expectTrue(issues, 'limits.heroDodge', hero.base.dodge / 100 <= limits.dodgeMax,
      `英雄「${hero.id}」闪避 ${hero.base.dodge}% 超过上限 ${limits.dodgeMax * 100}%`)
    expectTrue(issues, 'limits.heroCritDmg', hero.base.critDmg <= limits.critDmgMax,
      `英雄「${hero.id}」暴击伤害 ${hero.base.critDmg} 超过上限 ${limits.critDmgMax}`)
  }
}

/** 数值非负且主要属性为整数（校验规则 5） */
export function checkNumericShape(data: GameData, issues: ValidationIssue[]): void {
  for (const hero of data.heroes) {
    const b = hero.base
    expectTrue(
      issues,
      'numeric.heroBase',
      [b.hp, b.mp, b.atk, b.sp, b.def, b.spd].every((v) => Number.isInteger(v) && v >= 0),
      `英雄「${hero.id}」的 HP/MP/ATK/SP/DEF/SPD 必须为非负整数`,
    )
    expectTrue(
      issues,
      'numeric.heroRange',
      [b.dodge, b.crit, b.critDmg].every((v) => v >= 0),
      `英雄「${hero.id}」的闪避/会心/暴伤必须为非负`,
    )
  }
  for (const monster of data.monsters) {
    const { mul } = monster
    expectTrue(
      issues,
      'numeric.monsterMul',
      [mul.hp, mul.atk, mul.def, mul.spd].every((v) => v > 0),
      `怪物「${monster.id}」的属性系数必须为正数`,
    )
    expectTrue(
      issues,
      'numeric.monsterAtkSpeed',
      monster.attackSpeed > 0,
      `怪物「${monster.id}」攻击速度必须为正数`,
    )
    if (monster.class === 'anchorBoss') {
      expectTrue(
        issues,
        'numeric.bossHp',
        typeof monster.targetHp4p === 'number' && monster.targetHp4p > 0,
        `锚点 BOSS「${monster.id}」缺少有效的 targetHp4p`,
      )
    }
  }
}

/** 校验规则 6：成长线乘法（L(25) × R(太清) × E(T6) = L0 端点倍率）＋ 三线单调不减 */
export function checkGrowthMultipliers(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  const first = index.node.get('N1')
  const last = index.node.get('N6')
  const taiqing = index.rank.get('taiqing')
  const e6 = index.eCurve.get(6)
  if (!first || !last || !taiqing || !e6) {
    addError(issues, 'growth.missing', '成长校验缺少 N1/N6/太清/T6 定义')
    return
  }

  // 等级分段累计须等于登记的 totalMul
  const segments = [...data.level.segments].sort((a, b) => a.fromLevel - b.fromLevel)
  let product = 1
  for (const seg of segments) {
    product *= Math.pow(1 + seg.perLevelPct, seg.toLevel - seg.fromLevel)
  }
  expectTrue(
    issues,
    'growth.levelCurve',
    relError(product, data.level.totalMul) <= 0.02,
    `等级分段累计倍率 ${product.toFixed(4)} 与登记的 totalMul ${data.level.totalMul} 偏差 > 2%`,
  )

  // 分段连续性 + 递减式增幅
  for (let i = 0; i < segments.length; i += 1) {
    const seg = segments[i]
    const next = segments[i + 1]
    if (!seg) {
      continue
    }
    if (next) {
      expectTrue(issues, 'growth.levelContinuous', seg.toLevel === next.fromLevel,
        `等级分段不连续：${seg.fromLevel}-${seg.toLevel} 与 ${next.fromLevel}-${next.toLevel}`)
      expectTrue(issues, 'growth.levelDecel', next.perLevelPct <= seg.perLevelPct,
        `等级增幅未递减：段 ${next.fromLevel}-${next.toLevel} 增幅 ${next.perLevelPct} > 上段 ${seg.perLevelPct}`)
    }
  }

  const l = data.level.totalMul
  const hpTotal = l * taiqing.hpMul * e6.hpMul
  const atkTotal = l * taiqing.atkMul * e6.atkMul
  expectTrue(
    issues,
    'growth.hpProduct',
    relError(hpTotal, last.heroHp / first.heroHp) <= 0.05,
    `L×R×E(HP) = ${hpTotal.toFixed(3)}，L0 端点 HP 倍率 ${(last.heroHp / first.heroHp).toFixed(3)}，偏差 > 5%`,
  )
  expectTrue(
    issues,
    'growth.atkProduct',
    relError(atkTotal, last.heroAtk / first.heroAtk) <= 0.05,
    `L×R×E(ATK) = ${atkTotal.toFixed(3)}，L0 端点 ATK 倍率 ${(last.heroAtk / first.heroAtk).toFixed(3)}，偏差 > 5%`,
  )

  // 三线单调不减
  let prevRank = 0
  for (const rank of data.ranks) {
    expectTrue(issues, 'growth.rankMonotonic', rank.hpMul >= prevRank,
      `境界「${rank.id}」HP 倍率 ${rank.hpMul} 低于前一境界 ${prevRank}`)
    prevRank = rank.hpMul
  }
  let prevHp = 0
  let prevAtk = 0
  for (const tier of ALL_TIERS) {
    const row = index.eCurve.get(tier)
    if (!row) {
      continue
    }
    expectTrue(issues, 'growth.eMonotonic', row.hpMul >= prevHp && row.atkMul >= prevAtk,
      `装备曲线 T${tier} 非单调不减（HP ${row.hpMul} / ATK ${row.atkMul}）`)
    prevHp = row.hpMul
    prevAtk = row.atkMul
  }
}

/** 校验规则 11：装备主属性 = E 曲线 − 1（法宝线承担 E_ATK） */
export function checkECurveAlignment(
  data: GameData,
  index: GameDataIndex,
  issues: ValidationIssue[],
): void {
  for (const item of data.equipment) {
    if (item.line !== 'weapon') {
      continue
    }
    const curve = index.eCurve.get(item.tier)
    if (!curve) {
      addError(issues, 'eCurve.missingRow', `装备「${item.id}」档位 T${item.tier} 无 E 曲线行`)
      continue
    }
    const atkStat = item.mainStats.find((s) => s.stat === 'atk')
    if (!atkStat || atkStat.mode !== 'percent') {
      addError(issues, 'eCurve.weaponStat', `法宝「${item.id}」缺少百分比形式的攻击主属性`)
      continue
    }
    expectTrue(
      issues,
      'eCurve.alignment',
      relError(atkStat.value, curve.atkMul - 1) <= 0.03,
      `法宝「${item.id}」攻击加成 ${(atkStat.value * 100).toFixed(1)}% 应等于 E_ATK(T${item.tier}) − 1 = ${((curve.atkMul - 1) * 100).toFixed(1)}%`,
    )
  }
}

/** 校验规则 10：人数缩放自洽 */
export function checkPopulationSelfConsistency(data: GameData, issues: ValidationIssue[]): void {
  const { population, limits } = data
  for (const n of [1, 2, 3, 4, 5, 6]) {
    const row = population.table.find((r) => r.n === n)
    if (!row) {
      addError(issues, 'population.missing', `人数缩放表缺少 N=${n} 行`)
      continue
    }
    expectTrue(
      issues,
      'population.product',
      relError(row.hpMul * row.countMul, n) <= 0.05,
      `N=${n} 时 hpMul×countMul = ${(row.hpMul * row.countMul).toFixed(3)}，应约为 ${n}`,
    )
    expectTrue(issues, 'population.dmgConstant', row.dmgMul === 1,
      `N=${n} 伤害乘数应为恒定 1.0，实际 ${row.dmgMul}`)
  }
  const six = population.table.find((r) => r.n === 6)
  if (six) {
    expectTrue(issues, 'population.countCap', six.countMul <= 2.2,
      `N=6 数量乘数 ${six.countMul} 超过护栏 2.2`)
  }
  const one = population.table.find((r) => r.n === 1)
  if (one) {
    expectTrue(issues, 'population.baseline', one.hpMul === 1 && one.countMul === 1 && one.bossMul === 1,
      `N=1 应为基准行（hpMul/countMul/bossMul 全为 1），实际 ${one.hpMul}/${one.countMul}/${one.bossMul}`)
  }
  expectTrue(issues, 'population.screenCap', population.maxOnScreen <= limits.maxOnScreenMinions,
    `population.maxOnScreen ${population.maxOnScreen} 超过 limits.maxOnScreenMinions ${limits.maxOnScreenMinions}`)
}

/** 品质表数值域（数值文档 §7.4） */
export function checkQualityTable(data: GameData, issues: ValidationIssue[]): void {
  const expected: Record<string, readonly [number, number]> = {
    lower: [1.0, 1],
    middle: [1.15, 2],
    upper: [1.3, 3],
  }
  for (const quality of data.qualities) {
    const exp = expected[quality.id]
    if (!exp) {
      addError(issues, 'quality.unknown', `未知品质 id「${quality.id}」`)
      continue
    }
    expectTrue(issues, 'quality.statMul', quality.statMul === exp[0],
      `品质「${quality.id}」数值系数应为 ${exp[0]}，实际 ${quality.statMul}`)
    expectTrue(issues, 'quality.affixCount', quality.affixCount === exp[1],
      `品质「${quality.id}」词条数应为 ${exp[1]}，实际 ${quality.affixCount}`)
  }
  for (const id of ['lower', 'middle', 'upper']) {
    expectTrue(issues, 'quality.complete', data.qualities.some((q) => q.id === id),
      `品质表缺少「${id}」行`)
  }
}

/** 词条池非空且与装备线匹配（M1 仅法宝线） */
export function checkAffixPools(data: GameData, issues: ValidationIssue[]): void {
  const maxAffixes = Math.max(...data.qualities.map((q) => q.affixCount))
  for (const line of new Set(data.equipment.map((e) => e.line))) {
    const pool = data.affixes.filter((a) => a.line === line)
    expectTrue(
      issues,
      'affix.poolSize',
      pool.length >= maxAffixes,
      `装备线「${line}」的词条池只有 ${pool.length} 条，不足以支撑最高品质的 ${maxAffixes} 条词条`,
    )
  }
}
