import { buildIndex, type GameDataIndex } from '../indexes'
import type { GameData } from '../types/gameData'

import { checkEconomy } from './economy'
import type { ValidationIssue, ValidationResult } from './issues'
import {
  checkAffixPools,
  checkArmorKDerivation,
  checkECurveAlignment,
  checkGrowthMultipliers,
  checkHardLimits,
  checkIntervalConsistency,
  checkNodeDerivation,
  checkNumericShape,
  checkPopulationSelfConsistency,
  checkQualityTable,
  checkTierArmorKComplete,
} from './numeric'
import {
  checkMechanismGrouping,
  checkRecipeAcyclic,
  checkReferences,
  checkUniqueIds,
} from './reference'

/**
 * 依次执行全部启动校验规则，按 severity 分流为 error / warning。
 *
 * 顺序刻意「由结构到数值」：先引用完整性、再数值形态与派生，便于错误按层级阅读。
 * 规则实现分文件（reference / numeric / economy），本函数只做编排，不承载具体判断。
 */
export function validateGameData(data: GameData, index?: GameDataIndex): ValidationResult {
  const resolved = index ?? buildIndex(data)
  const issues: ValidationIssue[] = []

  // —— 结构与引用 ——
  checkUniqueIds(data, issues)
  checkReferences(data, resolved, issues)
  checkRecipeAcyclic(data, resolved, issues)
  checkMechanismGrouping(data, resolved, issues)

  // —— 数值骨架 L0–L5 ——
  checkTierArmorKComplete(data, issues)
  checkArmorKDerivation(data, issues)
  checkNodeDerivation(data, resolved, issues)
  checkIntervalConsistency(data, resolved, issues)
  checkHardLimits(data, issues)
  checkNumericShape(data, issues)
  checkGrowthMultipliers(data, resolved, issues)
  checkECurveAlignment(data, resolved, issues)
  checkPopulationSelfConsistency(data, issues)
  checkQualityTable(data, issues)
  checkAffixPools(data, issues)

  // —— 经济 L6 ——
  checkEconomy(data, issues)

  return {
    errors: issues.filter((issue) => issue.severity === 'error'),
    warnings: issues.filter((issue) => issue.severity === 'warn'),
  }
}
