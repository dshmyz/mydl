import { describe, expect, it } from 'vitest'

import { loadGameData } from '../load'
import { buildGameData } from '../tables'
import type { GameData } from '../types/gameData'

import { validateGameData } from './index'
import { ConfigError } from './issues'

/**
 * 启动校验测试。
 *
 * 规范：正常配置零 error（零 warn）；任意破坏结构 / 引用 / 数值约束的行为
 * 必须在 `loadGameData()` 处 fail fast 抛出 `ConfigError`，且携带对应规则标签。
 */

/** 深拷贝，避免污染模块级配置表 */
function cloneData(): GameData {
  return structuredClone(buildGameData())
}

/** 夹具取值：缺失即抛，避免误用 undefined 造成假绿 */
function must<T>(value: T | undefined, label: string): T {
  if (value === undefined) {
    throw new Error(`测试夹具缺少「${label}」`)
  }
  return value
}

/** 破坏配置后断言 loadGameData fail fast 且含指定规则标签 */
function expectConfigError(mutate: (data: GameData) => void, rule: string): void {
  const data = cloneData()
  mutate(data)
  let caught: unknown
  try {
    loadGameData(data)
  } catch (error) {
    caught = error
  }
  expect(caught, `期望抛出 ConfigError（规则 ${rule}），但未抛出`).toBeInstanceOf(ConfigError)
  const rules = (caught as ConfigError).issues.map((issue) => issue.rule)
  expect(rules).toContain(rule)
}

describe('启动校验 · 正常配置', () => {
  it('M1 内置配置零 error、零 warn', () => {
    const { errors, warnings } = validateGameData(buildGameData())
    expect(errors).toEqual([])
    expect(warnings).toEqual([])
  })

  it('loadGameData 正常返回，索引可用', () => {
    const loaded = loadGameData()
    expect(loaded.data.version).toBe('M1')
    expect(loaded.index.monster.get('heishui_xuanshe')?.class).toBe('anchorBoss')
    expect(loaded.index.recipe.get('weapon:1')?.toTier).toBe(2)
  })
})

describe('启动校验 · 结构 / 引用完整性（fail fast）', () => {
  it('K 表缺行 → k.complete', () => {
    expectConfigError((d) => {
      d.tierArmorK = d.tierArmorK.filter((row) => row.tier !== 3)
    }, 'k.complete')
  })

  it('英雄技能悬空引用 → ref.heroSkill', () => {
    expectConfigError((d) => {
      must(d.heroes.find((h) => h.id === 'zhangxiaofan'), 'zhangxiaofan').skills.Q = 'no_such_skill'
    }, 'ref.heroSkill')
  })

  it('波次模板引用不存在的怪物 → ref.waveGroup', () => {
    expectConfigError((d) => {
      const template = must(d.waveTemplates.find((t) => t.id === 'E1'), 'E1')
      must(template.groups[0], 'E1 首个怪物组').monsterId = 'ghost'
    }, 'ref.waveGroup')
  })

  it('配方引用不存在的材料 → ref.recipeMaterial', () => {
    expectConfigError((d) => {
      must(d.recipes[0], '首个配方').materialId = 'ghost_material'
    }, 'ref.recipeMaterial')
  })

  it('召唤目标不存在 → ref.summonTarget', () => {
    expectConfigError((d) => {
      const skill = must(d.skills.find((s) => s.id === 'hx_rage'), 'hx_rage')
      const effect = must(skill.effects[2], 'hx_rage 的召唤效果')
      if (effect.kind !== 'summon') {
        throw new Error('夹具不符：hx_rage 第三效果应为 summon')
      }
      effect.monsterId = 'ghost'
    }, 'ref.summonTarget')
  })
})

describe('启动校验 · 配方与机制约束（fail fast）', () => {
  it('配方目标档与材料目标档不一致 → recipe.materialTier', () => {
    expectConfigError((d) => {
      must(d.recipes[0], '首个配方').toTier = 3
    }, 'recipe.materialTier')
  })

  it('锚点 BOSS 未登记机制 → mechanism.bossRegistered', () => {
    expectConfigError((d) => {
      must(d.monsters.find((m) => m.id === 'heishui_xuanshe'), 'heishui_xuanshe').mechanism = 'none'
    }, 'mechanism.bossRegistered')
  })
})

describe('启动校验 · 数值骨架（fail fast）', () => {
  it('区间 HP 端点偏离 L0 锚点 → interval.hpEndpoint', () => {
    expectConfigError((d) => {
      must(d.intervals.find((i) => i.id === 'I'), '区间 I').hp = [30, 58] as const
    }, 'interval.hpEndpoint')
  })

  it('等级分段累计偏离 totalMul → growth.levelCurve', () => {
    expectConfigError((d) => {
      d.level.totalMul = 3.0
    }, 'growth.levelCurve')
  })

  it('人数缩放 hpMul×countMul ≠ N → population.product', () => {
    expectConfigError((d) => {
      must(d.population.table.find((r) => r.n === 2), 'population N=2').countMul = 9
    }, 'population.product')
  })
})

describe('启动校验 · 经济与软门控（fail fast）', () => {
  it('材料掉落幕跨两幕 → economy.softGate', () => {
    expectConfigError((d) => {
      must(d.materials.find((m) => m.id === 'bat_wing_shard'), 'bat_wing_shard').stage = 'act3'
    }, 'economy.softGate')
  })
})

describe('启动校验 · warn 不阻断启动', () => {
  it('幕一经验产出远超锚点一目标 → 仅 economy.xpAlignment warn', () => {
    const data = cloneData()
    for (const template of data.waveTemplates) {
      for (const group of template.groups) {
        group.count = 200
      }
    }
    const loaded = loadGameData(data)
    expect(loaded.warnings.map((w) => w.rule)).toContain('economy.xpAlignment')
    expect(loaded.warnings.every((w) => w.severity === 'warn')).toBe(true)
  })
})
