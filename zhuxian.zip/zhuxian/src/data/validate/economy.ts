import type { ActId, Tier } from '../types/common'
import type { GameData } from '../types/gameData'

import { addError, addWarn, expectTrue, relError, type ValidationIssue } from './issues'

/** 幕次序号（用于软门控「提前一幕」判定） */
const ACT_ORDER: Record<ActId, number> = { act1: 1, act2: 2, act3: 3 }
const ACT_BY_ORDER: Record<number, ActId> = { 1: 'act1', 2: 'act2', 3: 'act3' }

/** 每幕目标波数（数值文档 §8.1：总波 28–34 / 3 幕 ≈ 10 波） */
const WAVES_PER_ACT = 10

/** 各材料目标幕次 = 该升档解锁幕（主文档 附录 C.3） */
const TARGET_ACT_OF_TIER: Record<Tier, ActId> = {
  1: 'act1',
  2: 'act1',
  3: 'act2',
  4: 'act2',
  5: 'act3',
  6: 'act3',
}

/** 节点等级目标（数值文档 §4.7） */
const TARGET_LEVEL = { anchor1: 7, anchor2: 15, final: 25 } as const

/**
 * 经济与掉率校验（数值文档 §8 / 校验规则 14–16）。
 *
 * 收入-成本守恒与软门控为 error；经验对齐为 warn（调参类偏差，对齐 §9.5）。
 */
export function checkEconomy(data: GameData, issues: ValidationIssue[]): void {
  const { economy } = data

  // —— 收入-成本守恒：每幕金币收入须覆盖该幕解锁的单线合成成本 ——
  for (const act of ['act1', 'act2', 'act3'] as const) {
    const revenue = economy.goldPerWave[act] * WAVES_PER_ACT
    const cost = data.recipes
      .filter((r) => TARGET_ACT_OF_TIER[r.toTier] === act)
      .reduce((sum, r) => sum + r.gold, 0)
    expectTrue(
      issues,
      'economy.coverage',
      revenue >= cost,
      `幕「${act}」金币收入 ${revenue} 低于该幕单线合成成本 ${cost}，会出现卡进度`,
    )
  }

  // —— 基础材料掉率 ∈ [8%, 15%] 且随幕次单调不增 ——
  let prev = Number.POSITIVE_INFINITY
  for (const act of ['act1', 'act2', 'act3'] as const) {
    const chance = economy.materialDropChance[act]
    expectTrue(
      issues,
      'economy.dropRateBand',
      chance >= 0.08 && chance <= 0.15,
      `幕「${act}」材料掉率 ${chance} 越界（应 ∈ [0.08, 0.15]）`,
    )
    expectTrue(
      issues,
      'economy.dropRateMonotonic',
      chance <= prev,
      `材料掉率随幕次递增：${act} 为 ${chance}，高于前幕 ${prev}`,
    )
    prev = chance
  }

  // —— 软门控：材料掉落幕 ∈ {目标幕 − 提前量, 目标幕} ——
  for (const material of data.materials) {
    const targetOrder = ACT_ORDER[TARGET_ACT_OF_TIER[material.toTier]]
    const minimunOrder = Math.max(1, targetOrder - economy.softGateActs)
    const stageOrder = ACT_ORDER[material.stage]
    const allowed = stageOrder >= minimunOrder && stageOrder <= targetOrder
    expectTrue(
      issues,
      'economy.softGate',
      allowed,
      `材料「${material.id}」（T${material.fromTier}→T${material.toTier}）登记掉落幕为「${material.stage}」，` +
        `但软门控只允许 ${ACT_BY_ORDER[minimunOrder]}–${ACT_BY_ORDER[targetOrder]}（最多提前 ${economy.softGateActs} 幕）`,
    )
  }

  // —— 储物袋上限对齐 ——
  expectTrue(
    issues,
    'economy.storageCap',
    economy.storageCap === data.limits.materialStorageCap,
    `economy.storageCap ${economy.storageCap} 与 limits.materialStorageCap ${data.limits.materialStorageCap} 不一致`,
  )

  // —— 经验对齐（warn）——
  checkXpAlignment(data, issues)
}

/** 校验规则 16：由 XP 产出推算的节点等级与 L2 目标偏差 ≤ 2 级 */
function checkXpAlignment(data: GameData, issues: ValidationIssue[]): void {
  const templates = data.waveTemplates.filter((t) => t.layer === 'act1')
  if (templates.length === 0) {
    return
  }
  const avgMinions =
    templates.reduce((sum, t) => sum + t.groups.reduce((s, g) => s + g.count, 0), 0) / templates.length
  const totalMinions = Math.round(avgMinions * WAVES_PER_ACT)

  // 幕一小怪均为护甲 T1，XP = minionBase + perTier × 1
  const xpPerMinion = data.economy.xp.minionBase + data.economy.xp.perTier * 1
  const totalXp = totalMinions * xpPerMinion
  const level = levelFromXp(totalXp, data)

  const target = TARGET_LEVEL.anchor1
  if (Math.abs(level - target) > 2) {
    addWarn(
      issues,
      'economy.xpAlignment',
      `幕一 XP 产出 ${totalXp}（约 ${totalMinions} 只小怪 × ${xpPerMinion}）推算等级 L${level}，` +
        `与锚点一目标 L${target} 偏差 ${Math.abs(level - target)} 级（容差 2 级）`,
    )
  }

  // 强度曲线的 ATK 增速须慢于英雄 HP 增速，保证「越打越硬」的手感
  const nodes = data.nodes
  for (let i = 1; i < nodes.length; i += 1) {
    const prevNode = nodes[i - 1]
    const node = nodes[i]
    if (!prevNode || !node) {
      continue
    }
    const heroHpGain = node.heroHp / prevNode.heroHp
    const minionAtkGain = node.minionAtk / prevNode.minionAtk
    if (minionAtkGain > heroHpGain) {
      addError(
        issues,
        'economy.tempoDir',
        `节点 ${prevNode.id}→${node.id}：小怪 ATK 增速 ${minionAtkGain.toFixed(3)} 快于英雄 HP 增速 ${heroHpGain.toFixed(3)}，` +
          `会破坏「玩家越打越硬」的成长手感（数值文档 §2.4）`,
      )
    }
  }
}

/** 由累计 XP 反推等级：reaching level L 需 Σ need(1..L−1) */
function levelFromXp(totalXp: number, data: GameData): number {
  const { base, growth } = data.economy.levelNeed
  let cumulative = 0
  let level = 1
  while (level < data.level.maxLevel) {
    const need = base * Math.pow(growth, level - 1)
    if (cumulative + need > totalXp) {
      break
    }
    cumulative += need
    level += 1
  }
  return level
}

/** 保留给后续：断言收入盈余不超过目标成本 1.5×（数值文档 §8.5，需全量配方集） */
export function checkEconomySurplus(
  data: GameData,
  issues: ValidationIssue[],
): void {
  const totalRevenue = (data.economy.goldPerWave.act1 + data.economy.goldPerWave.act2 + data.economy.goldPerWave.act3) * WAVES_PER_ACT
  const totalCost = data.recipes.reduce((sum, r) => sum + r.gold, 0)
  if (totalCost === 0) {
    return
  }
  expectTrue(
    issues,
    'economy.surplus',
    relError(totalRevenue, totalCost) <= 1.5,
    `终局金币盈余偏离目标成本过大：收入 ${totalRevenue} / 成本 ${totalCost}`,
  )
}
