import type { DropSource, EquipLine, IntervalId, Quality, Rank, Tier } from './types/common'
import type {
  AffixDef,
  EquipmentDef,
  EquipmentECurveDef,
  MaterialDef,
  QualityDef,
  RecipeDef,
} from './types/equipment'
import type { GameData } from './types/gameData'
import type {
  AnchorNodeDef,
  DropTableRow,
  IntervalDef,
  PopulationRow,
  RankDef,
  TierArmorKDef,
} from './types/numeric'
import type { HeroDef, MonsterDef, SkillDef } from './types/units'
import type { EventDef, WaveTemplateDef } from './types/waves'

/** 配方索引键：线 + 起始档 */
export function recipeKey(line: EquipLine, fromTier: Tier): string {
  return `${line}:${fromTier}`
}

/** 配置表的 O(1) 索引（避免各系统反复 find） */
export interface GameDataIndex {
  hero: Map<string, HeroDef>
  skill: Map<string, SkillDef>
  monster: Map<string, MonsterDef>
  template: Map<string, WaveTemplateDef>
  event: Map<string, EventDef>
  material: Map<string, MaterialDef>
  equipment: Map<string, EquipmentDef>
  affix: Map<string, AffixDef>
  quality: Map<Quality, QualityDef>
  recipe: Map<string, RecipeDef>
  tierArmorK: Map<Tier, TierArmorKDef>
  eCurve: Map<Tier, EquipmentECurveDef>
  interval: Map<IntervalId, IntervalDef>
  rank: Map<Rank, RankDef>
  node: Map<string, AnchorNodeDef>
  population: Map<number, PopulationRow>
  drop: Map<DropSource, DropTableRow>
}

function indexBy<T, K>(items: readonly T[], key: (item: T) => K): Map<K, T> {
  return new Map(items.map((item) => [key(item), item]))
}

export function buildIndex(data: GameData): GameDataIndex {
  return {
    hero: indexBy(data.heroes, (h) => h.id),
    skill: indexBy(data.skills, (s) => s.id),
    monster: indexBy(data.monsters, (m) => m.id),
    template: indexBy(data.waveTemplates, (t) => t.id),
    event: indexBy(data.events, (e) => e.id),
    material: indexBy(data.materials, (m) => m.id),
    equipment: indexBy(data.equipment, (e) => e.id),
    affix: indexBy(data.affixes, (a) => a.id),
    quality: indexBy(data.qualities, (q) => q.id),
    recipe: indexBy(data.recipes, (r) => recipeKey(r.line, r.fromTier)),
    tierArmorK: indexBy(data.tierArmorK, (t) => t.tier),
    eCurve: indexBy(data.eCurve, (e) => e.tier),
    interval: indexBy(data.intervals, (i) => i.id),
    rank: indexBy(data.ranks, (r) => r.id),
    node: indexBy(data.nodes, (n) => n.id),
    population: indexBy(data.population.table, (p) => p.n),
    drop: indexBy(data.drops, (d) => d.source),
  }
}
