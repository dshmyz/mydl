import type { ActId, Rarity, RouteId } from './common'

/** 波次模板中的怪物构成（1 人基准数量） */
export interface WaveMonsterGroup {
  monsterId: string
  count: number
}

/** 模板携带的精英位（模板决定，非每波必有；数值文档 §5.3） */
export interface EliteSlot {
  min: number
  max: number
  monsterId: string
}

/** 波次模板（主文档 附录 D.1） */
export interface WaveTemplateDef {
  id: string
  layer: ActId
  name: string
  /** 1 人基准小怪构成，实际数量按 L4 countMul 缩放 */
  groups: WaveMonsterGroup[]
  route: RouteId
  elite?: EliteSlot
  /** 允许挂载的事件 id 子集（主文档 附录 E.4） */
  eventHooks: string[]
  waveBossPool: string[]
  note?: string
}

/** 事件效果原语（M1 仅时序类） */
export type EventEffect = {
  kind: 'waveTiming'
  /** 提前秒数（下一波提前） */
  earlySeconds: number
  /** 延后秒数（下一波延后） */
  lateSeconds: number
}

/** 随机事件（主文档 附录 E.1） */
export interface EventDef {
  id: string
  name: string
  rarity: Rarity
  /** 抽取权重 */
  weight: number
  /** 冷却窗口（同类事件 N 波内不重复） */
  cooldown: number
  /** 最早可出现的幕 */
  minAct: ActId
  effect: EventEffect
}
