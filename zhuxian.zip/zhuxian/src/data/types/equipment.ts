import type {
  ActId,
  EffectSpec,
  EquipLine,
  Quality,
  StatValue,
  Tier,
} from './common'

/** 品质分级（数值文档 §7.4） */
export interface QualityDef {
  id: Quality
  name: string
  /** 整件数值系数 */
  statMul: number
  /** 词条数量 */
  affixCount: number
}

/** 合成材料（主文档 附录 C.3，含软门控阶段） */
export interface MaterialDef {
  id: string
  name: string
  fromTier: Tier
  toTier: Tier
  /** 线专属；省略 = 通用辅料（任意线可用） */
  line?: EquipLine
  /** 掉落幕（软门控：∈ {目标幕 − 1, 目标幕}） */
  stage: ActId
}

/** 词条定义（按线分池，数值文档 §7.5） */
export interface AffixDef {
  id: string
  line: EquipLine
  name: string
  effect: EffectSpec
}

/** 升档配方（数值文档 §8.2 / 主文档 附录 C.4） */
export interface RecipeDef {
  line: EquipLine
  fromTier: Tier
  toTier: Tier
  gold: number
  spirit: number
  materialId: string
  materialCount: number
  /** 是否需要投入同线当前档装备作为合成素材 */
  requiresSourceItem: boolean
  scrollId?: string
}

/** 装备定义（统一装备模型，主文档 §6.13） */
export interface EquipmentDef {
  id: string
  line: EquipLine
  tier: Tier
  name: string
  /** 中品基线主属性（数值文档 §7.3） */
  mainStats: StatValue[]
}

/** 装备倍率曲线 E（数值文档 §4.6） */
export interface EquipmentECurveDef {
  tier: Tier
  hpMul: number
  atkMul: number
}
