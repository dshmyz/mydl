/**
 * 数据层通用类型。
 *
 * 全部枚举 / 原语与设计文档口径一致：
 *  - 数值口径见《2026-10-13-数值体系.md》
 *  - 内容口径见《2026-10-13-诛仙青云守卫战-设计文档.md》附录
 */

/** 伤害类型（数值文档 §3.2） */
export type DamageType = 'physical' | 'magic' | 'real'

/** 装备档位 T1–T6（数值文档 §3.3） */
export type Tier = 1 | 2 | 3 | 4 | 5 | 6

/** 境界（数值文档 §4.5） */
export type Rank = 'yuqing' | 'shangqing' | 'taiqing'

/** 品质 下品 / 中品 / 上品（数值文档 §7.4） */
export type Quality = 'lower' | 'middle' | 'upper'

/** 装备线：法宝 / 道袍 / 冠巾 / 灵佩 / 云履（主文档 §6.2） */
export type EquipLine = 'weapon' | 'robe' | 'crown' | 'pendant' | 'boots'

/** BOSS 机制档位：机制越重，HP 预算越薄（数值文档 §5.4） */
export type MechanismTier = 'none' | 'light' | 'mid' | 'heavy'

/** 事件稀有度（主文档 §3.4） */
export type Rarity = 'common' | 'rare' | 'epic'

/** 技能键位 Q / W / E / R（主文档 §四） */
export type SkillKey = 'Q' | 'W' | 'E' | 'R'

/** 幕次 / 难度层（主文档 §3.1） */
export type ActId = 'act1' | 'act2' | 'act3'

/** 强度区间 Ⅰ/Ⅱ/Ⅲ（数值文档 §5.1） */
export type IntervalId = 'I' | 'II' | 'III'

/** 进攻路线（主文档 附录 D.1） */
export type RouteId = 'main' | 'main+flank' | 'dual'

/** 属性键，一一对应数值文档 §2.1 */
export type StatKey = 'hp' | 'mp' | 'atk' | 'sp' | 'def' | 'spd' | 'dodge' | 'crit' | 'critDmg'

/** 单位属性集合（战斗结算的统一输入） */
export type Stats = Record<StatKey, number>

/** 技能作用范围形态 */
export type TargetShape = 'single' | 'cone' | 'aoeSelf' | 'aoeGround' | 'self'

/** 怪物角色（决定掉落来源与 AI 行为） */
export type MonsterClass = 'minion' | 'elite' | 'waveBoss' | 'anchorBoss'

/** 掉落来源（主文档 附录 C.2） */
export type DropSource = 'minion' | 'elite' | 'waveBoss' | 'anchorBoss'

/**
 * Modifier 效果原语。
 *
 * 技能 / 装备 / 词条 / BOSS 招式全部由这些原语组合而成，不写特殊逻辑
 * （主文档 §6.7「加技能 = 加效果组合，不写新系统」）。
 *
 * 约定：`duration` 省略 = 永久（由装备等来源持续提供，来源移除即失效）。
 */
export type EffectSpec =
  /** 吸血：回复造成伤害的百分比为气血 */
  | { kind: 'lifesteal'; percent: number }
  /** 护盾：按最大气血百分比或固定值，持续 duration 秒 */
  | { kind: 'shield'; percentOfMaxHp?: number; flat?: number; duration: number }
  /** 治疗：固定值或最大气血百分比 */
  | { kind: 'heal'; flat?: number; percentOfMaxHp?: number }
  /** 击退（格） */
  | { kind: 'knockback'; distance: number }
  /** 属性修饰：flat 固定值 / percent 百分比 */
  | { kind: 'statMod'; stat: StatKey; mode: 'flat' | 'percent'; value: number; duration?: number }
  /** 受伤乘数（< 1 为减伤，对应公式 dmgMult 的 Σ减伤修正） */
  | { kind: 'damageTakenMul'; value: number; duration: number }
  /** 造成伤害乘数（> 1 为增伤，对应公式 dmgMult 的 Σ增伤） */
  | { kind: 'damageDealtMul'; value: number; duration: number }
  /** 叠层增伤（如「魔气」+3%/层，上限 5 层） */
  | { kind: 'stackDamage'; stackId: string; perStack: number; maxStacks: number; duration: number }
  /** 定身（无法移动） */
  | { kind: 'root'; duration: number }
  /** 召唤：生成 count 只指定怪物 */
  | { kind: 'summon'; monsterId: string; count: number }

/** 属性数值对（用于单位基线 / 装备主属性） */
export interface StatValue {
  stat: StatKey
  mode: 'flat' | 'percent'
  value: number
}
