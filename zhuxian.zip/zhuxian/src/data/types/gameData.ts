import type {
  EquipmentDef,
  EquipmentECurveDef,
  QualityDef,
  AffixDef,
  MaterialDef,
  RecipeDef,
} from './equipment'
import type {
  AnchorNodeDef,
  DerivationDef,
  DropTableRow,
  EconomyDef,
  IntervalDef,
  LevelDef,
  LimitsDef,
  MechanismMultipliers,
  PopulationDef,
  RankDef,
  TierArmorKDef,
} from './numeric'
import type { HeroDef, MonsterDef, SkillDef } from './units'
import type { EventDef, WaveTemplateDef } from './waves'

/**
 * 全部配置表的聚合（data/ 层的唯一入口产物）。
 *
 * 由 `loadGameData()` 装配并执行启动校验；配置错误直接 fail fast。
 */
export interface GameData {
  version: string
  sim: { fixedDt: number; defaultSeed: number }

  // —— 数值骨架 L0–L7 ——
  limits: LimitsDef
  mechanismMul: MechanismMultipliers
  nodes: AnchorNodeDef[]
  tierArmorK: TierArmorKDef[]
  intervals: IntervalDef[]
  derivation: DerivationDef
  population: PopulationDef
  level: LevelDef
  ranks: RankDef[]
  eCurve: EquipmentECurveDef[]
  economy: EconomyDef

  // —— 装备与掉落 ——
  qualities: QualityDef[]
  affixes: AffixDef[]
  materials: MaterialDef[]
  recipes: RecipeDef[]
  equipment: EquipmentDef[]
  drops: DropTableRow[]

  // —— 内容 ——
  heroes: HeroDef[]
  skills: SkillDef[]
  monsters: MonsterDef[]
  waveTemplates: WaveTemplateDef[]
  events: EventDef[]
}
