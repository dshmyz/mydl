import type {
  ActId,
  DropSource,
  IntervalId,
  MechanismTier,
  Rank,
  SkillKey,
  Tier,
} from './common'

/** 减伤系数 K 挂档位（数值文档 §3.3） */
export interface TierArmorKDef {
  tier: Tier
  /** 同档标准 DEF */
  standardDef: number
  /** K = 2.33 × 标准 DEF */
  k: number
}

/** 强度区间（数值文档 §5.1） */
export interface IntervalDef {
  id: IntervalId
  act: ActId
  /** 小怪 HP 起止（1 人基准） */
  hp: readonly [number, number]
  /** 小怪 ATK 起止（1 人基准） */
  atk: readonly [number, number]
  /**
   * 区间起止的**护甲档**（= L0 节点序号，决定标准 DEF 与 K 表引用）。
   *
   * 注意：数值文档 §5.1 表格里的「档位」是**内容/装备档**（另一套刻度，§4.7 用），
   * 与护甲档不同源；本字段专用于 DEF / K 推导，避免两套刻度混用。
   */
  armorTier: readonly [Tier, Tier]
}

/** 派生关系（数值文档 §2.4） */
export interface DerivationDef {
  /** 英雄基准攻速（次/秒） */
  heroAttackSpeed: number
  /** 技能平均等效系数 */
  skillCoefficient: number
  /** 全队效率折损 */
  partyEfficiency: number
  /** 小怪区间基线之外的固定项 */
  minion: {
    spd: number
    attackSpeed: number
    range: number
    /** 小怪 DEF = 同档标准 DEF × 该比例 */
    defRatio: number
  }
  /** 精英 = 小怪 × 系数 */
  eliteMul: { hp: number; atk: number; def: number }
  /** 波次 BOSS HP = 小怪 × 该系数 */
  waveBossHpMul: number
  /** 锚点 BOSS 目标 TTK（秒，全队 4 人等效） */
  anchorBossTtk: number
  /** 野区 BOSS HP = 同阶锚点 BOSS × 区间 */
  wildBossHpRatio: readonly [number, number]
}

/** 人数缩放一行（数值文档 §6.3） */
export interface PopulationRow {
  n: number
  /** 群怪 HP = N^(1−α) */
  hpMul: number
  /** 数量 = N^α */
  countMul: number
  /** 单体 BOSS HP = N */
  bossMul: number
  /** 伤害恒 1.0 */
  dmgMul: number
}

export interface PopulationDef {
  alpha: number
  maxOnScreen: number
  table: PopulationRow[]
}

/** 等级曲线分段（数值文档 §4.4） */
export interface LevelSegment {
  fromLevel: number
  toLevel: number
  /** 每级增幅（小数，如 0.065） */
  perLevelPct: number
}

export interface LevelDef {
  maxLevel: number
  segments: LevelSegment[]
  /** 1 → maxLevel 总倍率 */
  totalMul: number
  /** 每 N 级 1 技能点 */
  skillPointEvery: number
}

/** 境界曲线（数值文档 §4.5） */
export interface RankDef {
  id: Rank
  name: string
  hpMul: number
  atkMul: number
  /** 该境界解锁的技能键位 */
  unlocks: SkillKey[]
}

/** 经济模型（数值文档 §8） */
export interface EconomyDef {
  /** 每波金币收入（按幕阶跃） */
  goldPerWave: Record<ActId, number>
  /** 灵石来源奖励 */
  spirit: Record<Exclude<DropSource, 'minion'>, number>
  xp: {
    minionBase: number
    perTier: number
    eliteMul: number
    bossMul: number
  }
  levelNeed: {
    base: number
    growth: number
  }
  /** 小怪材料掉率（按幕递减，数值文档 §8.3） */
  materialDropChance: Record<ActId, number>
  /** 软门控允许提前的幕数 */
  softGateActs: number
  /** 储物袋每类材料上限 */
  storageCap: number
}

/** 掉落表一行（主文档 附录 C.2） */
export interface DropTableRow {
  source: DropSource
  /** 小怪基础金币区间（1 人基准） */
  goldBase: readonly [number, number]
  /** 金币倍率（精英 ×5 / BOSS ×10 等） */
  goldMul: number
  spiritFlat: number
  /** 材料掉率覆盖；-1 = 沿用 economy.materialDropChance */
  materialChance: number
  materialPool: string[]
}

/** 护栏硬上限（数值文档 §9.1） */
export interface LimitsDef {
  defRedMax: number
  dodgeMax: number
  critMax: number
  critDmgMax: number
  dmgMultMin: number
  dmgMultMax: number
  maxOnScreenMinions: number
  materialStorageCap: number
  maxT6PerRun: number
}

/** 机制档 → HP 乘数（数值文档 §5.4） */
export type MechanismMultipliers = Record<MechanismTier, number>

/**
 * L0 阶段锚点节点（数值文档 §2.3，1 人基准）。
 * 作为区间端点 / 派生关系 / 包络校验的**权威来源**，代码中不得另行硬编码。
 */
export interface AnchorNodeDef {
  id: string
  name: string
  /** 该节点可达档位（决定标准 DEF 与 K 表引用） */
  tier: Tier
  heroHp: number
  heroAtk: number
  heroDef: number
  minionHp: number
  minionAtk: number
  minionDef: number
  eliteHp: number
  eliteAtk: number
  /** 锚点 BOSS 目标 HP（4 人基准，仅 N2/N4/N6） */
  anchorBossHp4p?: number
}
