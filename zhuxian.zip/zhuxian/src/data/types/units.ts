import type {
  DamageType,
  EffectSpec,
  MonsterClass,
  Rank,
  SkillKey,
  TargetShape,
  Tier,
} from './common'

/** 英雄定位（主文档 §四） */
export type HeroRole = 'front' | 'physical' | 'magic' | 'support'

/** 英雄开局属性（数值文档 §2.3 N1，1 人基准） */
export interface HeroBaseStats {
  hp: number
  mp: number
  atk: number
  /** 法强（SP） */
  sp: number
  def: number
  spd: number
  /** 闪避 % */
  dodge: number
  /** 会心 % */
  crit: number
  /** 暴击伤害倍率 */
  critDmg: number
}

export interface HeroDef {
  id: string
  name: string
  role: HeroRole
  base: HeroBaseStats
  /** 起始装备档位（决定减伤 K 表引用；英雄 DEF 即同档标准 DEF） */
  startTier: Tier
  /** 减伤系数 K 覆写（默认 1.0） */
  armorKMult?: number
  /** Q/W/E/R → 技能 id */
  skills: Record<SkillKey, string>
}

/** 技能境界强化（R 技：上清解锁 → 太清强化，数值文档 §4.5） */
export interface SkillUpgrade {
  rank: Rank
  rate?: number
  extraEffects?: EffectSpec[]
}

export interface SkillDef {
  id: string
  /** 持有者：英雄 id 或怪物 id */
  owner: string
  /** 键位：英雄技能必填（Q/W/E/R），怪物招式省略 */
  key?: SkillKey
  name: string
  damageType?: DamageType
  /** 技能倍率 RATE，base = (ATK 或 SP) × RATE（数值文档 §3.1） */
  rate?: number
  cooldown: number
  mpCost: number
  shape: TargetShape
  /** 作用半径（格），aoe 类必填 */
  radius?: number
  /** 释放距离（格），single / cone 类必填 */
  range?: number
  effects: EffectSpec[]
  /** 解锁所需境界（英雄 R 技 = 上清） */
  requiresRank?: Rank
  /** 境界强化 */
  upgrades?: SkillUpgrade[]
  /** BOSS 招式触发方式：默认按 CD；phase 表示阶段机触发一次 */
  trigger?: 'phase'
  /** 阶段触发阈值（当前气血 / 最大气血 ≤ threshold） */
  triggerThreshold?: number
}

/** 怪物相对「小怪区间基线」的属性系数（数值文档 §2.4 派生关系） */
export interface MonsterMul {
  hp: number
  atk: number
  def: number
  spd: number
}

export interface MonsterDef {
  id: string
  name: string
  class: MonsterClass
  /** 相对小怪区间基线的系数；小怪 = {1,1,1,1} */
  mul: MonsterMul
  /** 攻击速度（次/秒） */
  attackSpeed: number
  /** 攻击距离（格） */
  range: number
  flying?: boolean
  /** 机制档位：BOSS 必登记；启动校验同池不重复（主文档 附录 B 配置约束） */
  mechanism?: 'none' | 'light' | 'mid' | 'heavy'
  /** 机制类型标签（召唤 / 突进 / 阶段转换 / 光环 …）：同波次模板池内不得重复 */
  mechanismType?: readonly string[]
  /** 锚点 BOSS：以 L0 §2.5 的 4 人基准目标 HP 登记，生成时 ×机制乘数 ÷4 ×N */
  targetHp4p?: number
  /** 显式档位覆盖（锚点 BOSS 需固定档） */
  tierOverride?: Tier
  /** 减伤 K 覆写（锚点 BOSS = 1.2，数值文档 §3.3） */
  armorKMult?: number
  /** BOSS 招式技能 id 列表 */
  skills?: string[]
}
