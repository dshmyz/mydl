import { buildIndex, type GameDataIndex } from './indexes'
import { buildGameData } from './tables'
import type { GameData } from './types/gameData'
import { validateGameData } from './validate'
import { ConfigError, type ValidationIssue } from './validate/issues'

/** 装配并校验后的配置产物，供 logic 层直接消费 */
export interface LoadedGame {
  data: GameData
  index: GameDataIndex
  /** 调参类偏差（error 会在加载时 throw，不会进到这里） */
  warnings: ValidationIssue[]
}

/**
 * data 层唯一入口：装配 M1 子集配置 → 建索引 → 启动校验。
 *
 * 校验规则中 `error`（结构 / 引用 / 硬上限越界）fail fast 直接抛 `ConfigError`；
 * `warn`（节奏带 / 经验对齐等调参偏差）仅随结果返回，不阻断启动。
 *
 * @param data 允许注入自定义配置（测试用于构造损坏数据验证 fail fast）
 */
export function loadGameData(data: GameData = buildGameData()): LoadedGame {
  const index = buildIndex(data)
  const { errors, warnings } = validateGameData(data, index)
  if (errors.length > 0) {
    throw new ConfigError(errors)
  }
  return { data, index, warnings }
}
