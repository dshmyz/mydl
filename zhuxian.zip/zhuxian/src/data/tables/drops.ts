import type { DropTableRow } from '../types/numeric'

/**
 * 掉落表（主文档 附录 C.2）。
 *
 * M1 仅登记实际会遇到的来源：小怪 / 精英 / 锚点 BOSS。
 * `materialChance = -1` 表示沿用 economy 的按幕递减基础掉率（数值文档 §8.3）。
 */
export const drops: DropTableRow[] = [
  {
    source: 'minion',
    goldBase: [1, 3],
    goldMul: 1,
    spiritFlat: 0,
    materialChance: -1,
    materialPool: ['bat_wing_shard'],
  },
  {
    source: 'elite',
    goldBase: [1, 3],
    goldMul: 5,
    spiritFlat: 3,
    materialChance: -1,
    materialPool: ['bat_wing_shard'],
  },
  {
    source: 'anchorBoss',
    goldBase: [1, 3],
    goldMul: 20,
    spiritFlat: 80,
    // 锚点 BOSS 必掉「下一阶段关键材料」（主文档 附录 C.2）
    materialChance: 1,
    materialPool: ['bat_wing_shard'],
  },
]
