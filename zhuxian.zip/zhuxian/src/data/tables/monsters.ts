import type { MonsterDef } from '../types/units'

/**
 * 怪物表（主文档 附录 B.1 / D.2）。
 *
 * 小怪仅登记「相对区间基线的系数」：实际 HP/ATK 由波次导演按 L3 区间插值
 * （数值文档 §5.1）+ L4 人数缩放（§6.2）算出，避免把强度绑死波号。
 */
export const monsters: MonsterDef[] = [
  // —— 幕一小怪（区间Ⅰ模板 E1–E3）——
  {
    id: 'wolf',
    name: '狼妖',
    class: 'minion',
    mul: { hp: 1, atk: 1, def: 1, spd: 1 },
    attackSpeed: 1.0,
    range: 0.9,
  },
  {
    id: 'boar',
    name: '野猪',
    class: 'minion',
    mul: { hp: 1.3, atk: 1.1, def: 1.1, spd: 0.8 },
    attackSpeed: 0.9,
    range: 0.9,
  },
  {
    id: 'bat',
    name: '嗜血蝠',
    class: 'minion',
    mul: { hp: 0.6, atk: 0.8, def: 0.8, spd: 1.4 },
    attackSpeed: 1.2,
    range: 0.8,
    flying: true,
  },
  {
    id: 'elite_bat',
    name: '妖化蝙蝠',
    class: 'elite',
    // 精英 = 小怪 ×6 HP / ×2.2 ATK / ×1.5 DEF（数值文档 §2.4）
    mul: { hp: 6, atk: 2.2, def: 1.5, spd: 1.2 },
    attackSpeed: 1.1,
    range: 0.9,
    flying: true,
  },

  // —— 锚点一 BOSS 召唤物 ——
  {
    id: 'small_snake',
    name: '小玄蛇',
    class: 'minion',
    // HP = 小怪 ×12（主文档 附录 B.1）
    mul: { hp: 12, atk: 1.1, def: 1.0, spd: 1.1 },
    attackSpeed: 1.0,
    range: 0.9,
  },

  // —— 锚点一 BOSS · 黑水玄蛇 ——
  {
    id: 'heishui_xuanshe',
    name: '黑水玄蛇',
    class: 'anchorBoss',
    mul: { hp: 1, atk: 6, def: 1.5, spd: 0.8 },
    attackSpeed: 0.8,
    range: 1.6,
    mechanism: 'mid',
    mechanismType: ['phase', 'summon'],
    // L0 §2.5 的 11,000 为「4 人基准目标 HP」；生成时 ×机制乘数(0.8) ÷4 ×N
    targetHp4p: 11000,
    tierOverride: 1,
    armorKMult: 1.2,
    skills: ['hx_breath', 'hx_coil', 'hx_rage'],
  },
]
