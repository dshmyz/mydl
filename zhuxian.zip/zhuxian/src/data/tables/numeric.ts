import type { MechanismMultipliers } from '../types/numeric'
import type {
  AnchorNodeDef,
  DerivationDef,
  EconomyDef,
  IntervalDef,
  LevelDef,
  LimitsDef,
  PopulationDef,
  RankDef,
  TierArmorKDef,
} from '../types/numeric'
import type { EquipmentECurveDef } from '../types/equipment'

/** L0 阶段锚点节点（数值文档 §2.3，1 人基准） */
export const nodes: AnchorNodeDef[] = [
  {
    id: 'N1',
    name: '开局',
    tier: 1,
    heroHp: 800,
    heroAtk: 45,
    heroDef: 12,
    minionHp: 32,
    minionAtk: 18,
    minionDef: 7,
    eliteHp: 190,
    eliteAtk: 40,
  },
  {
    id: 'N2',
    name: '一锚前',
    tier: 2,
    heroHp: 1200,
    heroAtk: 70,
    heroDef: 20,
    minionHp: 58,
    minionAtk: 26,
    minionDef: 12,
    eliteHp: 350,
    eliteAtk: 57,
    anchorBossHp4p: 11000,
  },
  {
    id: 'N3',
    name: '一锚后',
    tier: 3,
    heroHp: 1800,
    heroAtk: 108,
    heroDef: 35,
    minionHp: 100,
    minionAtk: 38,
    minionDef: 21,
    eliteHp: 600,
    eliteAtk: 84,
  },
  {
    id: 'N4',
    name: '二锚前',
    tier: 4,
    heroHp: 2700,
    heroAtk: 168,
    heroDef: 60,
    minionHp: 175,
    minionAtk: 55,
    minionDef: 36,
    eliteHp: 1050,
    eliteAtk: 121,
    anchorBossHp4p: 27000,
  },
  {
    id: 'N5',
    name: '二锚后',
    tier: 5,
    heroHp: 4050,
    heroAtk: 260,
    heroDef: 100,
    minionHp: 300,
    minionAtk: 80,
    minionDef: 60,
    eliteHp: 1800,
    eliteAtk: 176,
  },
  {
    id: 'N6',
    name: '终局',
    tier: 6,
    heroHp: 6000,
    heroAtk: 400,
    heroDef: 160,
    minionHp: 470,
    minionAtk: 116,
    minionDef: 96,
    eliteHp: 2800,
    eliteAtk: 255,
    anchorBossHp4p: 63000,
  },
]

/** 减伤系数 K 挂档位（数值文档 §3.3） */
export const tierArmorK: TierArmorKDef[] = [
  { tier: 1, standardDef: 12, k: 28 },
  { tier: 2, standardDef: 20, k: 47 },
  { tier: 3, standardDef: 35, k: 82 },
  { tier: 4, standardDef: 60, k: 140 },
  { tier: 5, standardDef: 100, k: 233 },
  { tier: 6, standardDef: 160, k: 373 },
]

/** 强度区间（数值文档 §5.1，端点为 L0 锚点；护甲档 = 节点序号） */
export const intervals: IntervalDef[] = [
  { id: 'I', act: 'act1', hp: [32, 58], atk: [18, 26], armorTier: [1, 2] },
  { id: 'II', act: 'act2', hp: [58, 175], atk: [26, 55], armorTier: [2, 4] },
  { id: 'III', act: 'act3', hp: [175, 470], atk: [55, 116], armorTier: [4, 6] },
]

/** 派生关系（数值文档 §2.4） */
export const derivation: DerivationDef = {
  heroAttackSpeed: 1.3,
  skillCoefficient: 1.15,
  partyEfficiency: 0.7,
  minion: { spd: 220, attackSpeed: 1, range: 0.9, defRatio: 0.6 },
  eliteMul: { hp: 6, atk: 2.2, def: 1.5 },
  waveBossHpMul: 25,
  anchorBossTtk: 40,
  wildBossHpRatio: [0.3, 0.35],
}

/** 人数缩放（数值文档 §6.3，α = 0.42） */
export const population: PopulationDef = {
  alpha: 0.42,
  maxOnScreen: 40,
  table: [
    { n: 1, hpMul: 1, countMul: 1, bossMul: 1, dmgMul: 1 },
    { n: 2, hpMul: 1.49, countMul: 1.34, bossMul: 2, dmgMul: 1 },
    { n: 3, hpMul: 1.89, countMul: 1.59, bossMul: 3, dmgMul: 1 },
    { n: 4, hpMul: 2.23, countMul: 1.8, bossMul: 4, dmgMul: 1 },
    { n: 5, hpMul: 2.53, countMul: 1.98, bossMul: 5, dmgMul: 1 },
    { n: 6, hpMul: 2.82, countMul: 2.14, bossMul: 6, dmgMul: 1 },
  ],
}

/** 等级曲线（数值文档 §4.4，递减式增幅） */
export const level: LevelDef = {
  maxLevel: 25,
  segments: [
    { fromLevel: 1, toLevel: 10, perLevelPct: 0.065 },
    { fromLevel: 10, toLevel: 20, perLevelPct: 0.035 },
    { fromLevel: 20, toLevel: 25, perLevelPct: 0.015 },
  ],
  totalMul: 2.677,
  skillPointEvery: 2,
}

/** 境界曲线（数值文档 §4.5） */
export const ranks: RankDef[] = [
  { id: 'yuqing', name: '玉清', hpMul: 1, atkMul: 1, unlocks: [] },
  { id: 'shangqing', name: '上清', hpMul: 1.25, atkMul: 1.25, unlocks: ['R'] },
  { id: 'taiqing', name: '太清', hpMul: 1.5625, atkMul: 1.5625, unlocks: [] },
]

/** 装备倍率曲线 E（数值文档 §4.6/§7.1） */
export const eCurve: EquipmentECurveDef[] = [
  { tier: 1, hpMul: 1.0, atkMul: 1.0 },
  { tier: 2, hpMul: 1.127, atkMul: 1.163 },
  { tier: 3, hpMul: 1.269, atkMul: 1.352 },
  { tier: 4, hpMul: 1.431, atkMul: 1.572 },
  { tier: 5, hpMul: 1.612, atkMul: 1.827 },
  { tier: 6, hpMul: 1.816, atkMul: 2.125 },
]

/** 机制档 → HP 乘数（数值文档 §5.4） */
export const mechanismMul: MechanismMultipliers = {
  none: 1.0,
  light: 0.9,
  mid: 0.8,
  heavy: 0.7,
}

/** 护栏硬上限（数值文档 §9.1） */
export const limits: LimitsDef = {
  defRedMax: 0.75,
  dodgeMax: 0.25,
  critMax: 0.6,
  critDmgMax: 2.5,
  dmgMultMin: 0.5,
  dmgMultMax: 2.5,
  maxOnScreenMinions: 40,
  materialStorageCap: 20,
  maxT6PerRun: 2,
}

/** 经济模型（数值文档 §8） */
export const economy: EconomyDef = {
  goldPerWave: { act1: 30, act2: 55, act3: 85 },
  spirit: { elite: 3, waveBoss: 12, anchorBoss: 80 },
  xp: { minionBase: 4, perTier: 2, eliteMul: 5, bossMul: 20 },
  levelNeed: { base: 30, growth: 1.2 },
  materialDropChance: { act1: 0.15, act2: 0.11, act3: 0.08 },
  softGateActs: 1,
  storageCap: 20,
}
