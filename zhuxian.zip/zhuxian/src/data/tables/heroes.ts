import type { HeroDef } from '../types/units'

/**
 * 英雄表（M1 仅张小凡，主文档 附录 A.1）。
 * 数值口径：数值文档 §2.3 N1 开局（1 人基准）。
 */
export const heroes: HeroDef[] = [
  {
    id: 'zhangxiaofan',
    name: '张小凡',
    role: 'front',
    base: {
      hp: 800,
      mp: 200,
      atk: 45,
      sp: 45,
      def: 12,
      spd: 300,
      dodge: 0,
      crit: 5,
      critDmg: 1.5,
    },
    startTier: 1,
    skills: {
      Q: 'zxf_q',
      W: 'zxf_w',
      E: 'zxf_e',
      R: 'zxf_r',
    },
  },
]
