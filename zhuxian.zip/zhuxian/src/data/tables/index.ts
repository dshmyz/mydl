import type { GameData } from '../types/gameData'

import { drops } from './drops'
import { affixes, equipment, materials, qualities, recipes } from './equipment'
import { heroes } from './heroes'
import { monsters } from './monsters'
import {
  derivation,
  eCurve,
  economy,
  intervals,
  level,
  limits,
  mechanismMul,
  nodes,
  population,
  ranks,
  tierArmorK,
} from './numeric'
import { skills } from './skills'
import { events, waveTemplates } from './waves'

/**
 * 装配 M1 子集配置。
 *
 * 这里**不做校验**：校验统一发生在 `loadGameData()`，保证「装配」与「校验」解耦，
 * 测试可以注入损坏数据来验证 fail fast 行为。
 */
export function buildGameData(): GameData {
  return {
    version: 'M1',
    sim: { fixedDt: 1 / 30, defaultSeed: 20261013 },

    limits,
    mechanismMul,
    nodes,
    tierArmorK,
    intervals,
    derivation,
    population,
    level,
    ranks,
    eCurve,
    economy,

    qualities,
    affixes,
    materials,
    recipes,
    equipment,
    drops,

    heroes,
    skills,
    monsters,
    waveTemplates,
    events,
  }
}
