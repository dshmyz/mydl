import type { EventDef, WaveTemplateDef } from '../types/waves'

/**
 * 波次模板表（M1 小池 3 个，主文档 附录 D.2）。
 * 数量为 1 人基准，实战按 L4 countMul 缩放（数值文档 §6.3）。
 */
export const waveTemplates: WaveTemplateDef[] = [
  {
    id: 'E1',
    layer: 'act1',
    name: '狼妖来袭',
    groups: [{ monsterId: 'wolf', count: 8 }],
    route: 'main',
    eventHooks: ['beast_timing'],
    waveBossPool: [],
    note: '教学波',
  },
  {
    id: 'E2',
    layer: 'act1',
    name: '狼妖与野猪',
    groups: [
      { monsterId: 'wolf', count: 8 },
      { monsterId: 'boar', count: 2 },
    ],
    route: 'main',
    eventHooks: ['beast_timing'],
    waveBossPool: [],
  },
  {
    id: 'E3',
    layer: 'act1',
    name: '蝙蝠群',
    groups: [{ monsterId: 'bat', count: 10 }],
    route: 'main',
    elite: { min: 0, max: 1, monsterId: 'elite_bat' },
    eventHooks: ['beast_timing'],
    waveBossPool: [],
    note: '空袭预演',
  },
]

/** 事件表（M1 仅「兽潮提前 / 滞后」，主文档 附录 E.2） */
export const events: EventDef[] = [
  {
    id: 'beast_timing',
    name: '兽潮提前 / 滞后',
    rarity: 'common',
    weight: 12,
    cooldown: 6,
    minAct: 'act1',
    effect: { kind: 'waveTiming', earlySeconds: 30, lateSeconds: 45 },
  },
]
