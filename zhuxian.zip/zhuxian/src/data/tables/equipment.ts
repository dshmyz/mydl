import type {
  AffixDef,
  EquipmentDef,
  MaterialDef,
  QualityDef,
  RecipeDef,
} from '../types/equipment'

/** 品质分级（数值文档 §7.4） */
export const qualities: QualityDef[] = [
  { id: 'lower', name: '下品', statMul: 1.0, affixCount: 1 },
  { id: 'middle', name: '中品', statMul: 1.15, affixCount: 2 },
  { id: 'upper', name: '上品', statMul: 1.3, affixCount: 3 },
]

/** 词条池（M1 仅法宝线，数值文档 §7.5 / 主文档 附录 C.5） */
export const affixes: AffixDef[] = [
  {
    id: 'affix_weapon_atk',
    line: 'weapon',
    name: '攻伐',
    effect: { kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.06 },
  },
  {
    id: 'affix_weapon_sp',
    line: 'weapon',
    name: '术法',
    effect: { kind: 'statMod', stat: 'sp', mode: 'percent', value: 0.06 },
  },
  {
    id: 'affix_weapon_crit',
    line: 'weapon',
    name: '会心',
    effect: { kind: 'statMod', stat: 'crit', mode: 'flat', value: 6 },
  },
  {
    id: 'affix_weapon_lifesteal',
    line: 'weapon',
    name: '噬魂',
    effect: { kind: 'lifesteal', percent: 0.04 },
  },
]

/** 合成材料（M1 仅法宝线 T1→T2，主文档 附录 C.3） */
export const materials: MaterialDef[] = [
  {
    id: 'bat_wing_shard',
    name: '蝠翼碎片',
    fromTier: 1,
    toTier: 2,
    line: 'weapon',
    stage: 'act1',
  },
]

/** 升档配方（M1 仅一条，数值文档 §8.2 / 主文档 附录 C.4） */
export const recipes: RecipeDef[] = [
  {
    line: 'weapon',
    fromTier: 1,
    toTier: 2,
    gold: 25,
    spirit: 0,
    materialId: 'bat_wing_shard',
    materialCount: 2,
    requiresSourceItem: true,
  },
]

/** 装备定义（中品基线主属性，数值文档 §7.3） */
export const equipment: EquipmentDef[] = [
  {
    id: 'weapon_t1',
    line: 'weapon',
    tier: 1,
    name: '凡铁剑',
    mainStats: [{ stat: 'atk', mode: 'percent', value: 0 }],
  },
  {
    id: 'weapon_t2',
    line: 'weapon',
    tier: 2,
    name: '蝠翼灵剑',
    // 法宝线承担 E_ATK 100%：T2 = +16.3%（数值文档 §7.2/§7.3）
    mainStats: [{ stat: 'atk', mode: 'percent', value: 0.163 }],
  },
]
