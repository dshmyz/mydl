import type { SkillDef } from '../types/units'

/**
 * 技能表（主文档 附录 A.1 + B.1）。
 *
 * 全部走 Modifier 效果原语组合，不写特殊逻辑（主文档 §6.7）。
 */
export const skills: SkillDef[] = [
  // —— 张小凡 Q/W/E/R ——
  {
    id: 'zxf_q',
    owner: 'zhangxiaofan',
    key: 'Q',
    name: '嗜血珠 · 血刃',
    damageType: 'physical',
    rate: 1.0,
    cooldown: 5,
    mpCost: 20,
    shape: 'single',
    range: 1.0,
    effects: [{ kind: 'lifesteal', percent: 0.15 }],
  },
  {
    id: 'zxf_w',
    owner: 'zhangxiaofan',
    key: 'W',
    name: '大梵般若 · 佛掌',
    damageType: 'physical',
    rate: 0.9,
    cooldown: 10,
    mpCost: 35,
    shape: 'cone',
    radius: 2.5,
    range: 2.5,
    effects: [{ kind: 'knockback', distance: 2 }],
  },
  {
    id: 'zxf_e',
    owner: 'zhangxiaofan',
    key: 'E',
    name: '佛魔护体',
    cooldown: 18,
    mpCost: 40,
    shape: 'self',
    effects: [
      { kind: 'shield', percentOfMaxHp: 0.2, duration: 5 },
      // 减伤修正 +8% → 受伤乘数 0.92
      { kind: 'damageTakenMul', value: 0.92, duration: 5 },
    ],
  },
  {
    id: 'zxf_r',
    owner: 'zhangxiaofan',
    key: 'R',
    name: '三修 · 诛魔',
    damageType: 'physical',
    rate: 1.6,
    cooldown: 60,
    mpCost: 80,
    shape: 'aoeSelf',
    radius: 3.5,
    effects: [
      { kind: 'stackDamage', stackId: 'moqi', perStack: 0.03, maxStacks: 5, duration: 8 },
    ],
    requiresRank: 'shangqing',
    upgrades: [
      {
        rank: 'taiqing',
        rate: 2.0,
        extraEffects: [{ kind: 'heal', percentOfMaxHp: 0.02 }],
      },
    ],
  },

  // —— 锚点一 BOSS · 黑水玄蛇（主文档 附录 B.1）——
  {
    id: 'hx_breath',
    owner: 'heishui_xuanshe',
    name: '玄水吐息',
    damageType: 'magic',
    rate: 1.5,
    cooldown: 8,
    mpCost: 0,
    shape: 'cone',
    radius: 2.5,
    range: 2.5,
    effects: [{ kind: 'statMod', stat: 'spd', mode: 'percent', value: -0.2, duration: 2 }],
  },
  {
    id: 'hx_coil',
    owner: 'heishui_xuanshe',
    name: '蛇身缠绕',
    cooldown: 15,
    mpCost: 0,
    shape: 'aoeSelf',
    radius: 2.5,
    effects: [{ kind: 'root', duration: 1.5 }],
  },
  {
    id: 'hx_rage',
    owner: 'heishui_xuanshe',
    name: '阶段转换 · 暴走',
    cooldown: 0,
    mpCost: 0,
    shape: 'self',
    effects: [
      { kind: 'statMod', stat: 'spd', mode: 'percent', value: 0.3 },
      { kind: 'statMod', stat: 'atk', mode: 'percent', value: 0.25 },
      { kind: 'summon', monsterId: 'small_snake', count: 2 },
    ],
    trigger: 'phase',
    triggerThreshold: 0.5,
  },
]
