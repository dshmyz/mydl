/**
 * 坐标投影：逻辑「格」坐标 → War3 世界坐标（纯函数，确定性）。
 *
 * 逻辑战场以格为单位（`Bounds`，如 24 × 12），War3 以世界单位为单位（1 大格 = 128 单位）。
 * 桥接层所有落位都经本投影，保证地图装配参数（scale / origin）只在此一处调整——
 * 地图未定稿前用 `centeredOrigin` 居中兜底，建图后按实际区域坐标改 origin 即可。
 */

import type { Bounds, Vec2 } from '../logic/battle/spatial'

export interface ProjectionConfig {
  /** 每逻辑格对应的世界单位数（War3 大格标准 = 128） */
  scale: number
  /** 逻辑战场左下角的世界坐标 */
  originX: number
  originY: number
}

/** 以战场中心对齐世界原点求 origin（地图未定稿时的默认装配） */
export function centeredOrigin(bounds: Bounds, scale: number): { originX: number; originY: number } {
  return {
    originX: (-(bounds.max.x - bounds.min.x) * scale) / 2,
    originY: (-(bounds.max.y - bounds.min.y) * scale) / 2,
  }
}

export class MapProjection {
  constructor(
    private readonly bounds: Bounds,
    private readonly cfg: ProjectionConfig,
  ) {}

  toWorld(p: Vec2): Vec2 {
    return {
      x: this.cfg.originX + (p.x - this.bounds.min.x) * this.cfg.scale,
      y: this.cfg.originY + (p.y - this.bounds.min.y) * this.cfg.scale,
    }
  }
}
