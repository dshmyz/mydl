/**
 * 事件桥：把 `BattleEvent` 事实翻译为文本提示与位置特效（附录 F.3 任务 8）。
 *
 * 只做「事实 → 表现」的映射，不解释数值：伤害与核心耐久属高频结算事件，
 * 信息密度过高，M1 不播（HUD 在 M2 落地）。技能可视化的依据是逻辑层新增的
 * `cast` 事件（释放成功即产出，与是否命中无关）。
 */

import type { Vec2 } from '../../logic/battle/spatial'
import type { BattleEvent } from '../../logic/battle/battle'
import type { War3Api } from '../api'
import type { MapProjection } from '../projection'

export interface EventBridgeConfig {
  /** 特效模型路径（占位值，试跑后可按美术资源替换；无效路径仅无表现不报错） */
  effectModels: { spawn: string; kill: string; cast: string }
  /** 单位位置查询（含已移除单位的最后位置），由 UnitBridge 提供 */
  positionOf: (unitId: string) => Vec2 | null
}

export class EventBridge {
  constructor(
    private readonly api: War3Api,
    private readonly projection: MapProjection,
    private readonly cfg: EventBridgeConfig,
  ) {}

  play(events: readonly BattleEvent[]): void {
    for (const event of events) {
      switch (event.kind) {
        case 'spawn':
          this.effectAt(this.cfg.effectModels.spawn, event.unitId)
          break
        case 'cast':
          this.effectAt(this.cfg.effectModels.cast, event.casterId)
          break
        case 'kill':
          this.effectAt(this.cfg.effectModels.kill, event.unitId)
          this.text(
            `击杀 ${event.defId}：+${event.gold} 金` +
              (event.material ? `，材料 ${event.material} +1` : ''),
          )
          break
        case 'gold':
          this.text(`波次收入：+${event.amount} 金`)
          break
        case 'heroDeath':
          this.text('英雄阵亡，复活中……')
          break
        case 'heroRevive':
          this.text('英雄已复活')
          break
        case 'anchorStart':
          this.text('剧情锚点开启：限时击杀 BOSS！')
          break
        case 'anchorCleared':
          this.text('锚点通关！可以渡劫突破了')
          break
        case 'anchorFailed':
          this.text('锚点失守！')
          break
        case 'craft':
          this.text(`合成成功：${event.defId}（${event.quality}）`)
          break
        case 'breakthrough':
          this.text(`突破成功：进入 ${event.rank} 境`)
          break
        case 'damage':
        case 'coreDamage':
          break // 高频结算事件：M1 不播，HUD 在 M2 落地
      }
    }
  }

  /** 在单位（战场坐标）位置播放特效；位置未知则跳过 */
  private effectAt(model: string, unitId: string): void {
    const pos = this.cfg.positionOf(unitId)
    if (!pos) {
      return
    }
    const world = this.projection.toWorld(pos)
    this.api.spawnEffect(model, world.x, world.y)
  }

  private text(message: string): void {
    this.api.showText(message)
  }
}
