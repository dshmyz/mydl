import { describe, expect, it } from 'vitest'

import { KeyState } from './heroControl'
import { FakeWar3Api } from '../testing/fakeApi'

describe('KeyState（按键 → HeroIntent）', () => {
  it('无按键时意图为空', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    expect(keys.readIntent()).toEqual({})
  })

  it('按住上方向键产生向上移动方向', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    api.pressKey('UP')
    expect(keys.readIntent().moveDir).toEqual({ x: 0, y: 1 })
  })

  it('组合方向键产生归一化的斜向移动', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    api.pressKey('LEFT')
    api.pressKey('DOWN')
    const intent = keys.readIntent()
    expect(intent.moveDir?.x).toBeCloseTo(-Math.SQRT1_2, 5)
    expect(intent.moveDir?.y).toBeCloseTo(-Math.SQRT1_2, 5)
  })

  it('松开按键后不再产生移动', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    api.pressKey('RIGHT')
    api.releaseKey('RIGHT')
    expect(keys.readIntent().moveDir).toBeUndefined()
  })

  it('技能键按下产生一次 cast，消费后清空（边沿触发）', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    api.pressKey('Q')
    expect(keys.readIntent().cast).toBe('Q')
    expect(keys.readIntent().cast).toBeUndefined()
  })

  it('移动键与技能键互不干扰：W 释放技能不产生向上移动', () => {
    const api = new FakeWar3Api()
    const keys = new KeyState(api)
    api.pressKey('W')
    const intent = keys.readIntent()
    expect(intent.cast).toBe('W')
    expect(intent.moveDir).toBeUndefined()
  })
})
