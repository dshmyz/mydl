/**
 * 英雄操控桥接：把 War3 键盘事件折叠成每帧的 `HeroIntent`。
 *
 * 键位与 Web 原型一致（memory：方向键移动、QWER 释放技能）：方向键按「按住即移动」
 * 持续生效，技能键为按下边沿触发（一次按键只消费一次）。战斗结算权仍在逻辑层，
 * 本模块只翻译输入，不触碰技能规则。
 */

import { normalize, type Vec2 } from '../../logic/battle/spatial'
import type { HeroIntent } from '../../logic/battle/battle'
import type { SkillKey } from '../../data/types/common'
import type { KeyName, War3Api } from '../api'

/** 方向键 → 逻辑格方向（未归一化，readIntent 统一归一化） */
const MOVE_DIRS: Partial<Record<KeyName, Vec2>> = {
  UP: { x: 0, y: 1 },
  DOWN: { x: 0, y: -1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
}

function isCastKey(key: KeyName): key is SkillKey {
  return key === 'Q' || key === 'W' || key === 'E' || key === 'R'
}

export class KeyState {
  private readonly pressed = new Set<KeyName>()
  private pendingCast: SkillKey | null = null

  constructor(api: War3Api) {
    for (const key of [...Object.keys(MOVE_DIRS), 'Q', 'W', 'E', 'R'] as KeyName[]) {
      api.registerKey(
        key,
        () => {
          this.pressed.add(key)
          if (isCastKey(key)) {
            this.pendingCast = key
          }
        },
        () => {
          this.pressed.delete(key)
        },
      )
    }
  }

  /** 每帧取操作意图：组合方向键求和并归一化；cast 边沿触发、消费即清 */
  readIntent(): HeroIntent {
    const dir: Vec2 = { x: 0, y: 0 }
    for (const key of this.pressed) {
      const move = MOVE_DIRS[key]
      if (move) {
        dir.x += move.x
        dir.y += move.y
      }
    }
    const moveDir = dir.x !== 0 || dir.y !== 0 ? normalize(dir) : undefined
    const cast = this.pendingCast ?? undefined
    this.pendingCast = null
    return { moveDir, cast }
  }
}
