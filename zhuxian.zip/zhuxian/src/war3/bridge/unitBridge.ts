/**
 * 单位封装桥接：把逻辑战场投影为 War3 单位（附录 F.3 任务 5）。
 *
 * 同步策略——**对账式**：每帧以「英雄 + 存活怪物」为唯一事实源做全量对账，
 * 新出现的逻辑单位创建、消失的按两帧演出（killUnit 播死亡动画 → 下一帧 removeUnit），
 * 存活的做差量同步（位置 / 朝向 / 气血变化才调用原生）。
 * 逻辑层是唯一事实源，War3 单位只是呈现，结算权不外泄（§十一）。
 *
 * 英雄生死走独立通道：阵亡 `killUnit`（英雄句柄不移除），复活 `reviveHero` 回满状态。
 */

import type { Vec2 } from '../../logic/battle/spatial'
import type { Unit, UnitKind } from '../../logic/battle/unit'
import type { War3Api, UnitHandle } from '../api'
import type { MapProjection } from '../projection'

export interface UnitBridgeConfig {
  /** 各 kind 的占位单位码（地图未定稿前用标准种族单位，建图后换自定义模型） */
  unitCodeByKind: Record<UnitKind, string>
  /** 英雄 / 敌方玩家索引（War3 默认红蓝两方互为敌对） */
  players: { hero: number; enemy: number }
  /** 各 kind 的模型缩放（缺省或 1 不调用原生，BOSS 放大用） */
  scaleByKind?: Record<UnitKind, number>
}

interface Tracked {
  handle: UnitHandle
  dead: boolean
  pos: Vec2
  facing: Vec2
  hp: number
  maxHp: number
}

function angleDeg(v: Vec2): number {
  return (Math.atan2(v.y, v.x) * 180) / Math.PI
}

function samePoint(a: Vec2, b: Vec2): boolean {
  return a.x === b.x && a.y === b.y
}

export class UnitBridge {
  private readonly tracked = new Map<string, Tracked>()
  /** 上一帧标记死亡、待本帧移除的句柄（两帧死亡演出） */
  private readonly corpses: UnitHandle[] = []
  /** 战场坐标存档：单位移除后仍保留最后位置，供死亡特效取位 */
  private readonly lastPositions = new Map<string, Vec2>()

  constructor(
    private readonly api: War3Api,
    private readonly projection: MapProjection,
    private readonly cfg: UnitBridgeConfig,
  ) {}

  /** 每帧对账：英雄与存活怪物列表为事实源 */
  sync(hero: Unit, monsters: readonly Unit[]): void {
    for (const handle of this.corpses) {
      this.api.removeUnit(handle)
    }
    this.corpses.length = 0

    const present = new Set<string>()
    for (const unit of [hero, ...monsters]) {
      present.add(unit.id)
      this.lastPositions.set(unit.id, { ...unit.position })
      const tracked = this.tracked.get(unit.id)
      if (!tracked) {
        this.create(unit)
        continue
      }
      this.deltaSync(tracked, unit)
    }

    for (const [id, tracked] of this.tracked) {
      if (!present.has(id)) {
        this.api.killUnit(tracked.handle)
        this.corpses.push(tracked.handle)
        this.tracked.delete(id)
      }
    }
  }

  /** 单位的战场坐标（含已移除单位的最后位置）；未知 id 返回 null */
  positionOf(unitId: string): Vec2 | null {
    const pos = this.lastPositions.get(unitId)
    return pos ? { ...pos } : null
  }

  private create(unit: Unit): void {
    const playerIndex = unit.kind === 'hero' ? this.cfg.players.hero : this.cfg.players.enemy
    const handle = this.api.createUnit(
      playerIndex,
      this.cfg.unitCodeByKind[unit.kind],
      ...this.worldOf(unit.position),
      angleDeg(unit.facing),
    )
    if (!handle) {
      return
    }
    this.api.setUnitMaxLife(handle, unit.maxHp)
    this.api.setUnitLife(handle, unit.hp)
    const scale = this.cfg.scaleByKind?.[unit.kind]
    if (scale !== undefined && scale !== 1) {
      this.api.setUnitScale(handle, scale)
    }
    this.tracked.set(unit.id, {
      handle,
      dead: !unit.alive,
      pos: { ...unit.position },
      facing: { ...unit.facing },
      hp: unit.hp,
      maxHp: unit.maxHp,
    })
  }

  private deltaSync(tracked: Tracked, unit: Unit): void {
    const isDead = !unit.alive
    if (isDead !== tracked.dead) {
      if (isDead) {
        this.api.killUnit(tracked.handle)
      } else {
        this.api.reviveHero(tracked.handle, ...this.worldOf(unit.position))
        tracked.hp = unit.hp
      }
      tracked.dead = isDead
      return
    }
    if (tracked.dead) {
      return
    }

    if (unit.maxHp !== tracked.maxHp) {
      this.api.setUnitMaxLife(tracked.handle, unit.maxHp)
      tracked.maxHp = unit.maxHp
      this.api.setUnitLife(tracked.handle, unit.hp)
      tracked.hp = unit.hp
    } else if (unit.hp !== tracked.hp) {
      this.api.setUnitLife(tracked.handle, unit.hp)
      tracked.hp = unit.hp
    }
    if (!samePoint(unit.position, tracked.pos)) {
      this.api.setUnitPosition(tracked.handle, ...this.worldOf(unit.position))
      tracked.pos = { ...unit.position }
    }
    if (!samePoint(unit.facing, tracked.facing)) {
      this.api.setUnitFacing(tracked.handle, angleDeg(unit.facing))
      tracked.facing = { ...unit.facing }
    }
  }

  private worldOf(p: Vec2): [x: number, y: number] {
    const world = this.projection.toWorld(p)
    return [world.x, world.y]
  }
}
