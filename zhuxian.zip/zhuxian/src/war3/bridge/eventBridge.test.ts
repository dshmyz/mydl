import { describe, expect, it } from 'vitest'

import type { Bounds, Vec2 } from '../../logic/battle/spatial'
import { MapProjection } from '../projection'
import { FakeWar3Api } from '../testing/fakeApi'
import { EventBridge } from './eventBridge'

/** 与 `DEFAULT_BATTLE_CONFIG.field.bounds` 同形的战场（24 × 12 格） */
const FIELD: Bounds = { min: { x: 0, y: 0 }, max: { x: 24, y: 12 } }
const PROJECTION = new MapProjection(FIELD, { scale: 128, originX: -1536, originY: -768 })

const EFFECT_MODELS = { spawn: 'spawn.mdl', kill: 'kill.mdl', cast: 'cast.mdl' } as const

function makeBridge(api: FakeWar3Api, positions: Record<string, Vec2> = {}): EventBridge {
  return new EventBridge(api, PROJECTION, {
    effectModels: EFFECT_MODELS,
    positionOf: (id) => positions[id] ?? null,
  })
}

describe('EventBridge（BattleEvent → 表现）', () => {
  it('kill：在单位位置播放特效，并提示战利品', () => {
    const api = new FakeWar3Api()
    makeBridge(api, { m1: { x: 21, y: 6 } }).play([
      { kind: 'kill', unitId: 'm1', defId: 'wolf', gold: 12, material: 'fang' },
    ])
    expect(api.effects).toEqual([{ model: 'kill.mdl', x: -1536 + 21 * 128, y: -768 + 6 * 128 }])
    expect(api.texts).toEqual([expect.stringContaining('wolf')])
    expect(api.texts[0]).toContain('12')
    expect(api.texts[0]).toContain('fang')
  })

  it('kill：位置未知的单位只出文本不播特效（容错）', () => {
    const api = new FakeWar3Api()
    makeBridge(api).play([{ kind: 'kill', unitId: 'ghost', defId: 'wolf', gold: 1, material: null }])
    expect(api.effects).toHaveLength(0)
    expect(api.texts).toHaveLength(1)
  })

  it('spawn：在出生位置播放登场特效', () => {
    const api = new FakeWar3Api()
    makeBridge(api, { m2: { x: 22, y: 7 } }).play([{ kind: 'spawn', unitId: 'm2' }])
    expect(api.effects).toEqual([{ model: 'spawn.mdl', x: -1536 + 22 * 128, y: -768 + 7 * 128 }])
  })

  it('cast：在施法者位置播放技能特效', () => {
    const api = new FakeWar3Api()
    makeBridge(api, { hero: { x: 9, y: 6 } }).play([{ kind: 'cast', casterId: 'hero', skillId: 'zxf_w' }])
    expect(api.effects).toEqual([{ model: 'cast.mdl', x: -1536 + 9 * 128, y: -768 + 6 * 128 }])
  })

  it('关键状态事件产出文本：英雄生死 / 锚点 / 波次收入', () => {
    const api = new FakeWar3Api()
    makeBridge(api).play([
      { kind: 'heroDeath' },
      { kind: 'heroRevive' },
      { kind: 'anchorStart' },
      { kind: 'anchorCleared' },
      { kind: 'anchorFailed' },
      { kind: 'gold', amount: 30 },
    ])
    expect(api.texts).toHaveLength(6)
  })

  it('成长事件产出文本：合成带品质、突破带境界', () => {
    const api = new FakeWar3Api()
    makeBridge(api).play([
      { kind: 'craft', defId: 'wp_t2', quality: 'upper' },
      { kind: 'breakthrough', rank: 'shangqing' },
    ])
    expect(api.texts[0]).toContain('wp_t2')
    expect(api.texts[0]).toContain('upper')
    expect(api.texts[1]).toContain('shangqing')
  })

  it('高频结算事件（damage / coreDamage）不产出表现', () => {
    const api = new FakeWar3Api()
    makeBridge(api).play([
      { kind: 'damage', sourceId: 'hero', targetId: 'm1', amount: 5, crit: true, dodged: false },
      { kind: 'coreDamage', amount: 10, hp: 2990 },
    ])
    expect(api.texts).toHaveLength(0)
    expect(api.effects).toHaveLength(0)
  })
})
