import { describe, expect, it, vi } from 'vitest'

import { BattleRunner, startLoop } from './driver'
import { FakeWar3Api } from '../testing/fakeApi'

describe('startLoop（Timer 驱动契约）', () => {
  it('以给定周期注册周期性定时器', () => {
    const api = new FakeWar3Api()
    startLoop(api, 0.03, () => {})
    expect(api.timerStarts).toEqual([{ periodSeconds: 0.03 }])
  })

  it('定时器每次到期转发一次 onTick', () => {
    const api = new FakeWar3Api()
    const onTick = vi.fn()
    startLoop(api, 0.03, onTick)
    api.fireTimer(0, 3)
    expect(onTick).toHaveBeenCalledTimes(3)
  })

  it('stop() 后定时器到期不再转发 onTick', () => {
    const api = new FakeWar3Api()
    const onTick = vi.fn()
    const loop = startLoop(api, 0.03, onTick)
    api.fireTimer(0, 1)
    loop.stop()
    api.fireTimer(0, 5)
    expect(onTick).toHaveBeenCalledTimes(1)
  })
})

describe('BattleRunner（帧推进与停止规则）', () => {
  interface FakeBattleState {
    time: number
    status: 'running' | 'defeat' | 'anchorCleared' | 'anchorFailed'
  }

  /** 最小战斗替身：仅实现 BattleRunner 依赖的结构面 */
  function fakeBattle(state: FakeBattleState) {
    const steps: Array<{ dt: number; intent: object }> = []
    return {
      state,
      steps,
      get time() {
        return state.time
      },
      get status() {
        return state.status
      },
      step(dt: number, intent: object = {}) {
        state.time += dt
        steps.push({ dt, intent })
        return []
      },
    }
  }

  it('推进一帧：转发 dt 与 intent，事件交给 onEvents，返回 true', () => {
    const onEvents = vi.fn()
    const battle = fakeBattle({ time: 0, status: 'running' })
    const runner = new BattleRunner(battle, {
      intent: () => ({ moveDir: { x: 1, y: 0 } }),
      onEvents,
    })
    expect(runner.tick(0.03)).toBe(true)
    expect(battle.steps).toEqual([{ dt: 0.03, intent: { moveDir: { x: 1, y: 0 } } }])
    expect(onEvents).toHaveBeenCalledWith([])
  })

  it('战斗未结束（running 且未到限时）时持续推进', () => {
    const battle = fakeBattle({ time: 0, status: 'running' })
    const runner = new BattleRunner(battle, { maxSeconds: 90, onEvents: () => {} })
    for (let i = 0; i < 5; i += 1) {
      expect(runner.tick(1)).toBe(true)
    }
    expect(battle.steps).toHaveLength(5)
  })

  it('到达冒烟限时后不再推进，返回 false', () => {
    const battle = fakeBattle({ time: 90, status: 'running' })
    const runner = new BattleRunner(battle, { maxSeconds: 90, onEvents: () => {} })
    expect(runner.tick(0.03)).toBe(false)
    expect(battle.steps).toHaveLength(0)
  })

  it.each(['defeat', 'anchorCleared', 'anchorFailed'] as const)('终局 %s 后不再推进，返回 false', (status) => {
    const battle = fakeBattle({ time: 10, status })
    const runner = new BattleRunner(battle, { maxSeconds: 90, onEvents: () => {} })
    expect(runner.tick(0.03)).toBe(false)
    expect(battle.steps).toHaveLength(0)
  })
})
