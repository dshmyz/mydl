/**
 * Timer 驱动（§十一.1：War3 Timer 固定周期驱动 Battle.step，与渲染帧解耦）。
 *
 * `startLoop` 把「周期 + 周期性 + 可暂停」的定时器语义钉在端口上（adapter 用
 * TimerStart(periodic=true) / PauseTimer 实现）；`BattleRunner` 收敛一局的推进与
 * 停止规则，主循环只负责装配。
 */

import type { BattleEvent, BattleStatus, HeroIntent } from '../../logic/battle/battle'
import type { War3Api } from '../api'

/** 结构化最小战斗面：`Battle` 天然满足，测试用替身实现 */
export interface BattleLike {
  readonly time: number
  readonly status: BattleStatus
  step(dt: number, intent?: HeroIntent): readonly BattleEvent[]
}

export interface BattleRunnerDeps {
  /** 每帧取操作意图（键盘桥接传入；headless 传 () => ({})） */
  intent?: () => HeroIntent
  /** 每帧事件出口（表现层桥接挂接处） */
  onEvents: (events: readonly BattleEvent[]) => void
  /** 冒烟限时（模拟秒）：到达即停表，供与 Node 侧 golden 对照 */
  maxSeconds?: number
}

export class BattleRunner {
  constructor(
    private readonly battle: BattleLike,
    private readonly deps: BattleRunnerDeps,
  ) {}

  /**
   * 推进一帧。
   * @returns 是否应继续驱动（false = 已终局或到达冒烟限时，主循环应停表）
   */
  tick(dt: number): boolean {
    if (this.battle.status !== 'running') {
      return false
    }
    if (this.battle.time >= (this.deps.maxSeconds ?? Number.POSITIVE_INFINITY)) {
      return false
    }
    const events = this.battle.step(dt, this.deps.intent?.() ?? {})
    this.deps.onEvents(events)
    return this.battle.status === 'running'
  }
}

/** 注册驱动循环；返回句柄用于停表 */
export function startLoop(
  api: War3Api,
  periodSeconds: number,
  onTick: () => void,
): { stop(): void } {
  return api.startPeriodicTimer(periodSeconds, onTick)
}
