import { describe, expect, it } from 'vitest'

import type { Bounds, Vec2 } from '../../logic/battle/spatial'
import type { Stats } from '../../data/types/common'
import { Unit, type UnitKind } from '../../logic/battle/unit'
import { MapProjection } from '../projection'
import { FakeWar3Api } from '../testing/fakeApi'
import { UnitBridge } from './unitBridge'

/** 与 `DEFAULT_BATTLE_CONFIG.field.bounds` 同形的战场（24 × 12 格） */
const FIELD: Bounds = { min: { x: 0, y: 0 }, max: { x: 24, y: 12 } }
const PROJECTION = new MapProjection(FIELD, { scale: 128, originX: -1536, originY: -768 })

const CODES: Record<UnitKind, string> = {
  hero: 'Hpal',
  minion: 'hfoo',
  elite: 'hknight',
  boss: 'Udea',
}

const SCALES: Record<UnitKind, number> = { hero: 1, minion: 1, elite: 1.3, boss: 2 }

/** 全 0 属性基线（仅作单位构造占位，桥接不参与数值结算） */
const STATS: Stats = { hp: 100, mp: 0, atk: 10, sp: 0, def: 0, spd: 220, dodge: 0, crit: 0, critDmg: 0 }

function makeUnit(id: string, kind: UnitKind, position: Vec2): Unit {
  return new Unit({
    id,
    kind,
    defId: `def_${kind}`,
    name: id,
    baseStats: { ...STATS },
    position,
    tier: 1,
    attackSpeed: 1,
    attackRange: 1,
    damageType: 'physical',
  })
}

function makeBridge(api: FakeWar3Api): UnitBridge {
  return new UnitBridge(api, PROJECTION, {
    unitCodeByKind: CODES,
    players: { hero: 0, enemy: 1 },
    scaleByKind: SCALES,
  })
}

describe('UnitBridge（逻辑单位 ↔ War3 单位投影）', () => {
  it('首次同步：按 kind 创建单位（英雄己方 / 敌方阵营）并放到投影坐标', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)

    bridge.sync(makeUnit('hero', 'hero', { x: 9, y: 6 }), [makeUnit('m1', 'minion', { x: 21, y: 6 })])

    expect(api.createdUnits).toHaveLength(2)
    const [heroCall, minionCall] = api.createdUnits
    expect(heroCall).toMatchObject({ playerIndex: 0, code: 'Hpal', x: -1536 + 9 * 128, y: -768 + 6 * 128 })
    expect(minionCall).toMatchObject({ playerIndex: 1, code: 'hfoo', x: -1536 + 21 * 128, y: -768 + 6 * 128 })
  })

  it('创建时经 face 参数设置初始朝向（逻辑朝向向量 → 角度），缩放档位为 1 的 kind 不调缩放', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)

    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    hero.facing = { x: 0, y: -1 } // 朝下 → -90°（face() 接收目标点，此处直设方向向量）
    const boss = makeUnit('b1', 'boss', { x: 21, y: 6 })
    bridge.sync(hero, [boss])

    expect(api.createdUnits[0].faceDeg).toBe(-90)
    expect(api.createdUnits[1].faceDeg).toBe(0) // 默认朝向 {1, 0}
    expect(api.scales).toEqual([{ handle: api.createdUnits[1].handle, scale: 2 }])
  })

  it('位置与朝向差量同步：变化才调用，静止帧幂等', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)
    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    const minion = makeUnit('m1', 'minion', { x: 21, y: 6 })
    bridge.sync(hero, [minion])

    bridge.sync(hero, [minion]) // 静止帧：无新调用
    expect(api.movedUnits).toHaveLength(0)
    expect(api.facings).toHaveLength(0)

    minion.position = { x: 20, y: 6 }
    minion.facing = { x: -1, y: 0 } // 朝左 → 180°
    bridge.sync(hero, [minion])
    const lastMove = api.movedUnits.at(-1)
    expect(lastMove).toMatchObject({ handle: api.createdUnits[1].handle, x: -1536 + 20 * 128, y: -768 + 6 * 128 })
    expect(api.facings.at(-1)).toMatchObject({ handle: api.createdUnits[1].handle, faceDeg: 180 })
  })

  it('气血每帧同步到逻辑 hp；maxHp 变化时先改上限', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)
    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    const minion = makeUnit('m1', 'minion', { x: 21, y: 6 })
    bridge.sync(hero, [minion])

    minion.hp = 60
    bridge.sync(hero, [minion])
    expect(api.lives.at(-1)).toMatchObject({ handle: api.createdUnits[1].handle, hp: 60 })

    minion.setBaseStats({ ...STATS, hp: 300 })
    bridge.sync(hero, [minion])
    expect(api.maxLives.at(-1)).toMatchObject({ handle: api.createdUnits[1].handle, max: 300 })
  })

  it('阵亡两帧演出：消失帧 killUnit，下一帧 removeUnit', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)
    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    const minion = makeUnit('m1', 'minion', { x: 21, y: 6 })
    bridge.sync(hero, [minion])
    const handle = api.createdUnits[1].handle

    bridge.sync(hero, []) // 怪物已从战场移除
    expect(api.killed).toEqual([handle])
    expect(api.removed).toHaveLength(0)

    bridge.sync(hero, [])
    expect(api.removed).toEqual([handle])
  })

  it('英雄阵亡 killUnit 播死亡动画；复活时 reviveHero 到复活点', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)
    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    bridge.sync(hero, [])
    const handle = api.createdUnits[0].handle

    hero.alive = false
    bridge.sync(hero, [])
    expect(api.killed).toEqual([handle])

    hero.alive = true
    hero.position = { x: 9, y: 6 } // 逻辑复活回 heroSpawn
    bridge.sync(hero, [])
    expect(api.revives).toEqual([{ handle, x: -1536 + 9 * 128, y: -768 + 6 * 128 }])
  })

  it('positionOf 返回战场坐标：存活与已移除单位均可查（供死亡特效取位）', () => {
    const api = new FakeWar3Api()
    const bridge = makeBridge(api)
    const hero = makeUnit('hero', 'hero', { x: 9, y: 6 })
    const minion = makeUnit('m1', 'minion', { x: 21, y: 6 })
    bridge.sync(hero, [minion])
    expect(bridge.positionOf('m1')).toEqual({ x: 21, y: 6 })

    bridge.sync(hero, [])
    expect(bridge.positionOf('m1')).toEqual({ x: 21, y: 6 })
    expect(bridge.positionOf('no_such')).toBeNull()
  })
})
