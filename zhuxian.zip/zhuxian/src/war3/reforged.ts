/** @noSelfInFile **/

/**
 * War3 原生 adapter：把 reforged-types 原生函数接进 `War3Api` 端口。
 *
 * 全仓唯一接触 War3 原生 API 的模块（main.ts 只做装配）——桥接层与测试都不见原生类型，
 * 平台细节（句柄转换、键位映射、触发器注册）全部收敛在这层薄壳里。
 */

import type { EffectHandle, KeyName, UnitHandle, War3Api } from './api'

/** 英雄所属玩家（War3 红方）与敌方玩家（蓝方）索引 */
const HERO_PLAYER_INDEX = 0
const ENEMY_PLAYER_INDEX = 1

const KEY_OSKEY: Record<KeyName, oskeytype> = {
  UP: OSKEY_UP,
  DOWN: OSKEY_DOWN,
  LEFT: OSKEY_LEFT,
  RIGHT: OSKEY_RIGHT,
  Q: OSKEY_Q,
  W: OSKEY_W,
  E: OSKEY_E,
  R: OSKEY_R,
}

function playerOf(index: number): player {
  const p = Player(index)
  if (!p) {
    throw new Error(`War3 adapter：玩家槽位 ${index} 不存在`)
  }
  return p
}

function asUnit(handle: UnitHandle): unit {
  return handle as unknown as unit
}

function asEffect(handle: EffectHandle): effect {
  return handle as unknown as effect
}

export function createReforgedApi(): War3Api {
  return {
    createUnit(playerIndex: number, code: string, x: number, y: number, faceDeg: number) {
      const rawcode = FourCC(code)
      const created = CreateUnit(
        playerOf(playerIndex === HERO_PLAYER_INDEX ? HERO_PLAYER_INDEX : ENEMY_PLAYER_INDEX),
        rawcode,
        x,
        y,
        faceDeg,
      )
      return created !== undefined ? (created as unknown as UnitHandle) : null
    },

    setUnitPosition(handle: UnitHandle, x: number, y: number): void {
      // SetUnitX/Y 直设坐标不走寻路，与逻辑层直控语义一致
      SetUnitX(asUnit(handle), x)
      SetUnitY(asUnit(handle), y)
    },

    setUnitFacing(handle: UnitHandle, faceDeg: number): void {
      SetUnitFacing(asUnit(handle), faceDeg)
    },

    setUnitLife(handle: UnitHandle, hp: number): void {
      SetUnitState(asUnit(handle), UNIT_STATE_LIFE, hp)
    },

    setUnitMaxLife(handle: UnitHandle, max: number): void {
      SetUnitState(asUnit(handle), UNIT_STATE_MAX_LIFE, max)
    },

    setUnitScale(handle: UnitHandle, scale: number): void {
      SetUnitScale(asUnit(handle), scale, scale, scale)
    },

    killUnit(handle: UnitHandle): void {
      KillUnit(asUnit(handle))
    },

    removeUnit(handle: UnitHandle): void {
      RemoveUnit(asUnit(handle))
    },

    reviveHero(handle: UnitHandle, x: number, y: number): void {
      ReviveHero(asUnit(handle), x, y, true)
    },

    showText(message: string): void {
      DisplayTimedTextToPlayer(playerOf(HERO_PLAYER_INDEX), 0, 0, 5, message)
    },

    spawnEffect(model: string, x: number, y: number) {
      const created = AddSpecialEffect(model, x, y)
      return created !== undefined ? (created as unknown as EffectHandle) : null
    },

    destroyEffect(handle: EffectHandle): void {
      DestroyEffect(asEffect(handle))
    },

    startPeriodicTimer(periodSeconds: number, onTick: () => void) {
      const timer = CreateTimer()
      TimerStart(timer, periodSeconds, true, onTick)
      return {
        stop(): void {
          PauseTimer(timer)
        },
      }
    },

    registerKey(key: KeyName, onKeyDown: () => void, onKeyUp: () => void): void {
      const oskey = KEY_OSKEY[key]
      const localPlayer = playerOf(HERO_PLAYER_INDEX)
      // 按下 / 抬起各挂一个触发器；metaKey 0 = 不要求修饰键
      const downTrigger = CreateTrigger()
      BlzTriggerRegisterPlayerKeyEvent(downTrigger, localPlayer, oskey, 0, true)
      TriggerAddAction(downTrigger, onKeyDown)
      const upTrigger = CreateTrigger()
      BlzTriggerRegisterPlayerKeyEvent(upTrigger, localPlayer, oskey, 0, false)
      TriggerAddAction(upTrigger, onKeyUp)
    },
  }
}
