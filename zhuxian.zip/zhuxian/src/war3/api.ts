/**
 * War3 端口接口（依赖反转 seam，§十一）。
 *
 * 桥接层（unitBridge / eventBridge / driver / heroControl）只依赖本端口；
 * `reforged.ts` 是唯一把原生 API 接进端口的 adapter，vitest 用 `testing/fakeApi.ts` 驱动。
 * 句柄为不透明品牌类型：桥接层只传递、不触碰内部。
 */

export type UnitHandle = { readonly __kind: 'unit' }
export type EffectHandle = { readonly __kind: 'effect' }

/** 键盘按键名（adapter 负责映射到 `oskeytype`） */
export type KeyName =
  | 'UP'
  | 'DOWN'
  | 'LEFT'
  | 'RIGHT'
  | 'Q'
  | 'W'
  | 'E'
  | 'R'

export interface War3Api {
  // —— 单位 ——
  /** 在世界坐标创建单位；`playerIndex` 0 为己方（英雄）、1 为敌方（怪物），faceDeg 为朝向角（度） */
  createUnit(playerIndex: number, code: string, x: number, y: number, faceDeg: number): UnitHandle | null
  setUnitPosition(handle: UnitHandle, x: number, y: number): void
  setUnitFacing(handle: UnitHandle, faceDeg: number): void
  setUnitLife(handle: UnitHandle, hp: number): void
  setUnitMaxLife(handle: UnitHandle, max: number): void
  setUnitScale(handle: UnitHandle, scale: number): void
  /** 播放死亡动画（句柄此后不可再同步，等待下一帧 removeUnit） */
  killUnit(handle: UnitHandle): void
  removeUnit(handle: UnitHandle): void
  /** 英雄复活（原生 ReviveHero：满状态回到指定世界坐标） */
  reviveHero(handle: UnitHandle, x: number, y: number): void

  // —— 表现 ——
  showText(message: string): void
  spawnEffect(model: string, x: number, y: number): EffectHandle | null
  destroyEffect(handle: EffectHandle): void

  // —— 驱动 ——
  /** 注册周期定时器；返回句柄的 stop() 暂停定时器（取消驱动） */
  startPeriodicTimer(periodSeconds: number, onTick: () => void): { stop(): void }

  // —— 输入 ——
  /** 注册按键的按下 / 抬起回调 */
  registerKey(key: KeyName, onKeyDown: () => void, onKeyUp: () => void): void
}
