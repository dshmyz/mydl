/** @noSelfInFile **/

/**
 * War3 地图脚本入口（阶段 1 · 表现层桥接装配）。
 *
 * 装配链：配置数据 → 建 `Battle` → 原生 adapter（reforged.ts）注入各桥接组件 →
 * Timer 周期驱动 `BattleRunner.tick`：
 *   step（逻辑）→ unitBridge.sync（对账投影单位）→ eventBridge.play（播事件表现）
 *
 * 键盘：方向键移动，Q / W / E / R 释放技能（与 Web 原型键位一致）。
 *
 * 验证锚点：英雄静止不动时，一局输出应与 Node 侧 golden 一致
 *   `t=90.0s，击杀 8，存活单位 0，核心 3000，状态 running`
 * 两端对不上即 TS → Lua 的移植有偏（附录 F.5 风险 1）。
 */

import { loadGameData } from '../data/load'
import { Battle } from '../logic/battle/battle'
import type { BattleEvent } from '../logic/battle/battle'
import { DEFAULT_BATTLE_CONFIG } from '../logic/battle/config'
import type { UnitKind } from '../logic/battle/unit'
import { BattleRunner, startLoop } from './bridge/driver'
import { EventBridge } from './bridge/eventBridge'
import { KeyState } from './bridge/heroControl'
import { UnitBridge } from './bridge/unitBridge'
import { centeredOrigin, MapProjection } from './projection'
import { createReforgedApi } from './reforged'

/** 定时器周期（秒），与逻辑固定步长（`DEFAULT_BATTLE_CONFIG.dt`）解耦 */
const TICK_SECONDS = 0.03
/** 冒烟时长（模拟秒）：覆盖「准备 → 第一波刷怪 → 交战」，与 Node 侧 golden 场景对齐 */
const SMOKE_SECONDS = 90
/** 每逻辑格的世界单位数（War3 大格标准） */
const WORLD_SCALE = 128

/** 占位单位码：地图未定稿前用标准种族单位，建图后替换为自定义单位 */
const UNIT_CODES: Record<UnitKind, string> = {
  hero: 'Hpal',
  minion: 'hfoo',
  elite: 'hknight',
  boss: 'Udea',
}
/** 各 kind 模型缩放（1 = 原始大小不调原生） */
const UNIT_SCALES: Record<UnitKind, number> = {
  hero: 1.1,
  minion: 1,
  elite: 1.3,
  boss: 2,
}

/**
 * 特效模型路径（占位值）：路径无效时 War3 只是无表现、不报错，
 * 试跑后按需要替换为可用的内置特效或自定义模型。
 */
const EFFECT_MODELS = {
  spawn: 'Abilities\\Spells\\Orc\\FeralSpirit\\feralspiritdone.mdl',
  kill: 'Abilities\\Weapons\\Bolt\\BoltImpact.mdl',
  cast: 'Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl',
}

/** 地图加载时启动。 */
function boot(): void {
  const { data, index, warnings } = loadGameData()
  BJDebugMsg(
    `[阶段1] 配置装配完成：英雄 ${data.heroes.length} / 怪物 ${data.monsters.length} / 波次模板 ${data.waveTemplates.length}，校验告警 ${warnings.length} 条`,
  )

  const battle = new Battle({ data, index, config: DEFAULT_BATTLE_CONFIG })
  BJDebugMsg(`[阶段1] 建局完成：seed ${DEFAULT_BATTLE_CONFIG.seed}，核心耐久 ${battle.core.maxHp}`)

  const api = createReforgedApi()
  const bounds = DEFAULT_BATTLE_CONFIG.field.bounds
  const projection = new MapProjection(bounds, {
    scale: WORLD_SCALE,
    ...centeredOrigin(bounds, WORLD_SCALE),
  })

  const unitBridge = new UnitBridge(api, projection, {
    unitCodeByKind: UNIT_CODES,
    players: { hero: 0, enemy: 1 },
    scaleByKind: UNIT_SCALES,
  })
  const eventBridge = new EventBridge(api, projection, {
    effectModels: EFFECT_MODELS,
    positionOf: (unitId) => unitBridge.positionOf(unitId),
  })
  const keys = new KeyState(api)

  // 事件先暂存：主循环里先对账同步（出生单位获得位置），再播放事件表现
  let frameEvents: readonly BattleEvent[] = []
  const runner = new BattleRunner(battle, {
    intent: () => keys.readIntent(),
    onEvents: (events) => {
      frameEvents = events
    },
    maxSeconds: SMOKE_SECONDS,
  })

  const loop = startLoop(api, TICK_SECONDS, () => {
    if (!runner.tick(TICK_SECONDS)) {
      loop.stop()
      BJDebugMsg(
        `[阶段1] 停表：t=${battle.time.toFixed(1)}s，击杀 ${battle.kills}，存活单位 ${battle.units.length}，核心 ${Math.round(battle.core.hp)}，状态 ${battle.status}`,
      )
      return
    }
    unitBridge.sync(battle.hero, battle.units)
    eventBridge.play(frameEvents)
  })
}

boot()
