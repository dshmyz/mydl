import { describe, expect, it } from 'vitest'

import type { Bounds } from '../logic/battle/spatial'
import { MapProjection, centeredOrigin } from './projection'

/** 与 `DEFAULT_BATTLE_CONFIG.field.bounds` 同形的战场（24 × 12 格） */
const FIELD: Bounds = { min: { x: 0, y: 0 }, max: { x: 24, y: 12 } }

describe('centeredOrigin', () => {
  it('战场中心映射到世界原点：origin = -(尺寸 × scale) / 2', () => {
    expect(centeredOrigin(FIELD, 128)).toEqual({ originX: -1536, originY: -768 })
  })
})

describe('MapProjection', () => {
  it('战场左下角映射到 origin', () => {
    const projection = new MapProjection(FIELD, { scale: 128, originX: -1536, originY: -768 })
    expect(projection.toWorld({ x: 0, y: 0 })).toEqual({ x: -1536, y: -768 })
  })

  it('战场右上角映射到 origin + 尺寸 × scale', () => {
    const projection = new MapProjection(FIELD, { scale: 128, originX: -1536, originY: -768 })
    expect(projection.toWorld({ x: 24, y: 12 })).toEqual({ x: 1536, y: 768 })
  })

  it('战场中心映射到世界原点', () => {
    const projection = new MapProjection(FIELD, { scale: 128, originX: -1536, originY: -768 })
    expect(projection.toWorld({ x: 12, y: 6 })).toEqual({ x: 0, y: 0 })
  })

  it('非零下界的战场按 bounds.min 平移换算', () => {
    const shifted: Bounds = { min: { x: 10, y: 20 }, max: { x: 34, y: 32 } }
    const projection = new MapProjection(shifted, { scale: 100, originX: -1200, originY: -600 })
    // min → origin；(0, 2) 格的偏移 → +200
    expect(projection.toWorld({ x: 10, y: 22 })).toEqual({ x: -1200, y: -400 })
  })

  it('自定义 scale 线性缩放格距离', () => {
    const projection = new MapProjection(FIELD, { scale: 64, originX: 0, originY: 0 })
    expect(projection.toWorld({ x: 3, y: 4 })).toEqual({ x: 192, y: 256 })
  })
})
