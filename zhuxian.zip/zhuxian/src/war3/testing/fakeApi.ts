import type { EffectHandle, KeyName, UnitHandle, War3Api } from '../api'

/**
 * War3Api 测试替身：按端口语义记录调用，供桥接层单测断言调用序列。
 *
 * 只做真做的事——不实现渲染，仅维护定时器活跃 / 按键回调这两个可观察语义。
 */

export interface CreatedUnit {
  handle: UnitHandle
  playerIndex: number
  code: string
  x: number
  y: number
  faceDeg: number
}

export interface KeyHandlers {
  down: () => void
  up: () => void
}

export class FakeWar3Api implements War3Api {
  readonly createdUnits: CreatedUnit[] = []
  readonly movedUnits: Array<{ handle: UnitHandle; x: number; y: number }> = []
  readonly facings: Array<{ handle: UnitHandle; faceDeg: number }> = []
  readonly lives: Array<{ handle: UnitHandle; hp: number }> = []
  readonly maxLives: Array<{ handle: UnitHandle; max: number }> = []
  readonly scales: Array<{ handle: UnitHandle; scale: number }> = []
  readonly killed: UnitHandle[] = []
  readonly removed: UnitHandle[] = []
  readonly revives: Array<{ handle: UnitHandle; x: number; y: number }> = []
  readonly texts: string[] = []
  readonly effects: Array<{ model: string; x: number; y: number }> = []
  readonly destroyedEffects: EffectHandle[] = []
  readonly timerStarts: Array<{ periodSeconds: number }> = []
  readonly keyHandlers = new Map<KeyName, KeyHandlers>()

  private timerCallbacks: Array<() => void> = []
  private timerActive = false

  createUnit(playerIndex: number, code: string, x: number, y: number, faceDeg: number): UnitHandle {
    const handle: UnitHandle = { __kind: 'unit' }
    this.createdUnits.push({ handle, playerIndex, code, x, y, faceDeg })
    return handle
  }

  setUnitPosition(handle: UnitHandle, x: number, y: number): void {
    this.movedUnits.push({ handle, x, y })
  }

  setUnitFacing(handle: UnitHandle, faceDeg: number): void {
    this.facings.push({ handle, faceDeg })
  }

  setUnitLife(handle: UnitHandle, hp: number): void {
    this.lives.push({ handle, hp })
  }

  setUnitMaxLife(handle: UnitHandle, max: number): void {
    this.maxLives.push({ handle, max })
  }

  setUnitScale(handle: UnitHandle, scale: number): void {
    this.scales.push({ handle, scale })
  }

  killUnit(handle: UnitHandle): void {
    this.killed.push(handle)
  }

  removeUnit(handle: UnitHandle): void {
    this.removed.push(handle)
  }

  reviveHero(handle: UnitHandle, x: number, y: number): void {
    this.revives.push({ handle, x, y })
  }

  showText(message: string): void {
    this.texts.push(message)
  }

  spawnEffect(model: string, x: number, y: number): EffectHandle {
    this.effects.push({ model, x, y })
    return { __kind: 'effect' }
  }

  destroyEffect(handle: EffectHandle): void {
    this.destroyedEffects.push(handle)
  }

  startPeriodicTimer(periodSeconds: number, onTick: () => void): { stop(): void } {
    this.timerStarts.push({ periodSeconds })
    this.timerCallbacks.push(onTick)
    this.timerActive = true
    return {
      stop: () => {
        this.timerActive = false
      },
    }
  }

  registerKey(key: KeyName, onKeyDown: () => void, onKeyUp: () => void): void {
    this.keyHandlers.set(key, { down: onKeyDown, up: onKeyUp })
  }

  /** 测试注入：手动让第 `index` 个定时器到期 `times` 次（仅在活跃时转发回调） */
  fireTimer(index: number, times: number): void {
    for (let i = 0; i < times; i += 1) {
      if (!this.timerActive) {
        return
      }
      this.timerCallbacks[index]?.()
    }
  }

  /** 测试注入：模拟按键按下 / 抬起 */
  pressKey(key: KeyName): void {
    this.keyHandlers.get(key)?.down()
  }

  releaseKey(key: KeyName): void {
    this.keyHandlers.get(key)?.up()
  }
}
