import Phaser from 'phaser'

import type { BattleEvent } from '../../logic/battle/battle'
import { CSS, DEPTH, gridToPixel, textStyle } from '../theme'

/** 命中方位映射：单位 id → 渲染坐标（阵亡单位已移出战场时返回 undefined） */
export type PositionLookup = (unitId: string) => { x: number; y: number } | undefined

/**
 * 战斗反馈浮字：伤害 / 暴击 / 闪避 / 核心受创。
 *
 * 消费编排层产出的 `BattleEvent`，纯表现、无逻辑副作用；对象池复用文本，避免频繁创建。
 */
export class DamageNumbers {
  private readonly scene: Phaser.Scene
  private readonly pool: Phaser.GameObjects.Text[] = []

  constructor(scene: Phaser.Scene) {
    this.scene = scene
  }

  /** 消费本帧事件（`corePos` 为核心点位，用于核心受创浮字） */
  play(
    events: readonly BattleEvent[],
    posOf: PositionLookup,
    corePosition: { x: number; y: number },
  ): void {
    const core = gridToPixel(corePosition)
    for (const event of events) {
      if (event.kind === 'damage') {
        const pos = posOf(event.targetId)
        if (!pos) {
          continue
        }
        const at = gridToPixel(pos)
        const againstHero = event.targetId === 'hero'
        const label = event.dodged ? '闪避' : `-${Math.round(event.amount)}`
        const color = event.dodged ? CSS.dim : againstHero ? CSS.danger : CSS.text
        this.spawn(at.x, at.y - 18, label, color, event.crit)
      } else if (event.kind === 'coreDamage') {
        this.spawn(core.x, core.y - 46, `-${event.amount}`, CSS.danger, true)
      }
    }
  }

  private spawn(x: number, y: number, label: string, color: string, big: boolean): void {
    const text = this.acquire()
    this.scene.tweens.killTweensOf(text)
    text
      .setText(label)
      .setColor(color)
      .setFontSize(big ? 20 : 14)
      .setPosition(x + Phaser.Math.Between(-6, 6), y)
      .setAlpha(1)
      .setVisible(true)
      .setDepth(DEPTH.effect)

    this.scene.tweens.add({
      targets: text,
      y: y - 26,
      alpha: 0,
      duration: 620,
      ease: 'Cubic.easeOut',
      onComplete: () => {
        text.setVisible(false)
        this.pool.push(text)
      },
    })
  }

  private acquire(): Phaser.GameObjects.Text {
    const reused = this.pool.pop()
    if (reused) {
      return reused
    }
    return this.scene.add.text(0, 0, '', textStyle(14, CSS.text)).setOrigin(0.5, 0.5)
  }
}
