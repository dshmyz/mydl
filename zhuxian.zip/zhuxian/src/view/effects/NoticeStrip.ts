import type Phaser from 'phaser'

import { CSS, DEPTH, WORLD_HEIGHT, WORLD_WIDTH, textStyle } from '../theme'

/** 单条提示的存活时长（秒） */
const DEFAULT_TTL = 2.6
/** 提示条基线 y（像素） */
const BASE_Y = WORLD_HEIGHT - 150
/** 逐条上移间距（像素） */
const LINE_HEIGHT = 22

interface Notice {
  text: string
  color: string
  remaining: number
}

/**
 * 底部中央的瞬时提示条：事件注入 / 阵亡复活 / 合成突破等一次性反馈。
 *
 * 采用文本对象池：条目随寿命淘汰，池对象复用，避免高频新建造成对象抖动。
 */
export class NoticeStrip {
  private readonly scene: Phaser.Scene
  private readonly items: Notice[] = []
  private readonly pool: Phaser.GameObjects.Text[] = []

  constructor(scene: Phaser.Scene) {
    this.scene = scene
  }

  push(text: string, color: string = CSS.text, ttl = DEFAULT_TTL): void {
    this.items.push({ text, color, remaining: ttl })
  }

  /** 推进寿命并重绘（`dt` 为真实帧时长，秒） */
  update(dt: number): void {
    for (const item of this.items) {
      item.remaining -= dt
    }
    // 从队首剔除已过期条目（保持堆叠顺序稳定）
    for (;;) {
      const first = this.items[0]
      if (!first || first.remaining > 0) {
        break
      }
      this.items.shift()
    }

    const count = this.items.length
    for (let i = 0; i < count; i += 1) {
      const item = this.items[i]
      if (!item) {
        continue
      }
      const text = this.acquire(i)
      text.setText(item.text)
      text.setColor(item.color)
      text.setPosition(WORLD_WIDTH / 2, BASE_Y - i * LINE_HEIGHT)
      text.setAlpha(Math.min(1, item.remaining / 0.6))
      text.setVisible(true)
    }
    for (let i = count; i < this.pool.length; i += 1) {
      this.pool[i]?.setVisible(false)
    }
  }

  private acquire(index: number): Phaser.GameObjects.Text {
    const existing = this.pool[index]
    if (existing) {
      return existing
    }
    const created = this.scene.add
      .text(0, 0, '', textStyle(14, CSS.text))
      .setOrigin(0.5, 1)
      .setDepth(DEPTH.hud)
    this.pool[index] = created
    return created
  }
}
