import Phaser from 'phaser'

import { loadGameData } from '../data/load'
import { Battle } from '../logic/battle/battle'
import { DEFAULT_BATTLE_CONFIG } from '../logic/battle/config'
import { EventDirector } from '../logic/events/eventDirector'
import { GameScene } from './scene/GameScene'
import { PALETTE, WORLD_HEIGHT, WORLD_WIDTH } from './theme'

/**
 * 表现层入口：装配数据 → 建一局 `Battle` → 启动 Phaser。
 *
 * 逻辑层（`Battle` / `FixedStepController`）不依赖 Phaser，可 headless 复用；
 * 场景只负责把逻辑事实渲染出来并把玩家输入回灌给逻辑。
 */
const { data, index, warnings } = loadGameData()
for (const warning of warnings) {
  console.warn('[配置校验]', warning)
}

const battle = new Battle({
  data,
  index,
  config: DEFAULT_BATTLE_CONFIG,
  events: new EventDirector(index),
})

export const game = new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game-root',
  width: WORLD_WIDTH,
  height: WORLD_HEIGHT,
  backgroundColor: PALETTE.background,
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  scene: [new GameScene({ battle, data, index })],
})
