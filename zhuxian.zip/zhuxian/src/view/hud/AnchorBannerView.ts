import type Phaser from 'phaser'

import type { Battle } from '../../logic/battle/battle'
import { CSS, DEPTH, PALETTE, WORLD_WIDTH, textStyle } from '../theme'
import { HealthBar } from '../units/HealthBar'

const BANNER_W = 384
const BANNER_H = 72
const BANNER_Y = 86
const BAR_W = 344

/**
 * 锚点限时战横幅：BOSS 名称 + 血量条 + 剩余倒计时；结算后转为结果提示。
 *
 * BOSS 满血值由编排层在 `anchorStart` 事件时经 `begin()` 注入（逻辑层未单独暴露上限）。
 */
export class AnchorBannerView {
  private readonly container: Phaser.GameObjects.Container
  private readonly title: Phaser.GameObjects.Text
  private readonly bar: HealthBar
  private readonly timer: Phaser.GameObjects.Text
  private readonly bossName: string
  private bossMaxHp = 0

  constructor(scene: Phaser.Scene, bossName: string) {
    this.bossName = bossName
    this.container = scene.add.container(WORLD_WIDTH / 2, BANNER_Y).setDepth(DEPTH.hud).setVisible(false)

    const bg = scene.add
      .rectangle(0, 0, BANNER_W, BANNER_H, PALETTE.panel, 0.86)
      .setStrokeStyle(1, PALETTE.bossEdge, 0.7)
    this.title = scene.add.text(0, -22, '', textStyle(15, '#ffcec6', 'bold')).setOrigin(0.5, 0.5)
    this.bar = new HealthBar(scene, -BAR_W / 2, 6, { width: BAR_W, height: 9, lowRatio: 0.3 })
    this.timer = scene.add.text(0, 24, '', textStyle(12, CSS.text)).setOrigin(0.5, 0.5)
    this.container.add([bg, this.title, this.bar.group, this.timer])
  }

  /** 记录锚点 BOSS 满血（限时战开始时调用） */
  begin(maxHp: number): void {
    this.bossMaxHp = maxHp
  }

  update(battle: Battle): void {
    const status = battle.challenge.status
    if (status === 'idle') {
      this.container.setVisible(false)
      return
    }

    this.container.setVisible(true)
    if (status === 'active') {
      this.title.setText(`锚点限时战 · ${this.bossName}`)
      this.bar.group.setVisible(true)
      this.bar.setRatio(this.bossMaxHp > 0 ? battle.challenge.bossHp / this.bossMaxHp : 0)
      this.timer.setText(`剩余 ${Math.ceil(battle.challenge.remaining)}s`)
      this.timer.setColor(CSS.text)
      return
    }

    this.bar.group.setVisible(false)
    if (status === 'cleared') {
      this.title.setText('锚点已攻克')
      const hint = battle.canBreakthrough()
        ? '按 B 渡劫突破上清'
        : battle.hero.rank === 'yuqing'
          ? '渡劫机会已用尽'
          : `已突破 ${rankName(battle)} · M1 通关`
      this.timer.setText(hint)
      this.timer.setColor(CSS.good)
    } else {
      this.title.setText('锚点失守')
      this.timer.setText('本局结束')
      this.timer.setColor(CSS.danger)
    }
  }
}

function rankName(battle: Battle): string {
  return battle.hero.rank === 'taiqing' ? '太清' : battle.hero.rank === 'shangqing' ? '上清' : '玉清'
}
