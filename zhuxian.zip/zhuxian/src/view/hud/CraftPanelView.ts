import type Phaser from 'phaser'

import type { GameDataIndex } from '../../data/indexes'
import type { GameData } from '../../data/types/gameData'
import type { RecipeDef } from '../../data/types/equipment'
import type { Battle } from '../../logic/battle/battle'
import { CSS, DEPTH, PALETTE, WORLD_HEIGHT, WORLD_WIDTH, textStyle } from '../theme'

const PANEL_W = 244
const PANEL_H = 72
const PANEL_X = WORLD_WIDTH - PANEL_W - 14
const PANEL_Y = WORLD_HEIGHT - PANEL_H - 14

/** 合成面板：展示法宝线升档配方与成本，并提示是否可合成（按 C 合成） */
export class CraftPanelView {
  private readonly data: GameData
  private readonly index: GameDataIndex
  private readonly recipe: RecipeDef
  private readonly status: Phaser.GameObjects.Text

  constructor(scene: Phaser.Scene, data: GameData, index: GameDataIndex, recipe: RecipeDef) {
    this.data = data
    this.index = index
    this.recipe = recipe

    scene.add
      .rectangle(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, PALETTE.panel, 0.78)
      .setOrigin(0, 0)
      .setStrokeStyle(1, PALETTE.coreRing, 0.8)
      .setDepth(DEPTH.hud)
    scene.add
      .text(PANEL_X + 10, PANEL_Y + 8, '合成 · 法宝线', textStyle(12, CSS.gold, 'bold'))
      .setDepth(DEPTH.hud)
    scene.add
      .text(PANEL_X + 10, PANEL_Y + 28, this.detailText(), textStyle(11, CSS.text))
      .setDepth(DEPTH.hud)
    this.status = scene.add
      .text(PANEL_X + PANEL_W - 10, PANEL_Y + 50, '', textStyle(11, CSS.dim))
      .setOrigin(1, 0)
      .setDepth(DEPTH.hud)
  }

  update(battle: Battle): void {
    const craftable = battle.canCraft(this.recipe)
    this.status.setText(craftable ? '按 C 合成升档' : '材料不足')
    this.status.setColor(craftable ? CSS.good : CSS.dim)
  }

  /** 配方一行：凡铁剑 → 蝠翼灵剑（需 25 金 · 蝠翼碎片×2） */
  private detailText(): string {
    const recipe = this.recipe
    const from = this.equipName(recipe.line, recipe.fromTier)
    const to = this.equipName(recipe.line, recipe.toTier)
    const material = this.index.material.get(recipe.materialId)?.name ?? recipe.materialId
    return `${from} → ${to}（需 ${recipe.gold} 金 · ${material}×${recipe.materialCount}）`
  }

  private equipName(line: RecipeDef['line'], tier: RecipeDef['fromTier']): string {
    const def = this.data.equipment.find((item) => item.line === line && item.tier === tier)
    return def?.name ?? `T${tier}`
  }
}
