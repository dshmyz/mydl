import type Phaser from 'phaser'

import type { GameDataIndex } from '../../data/indexes'
import type { Battle } from '../../logic/battle/battle'
import { CSS, DEPTH, PALETTE, WORLD_WIDTH, textStyle } from '../theme'

/** 顶栏高度（像素） */
const BAR_HEIGHT = 46

/** 顶部资源栏：金币 / 灵石 / 等级 / 境界 / 材料 / 事件 / 波次 / 击杀 */
export class ResourceBarView {
  private readonly index: GameDataIndex
  private readonly line: Phaser.GameObjects.Text
  private readonly lineSub: Phaser.GameObjects.Text
  private readonly right: Phaser.GameObjects.Text
  private readonly rightSub: Phaser.GameObjects.Text

  constructor(scene: Phaser.Scene, index: GameDataIndex) {
    this.index = index

    scene.add
      .rectangle(0, 0, WORLD_WIDTH, BAR_HEIGHT, PALETTE.panel, 0.78)
      .setOrigin(0, 0)
      .setDepth(DEPTH.hud)

    this.line = scene.add
      .text(12, 7, '', textStyle(15, CSS.text))
      .setDepth(DEPTH.hud)
    this.lineSub = scene.add
      .text(12, 27, '', textStyle(11, CSS.dim))
      .setDepth(DEPTH.hud)
    this.right = scene.add
      .text(WORLD_WIDTH - 12, 7, '', textStyle(15, CSS.accent))
      .setOrigin(1, 0)
      .setDepth(DEPTH.hud)
    this.rightSub = scene.add
      .text(WORLD_WIDTH - 12, 27, '', textStyle(11, CSS.dim))
      .setOrigin(1, 0)
      .setDepth(DEPTH.hud)
  }

  update(battle: Battle): void {
    const hero = battle.hero
    const rankName = this.index.rank.get(hero.rank)?.name ?? hero.rank
    this.line.setText(`金币 ${battle.gold}   灵石 ${battle.spirit}   Lv.${hero.level}   境界 ${rankName}`)

    const materials =
      [...battle.materials.entries()]
        .filter(([, count]) => count > 0)
        .map(([id, count]) => `${this.index.material.get(id)?.name ?? id}×${count}`)
        .join('  ') || '无'
    this.lineSub.setText(`材料：${materials}   事件：${this.eventText(battle)}`)

    const phase = phaseText(battle)
    this.right.setText(`第 ${battle.scheduler.waveNumber} 波 · ${phase.label}   击杀 ${battle.kills}`)
    this.rightSub.setText(phase.detail)
  }

  /** 本波注入事件的描述（含时序修正） */
  private eventText(battle: Battle): string {
    const event = battle.scheduler.currentEvent
    if (!event) {
      return '无'
    }
    const delta = battle.scheduler.currentTimingDelta
    const timing = delta < 0 ? `提前 ${Math.round(-delta)}s` : `延后 ${Math.round(delta)}s`
    return `${event.name}（${timing}）`
  }
}

/** 波次阶段文案（标签 + 细节） */
function phaseText(battle: Battle): { label: string; detail: string } {
  const scheduler = battle.scheduler
  switch (scheduler.phase) {
    case 'prep':
      return { label: '备战', detail: `下一波 ${Math.ceil(scheduler.prepRemaining)}s` }
    case 'combat':
      return { label: '交战', detail: `剩余敌人 ${battle.units.length}` }
    case 'anchorPrep':
      return { label: '锚点备战', detail: `${Math.ceil(scheduler.prepRemaining)}s 后 BOSS 现身` }
    case 'anchor':
      return { label: '锚点限时战', detail: `剩余 ${Math.ceil(battle.challenge.remaining)}s` }
    case 'done':
      return { label: '本局结束', detail: '' }
  }
}
