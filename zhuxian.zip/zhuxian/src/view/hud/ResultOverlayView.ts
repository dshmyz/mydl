import type Phaser from 'phaser'

import { CSS, DEPTH, WORLD_HEIGHT, WORLD_WIDTH, textStyle } from '../theme'

/** 终局遮罩：核心被击破时全屏压暗并提示重开 */
export class ResultOverlayView {
  private readonly container: Phaser.GameObjects.Container

  constructor(scene: Phaser.Scene) {
    const dim = scene.add
      .rectangle(0, 0, WORLD_WIDTH, WORLD_HEIGHT, 0x000000, 0.68)
      .setOrigin(0, 0)
    const title = scene.add
      .text(WORLD_WIDTH / 2, WORLD_HEIGHT / 2 - 16, '剑阵核心被击破', textStyle(30, CSS.danger, 'bold'))
      .setOrigin(0.5, 0.5)
    const sub = scene.add
      .text(WORLD_WIDTH / 2, WORLD_HEIGHT / 2 + 26, '本局失败 · 刷新页面重开', textStyle(14, CSS.dim))
      .setOrigin(0.5, 0.5)
    this.container = scene.add.container(0, 0, [dim, title, sub]).setDepth(DEPTH.overlay).setVisible(false)
  }

  showDefeat(): void {
    this.container.setVisible(true)
  }
}
