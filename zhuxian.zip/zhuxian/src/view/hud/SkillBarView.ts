import type Phaser from 'phaser'

import type { GameDataIndex } from '../../data/indexes'
import type { HeroDef } from '../../data/types/units'
import type { Battle } from '../../logic/battle/battle'
import type { SkillKey } from '../../data/types/common'
import type { SkillEngine } from '../../logic/skills/skillEngine'
import { CSS, DEPTH, PALETTE, WORLD_HEIGHT, textStyle } from '../theme'
import { HealthBar } from '../units/HealthBar'

/** 技能槽边长 / 间距（像素） */
const SLOT_SIZE = 56
const SLOT_GAP = 8
const ROW_LEFT = 14
const ROW_TOP = WORLD_HEIGHT - 70

/** 单个技能槽的绘制对象集合 */
interface SkillSlot {
  key: SkillKey
  skillId: string
  bg: Phaser.GameObjects.Rectangle
  cdOverlay: Phaser.GameObjects.Rectangle
  keyText: Phaser.GameObjects.Text
  nameText: Phaser.GameObjects.Text
  mpText: Phaser.GameObjects.Text
  cdText: Phaser.GameObjects.Text
}

const KEYS: readonly SkillKey[] = ['Q', 'W', 'E', 'R']

/** 技能栏 + 英雄气血 / 真气：Q/W/E/R 冷却、真气消耗、境界解锁状态 */
export class SkillBarView {
  private readonly index: GameDataIndex
  private readonly slots: SkillSlot[] = []
  private readonly hpBar: HealthBar
  private readonly mpBar: HealthBar
  private readonly vitals: Phaser.GameObjects.Text

  constructor(scene: Phaser.Scene, index: GameDataIndex, heroDef: HeroDef) {
    this.index = index

    this.vitals = scene.add.text(ROW_LEFT, WORLD_HEIGHT - 118, '', textStyle(11, CSS.text)).setDepth(DEPTH.hud)
    this.hpBar = new HealthBar(scene, ROW_LEFT, WORLD_HEIGHT - 100, { width: 210, height: 6, lowRatio: 0.35 })
    this.mpBar = new HealthBar(scene, ROW_LEFT, WORLD_HEIGHT - 90, {
      width: 210,
      height: 6,
      fill: PALETTE.mpFill,
      lowFill: PALETTE.mpFill,
    })
    this.hpBar.group.setDepth(DEPTH.hud)
    this.mpBar.group.setDepth(DEPTH.hud)

    for (let i = 0; i < KEYS.length; i += 1) {
      const key = KEYS[i]
      if (!key) {
        continue
      }
      this.slots.push(this.buildSlot(scene, key, heroDef, i))
    }
  }

  update(battle: Battle, engine: SkillEngine): void {
    const hero = battle.hero
    this.vitals.setText(`气血 ${Math.ceil(hero.hp)} / ${hero.maxHp}   真气 ${Math.ceil(hero.skillState.mp)} / ${hero.skillState.maxMp}`)
    this.hpBar.setRatio(hero.maxHp > 0 ? hero.hp / hero.maxHp : 0)
    this.mpBar.setRatio(hero.skillState.maxMp > 0 ? hero.skillState.mp / hero.skillState.maxMp : 0)

    for (const slot of this.slots) {
      const def = this.index.skill.get(slot.skillId)
      const unlocked = engine.isUnlocked(slot.skillId, hero.rank)
      const ready = engine.canCast(slot.skillId, hero.skillState, hero.rank) === null
      const total = def?.cooldown ?? 0
      const remaining = hero.skillState.cooldownRemaining(slot.skillId)

      slot.bg.setFillStyle(unlocked && ready ? PALETTE.slotReady : PALETTE.slotIdle)
      slot.bg.setAlpha(unlocked ? 1 : 0.45)
      slot.cdOverlay.setVisible(remaining > 0)
      slot.cdOverlay.setScale(1, total > 0 ? Math.min(1, remaining / total) : 0)
      slot.cdText.setVisible(remaining > 0)
      slot.cdText.setText(remaining > 0 ? remaining.toFixed(1) : '')
      slot.mpText.setText(def ? `${def.mpCost}` : '')
      slot.mpText.setColor(hero.skillState.mp >= (def?.mpCost ?? 0) ? CSS.accent : CSS.danger)
      slot.nameText.setText(def?.name ?? '')
    }
  }

  private buildSlot(scene: Phaser.Scene, key: SkillKey, heroDef: HeroDef, index: number): SkillSlot {
    const cx = ROW_LEFT + index * (SLOT_SIZE + SLOT_GAP) + SLOT_SIZE / 2
    const cy = ROW_TOP + SLOT_SIZE / 2

    const bg = scene.add.rectangle(cx, cy, SLOT_SIZE, SLOT_SIZE, PALETTE.slotIdle).setDepth(DEPTH.hud)
    bg.setStrokeStyle(1, PALETTE.coreRing, 0.9)
    const cdOverlay = scene.add
      .rectangle(cx, cy + SLOT_SIZE / 2, SLOT_SIZE, SLOT_SIZE, 0x000000, 0.62)
      .setOrigin(0.5, 1)
      .setDepth(DEPTH.hud + 1)
    const keyText = scene.add
      .text(cx - SLOT_SIZE / 2 + 6, cy - SLOT_SIZE / 2 + 4, key, textStyle(16, CSS.accent, 'bold'))
      .setDepth(DEPTH.hud + 2)
    const mpText = scene.add
      .text(cx + SLOT_SIZE / 2 - 6, cy - SLOT_SIZE / 2 + 5, '', textStyle(10, CSS.accent))
      .setOrigin(1, 0)
      .setDepth(DEPTH.hud + 2)
    const nameText = scene.add
      .text(cx, cy + 8, '', textStyle(9, CSS.dim))
      .setOrigin(0.5, 0)
      .setWordWrapWidth(SLOT_SIZE - 8, true)
      .setDepth(DEPTH.hud + 2)
    const cdText = scene.add
      .text(cx, cy, '', textStyle(16, CSS.text, 'bold'))
      .setOrigin(0.5, 0.5)
      .setDepth(DEPTH.hud + 2)

    return { key, skillId: heroDef.skills[key], bg, cdOverlay, keyText, nameText, mpText, cdText }
  }
}
