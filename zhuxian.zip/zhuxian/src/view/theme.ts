/**
 * 表现层共享常量：格 → 像素换算、世界尺寸、渲染分层、配色与文字样式。
 *
 * 逻辑层以「格」描述位置，渲染层以「像素」呈现；所有换算集中在此，避免各处硬编码比例。
 * 本模块只有常量与纯函数，不依赖 Phaser 运行时。
 */

/** 单格像素边长 */
export const CELL_PX = 40

/** 战场格数（与 `DEFAULT_BATTLE_CONFIG.field.bounds` 一致：24×12） */
export const COLS = 24
export const ROWS = 12

/** 画布世界尺寸（像素） */
export const WORLD_WIDTH = COLS * CELL_PX
export const WORLD_HEIGHT = ROWS * CELL_PX

/** 渲染深度分层：数值越大越靠前 */
export const DEPTH = {
  field: 0,
  core: 10,
  unit: 20,
  boss: 26,
  effect: 60,
  hud: 100,
  overlay: 200,
} as const

/** Phaser 颜色（十六进制数值） */
export const PALETTE = {
  background: 0x05070d,
  fieldFill: 0x0d1322,
  gridLine: 0x1b2540,
  laneBand: 0x121a30,
  spawnZone: 0x3a1620,
  spawnEdge: 0xff6b5e,
  coreRing: 0x2b4a8f,
  core: 0x3f6fd8,
  coreEdge: 0x9fc2ff,
  hero: 0x5fd0ff,
  heroCore: 0x0f3b52,
  heroEdge: 0xcaf2ff,
  minion: 0x8d97a8,
  elite: 0xd98b3a,
  eliteEdge: 0xffd8a0,
  boss: 0xe0483d,
  bossEdge: 0xffb0a6,
  hpFill: 0x4cd07d,
  hpLow: 0xe0483d,
  hpBack: 0x2a3346,
  mpFill: 0x4a7bd6,
  panel: 0x0b1220,
  slotReady: 0x1d2b45,
  slotIdle: 0x141b28,
  bar: 0x0a0f1a,
} as const

/** 文字颜色（CSS 字符串） */
export const CSS = {
  text: '#e6ecf5',
  dim: '#8d97a8',
  gold: '#e0b34c',
  good: '#63e0a0',
  danger: '#ff6b5e',
  accent: '#5fd0ff',
} as const

/** 统一字体栈（中文优先） */
export const FONT_FAMILY = '"PingFang SC", "Microsoft YaHei", system-ui, sans-serif'

/** 生成 Phaser 文本样式（结构上兼容 `Phaser.Types.GameObjects.Text.TextStyle`） */
export function textStyle(size: number, color: string, fontStyle = 'normal') {
  return { fontFamily: FONT_FAMILY, fontSize: `${size}px`, color, fontStyle }
}

/** 逻辑坐标（格）→ 渲染坐标（像素） */
export function gridToPixel(v: { x: number; y: number }): { x: number; y: number } {
  return { x: v.x * CELL_PX, y: v.y * CELL_PX }
}
