import Phaser from 'phaser'

import type { GameDataIndex } from '../../data/indexes'
import type { RecipeDef } from '../../data/types/equipment'
import type { GameData } from '../../data/types/gameData'
import type { BattleEvent, HeroIntent } from '../../logic/battle/battle'
import type { Battle } from '../../logic/battle/battle'
import type { Vec2 } from '../../logic/battle/spatial'
import { FixedStepController } from '../../logic/core/fixedStep'
import { SkillEngine } from '../../logic/skills/skillEngine'
import { CSS } from '../theme'
import { DamageNumbers } from '../effects/DamageNumbers'
import { NoticeStrip } from '../effects/NoticeStrip'
import { AnchorBannerView } from '../hud/AnchorBannerView'
import { CraftPanelView } from '../hud/CraftPanelView'
import { ResourceBarView } from '../hud/ResourceBarView'
import { ResultOverlayView } from '../hud/ResultOverlayView'
import { SkillBarView } from '../hud/SkillBarView'
import { IntentController } from '../input/IntentController'
import { CoreView } from '../units/CoreView'
import { EnemyView } from '../units/EnemyView'
import { HeroView } from '../units/HeroView'
import { BattlefieldView } from '../world/BattlefieldView'

export interface GameSceneDeps {
  battle: Battle
  data: GameData
  index: GameDataIndex
}

/** 场景内所有子视图的聚合（一次性构建，逐帧分工同步） */
interface GameViews {
  field: BattlefieldView
  core: CoreView
  hero: HeroView
  resource: ResourceBarView
  skills: SkillBarView
  craft: CraftPanelView
  anchor: AnchorBannerView
  result: ResultOverlayView
  notices: NoticeStrip
  numbers: DamageNumbers
  input: IntentController
}

/** 开局操作提示（常驻一小段时间后自动消失） */
const CONTROLS_HINT = '方向键移动 · Q/W/E/R 施法 · B 渡劫突破 · C 合成升档'

/**
 * 主场景：以固定步长驱动逻辑，逐帧把逻辑事实分发给各子视图呈现。
 *
 * 表现层可 import 逻辑层，逻辑层绝不 import 表现层（技术架构 §十一）。
 */
export class GameScene extends Phaser.Scene {
  private readonly deps: GameSceneDeps
  private readonly battle: Battle
  private readonly controller: FixedStepController
  private readonly skills: SkillEngine
  private readonly anchorBossName: string
  private readonly enemies = new Map<string, EnemyView>()

  private views: GameViews | null = null

  constructor(deps: GameSceneDeps) {
    super({ key: 'GameScene' })
    this.deps = deps
    this.battle = deps.battle
    this.controller = new FixedStepController(deps.battle.config.dt, 5)
    this.skills = new SkillEngine(deps.index)
    this.anchorBossName = deps.index.monster.get(deps.battle.config.wave.anchorBossId)?.name ?? '锚点BOSS'
  }

  create(): void {
    const views = this.buildViews()
    this.views = views
    views.notices.push(CONTROLS_HINT, CSS.accent, 8)
  }

  override update(_time: number, delta: number): void {
    const views = this.views
    if (!views) {
      return
    }

    // 真实帧 → 固定逻辑步：与渲染帧率解耦，`alpha` 用于位置插值
    const plan = this.controller.accumulate(delta / 1000)
    const intent: HeroIntent = views.input.readIntent()
    for (let step = 0; step < plan.steps; step += 1) {
      this.battle.step(this.battle.config.dt, intent)
    }

    if (views.input.consumeBreakthrough()) {
      this.battle.breakthrough()
    }
    if (views.input.consumeCraft()) {
      this.craftFirstAvailable()
    }

    // 仅在本帧确实推进过逻辑时消费事件（事件缓冲在每步开头清空）
    if (plan.steps > 0) {
      this.consumeEvents(views)
    }

    this.syncUnits(views, plan.alpha)
    views.notices.update(delta / 1000)
    views.resource.update(this.battle)
    views.skills.update(this.battle, this.skills)
    views.craft.update(this.battle)
    views.anchor.update(this.battle)
    if (this.battle.status === 'defeat') {
      views.result.showDefeat()
    }
  }

  private buildViews(): GameViews {
    const { data, index } = this.deps
    const heroDef = index.hero.get(this.battle.config.heroId)
    if (!heroDef) {
      throw new Error(`表现层：未知英雄「${this.battle.config.heroId}」`)
    }
    return {
      field: new BattlefieldView(this, this.battle.config.field),
      core: new CoreView(this, this.battle.config.field.core),
      hero: new HeroView(this, this.battle.hero),
      resource: new ResourceBarView(this, index),
      skills: new SkillBarView(this, index, heroDef),
      craft: new CraftPanelView(this, data, index, this.firstRecipe()),
      anchor: new AnchorBannerView(this, this.anchorBossName),
      result: new ResultOverlayView(this),
      notices: new NoticeStrip(this),
      numbers: new DamageNumbers(this),
      input: new IntentController(this),
    }
  }

  /** 同步英雄、敌人与核心的渲染状态 */
  private syncUnits(views: GameViews, alpha: number): void {
    views.hero.sync(this.battle.hero, alpha)

    const seen = new Set<string>()
    for (const unit of this.battle.units) {
      seen.add(unit.id)
      let view = this.enemies.get(unit.id)
      if (!view) {
        view = new EnemyView(this, unit)
        this.enemies.set(unit.id, view)
      }
      view.sync(unit, alpha)
    }
    for (const [id, view] of this.enemies) {
      if (!seen.has(id)) {
        view.destroy()
        this.enemies.delete(id)
      }
    }

    views.core.sync(this.battle.core)
  }

  /** 把本帧事件转为表现反馈：浮字 + 提示条 */
  private consumeEvents(views: GameViews): void {
    const events = this.battle.events
    const positions = this.buildPositionLookup()
    views.numbers.play(events, (id) => positions.get(id), this.battle.config.field.core)

    for (const event of events) {
      this.pushNotice(views, event)
    }
  }

  private pushNotice(views: GameViews, event: BattleEvent): void {
    switch (event.kind) {
      case 'heroDeath':
        views.notices.push(`英雄阵亡 · ${this.battle.heroLife.reviveSeconds}s 后复活`, CSS.danger)
        break
      case 'heroRevive':
        views.notices.push('英雄复活', CSS.good)
        break
      case 'anchorStart':
        views.anchor.begin(this.battle.challenge.bossHp)
        views.notices.push(`锚点 BOSS · ${this.anchorBossName} 现身`, CSS.danger)
        break
      case 'anchorCleared':
        views.notices.push('锚点已攻克 · 按 B 渡劫突破上清', CSS.good, 6)
        break
      case 'anchorFailed':
        views.notices.push('锚点失守！', CSS.danger, 6)
        break
      case 'craft':
        views.notices.push(`合成成功：${this.deps.index.equipment.get(event.defId)?.name ?? event.defId}`, CSS.gold, 3)
        break
      case 'breakthrough':
        views.notices.push(`突破成功 · 境界晋升「${this.deps.index.rank.get(event.rank)?.name ?? event.rank}」`, CSS.gold, 4)
        break
      case 'gold':
        views.notices.push(`+${event.amount} 金币`, CSS.gold, 1.6)
        break
      default:
        break
    }
  }

  /** 本帧各单位的渲染坐标查找表（用于把伤害事件定位到目标身上） */
  private buildPositionLookup(): Map<string, Vec2> {
    const positions = new Map<string, Vec2>()
    positions.set(this.battle.hero.id, this.battle.hero.position)
    for (const unit of this.battle.units) {
      positions.set(unit.id, unit.position)
    }
    return positions
  }

  /** M1 仅有法宝线 T1→T2 一条配方；合成即装备 */
  private craftFirstAvailable(): void {
    const recipe = this.firstRecipe()
    if (this.battle.canCraft(recipe)) {
      this.battle.craftAndEquip(recipe)
    }
  }

  private firstRecipe(): RecipeDef {
    const recipe = this.deps.data.recipes[0]
    if (!recipe) {
      throw new Error('表现层：配置缺少合成配方')
    }
    return recipe
  }
}
