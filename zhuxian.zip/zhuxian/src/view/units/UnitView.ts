import type Phaser from 'phaser'

import type { Unit } from '../../logic/battle/unit'
import { CELL_PX } from '../theme'
import { HealthBar } from './HealthBar'

/** 单帧位移超过该像素视为瞬移（复活 / 传送），直接落位而不插值滑行 */
const SNAP_DISTANCE_PX = CELL_PX * 3

export interface UnitViewOptions {
  /** 血条宽度（像素） */
  barWidth: number
  /** 血条相对单位中心的纵向偏移（像素，负值在上方） */
  barOffsetY: number
  depth: number
}

/**
 * 战场单位的通用视图骨架：位置插值 + 气血条 + 阵亡淡出。
 *
 * 形体交由子类 `buildBody` 决定；`sync` 用固定步长余量 `alpha` 在上一帧与当前帧位置间插值，
 * 使渲染与逻辑解耦后仍保持平滑。
 */
export abstract class UnitView {
  readonly id: string
  protected readonly scene: Phaser.Scene
  protected readonly container: Phaser.GameObjects.Container
  protected readonly bar: HealthBar

  private prevX = 0
  private prevY = 0
  private placed = false

  constructor(scene: Phaser.Scene, unit: Unit, options: UnitViewOptions) {
    this.scene = scene
    this.id = unit.id
    // 调用子类形体工厂：此时仅 `scene` 可用（子类字段尚未初始化），故工厂只依赖 scene
    this.container = scene.add.container(0, 0, this.buildBody(unit))
    this.container.setDepth(options.depth)
    this.bar = new HealthBar(scene, 0, options.barOffsetY, { width: options.barWidth })
    this.container.add(this.bar.group)
  }

  /** 子类构造形体（仅可使用 `this.scene`） */
  protected abstract buildBody(unit: Unit): Phaser.GameObjects.GameObject[]

  /** 每渲染帧同步单位状态；`alpha` 为固定步长余量比例（位置插值用） */
  sync(unit: Unit, alpha: number): void {
    const px = unit.position.x * CELL_PX
    const py = unit.position.y * CELL_PX

    // 阵亡时冻结并标记待重定位：复活 / 出场即瞬移落位，避免长距离滑行
    if (!unit.alive) {
      this.placed = false
    }
    if (!this.placed || Math.hypot(px - this.prevX, py - this.prevY) > SNAP_DISTANCE_PX) {
      this.prevX = px
      this.prevY = py
      this.placed = true
    }

    this.container.setPosition(
      this.prevX + (px - this.prevX) * alpha,
      this.prevY + (py - this.prevY) * alpha,
    )
    this.prevX = px
    this.prevY = py

    this.bar.setRatio(unit.maxHp > 0 ? unit.hp / unit.maxHp : 0)
    this.container.setAlpha(unit.alive ? 1 : 0.3)
    this.applyState(unit)
  }

  /** 子类按状态调整额外表现（朝向 / 附属条等） */
  protected applyState(_unit: Unit): void {}

  destroy(): void {
    this.container.destroy(true)
  }
}
