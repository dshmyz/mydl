import type Phaser from 'phaser'

import type { Unit } from '../../logic/battle/unit'
import { PALETTE } from '../theme'
import { HealthBar } from './HealthBar'
import { UnitView } from './UnitView'

/** 英雄本体半径（像素） */
const BODY_RADIUS = 13

/**
 * 英雄视图：圆形本体 + 朝向指针 + 气血 / 真气双条；阵亡时整体淡出。
 */
export class HeroView extends UnitView {
  private readonly mpBar: HealthBar
  private readonly pointer: Phaser.GameObjects.Rectangle

  constructor(scene: Phaser.Scene, unit: Unit) {
    super(scene, unit, { barWidth: 40, barOffsetY: -26, depth: 22 })

    // 朝向指针：右锚定于本体边缘，随 `facing` 旋转
    this.pointer = scene.add
      .rectangle(BODY_RADIUS - 2, 0, 12, 5, PALETTE.heroEdge)
      .setOrigin(0, 0.5)
    this.container.add(this.pointer)

    this.mpBar = new HealthBar(scene, 0, -20, {
      width: 40,
      fill: PALETTE.mpFill,
      lowFill: PALETTE.mpFill,
    })
    this.container.add(this.mpBar.group)
  }

  protected buildBody(_unit: Unit): Phaser.GameObjects.GameObject[] {
    const body = this.scene.add
      .circle(0, 0, BODY_RADIUS, PALETTE.hero)
      .setStrokeStyle(2, PALETTE.heroEdge, 1)
    const core = this.scene.add.circle(0, 0, BODY_RADIUS - 6, PALETTE.heroCore)
    return [body, core]
  }

  protected override applyState(unit: Unit): void {
    this.pointer.setRotation(Math.atan2(unit.facing.y, unit.facing.x))
    this.mpBar.setRatio(unit.skillState.maxMp > 0 ? unit.skillState.mp / unit.skillState.maxMp : 0)
  }
}
