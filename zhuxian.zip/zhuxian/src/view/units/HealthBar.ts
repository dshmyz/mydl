import type Phaser from 'phaser'

import { PALETTE } from '../theme'

export interface HealthBarOptions {
  /** 条宽（像素） */
  width: number
  /** 填充高（像素）；背景自动留 2px 边框感 */
  height?: number
  /** 常规填充色 */
  fill?: number
  /** 告急填充色（比例 ≤ `lowRatio` 时） */
  lowFill?: number
  /** 触发告急色的比例阈值 */
  lowRatio?: number
}

/**
 * 可复用的数值条：背景 + 左锚定填充，按比例横向收缩。
 *
 * 通过 `group` 挂到单位容器内即可随单位移动；供气血 / 真气 / 核心耐久复用，
 * 避免每种条各写一套绘制逻辑。
 */
export class HealthBar {
  readonly group: Phaser.GameObjects.Container

  private readonly fill: Phaser.GameObjects.Rectangle
  private readonly fillColor: number
  private readonly lowFill: number
  private readonly lowRatio: number

  constructor(scene: Phaser.Scene, x: number, y: number, options: HealthBarOptions) {
    this.fillColor = options.fill ?? PALETTE.hpFill
    this.lowFill = options.lowFill ?? PALETTE.hpLow
    this.lowRatio = options.lowRatio ?? 0.3

    const height = options.height ?? 4
    const width = options.width
    const back = scene.add.rectangle(0, 0, width, height + 2, PALETTE.hpBack).setOrigin(0, 0.5)
    this.fill = scene.add.rectangle(0, 0, width, height, this.fillColor).setOrigin(0, 0.5)
    this.group = scene.add.container(x, y, [back, this.fill])
  }

  /** 设置填充比例（自动钳到 [0,1]；非法值按 0 处理） */
  setRatio(ratio: number): void {
    const clamped = Math.min(1, Math.max(0, Number.isFinite(ratio) ? ratio : 0))
    this.fill.setScale(clamped, 1)
    this.fill.setFillStyle(clamped <= this.lowRatio ? this.lowFill : this.fillColor)
  }

  setVisible(visible: boolean): void {
    this.group.setVisible(visible)
  }

  destroy(): void {
    this.group.destroy(true)
  }
}
