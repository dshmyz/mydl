import type Phaser from 'phaser'

import type { Unit } from '../../logic/battle/unit'
import { PALETTE, textStyle } from '../theme'
import { UnitView } from './UnitView'

/**
 * 敌人视图：按档位（小怪 / 精英 / BOSS）区分体型与配色，BOSS 附带名称标签。
 */
export class EnemyView extends UnitView {
  constructor(scene: Phaser.Scene, unit: Unit) {
    super(scene, unit, {
      barWidth: unit.isBoss ? 60 : unit.isElite ? 34 : 22,
      barOffsetY: unit.isBoss ? -30 : unit.isElite ? -18 : -14,
      depth: unit.isBoss ? 26 : 20,
    })
  }

  protected buildBody(unit: Unit): Phaser.GameObjects.GameObject[] {
    const radius = unit.isBoss ? 17 : unit.isElite ? 11 : 8
    const fill = unit.isBoss ? PALETTE.boss : unit.isElite ? PALETTE.elite : PALETTE.minion
    const body = this.scene.add.circle(0, 0, radius, fill)

    if (unit.isBoss) {
      body.setStrokeStyle(3, PALETTE.bossEdge, 1)
      const label = this.scene.add
        .text(0, -radius - 20, unit.name, textStyle(11, '#ffcec6'))
        .setOrigin(0.5, 1)
      return [body, label]
    }

    body.setStrokeStyle(unit.isElite ? 2 : 1, unit.isElite ? PALETTE.eliteEdge : 0x000000, unit.isElite ? 0.9 : 0.25)
    return [body]
  }
}
