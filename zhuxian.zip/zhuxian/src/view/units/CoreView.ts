import type Phaser from 'phaser'

import type { CoreTarget } from '../../logic/objective/coreTarget'
import { DEPTH, PALETTE, gridToPixel, textStyle } from '../theme'
import { HealthBar } from './HealthBar'

/** 核心底座尺寸（像素） */
const PEDESTAL_W = 52
const PEDESTAL_H = 74

/**
 * 剑阵核心视图：底座 + 阵眼 + 耐久条与数值。
 *
 * 与 `UnitView` 分开：核心不是移动单位、也无朝向 / 阵亡语义，单独绘制更直白。
 */
export class CoreView {
  private readonly bar: HealthBar
  private readonly hpText: Phaser.GameObjects.Text

  constructor(scene: Phaser.Scene, corePosition: { x: number; y: number }) {
    const at = gridToPixel(corePosition)

    scene.add
      .rectangle(at.x, at.y, PEDESTAL_W, PEDESTAL_H, PALETTE.bar)
      .setStrokeStyle(2, PALETTE.coreRing, 0.8)
      .setDepth(DEPTH.field)
    scene.add
      .rectangle(at.x, at.y - 6, 22, 22, PALETTE.core)
      .setAngle(45)
      .setStrokeStyle(2, PALETTE.coreEdge, 1)
      .setDepth(DEPTH.core)
    scene.add
      .text(at.x, at.y - PEDESTAL_H / 2 - 10, '剑阵核心', textStyle(11, '#9fc2ff'))
      .setOrigin(0.5, 1)
      .setDepth(DEPTH.core)

    this.bar = new HealthBar(scene, at.x - 45, at.y - PEDESTAL_H / 2 - 26, {
      width: 90,
      height: 7,
      lowRatio: 0.35,
    })
    this.hpText = scene.add
      .text(at.x, at.y + PEDESTAL_H / 2 + 8, '', textStyle(10, '#9fc2ff'))
      .setOrigin(0.5, 0)
      .setDepth(DEPTH.core)
  }

  sync(core: CoreTarget): void {
    this.bar.setRatio(core.maxHp > 0 ? core.hp / core.maxHp : 0)
    this.hpText.setText(`${Math.ceil(core.hp)} / ${core.maxHp}`)
  }
}
