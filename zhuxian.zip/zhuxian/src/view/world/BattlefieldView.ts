import type Phaser from 'phaser'

import type { BattleFieldConfig } from '../../logic/battle/config'
import {
  CELL_PX,
  COLS,
  DEPTH,
  PALETTE,
  ROWS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  gridToPixel,
  textStyle,
} from '../theme'

/** 主路通道的视觉宽度（格） */
const LANE_WIDTH_GRID = 2.4

/**
 * 静态战场视图：底色、网格、主路通道、出生区、核心阵位与文字标注。
 *
 * 一次性绘制，不含逐帧状态；单位与核心的动效由各自视图负责。
 */
export class BattlefieldView {
  constructor(scene: Phaser.Scene, field: BattleFieldConfig) {
    const graphics = scene.add.graphics().setDepth(DEPTH.field)

    // 战场底色
    graphics.fillStyle(PALETTE.fieldFill, 1).fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT)

    // 主路通道：妖兽出生点 → 剑阵核心
    const spawn = gridToPixel(field.spawn)
    const core = gridToPixel(field.core)
    const laneTop = (field.spawn.y - LANE_WIDTH_GRID / 2) * CELL_PX
    graphics
      .fillStyle(PALETTE.laneBand, 0.9)
      .fillRect(core.x, laneTop, spawn.x - core.x, LANE_WIDTH_GRID * CELL_PX)

    // 网格
    graphics.lineStyle(1, PALETTE.gridLine, 0.55)
    for (let col = 0; col <= COLS; col += 1) {
      graphics.lineBetween(col * CELL_PX, 0, col * CELL_PX, WORLD_HEIGHT)
    }
    for (let row = 0; row <= ROWS; row += 1) {
      graphics.lineBetween(0, row * CELL_PX, WORLD_WIDTH, row * CELL_PX)
    }

    // 妖兽出生区
    const spawnZone = scene.add
      .circle(spawn.x, spawn.y, LANE_WIDTH_GRID * CELL_PX, PALETTE.spawnZone, 0.35)
      .setStrokeStyle(2, PALETTE.spawnEdge, 0.6)
      .setDepth(DEPTH.field)
    scene.add
      .text(spawn.x, spawnZone.y - LANE_WIDTH_GRID * CELL_PX - 6, '妖兽出生地', textStyle(12, '#ffb0a6'))
      .setOrigin(0.5, 1)
      .setDepth(DEPTH.field)

    // 核心阵位（本体由 CoreView 绘制，此处只画一圈阵法）
    scene.add
      .circle(core.x, core.y, LANE_WIDTH_GRID * CELL_PX, PALETTE.coreRing, 0.12)
      .setStrokeStyle(2, PALETTE.coreRing, 0.5)
      .setDepth(DEPTH.field)
  }
}
