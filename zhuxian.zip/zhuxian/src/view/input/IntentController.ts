import Phaser from 'phaser'

import type { SkillKey } from '../../data/types/common'
import type { HeroIntent } from '../../logic/battle/battle'

/**
 * 键盘操作读数：方向键移动，Q/W/E/R 释放技能，B 突破，C 合成。
 *
 * 只用方向键做移动（不用 WASD），避免与技能键 W 冲突。技能与动作键按「本帧首次按下」
 * 边沿触发，保证一次按键只释放一次。
 */
export class IntentController {
  private readonly up: Phaser.Input.Keyboard.Key
  private readonly down: Phaser.Input.Keyboard.Key
  private readonly left: Phaser.Input.Keyboard.Key
  private readonly right: Phaser.Input.Keyboard.Key
  private readonly skillKeys: ReadonlyArray<readonly [SkillKey, Phaser.Input.Keyboard.Key]>
  private readonly breakthroughKey: Phaser.Input.Keyboard.Key
  private readonly craftKey: Phaser.Input.Keyboard.Key

  constructor(scene: Phaser.Scene) {
    const keyboard = scene.input.keyboard
    if (!keyboard) {
      throw new Error('表现层：键盘输入插件不可用，请确认 Phaser 已启用键盘输入')
    }
    const codes = Phaser.Input.Keyboard.KeyCodes
    this.up = keyboard.addKey(codes.UP)
    this.down = keyboard.addKey(codes.DOWN)
    this.left = keyboard.addKey(codes.LEFT)
    this.right = keyboard.addKey(codes.RIGHT)
    this.skillKeys = [
      ['Q', keyboard.addKey(codes.Q)],
      ['W', keyboard.addKey(codes.W)],
      ['E', keyboard.addKey(codes.E)],
      ['R', keyboard.addKey(codes.R)],
    ]
    this.breakthroughKey = keyboard.addKey(codes.B)
    this.craftKey = keyboard.addKey(codes.C)
  }

  /** 读取本帧英雄意图（移动 + 一次技能释放） */
  readIntent(): HeroIntent {
    const intent: HeroIntent = {}
    const x = (this.right.isDown ? 1 : 0) - (this.left.isDown ? 1 : 0)
    const y = (this.down.isDown ? 1 : 0) - (this.up.isDown ? 1 : 0)
    if (x !== 0 || y !== 0) {
      intent.moveDir = { x, y }
    }
    const cast = this.firstJustDown()
    if (cast) {
      intent.cast = cast
    }
    return intent
  }

  /** 本帧是否按下突破键 */
  consumeBreakthrough(): boolean {
    return Phaser.Input.Keyboard.JustDown(this.breakthroughKey)
  }

  /** 本帧是否按下合成键 */
  consumeCraft(): boolean {
    return Phaser.Input.Keyboard.JustDown(this.craftKey)
  }

  private firstJustDown(): SkillKey | null {
    for (const [key, input] of this.skillKeys) {
      if (Phaser.Input.Keyboard.JustDown(input)) {
        return key
      }
    }
    return null
  }
}
