--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]

local ____modules = {}
local ____moduleCache = {}
local ____originalRequire = require
local function require(file, ...)
    if ____moduleCache[file] then
        return ____moduleCache[file].value
    end
    if ____modules[file] then
        local module = ____modules[file]
        local value = nil
        if (select("#", ...) > 0) then value = module(...) else value = module(file) end
        ____moduleCache[file] = { value = value }
        return value
    else
        if ____originalRequire then
            return ____originalRequire(file)
        else
            error("module '" .. file .. "' not found")
        end
    end
end
____modules = {
["lualib_bundle"] = function(...) 
local function __TS__ArrayAt(self, relativeIndex)
    local absoluteIndex = relativeIndex < 0 and #self + relativeIndex or relativeIndex
    if absoluteIndex >= 0 and absoluteIndex < #self then
        return self[absoluteIndex + 1]
    end
    return nil
end

local function __TS__ArrayIsArray(value)
    return type(value) == "table" and (value[1] ~= nil or next(value) == nil)
end

local function __TS__ArrayConcat(self, ...)
    local items = {...}
    local result = {}
    local len = 0
    for i = 1, #self do
        len = len + 1
        result[len] = self[i]
    end
    for i = 1, #items do
        local item = items[i]
        if __TS__ArrayIsArray(item) then
            for j = 1, #item do
                len = len + 1
                result[len] = item[j]
            end
        else
            len = len + 1
            result[len] = item
        end
    end
    return result
end

local __TS__Symbol, Symbol
do
    local symbolMetatable = {__tostring = function(self)
        return ("Symbol(" .. (self.description or "")) .. ")"
    end}
    function __TS__Symbol(description)
        return setmetatable({description = description}, symbolMetatable)
    end
    Symbol = {
        asyncDispose = __TS__Symbol("Symbol.asyncDispose"),
        dispose = __TS__Symbol("Symbol.dispose"),
        iterator = __TS__Symbol("Symbol.iterator"),
        hasInstance = __TS__Symbol("Symbol.hasInstance"),
        species = __TS__Symbol("Symbol.species"),
        toStringTag = __TS__Symbol("Symbol.toStringTag")
    }
end

local function __TS__ArrayEntries(array)
    local key = 0
    return {
        [Symbol.iterator] = function(self)
            return self
        end,
        next = function(self)
            local result = {done = array[key + 1] == nil, value = {key, array[key + 1]}}
            key = key + 1
            return result
        end
    }
end

local function __TS__ArrayEvery(self, callbackfn, thisArg)
    for i = 1, #self do
        if not callbackfn(thisArg, self[i], i - 1, self) then
            return false
        end
    end
    return true
end

local function __TS__ArrayFill(self, value, start, ____end)
    local relativeStart = start or 0
    local relativeEnd = ____end or #self
    if relativeStart < 0 then
        relativeStart = relativeStart + #self
    end
    if relativeEnd < 0 then
        relativeEnd = relativeEnd + #self
    end
    do
        local i = relativeStart
        while i < relativeEnd do
            self[i + 1] = value
            i = i + 1
        end
    end
    return self
end

local function __TS__ArrayFilter(self, callbackfn, thisArg)
    local result = {}
    local len = 0
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            len = len + 1
            result[len] = self[i]
        end
    end
    return result
end

local function __TS__ArrayForEach(self, callbackFn, thisArg)
    for i = 1, #self do
        callbackFn(thisArg, self[i], i - 1, self)
    end
end

local function __TS__ArrayFind(self, predicate, thisArg)
    for i = 1, #self do
        local elem = self[i]
        if predicate(thisArg, elem, i - 1, self) then
            return elem
        end
    end
    return nil
end

local function __TS__ArrayFindIndex(self, callbackFn, thisArg)
    for i = 1, #self do
        if callbackFn(thisArg, self[i], i - 1, self) then
            return i - 1
        end
    end
    return -1
end

local __TS__Iterator
do
    local function iteratorGeneratorStep(self)
        local co = self.____coroutine
        local status, value = coroutine.resume(co)
        if not status then
            error(value, 0)
        end
        if coroutine.status(co) == "dead" then
            return
        end
        return true, value
    end
    local function iteratorIteratorStep(self)
        local result = self:next()
        if result.done then
            return
        end
        return true, result.value
    end
    local function iteratorStringStep(self, index)
        index = index + 1
        if index > #self then
            return
        end
        return index, string.sub(self, index, index)
    end
    function __TS__Iterator(iterable)
        if type(iterable) == "string" then
            return iteratorStringStep, iterable, 0
        elseif iterable.____coroutine ~= nil then
            return iteratorGeneratorStep, iterable
        elseif iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            return iteratorIteratorStep, iterator
        else
            return ipairs(iterable)
        end
    end
end

local __TS__ArrayFrom
do
    local function arrayLikeStep(self, index)
        index = index + 1
        if index > self.length then
            return
        end
        return index, self[index]
    end
    local function arrayLikeIterator(arr)
        if type(arr.length) == "number" then
            return arrayLikeStep, arr, 0
        end
        return __TS__Iterator(arr)
    end
    function __TS__ArrayFrom(arrayLike, mapFn, thisArg)
        local result = {}
        if mapFn == nil then
            for ____, v in arrayLikeIterator(arrayLike) do
                result[#result + 1] = v
            end
        else
            local i = 0
            for ____, v in arrayLikeIterator(arrayLike) do
                local ____mapFn_3 = mapFn
                local ____thisArg_1 = thisArg
                local ____v_2 = v
                local ____i_0 = i
                i = ____i_0 + 1
                result[#result + 1] = ____mapFn_3(____thisArg_1, ____v_2, ____i_0)
            end
        end
        return result
    end
end

local function __TS__ArrayIncludes(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    local k = fromIndex
    if fromIndex < 0 then
        k = len + fromIndex
    end
    if k < 0 then
        k = 0
    end
    for i = k + 1, len do
        if self[i] == searchElement then
            return true
        end
    end
    return false
end

local function __TS__ArrayIndexOf(self, searchElement, fromIndex)
    if fromIndex == nil then
        fromIndex = 0
    end
    local len = #self
    if len == 0 then
        return -1
    end
    if fromIndex >= len then
        return -1
    end
    if fromIndex < 0 then
        fromIndex = len + fromIndex
        if fromIndex < 0 then
            fromIndex = 0
        end
    end
    for i = fromIndex + 1, len do
        if self[i] == searchElement then
            return i - 1
        end
    end
    return -1
end

local function __TS__ArrayJoin(self, separator)
    if separator == nil then
        separator = ","
    end
    local parts = {}
    for i = 1, #self do
        parts[i] = tostring(self[i])
    end
    return table.concat(parts, separator)
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__ArrayPush(self, ...)
    local items = {...}
    local len = #self
    for i = 1, #items do
        len = len + 1
        self[len] = items[i]
    end
    return len
end

local function __TS__ArrayPushArray(self, items)
    local len = #self
    for i = 1, #items do
        len = len + 1
        self[len] = items[i]
    end
    return len
end

local function __TS__CountVarargs(...)
    return select("#", ...)
end

local function __TS__ArrayReduce(self, callbackFn, ...)
    local len = #self
    local k = 0
    local accumulator = nil
    if __TS__CountVarargs(...) ~= 0 then
        accumulator = ...
    elseif len > 0 then
        accumulator = self[1]
        k = 1
    else
        error("Reduce of empty array with no initial value", 0)
    end
    for i = k + 1, len do
        accumulator = callbackFn(
            nil,
            accumulator,
            self[i],
            i - 1,
            self
        )
    end
    return accumulator
end

local function __TS__ArrayReduceRight(self, callbackFn, ...)
    local len = #self
    local k = len - 1
    local accumulator = nil
    if __TS__CountVarargs(...) ~= 0 then
        accumulator = ...
    elseif len > 0 then
        accumulator = self[k + 1]
        k = k - 1
    else
        error("Reduce of empty array with no initial value", 0)
    end
    for i = k + 1, 1, -1 do
        accumulator = callbackFn(
            nil,
            accumulator,
            self[i],
            i - 1,
            self
        )
    end
    return accumulator
end

local function __TS__ArrayReverse(self)
    local i = 1
    local j = #self
    while i < j do
        local temp = self[j]
        self[j] = self[i]
        self[i] = temp
        i = i + 1
        j = j - 1
    end
    return self
end

local function __TS__ArrayUnshift(self, ...)
    local items = {...}
    local numItemsToInsert = #items
    if numItemsToInsert == 0 then
        return #self
    end
    for i = #self, 1, -1 do
        self[i + numItemsToInsert] = self[i]
    end
    for i = 1, numItemsToInsert do
        self[i] = items[i]
    end
    return #self
end

local function __TS__ArraySort(self, compareFn)
    if compareFn ~= nil then
        table.sort(
            self,
            function(a, b) return compareFn(nil, a, b) < 0 end
        )
    else
        table.sort(self)
    end
    return self
end

local function __TS__ArraySlice(self, first, last)
    local len = #self
    first = first or 0
    if first < 0 then
        first = len + first
        if first < 0 then
            first = 0
        end
    else
        if first > len then
            first = len
        end
    end
    last = last or len
    if last < 0 then
        last = len + last
        if last < 0 then
            last = 0
        end
    else
        if last > len then
            last = len
        end
    end
    local out = {}
    first = first + 1
    last = last + 1
    local n = 1
    while first < last do
        out[n] = self[first]
        first = first + 1
        n = n + 1
    end
    return out
end

local function __TS__ArraySome(self, callbackfn, thisArg)
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            return true
        end
    end
    return false
end

local function __TS__ArraySplice(self, ...)
    local args = {...}
    local len = #self
    local actualArgumentCount = __TS__CountVarargs(...)
    local start = args[1]
    local deleteCount = args[2]
    if start < 0 then
        start = len + start
        if start < 0 then
            start = 0
        end
    elseif start > len then
        start = len
    end
    local itemCount = actualArgumentCount - 2
    if itemCount < 0 then
        itemCount = 0
    end
    local actualDeleteCount
    if actualArgumentCount == 0 then
        actualDeleteCount = 0
    elseif actualArgumentCount == 1 then
        actualDeleteCount = len - start
    else
        actualDeleteCount = deleteCount or 0
        if actualDeleteCount < 0 then
            actualDeleteCount = 0
        end
        if actualDeleteCount > len - start then
            actualDeleteCount = len - start
        end
    end
    local out = {}
    for k = 1, actualDeleteCount do
        local from = start + k
        if self[from] ~= nil then
            out[k] = self[from]
        end
    end
    if itemCount < actualDeleteCount then
        for k = start + 1, len - actualDeleteCount do
            local from = k + actualDeleteCount
            local to = k + itemCount
            if self[from] then
                self[to] = self[from]
            else
                self[to] = nil
            end
        end
        for k = len - actualDeleteCount + itemCount + 1, len do
            self[k] = nil
        end
    elseif itemCount > actualDeleteCount then
        for k = len - actualDeleteCount, start + 1, -1 do
            local from = k + actualDeleteCount
            local to = k + itemCount
            if self[from] then
                self[to] = self[from]
            else
                self[to] = nil
            end
        end
    end
    local j = start + 1
    for i = 3, actualArgumentCount do
        self[j] = args[i]
        j = j + 1
    end
    for k = #self, len - actualDeleteCount + itemCount + 1, -1 do
        self[k] = nil
    end
    return out
end

local function __TS__ArrayToObject(self)
    local object = {}
    for i = 1, #self do
        object[i - 1] = self[i]
    end
    return object
end

local function __TS__ArrayFlat(self, depth)
    if depth == nil then
        depth = 1
    end
    local result = {}
    local len = 0
    for i = 1, #self do
        local value = self[i]
        if depth > 0 and __TS__ArrayIsArray(value) then
            local toAdd
            if depth == 1 then
                toAdd = value
            else
                toAdd = __TS__ArrayFlat(value, depth - 1)
            end
            for j = 1, #toAdd do
                local val = toAdd[j]
                len = len + 1
                result[len] = val
            end
        else
            len = len + 1
            result[len] = value
        end
    end
    return result
end

local function __TS__ArrayFlatMap(self, callback, thisArg)
    local result = {}
    local len = 0
    for i = 1, #self do
        local value = callback(thisArg, self[i], i - 1, self)
        if __TS__ArrayIsArray(value) then
            for j = 1, #value do
                len = len + 1
                result[len] = value[j]
            end
        else
            len = len + 1
            result[len] = value
        end
    end
    return result
end

local function __TS__ArraySetLength(self, length)
    if length < 0 or length ~= length or length == math.huge or math.floor(length) ~= length then
        error(
            "invalid array length: " .. tostring(length),
            0
        )
    end
    for i = length + 1, #self do
        self[i] = nil
    end
    return length
end

local __TS__Unpack = table.unpack or unpack

local function __TS__ArrayToReversed(self)
    local copy = {__TS__Unpack(self)}
    __TS__ArrayReverse(copy)
    return copy
end

local function __TS__ArrayToSorted(self, compareFn)
    local copy = {__TS__Unpack(self)}
    __TS__ArraySort(copy, compareFn)
    return copy
end

local function __TS__ArrayToSpliced(self, start, deleteCount, ...)
    local copy = {__TS__Unpack(self)}
    __TS__ArraySplice(copy, start, deleteCount, ...)
    return copy
end

local function __TS__ArrayWith(self, index, value)
    local copy = {__TS__Unpack(self)}
    copy[index + 1] = value
    return copy
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__InstanceOf(obj, classTbl)
    if type(classTbl) ~= "table" then
        error("Right-hand side of 'instanceof' is not an object", 0)
    end
    if classTbl[Symbol.hasInstance] ~= nil then
        return not not classTbl[Symbol.hasInstance](classTbl, obj)
    end
    if type(obj) == "table" then
        local luaClass = obj.constructor
        while luaClass ~= nil do
            if luaClass == classTbl then
                return true
            end
            luaClass = luaClass.____super
        end
    end
    return false
end

local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local __TS__Promise
do
    local function makeDeferredPromiseFactory()
        local resolve
        local reject
        local function executor(____, res, rej)
            resolve = res
            reject = rej
        end
        return function()
            local promise = __TS__New(__TS__Promise, executor)
            return promise, resolve, reject
        end
    end
    local makeDeferredPromise = makeDeferredPromiseFactory()
    local function isPromiseLike(value)
        return __TS__InstanceOf(value, __TS__Promise)
    end
    local function doNothing(self)
    end
    local ____pcall = _G.pcall
    __TS__Promise = __TS__Class()
    __TS__Promise.name = "__TS__Promise"
    function __TS__Promise.prototype.____constructor(self, executor)
        self.state = 0
        self.fulfilledCallbacks = {}
        self.rejectedCallbacks = {}
        self.finallyCallbacks = {}
        local success, ____error = ____pcall(
            executor,
            nil,
            function(____, v) return self:resolve(v) end,
            function(____, err) return self:reject(err) end
        )
        if not success then
            self:reject(____error)
        end
    end
    function __TS__Promise.resolve(value)
        if __TS__InstanceOf(value, __TS__Promise) then
            return value
        end
        local promise = __TS__New(__TS__Promise, doNothing)
        promise.state = 1
        promise.value = value
        return promise
    end
    function __TS__Promise.reject(reason)
        local promise = __TS__New(__TS__Promise, doNothing)
        promise.state = 2
        promise.rejectionReason = reason
        return promise
    end
    __TS__Promise.prototype["then"] = function(self, onFulfilled, onRejected)
        local promise, resolve, reject = makeDeferredPromise()
        self:addCallbacks(
            onFulfilled and self:createPromiseResolvingCallback(onFulfilled, resolve, reject) or resolve,
            onRejected and self:createPromiseResolvingCallback(onRejected, resolve, reject) or reject
        )
        return promise
    end
    function __TS__Promise.prototype.addCallbacks(self, fulfilledCallback, rejectedCallback)
        if self.state == 1 then
            return fulfilledCallback(nil, self.value)
        end
        if self.state == 2 then
            return rejectedCallback(nil, self.rejectionReason)
        end
        local ____self_fulfilledCallbacks_0 = self.fulfilledCallbacks
        ____self_fulfilledCallbacks_0[#____self_fulfilledCallbacks_0 + 1] = fulfilledCallback
        local ____self_rejectedCallbacks_1 = self.rejectedCallbacks
        ____self_rejectedCallbacks_1[#____self_rejectedCallbacks_1 + 1] = rejectedCallback
    end
    function __TS__Promise.prototype.catch(self, onRejected)
        return self["then"](self, nil, onRejected)
    end
    function __TS__Promise.prototype.finally(self, onFinally)
        if onFinally then
            local ____self_finallyCallbacks_2 = self.finallyCallbacks
            ____self_finallyCallbacks_2[#____self_finallyCallbacks_2 + 1] = onFinally
            if self.state ~= 0 then
                onFinally(nil)
            end
        end
        return self
    end
    function __TS__Promise.prototype.resolve(self, value)
        if isPromiseLike(value) then
            return value:addCallbacks(
                function(____, v) return self:resolve(v) end,
                function(____, err) return self:reject(err) end
            )
        end
        if self.state == 0 then
            self.state = 1
            self.value = value
            return self:invokeCallbacks(self.fulfilledCallbacks, value)
        end
    end
    function __TS__Promise.prototype.reject(self, reason)
        if self.state == 0 then
            self.state = 2
            self.rejectionReason = reason
            return self:invokeCallbacks(self.rejectedCallbacks, reason)
        end
    end
    function __TS__Promise.prototype.invokeCallbacks(self, callbacks, value)
        local callbacksLength = #callbacks
        local finallyCallbacks = self.finallyCallbacks
        local finallyCallbacksLength = #finallyCallbacks
        if callbacksLength ~= 0 then
            for i = 1, callbacksLength - 1 do
                callbacks[i](callbacks, value)
            end
            if finallyCallbacksLength == 0 then
                return callbacks[callbacksLength](callbacks, value)
            end
            callbacks[callbacksLength](callbacks, value)
        end
        if finallyCallbacksLength ~= 0 then
            for i = 1, finallyCallbacksLength - 1 do
                finallyCallbacks[i](finallyCallbacks)
            end
            return finallyCallbacks[finallyCallbacksLength](finallyCallbacks)
        end
    end
    function __TS__Promise.prototype.createPromiseResolvingCallback(self, f, resolve, reject)
        return function(____, value)
            local success, resultOrError = ____pcall(f, nil, value)
            if not success then
                return reject(nil, resultOrError)
            end
            return self:handleCallbackValue(resultOrError, resolve, reject)
        end
    end
    function __TS__Promise.prototype.handleCallbackValue(self, value, resolve, reject)
        if isPromiseLike(value) then
            local nextpromise = value
            if nextpromise.state == 1 then
                return resolve(nil, nextpromise.value)
            elseif nextpromise.state == 2 then
                return reject(nil, nextpromise.rejectionReason)
            else
                return nextpromise:addCallbacks(resolve, reject)
            end
        else
            return resolve(nil, value)
        end
    end
end

local __TS__AsyncAwaiter, __TS__Await
do
    local ____coroutine = _G.coroutine or ({})
    local cocreate = ____coroutine.create
    local coresume = ____coroutine.resume
    local costatus = ____coroutine.status
    local coyield = ____coroutine.yield
    function __TS__AsyncAwaiter(generator)
        return __TS__New(
            __TS__Promise,
            function(____, resolve, reject)
                local fulfilled, step, resolved, asyncCoroutine
                function fulfilled(self, value)
                    local success, resultOrError = coresume(asyncCoroutine, value)
                    if success then
                        return step(resultOrError)
                    end
                    return reject(nil, resultOrError)
                end
                function step(result)
                    if resolved then
                        return
                    end
                    if costatus(asyncCoroutine) == "dead" then
                        return resolve(nil, result)
                    end
                    return __TS__Promise.resolve(result):addCallbacks(fulfilled, reject)
                end
                resolved = false
                asyncCoroutine = cocreate(generator)
                local success, resultOrError = coresume(
                    asyncCoroutine,
                    function(____, v)
                        resolved = true
                        return __TS__Promise.resolve(v):addCallbacks(resolve, reject)
                    end
                )
                if success then
                    return step(resultOrError)
                else
                    return reject(nil, resultOrError)
                end
            end
        )
    end
    function __TS__Await(thing)
        return coyield(thing)
    end
end

local function __TS__ClassExtends(target, base)
    target.____super = base
    local staticMetatable = setmetatable({__index = base}, base)
    setmetatable(target, staticMetatable)
    local baseMetatable = getmetatable(base)
    if baseMetatable then
        if type(baseMetatable.__index) == "function" then
            staticMetatable.__index = baseMetatable.__index
        end
        if type(baseMetatable.__newindex) == "function" then
            staticMetatable.__newindex = baseMetatable.__newindex
        end
    end
    setmetatable(target.prototype, base.prototype)
    if type(base.prototype.__index) == "function" then
        target.prototype.__index = base.prototype.__index
    end
    if type(base.prototype.__newindex) == "function" then
        target.prototype.__newindex = base.prototype.__newindex
    end
    if type(base.prototype.__tostring) == "function" then
        target.prototype.__tostring = base.prototype.__tostring
    end
end

local function __TS__CloneDescriptor(____bindingPattern0)
    local value
    local writable
    local set
    local get
    local configurable
    local enumerable
    enumerable = ____bindingPattern0.enumerable
    configurable = ____bindingPattern0.configurable
    get = ____bindingPattern0.get
    set = ____bindingPattern0.set
    writable = ____bindingPattern0.writable
    value = ____bindingPattern0.value
    local descriptor = {enumerable = enumerable == true, configurable = configurable == true}
    local hasGetterOrSetter = get ~= nil or set ~= nil
    local hasValueOrWritableAttribute = writable ~= nil or value ~= nil
    if hasGetterOrSetter and hasValueOrWritableAttribute then
        error("Invalid property descriptor. Cannot both specify accessors and a value or writable attribute.", 0)
    end
    if get or set then
        descriptor.get = get
        descriptor.set = set
    else
        descriptor.value = value
        descriptor.writable = writable == true
    end
    return descriptor
end

local function __TS__Decorate(self, originalValue, decorators, context)
    local result = originalValue
    do
        local i = #decorators
        while i >= 0 do
            local decorator = decorators[i + 1]
            if decorator ~= nil then
                local ____decorator_result_0 = decorator(self, result, context)
                if ____decorator_result_0 == nil then
                    ____decorator_result_0 = result
                end
                result = ____decorator_result_0
            end
            i = i - 1
        end
    end
    return result
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        for key in pairs(source) do
            target[key] = source[key]
        end
    end
    return target
end

local function __TS__ObjectGetOwnPropertyDescriptor(object, key)
    local metatable = getmetatable(object)
    if not metatable then
        return
    end
    if not rawget(metatable, "_descriptors") then
        return
    end
    return rawget(metatable, "_descriptors")[key]
end

local __TS__DescriptorGet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    function __TS__DescriptorGet(self, metatable, key)
        while metatable do
            local rawResult = ____rawget(metatable, key)
            if rawResult ~= nil then
                return rawResult
            end
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.get then
                        return descriptor.get(self)
                    end
                    return descriptor.value
                end
            end
            metatable = getmetatable(metatable)
        end
    end
end

local __TS__DescriptorSet
do
    local getmetatable = _G.getmetatable
    local ____rawget = _G.rawget
    local rawset = _G.rawset
    function __TS__DescriptorSet(self, metatable, key, value)
        while metatable do
            local descriptors = ____rawget(metatable, "_descriptors")
            if descriptors then
                local descriptor = descriptors[key]
                if descriptor ~= nil then
                    if descriptor.set then
                        descriptor.set(self, value)
                    else
                        if descriptor.writable == false then
                            error(
                                ((("Cannot assign to read only property '" .. key) .. "' of object '") .. tostring(self)) .. "'",
                                0
                            )
                        end
                        descriptor.value = value
                    end
                    return
                end
            end
            metatable = getmetatable(metatable)
        end
        rawset(self, key, value)
    end
end

local __TS__SetDescriptor
do
    local getmetatable = _G.getmetatable
    local function descriptorIndex(self, key)
        return __TS__DescriptorGet(
            self,
            getmetatable(self),
            key
        )
    end
    local function descriptorNewIndex(self, key, value)
        return __TS__DescriptorSet(
            self,
            getmetatable(self),
            key,
            value
        )
    end
    function __TS__SetDescriptor(target, key, desc, isPrototype)
        if isPrototype == nil then
            isPrototype = false
        end
        local ____isPrototype_0
        if isPrototype then
            ____isPrototype_0 = target
        else
            ____isPrototype_0 = getmetatable(target)
        end
        local metatable = ____isPrototype_0
        if not metatable then
            metatable = {}
            setmetatable(target, metatable)
        end
        local value = rawget(target, key)
        if value ~= nil then
            rawset(target, key, nil)
        end
        if not rawget(metatable, "_descriptors") then
            metatable._descriptors = {}
        end
        metatable._descriptors[key] = __TS__CloneDescriptor(desc)
        metatable.__index = descriptorIndex
        metatable.__newindex = descriptorNewIndex
    end
end

local function __TS__DecorateLegacy(decorators, target, key, desc)
    local result = target
    do
        local i = #decorators
        while i >= 0 do
            local decorator = decorators[i + 1]
            if decorator ~= nil then
                local oldResult = result
                if key == nil then
                    result = decorator(nil, result)
                elseif desc == true then
                    local value = rawget(target, key)
                    local descriptor = __TS__ObjectGetOwnPropertyDescriptor(target, key) or ({configurable = true, writable = true, value = value})
                    local desc = decorator(nil, target, key, descriptor) or descriptor
                    local isSimpleValue = desc.configurable == true and desc.writable == true and not desc.get and not desc.set
                    if isSimpleValue then
                        rawset(target, key, desc.value)
                    else
                        __TS__SetDescriptor(
                            target,
                            key,
                            __TS__ObjectAssign({}, descriptor, desc)
                        )
                    end
                elseif desc == false then
                    result = decorator(nil, target, key, desc)
                else
                    result = decorator(nil, target, key)
                end
                result = result or oldResult
            end
            i = i - 1
        end
    end
    return result
end

local function __TS__DecorateParam(paramIndex, decorator)
    return function(____, target, key) return decorator(nil, target, key, paramIndex) end
end

local function __TS__StringIncludes(self, searchString, position)
    if not position then
        position = 1
    else
        position = position + 1
    end
    local index = string.find(self, searchString, position, true)
    return index ~= nil
end

local Error, RangeError, ReferenceError, SyntaxError, TypeError, URIError
do
    local function getErrorStack(self, constructor)
        if debug == nil then
            return nil
        end
        local level = 1
        while true do
            local info = debug.getinfo(level, "f")
            level = level + 1
            if not info then
                level = 1
                break
            elseif info.func == constructor then
                break
            end
        end
        if __TS__StringIncludes(_VERSION, "Lua 5.0") then
            return debug.traceback(("[Level " .. tostring(level)) .. "]")
        elseif _VERSION == "Lua 5.1" then
            return string.sub(
                debug.traceback("", level),
                2
            )
        else
            return debug.traceback(nil, level)
        end
    end
    local function wrapErrorToString(self, getDescription)
        return function(self)
            local description = getDescription(self)
            local caller = debug.getinfo(3, "f")
            local isClassicLua = __TS__StringIncludes(_VERSION, "Lua 5.0")
            if isClassicLua or caller and caller.func ~= error then
                return description
            else
                return (description .. "\n") .. tostring(self.stack)
            end
        end
    end
    local function initErrorClass(self, Type, name)
        Type.name = name
        return setmetatable(
            Type,
            {__call = function(____, _self, message) return __TS__New(Type, message) end}
        )
    end
    local ____initErrorClass_1 = initErrorClass
    local ____class_0 = __TS__Class()
    ____class_0.name = ""
    function ____class_0.prototype.____constructor(self, message)
        if message == nil then
            message = ""
        end
        self.message = message
        self.name = "Error"
        self.stack = getErrorStack(nil, __TS__New)
        local metatable = getmetatable(self)
        if metatable and not metatable.__errorToStringPatched then
            metatable.__errorToStringPatched = true
            metatable.__tostring = wrapErrorToString(nil, metatable.__tostring)
        end
    end
    function ____class_0.prototype.__tostring(self)
        return self.message ~= "" and (self.name .. ": ") .. self.message or self.name
    end
    Error = ____initErrorClass_1(nil, ____class_0, "Error")
    local function createErrorClass(self, name)
        local ____initErrorClass_3 = initErrorClass
        local ____class_2 = __TS__Class()
        ____class_2.name = ____class_2.name
        __TS__ClassExtends(____class_2, Error)
        function ____class_2.prototype.____constructor(self, ...)
            ____class_2.____super.prototype.____constructor(self, ...)
            self.name = name
        end
        return ____initErrorClass_3(nil, ____class_2, name)
    end
    RangeError = createErrorClass(nil, "RangeError")
    ReferenceError = createErrorClass(nil, "ReferenceError")
    SyntaxError = createErrorClass(nil, "SyntaxError")
    TypeError = createErrorClass(nil, "TypeError")
    URIError = createErrorClass(nil, "URIError")
end

local function __TS__ObjectGetOwnPropertyDescriptors(object)
    local metatable = getmetatable(object)
    if not metatable then
        return {}
    end
    return rawget(metatable, "_descriptors") or ({})
end

local function __TS__Delete(target, key)
    local descriptors = __TS__ObjectGetOwnPropertyDescriptors(target)
    local descriptor = descriptors[key]
    if descriptor then
        if not descriptor.configurable then
            error(
                __TS__New(
                    TypeError,
                    ((("Cannot delete property " .. tostring(key)) .. " of ") .. tostring(target)) .. "."
                ),
                0
            )
        end
        descriptors[key] = nil
        return true
    end
    target[key] = nil
    return true
end

local function __TS__StringAccess(self, index)
    if index >= 0 and index < #self then
        return string.sub(self, index + 1, index + 1)
    end
end

local function __TS__DelegatedYield(iterable)
    if type(iterable) == "string" then
        for index = 0, #iterable - 1 do
            coroutine.yield(__TS__StringAccess(iterable, index))
        end
    elseif iterable.____coroutine ~= nil then
        local co = iterable.____coroutine
        while true do
            local status, value = coroutine.resume(co)
            if not status then
                error(value, 0)
            end
            if coroutine.status(co) == "dead" then
                return value
            else
                coroutine.yield(value)
            end
        end
    elseif iterable[Symbol.iterator] then
        local iterator = iterable[Symbol.iterator](iterable)
        while true do
            local result = iterator:next()
            if result.done then
                return result.value
            else
                coroutine.yield(result.value)
            end
        end
    else
        for ____, value in ipairs(iterable) do
            coroutine.yield(value)
        end
    end
end

local function __TS__FunctionBind(fn, ...)
    local boundArgs = {...}
    return function(____, ...)
        local args = {...}
        __TS__ArrayUnshift(
            args,
            __TS__Unpack(boundArgs)
        )
        return fn(__TS__Unpack(args))
    end
end

local __TS__Generator
do
    local function generatorIterator(self)
        return self
    end
    local function generatorNext(self, ...)
        local co = self.____coroutine
        if coroutine.status(co) == "dead" then
            return {done = true}
        end
        local status, value = coroutine.resume(co, ...)
        if not status then
            error(value, 0)
        end
        return {
            value = value,
            done = coroutine.status(co) == "dead"
        }
    end
    function __TS__Generator(fn)
        return function(...)
            local args = {...}
            local argsLength = __TS__CountVarargs(...)
            return {
                ____coroutine = coroutine.create(function() return fn(__TS__Unpack(args, 1, argsLength)) end),
                [Symbol.iterator] = generatorIterator,
                next = generatorNext
            }
        end
    end
end

local function __TS__InstanceOfObject(value)
    local valueType = type(value)
    return valueType == "table" or valueType == "function"
end

local function __TS__LuaIteratorSpread(self, state, firstKey)
    local results = {}
    local key, value = self(state, firstKey)
    while key do
        results[#results + 1] = {key, value}
        key, value = self(state, key)
    end
    return __TS__Unpack(results)
end

local Map
do
    Map = __TS__Class()
    Map.name = "Map"
    function Map.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "Map"
        self.items = {}
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self:set(value[1], value[2])
            end
        else
            local array = entries
            for ____, kvp in ipairs(array) do
                self:set(kvp[1], kvp[2])
            end
        end
    end
    function Map.prototype.clear(self)
        self.items = {}
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Map.prototype.delete(self, key)
        local contains = self:has(key)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[key]
            local previous = self.previousKey[key]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[key] = nil
            self.previousKey[key] = nil
        end
        self.items[key] = nil
        return contains
    end
    function Map.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, self.items[key], key, self)
        end
    end
    function Map.prototype.get(self, key)
        return self.items[key]
    end
    function Map.prototype.has(self, key)
        return self.nextKey[key] ~= nil or self.lastKey == key
    end
    function Map.prototype.set(self, key, value)
        local isNewValue = not self:has(key)
        if isNewValue then
            self.size = self.size + 1
        end
        self.items[key] = value
        if self.firstKey == nil then
            self.firstKey = key
            self.lastKey = key
        elseif isNewValue then
            self.nextKey[self.lastKey] = key
            self.previousKey[key] = self.lastKey
            self.lastKey = key
        end
        return self
    end
    Map.prototype[Symbol.iterator] = function(self)
        return self:entries()
    end
    function Map.prototype.entries(self)
        local items = self.items
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = {key, items[key]}}
                key = nextKey[key]
                return result
            end
        }
    end
    function Map.prototype.keys(self)
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = key}
                key = nextKey[key]
                return result
            end
        }
    end
    function Map.prototype.values(self)
        local items = self.items
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = items[key]}
                key = nextKey[key]
                return result
            end
        }
    end
    Map[Symbol.species] = Map
end

local function __TS__MapGroupBy(items, keySelector)
    local result = __TS__New(Map)
    local i = 0
    for ____, item in __TS__Iterator(items) do
        local key = keySelector(nil, item, i)
        if result:has(key) then
            local ____temp_0 = result:get(key)
            ____temp_0[#____temp_0 + 1] = item
        else
            result:set(key, {item})
        end
        i = i + 1
    end
    return result
end

local __TS__Match = string.match

local __TS__MathAtan2 = math.atan2 or math.atan

local __TS__MathModf = math.modf

local function __TS__NumberIsNaN(value)
    return value ~= value
end

local function __TS__MathSign(val)
    if __TS__NumberIsNaN(val) or val == 0 then
        return val
    end
    if val < 0 then
        return -1
    end
    return 1
end

local function __TS__NumberIsFinite(value)
    return type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge
end

local function __TS__MathTrunc(val)
    if not __TS__NumberIsFinite(val) or val == 0 then
        return val
    end
    return val > 0 and math.floor(val) or math.ceil(val)
end

local function __TS__Number(value)
    local valueType = type(value)
    if valueType == "number" then
        return value
    elseif valueType == "string" then
        local numberValue = tonumber(value)
        if numberValue then
            return numberValue
        end
        if value == "Infinity" then
            return math.huge
        end
        if value == "-Infinity" then
            return -math.huge
        end
        local stringWithoutSpaces = string.gsub(value, "%s", "")
        if stringWithoutSpaces == "" then
            return 0
        end
        return 0 / 0
    elseif valueType == "boolean" then
        return value and 1 or 0
    else
        return 0 / 0
    end
end

local function __TS__NumberIsInteger(value)
    return __TS__NumberIsFinite(value) and math.floor(value) == value
end

local function __TS__StringSubstring(self, start, ____end)
    if ____end ~= ____end then
        ____end = 0
    end
    if ____end ~= nil and start > ____end then
        start, ____end = ____end, start
    end
    if start >= 0 then
        start = start + 1
    else
        start = 1
    end
    if ____end ~= nil and ____end < 0 then
        ____end = 0
    end
    return string.sub(self, start, ____end)
end

local __TS__ParseInt
do
    local parseIntBasePattern = "0123456789aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTvVwWxXyYzZ"
    function __TS__ParseInt(numberString, base)
        if base == nil then
            base = 10
            local hexMatch = __TS__Match(numberString, "^%s*-?0[xX]")
            if hexMatch ~= nil then
                base = 16
                numberString = (__TS__Match(hexMatch, "-")) and "-" .. __TS__StringSubstring(numberString, #hexMatch) or __TS__StringSubstring(numberString, #hexMatch)
            end
        end
        if base < 2 or base > 36 then
            return 0 / 0
        end
        local allowedDigits = base <= 10 and __TS__StringSubstring(parseIntBasePattern, 0, base) or __TS__StringSubstring(parseIntBasePattern, 0, 10 + 2 * (base - 10))
        local pattern = ("^%s*(-?[" .. allowedDigits) .. "]*)"
        local number = tonumber((__TS__Match(numberString, pattern)), base)
        if number == nil then
            return 0 / 0
        end
        if number >= 0 then
            return math.floor(number)
        else
            return math.ceil(number)
        end
    end
end

local function __TS__ParseFloat(numberString)
    local infinityMatch = __TS__Match(numberString, "^%s*(-?Infinity)")
    if infinityMatch ~= nil then
        return __TS__StringAccess(infinityMatch, 0) == "-" and -math.huge or math.huge
    end
    local number = tonumber((__TS__Match(numberString, "^%s*(-?%d+%.?%d*)")))
    return number or 0 / 0
end

local __TS__NumberToString
do
    local radixChars = "0123456789abcdefghijklmnopqrstuvwxyz"
    function __TS__NumberToString(self, radix)
        if radix == nil or radix == 10 or self == math.huge or self == -math.huge or self ~= self then
            return tostring(self)
        end
        radix = math.floor(radix)
        if radix < 2 or radix > 36 then
            error("toString() radix argument must be between 2 and 36", 0)
        end
        local integer, fraction = __TS__MathModf(math.abs(self))
        local result = ""
        if radix == 8 then
            result = string.format("%o", integer)
        elseif radix == 16 then
            result = string.format("%x", integer)
        else
            repeat
                do
                    result = __TS__StringAccess(radixChars, integer % radix) .. result
                    integer = math.floor(integer / radix)
                end
            until not (integer ~= 0)
        end
        if fraction ~= 0 then
            result = result .. "."
            local delta = 1e-16
            repeat
                do
                    fraction = fraction * radix
                    delta = delta * radix
                    local digit = math.floor(fraction)
                    result = result .. __TS__StringAccess(radixChars, digit)
                    fraction = fraction - digit
                end
            until not (fraction >= delta)
        end
        if self < 0 then
            result = "-" .. result
        end
        return result
    end
end

local function __TS__NumberToFixed(self, fractionDigits)
    if math.abs(self) >= 1e+21 or self ~= self then
        return tostring(self)
    end
    local f = math.floor(fractionDigits or 0)
    if f < 0 or f > 99 then
        error("toFixed() digits argument must be between 0 and 99", 0)
    end
    return string.format(
        ("%." .. tostring(f)) .. "f",
        self
    )
end

local function __TS__ObjectDefineProperty(target, key, desc)
    local luaKey = type(key) == "number" and key + 1 or key
    local value = rawget(target, luaKey)
    local hasGetterOrSetter = desc.get ~= nil or desc.set ~= nil
    local descriptor
    if hasGetterOrSetter then
        if value ~= nil then
            error(
                "Cannot redefine property: " .. tostring(key),
                0
            )
        end
        descriptor = desc
    else
        local valueExists = value ~= nil
        local ____desc_set_4 = desc.set
        local ____desc_get_5 = desc.get
        local ____desc_configurable_0 = desc.configurable
        if ____desc_configurable_0 == nil then
            ____desc_configurable_0 = valueExists
        end
        local ____desc_enumerable_1 = desc.enumerable
        if ____desc_enumerable_1 == nil then
            ____desc_enumerable_1 = valueExists
        end
        local ____desc_writable_2 = desc.writable
        if ____desc_writable_2 == nil then
            ____desc_writable_2 = valueExists
        end
        local ____temp_3
        if desc.value ~= nil then
            ____temp_3 = desc.value
        else
            ____temp_3 = value
        end
        descriptor = {
            set = ____desc_set_4,
            get = ____desc_get_5,
            configurable = ____desc_configurable_0,
            enumerable = ____desc_enumerable_1,
            writable = ____desc_writable_2,
            value = ____temp_3
        }
    end
    __TS__SetDescriptor(target, luaKey, descriptor)
    return target
end

local function __TS__ObjectEntries(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = {key, obj[key]}
    end
    return result
end

local function __TS__ObjectFromEntries(entries)
    local obj = {}
    local iterable = entries
    if iterable[Symbol.iterator] then
        local iterator = iterable[Symbol.iterator](iterable)
        while true do
            local result = iterator:next()
            if result.done then
                break
            end
            local value = result.value
            obj[value[1]] = value[2]
        end
    else
        for ____, entry in ipairs(entries) do
            obj[entry[1]] = entry[2]
        end
    end
    return obj
end

local function __TS__ObjectGroupBy(items, keySelector)
    local result = {}
    local i = 0
    for ____, item in __TS__Iterator(items) do
        local key = keySelector(nil, item, i)
        if result[key] ~= nil then
            local ____result_key_0 = result[key]
            ____result_key_0[#____result_key_0 + 1] = item
        else
            result[key] = {item}
        end
        i = i + 1
    end
    return result
end

local function __TS__ObjectKeys(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = key
    end
    return result
end

local function __TS__ObjectRest(target, usedProperties)
    local result = {}
    for property in pairs(target) do
        if not usedProperties[property] then
            result[property] = target[property]
        end
    end
    return result
end

local function __TS__ObjectValues(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = obj[key]
    end
    return result
end

local function __TS__PromiseAll(iterable)
    local results = {}
    local toResolve = {}
    local numToResolve = 0
    local i = 0
    for ____, item in __TS__Iterator(iterable) do
        if __TS__InstanceOf(item, __TS__Promise) then
            if item.state == 1 then
                results[i + 1] = item.value
            elseif item.state == 2 then
                return __TS__Promise.reject(item.rejectionReason)
            else
                numToResolve = numToResolve + 1
                toResolve[i] = item
            end
        else
            results[i + 1] = item
        end
        i = i + 1
    end
    if numToResolve == 0 then
        return __TS__Promise.resolve(results)
    end
    return __TS__New(
        __TS__Promise,
        function(____, resolve, reject)
            for index, promise in pairs(toResolve) do
                promise["then"](
                    promise,
                    function(____, data)
                        results[index + 1] = data
                        numToResolve = numToResolve - 1
                        if numToResolve == 0 then
                            resolve(nil, results)
                        end
                    end,
                    function(____, reason)
                        reject(nil, reason)
                    end
                )
            end
        end
    )
end

local function __TS__PromiseAllSettled(iterable)
    local results = {}
    local toResolve = {}
    local numToResolve = 0
    local i = 0
    for ____, item in __TS__Iterator(iterable) do
        if __TS__InstanceOf(item, __TS__Promise) then
            if item.state == 1 then
                results[i + 1] = {status = "fulfilled", value = item.value}
            elseif item.state == 2 then
                results[i + 1] = {status = "rejected", reason = item.rejectionReason}
            else
                numToResolve = numToResolve + 1
                toResolve[i] = item
            end
        else
            results[i + 1] = {status = "fulfilled", value = item}
        end
        i = i + 1
    end
    if numToResolve == 0 then
        return __TS__Promise.resolve(results)
    end
    return __TS__New(
        __TS__Promise,
        function(____, resolve)
            for index, promise in pairs(toResolve) do
                promise["then"](
                    promise,
                    function(____, data)
                        results[index + 1] = {status = "fulfilled", value = data}
                        numToResolve = numToResolve - 1
                        if numToResolve == 0 then
                            resolve(nil, results)
                        end
                    end,
                    function(____, reason)
                        results[index + 1] = {status = "rejected", reason = reason}
                        numToResolve = numToResolve - 1
                        if numToResolve == 0 then
                            resolve(nil, results)
                        end
                    end
                )
            end
        end
    )
end

local function __TS__PromiseAny(iterable)
    local rejections = {}
    local pending = {}
    for ____, item in __TS__Iterator(iterable) do
        if __TS__InstanceOf(item, __TS__Promise) then
            if item.state == 1 then
                return __TS__Promise.resolve(item.value)
            elseif item.state == 2 then
                rejections[#rejections + 1] = item.rejectionReason
            else
                pending[#pending + 1] = item
            end
        else
            return __TS__Promise.resolve(item)
        end
    end
    if #pending == 0 then
        return __TS__Promise.reject("No promises to resolve with .any()")
    end
    local numResolved = 0
    return __TS__New(
        __TS__Promise,
        function(____, resolve, reject)
            for ____, promise in ipairs(pending) do
                promise["then"](
                    promise,
                    function(____, data)
                        resolve(nil, data)
                    end,
                    function(____, reason)
                        rejections[#rejections + 1] = reason
                        numResolved = numResolved + 1
                        if numResolved == #pending then
                            reject(nil, {name = "AggregateError", message = "All Promises rejected", errors = rejections})
                        end
                    end
                )
            end
        end
    )
end

local function __TS__PromiseRace(iterable)
    local pending = {}
    for ____, item in __TS__Iterator(iterable) do
        if __TS__InstanceOf(item, __TS__Promise) then
            if item.state == 1 then
                return __TS__Promise.resolve(item.value)
            elseif item.state == 2 then
                return __TS__Promise.reject(item.rejectionReason)
            else
                pending[#pending + 1] = item
            end
        else
            return __TS__Promise.resolve(item)
        end
    end
    return __TS__New(
        __TS__Promise,
        function(____, resolve, reject)
            for ____, promise in ipairs(pending) do
                promise["then"](
                    promise,
                    function(____, value) return resolve(nil, value) end,
                    function(____, reason) return reject(nil, reason) end
                )
            end
        end
    )
end

local Set
do
    Set = __TS__Class()
    Set.name = "Set"
    function Set.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "Set"
        self.size = 0
        self.nextKey = {}
        self.previousKey = {}
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self:add(result.value)
            end
        else
            local array = values
            for ____, value in ipairs(array) do
                self:add(value)
            end
        end
    end
    function Set.prototype.add(self, value)
        local isNewValue = not self:has(value)
        if isNewValue then
            self.size = self.size + 1
        end
        if self.firstKey == nil then
            self.firstKey = value
            self.lastKey = value
        elseif isNewValue then
            self.nextKey[self.lastKey] = value
            self.previousKey[value] = self.lastKey
            self.lastKey = value
        end
        return self
    end
    function Set.prototype.clear(self)
        self.nextKey = {}
        self.previousKey = {}
        self.firstKey = nil
        self.lastKey = nil
        self.size = 0
    end
    function Set.prototype.delete(self, value)
        local contains = self:has(value)
        if contains then
            self.size = self.size - 1
            local next = self.nextKey[value]
            local previous = self.previousKey[value]
            if next ~= nil and previous ~= nil then
                self.nextKey[previous] = next
                self.previousKey[next] = previous
            elseif next ~= nil then
                self.firstKey = next
                self.previousKey[next] = nil
            elseif previous ~= nil then
                self.lastKey = previous
                self.nextKey[previous] = nil
            else
                self.firstKey = nil
                self.lastKey = nil
            end
            self.nextKey[value] = nil
            self.previousKey[value] = nil
        end
        return contains
    end
    function Set.prototype.forEach(self, callback)
        for ____, key in __TS__Iterator(self:keys()) do
            callback(nil, key, key, self)
        end
    end
    function Set.prototype.has(self, value)
        return self.nextKey[value] ~= nil or self.lastKey == value
    end
    Set.prototype[Symbol.iterator] = function(self)
        return self:values()
    end
    function Set.prototype.entries(self)
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = {key, key}}
                key = nextKey[key]
                return result
            end
        }
    end
    function Set.prototype.keys(self)
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = key}
                key = nextKey[key]
                return result
            end
        }
    end
    function Set.prototype.values(self)
        local nextKey = self.nextKey
        local key = self.firstKey
        return {
            [Symbol.iterator] = function(self)
                return self
            end,
            next = function(self)
                local result = {done = not key, value = key}
                key = nextKey[key]
                return result
            end
        }
    end
    function Set.prototype.union(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:add(item)
        end
        return result
    end
    function Set.prototype.intersection(self, other)
        local result = __TS__New(Set)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.difference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            result:delete(item)
        end
        return result
    end
    function Set.prototype.symmetricDifference(self, other)
        local result = __TS__New(Set, self)
        for ____, item in __TS__Iterator(other) do
            if self:has(item) then
                result:delete(item)
            else
                result:add(item)
            end
        end
        return result
    end
    function Set.prototype.isSubsetOf(self, other)
        for ____, item in __TS__Iterator(self) do
            if not other:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isSupersetOf(self, other)
        for ____, item in __TS__Iterator(other) do
            if not self:has(item) then
                return false
            end
        end
        return true
    end
    function Set.prototype.isDisjointFrom(self, other)
        for ____, item in __TS__Iterator(self) do
            if other:has(item) then
                return false
            end
        end
        return true
    end
    Set[Symbol.species] = Set
end

local function __TS__SparseArrayNew(...)
    local sparseArray = {...}
    sparseArray.sparseLength = __TS__CountVarargs(...)
    return sparseArray
end

local function __TS__SparseArrayPush(sparseArray, ...)
    local args = {...}
    local argsLen = __TS__CountVarargs(...)
    local listLen = sparseArray.sparseLength
    for i = 1, argsLen do
        sparseArray[listLen + i] = args[i]
    end
    sparseArray.sparseLength = listLen + argsLen
end

local function __TS__SparseArraySpread(sparseArray)
    local _unpack = unpack or table.unpack
    return _unpack(sparseArray, 1, sparseArray.sparseLength)
end

local WeakMap
do
    WeakMap = __TS__Class()
    WeakMap.name = "WeakMap"
    function WeakMap.prototype.____constructor(self, entries)
        self[Symbol.toStringTag] = "WeakMap"
        self.items = {}
        setmetatable(self.items, {__mode = "k"})
        if entries == nil then
            return
        end
        local iterable = entries
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                local value = result.value
                self.items[value[1]] = value[2]
            end
        else
            for ____, kvp in ipairs(entries) do
                self.items[kvp[1]] = kvp[2]
            end
        end
    end
    function WeakMap.prototype.delete(self, key)
        local contains = self:has(key)
        self.items[key] = nil
        return contains
    end
    function WeakMap.prototype.get(self, key)
        return self.items[key]
    end
    function WeakMap.prototype.has(self, key)
        return self.items[key] ~= nil
    end
    function WeakMap.prototype.set(self, key, value)
        self.items[key] = value
        return self
    end
    WeakMap[Symbol.species] = WeakMap
end

local WeakSet
do
    WeakSet = __TS__Class()
    WeakSet.name = "WeakSet"
    function WeakSet.prototype.____constructor(self, values)
        self[Symbol.toStringTag] = "WeakSet"
        self.items = {}
        setmetatable(self.items, {__mode = "k"})
        if values == nil then
            return
        end
        local iterable = values
        if iterable[Symbol.iterator] then
            local iterator = iterable[Symbol.iterator](iterable)
            while true do
                local result = iterator:next()
                if result.done then
                    break
                end
                self.items[result.value] = true
            end
        else
            for ____, value in ipairs(values) do
                self.items[value] = true
            end
        end
    end
    function WeakSet.prototype.add(self, value)
        self.items[value] = true
        return self
    end
    function WeakSet.prototype.delete(self, value)
        local contains = self:has(value)
        self.items[value] = nil
        return contains
    end
    function WeakSet.prototype.has(self, value)
        return self.items[value] == true
    end
    WeakSet[Symbol.species] = WeakSet
end

local function __TS__SourceMapTraceBack(fileName, sourceMap)
    _G.__TS__sourcemap = _G.__TS__sourcemap or ({})
    _G.__TS__sourcemap[fileName] = sourceMap
    if _G.__TS__originalTraceback == nil then
        local originalTraceback = debug.traceback
        _G.__TS__originalTraceback = originalTraceback
        debug.traceback = function(thread, message, level)
            local trace
            if thread == nil and message == nil and level == nil then
                trace = originalTraceback()
            elseif __TS__StringIncludes(_VERSION, "Lua 5.0") then
                trace = originalTraceback((("[Level " .. tostring(level)) .. "] ") .. tostring(message))
            else
                trace = originalTraceback(thread, message, level)
            end
            if type(trace) ~= "string" then
                return trace
            end
            local function replacer(____, file, srcFile, line)
                local fileSourceMap = _G.__TS__sourcemap[file]
                if fileSourceMap ~= nil and fileSourceMap[line] ~= nil then
                    local data = fileSourceMap[line]
                    if type(data) == "number" then
                        return (srcFile .. ":") .. tostring(data)
                    end
                    return (data.file .. ":") .. tostring(data.line)
                end
                return (file .. ":") .. line
            end
            local result = string.gsub(
                trace,
                "([^%s<]+)%.lua:(%d+)",
                function(file, line) return replacer(nil, file .. ".lua", file .. ".ts", line) end
            )
            local function stringReplacer(____, file, line)
                local fileSourceMap = _G.__TS__sourcemap[file]
                if fileSourceMap ~= nil and fileSourceMap[line] ~= nil then
                    local chunkName = (__TS__Match(file, "%[string \"([^\"]+)\"%]"))
                    local sourceName = string.gsub(chunkName, ".lua$", ".ts")
                    local data = fileSourceMap[line]
                    if type(data) == "number" then
                        return (sourceName .. ":") .. tostring(data)
                    end
                    return (data.file .. ":") .. tostring(data.line)
                end
                return (file .. ":") .. line
            end
            result = string.gsub(
                result,
                "(%[string \"[^\"]+\"%]):(%d+)",
                function(file, line) return stringReplacer(nil, file, line) end
            )
            return result
        end
    end
end

local function __TS__Spread(iterable)
    local arr = {}
    if type(iterable) == "string" then
        for i = 0, #iterable - 1 do
            arr[i + 1] = __TS__StringAccess(iterable, i)
        end
    else
        local len = 0
        for ____, item in __TS__Iterator(iterable) do
            len = len + 1
            arr[len] = item
        end
    end
    return __TS__Unpack(arr)
end

local function __TS__StringCharAt(self, pos)
    if pos ~= pos then
        pos = 0
    end
    if pos < 0 then
        return ""
    end
    return string.sub(self, pos + 1, pos + 1)
end

local function __TS__StringCharCodeAt(self, index)
    if index ~= index then
        index = 0
    end
    if index < 0 then
        return 0 / 0
    end
    return string.byte(self, index + 1) or 0 / 0
end

local function __TS__StringEndsWith(self, searchString, endPosition)
    if endPosition == nil or endPosition > #self then
        endPosition = #self
    end
    return string.sub(self, endPosition - #searchString + 1, endPosition) == searchString
end

local function __TS__StringPadEnd(self, maxLength, fillString)
    if fillString == nil then
        fillString = " "
    end
    if maxLength ~= maxLength then
        maxLength = 0
    end
    if maxLength == -math.huge or maxLength == math.huge then
        error("Invalid string length", 0)
    end
    if #self >= maxLength or #fillString == 0 then
        return self
    end
    maxLength = maxLength - #self
    if maxLength > #fillString then
        fillString = fillString .. string.rep(
            fillString,
            math.floor(maxLength / #fillString)
        )
    end
    return self .. string.sub(
        fillString,
        1,
        math.floor(maxLength)
    )
end

local function __TS__StringPadStart(self, maxLength, fillString)
    if fillString == nil then
        fillString = " "
    end
    if maxLength ~= maxLength then
        maxLength = 0
    end
    if maxLength == -math.huge or maxLength == math.huge then
        error("Invalid string length", 0)
    end
    if #self >= maxLength or #fillString == 0 then
        return self
    end
    maxLength = maxLength - #self
    if maxLength > #fillString then
        fillString = fillString .. string.rep(
            fillString,
            math.floor(maxLength / #fillString)
        )
    end
    return string.sub(
        fillString,
        1,
        math.floor(maxLength)
    ) .. self
end

local __TS__StringReplace
do
    local sub = string.sub
    function __TS__StringReplace(source, searchValue, replaceValue)
        local startPos, endPos = string.find(source, searchValue, nil, true)
        if not startPos then
            return source
        end
        local before = sub(source, 1, startPos - 1)
        local replacement = type(replaceValue) == "string" and replaceValue or replaceValue(nil, searchValue, startPos - 1, source)
        local after = sub(source, endPos + 1)
        return (before .. replacement) .. after
    end
end

local __TS__StringSplit
do
    local sub = string.sub
    local find = string.find
    function __TS__StringSplit(source, separator, limit)
        if limit == nil then
            limit = 4294967295
        end
        if limit == 0 then
            return {}
        end
        local result = {}
        local resultIndex = 1
        if separator == nil or separator == "" then
            for i = 1, #source do
                result[resultIndex] = sub(source, i, i)
                resultIndex = resultIndex + 1
            end
        else
            local currentPos = 1
            while resultIndex <= limit do
                local startPos, endPos = find(source, separator, currentPos, true)
                if not startPos then
                    break
                end
                result[resultIndex] = sub(source, currentPos, startPos - 1)
                resultIndex = resultIndex + 1
                currentPos = endPos + 1
            end
            if resultIndex <= limit then
                result[resultIndex] = sub(source, currentPos)
            end
        end
        return result
    end
end

local __TS__StringReplaceAll
do
    local sub = string.sub
    local find = string.find
    function __TS__StringReplaceAll(source, searchValue, replaceValue)
        if type(replaceValue) == "string" then
            local concat = table.concat(
                __TS__StringSplit(source, searchValue),
                replaceValue
            )
            if #searchValue == 0 then
                return (replaceValue .. concat) .. replaceValue
            end
            return concat
        end
        local parts = {}
        local partsIndex = 1
        if #searchValue == 0 then
            parts[1] = replaceValue(nil, "", 0, source)
            partsIndex = 2
            for i = 1, #source do
                parts[partsIndex] = sub(source, i, i)
                parts[partsIndex + 1] = replaceValue(nil, "", i, source)
                partsIndex = partsIndex + 2
            end
        else
            local currentPos = 1
            while true do
                local startPos, endPos = find(source, searchValue, currentPos, true)
                if not startPos then
                    break
                end
                parts[partsIndex] = sub(source, currentPos, startPos - 1)
                parts[partsIndex + 1] = replaceValue(nil, searchValue, startPos - 1, source)
                partsIndex = partsIndex + 2
                currentPos = endPos + 1
            end
            parts[partsIndex] = sub(source, currentPos)
        end
        return table.concat(parts)
    end
end

local function __TS__StringSlice(self, start, ____end)
    if start == nil or start ~= start then
        start = 0
    end
    if ____end ~= ____end then
        ____end = 0
    end
    if start >= 0 then
        start = start + 1
    end
    if ____end ~= nil and ____end < 0 then
        ____end = ____end - 1
    end
    return string.sub(self, start, ____end)
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end

local function __TS__StringSubstr(self, from, length)
    if from ~= from then
        from = 0
    end
    if length ~= nil then
        if length ~= length or length <= 0 then
            return ""
        end
        length = length + from
    end
    if from >= 0 then
        from = from + 1
    end
    return string.sub(self, from, length)
end

local function __TS__StringTrim(self)
    local result = string.gsub(self, "^[%s ﻿]*(.-)[%s ﻿]*$", "%1")
    return result
end

local function __TS__StringTrimEnd(self)
    local result = string.gsub(self, "[%s ﻿]*$", "")
    return result
end

local function __TS__StringTrimStart(self)
    local result = string.gsub(self, "^[%s ﻿]*", "")
    return result
end

local __TS__SymbolRegistryFor, __TS__SymbolRegistryKeyFor
do
    local symbolRegistry = {}
    function __TS__SymbolRegistryFor(key)
        if not symbolRegistry[key] then
            symbolRegistry[key] = __TS__Symbol(key)
        end
        return symbolRegistry[key]
    end
    function __TS__SymbolRegistryKeyFor(sym)
        for key in pairs(symbolRegistry) do
            if symbolRegistry[key] == sym then
                return key
            end
        end
        return nil
    end
end

local function __TS__TypeOf(value)
    local luaType = type(value)
    if luaType == "table" then
        return "object"
    elseif luaType == "nil" then
        return "undefined"
    else
        return luaType
    end
end

local function __TS__Using(self, cb, ...)
    local args = {...}
    local thrownError
    local ok, result = xpcall(
        function() return cb(__TS__Unpack(args)) end,
        function(err)
            thrownError = err
            return thrownError
        end
    )
    local argArray = {__TS__Unpack(args)}
    do
        local i = #argArray - 1
        while i >= 0 do
            local ____self_0 = argArray[i + 1]
            ____self_0[Symbol.dispose](____self_0)
            i = i - 1
        end
    end
    if not ok then
        error(thrownError, 0)
    end
    return result
end

local function __TS__UsingAsync(self, cb, ...)
    local args = {...}
    return __TS__AsyncAwaiter(function(____awaiter_resolve)
        local thrownError
        local ok, result = xpcall(
            function() return cb(
                nil,
                __TS__Unpack(args)
            ) end,
            function(err)
                thrownError = err
                return thrownError
            end
        )
        local argArray = {__TS__Unpack(args)}
        do
            local i = #argArray - 1
            while i >= 0 do
                if argArray[i + 1][Symbol.dispose] ~= nil then
                    local ____self_0 = argArray[i + 1]
                    ____self_0[Symbol.dispose](____self_0)
                end
                if argArray[i + 1][Symbol.asyncDispose] ~= nil then
                    local ____self_1 = argArray[i + 1]
                    __TS__Await(____self_1[Symbol.asyncDispose](____self_1))
                end
                i = i - 1
            end
        end
        if not ok then
            error(thrownError, 0)
        end
        return ____awaiter_resolve(nil, result)
    end)
end

return {
  __TS__ArrayAt = __TS__ArrayAt,
  __TS__ArrayConcat = __TS__ArrayConcat,
  __TS__ArrayEntries = __TS__ArrayEntries,
  __TS__ArrayEvery = __TS__ArrayEvery,
  __TS__ArrayFill = __TS__ArrayFill,
  __TS__ArrayFilter = __TS__ArrayFilter,
  __TS__ArrayForEach = __TS__ArrayForEach,
  __TS__ArrayFind = __TS__ArrayFind,
  __TS__ArrayFindIndex = __TS__ArrayFindIndex,
  __TS__ArrayFrom = __TS__ArrayFrom,
  __TS__ArrayIncludes = __TS__ArrayIncludes,
  __TS__ArrayIndexOf = __TS__ArrayIndexOf,
  __TS__ArrayIsArray = __TS__ArrayIsArray,
  __TS__ArrayJoin = __TS__ArrayJoin,
  __TS__ArrayMap = __TS__ArrayMap,
  __TS__ArrayPush = __TS__ArrayPush,
  __TS__ArrayPushArray = __TS__ArrayPushArray,
  __TS__ArrayReduce = __TS__ArrayReduce,
  __TS__ArrayReduceRight = __TS__ArrayReduceRight,
  __TS__ArrayReverse = __TS__ArrayReverse,
  __TS__ArrayUnshift = __TS__ArrayUnshift,
  __TS__ArraySort = __TS__ArraySort,
  __TS__ArraySlice = __TS__ArraySlice,
  __TS__ArraySome = __TS__ArraySome,
  __TS__ArraySplice = __TS__ArraySplice,
  __TS__ArrayToObject = __TS__ArrayToObject,
  __TS__ArrayFlat = __TS__ArrayFlat,
  __TS__ArrayFlatMap = __TS__ArrayFlatMap,
  __TS__ArraySetLength = __TS__ArraySetLength,
  __TS__ArrayToReversed = __TS__ArrayToReversed,
  __TS__ArrayToSorted = __TS__ArrayToSorted,
  __TS__ArrayToSpliced = __TS__ArrayToSpliced,
  __TS__ArrayWith = __TS__ArrayWith,
  __TS__AsyncAwaiter = __TS__AsyncAwaiter,
  __TS__Await = __TS__Await,
  __TS__Class = __TS__Class,
  __TS__ClassExtends = __TS__ClassExtends,
  __TS__CloneDescriptor = __TS__CloneDescriptor,
  __TS__CountVarargs = __TS__CountVarargs,
  __TS__Decorate = __TS__Decorate,
  __TS__DecorateLegacy = __TS__DecorateLegacy,
  __TS__DecorateParam = __TS__DecorateParam,
  __TS__Delete = __TS__Delete,
  __TS__DelegatedYield = __TS__DelegatedYield,
  __TS__DescriptorGet = __TS__DescriptorGet,
  __TS__DescriptorSet = __TS__DescriptorSet,
  Error = Error,
  RangeError = RangeError,
  ReferenceError = ReferenceError,
  SyntaxError = SyntaxError,
  TypeError = TypeError,
  URIError = URIError,
  __TS__FunctionBind = __TS__FunctionBind,
  __TS__Generator = __TS__Generator,
  __TS__InstanceOf = __TS__InstanceOf,
  __TS__InstanceOfObject = __TS__InstanceOfObject,
  __TS__Iterator = __TS__Iterator,
  __TS__LuaIteratorSpread = __TS__LuaIteratorSpread,
  Map = Map,
  __TS__MapGroupBy = __TS__MapGroupBy,
  __TS__Match = __TS__Match,
  __TS__MathAtan2 = __TS__MathAtan2,
  __TS__MathModf = __TS__MathModf,
  __TS__MathSign = __TS__MathSign,
  __TS__MathTrunc = __TS__MathTrunc,
  __TS__New = __TS__New,
  __TS__Number = __TS__Number,
  __TS__NumberIsFinite = __TS__NumberIsFinite,
  __TS__NumberIsInteger = __TS__NumberIsInteger,
  __TS__NumberIsNaN = __TS__NumberIsNaN,
  __TS__ParseInt = __TS__ParseInt,
  __TS__ParseFloat = __TS__ParseFloat,
  __TS__NumberToString = __TS__NumberToString,
  __TS__NumberToFixed = __TS__NumberToFixed,
  __TS__ObjectAssign = __TS__ObjectAssign,
  __TS__ObjectDefineProperty = __TS__ObjectDefineProperty,
  __TS__ObjectEntries = __TS__ObjectEntries,
  __TS__ObjectFromEntries = __TS__ObjectFromEntries,
  __TS__ObjectGetOwnPropertyDescriptor = __TS__ObjectGetOwnPropertyDescriptor,
  __TS__ObjectGetOwnPropertyDescriptors = __TS__ObjectGetOwnPropertyDescriptors,
  __TS__ObjectGroupBy = __TS__ObjectGroupBy,
  __TS__ObjectKeys = __TS__ObjectKeys,
  __TS__ObjectRest = __TS__ObjectRest,
  __TS__ObjectValues = __TS__ObjectValues,
  __TS__ParseFloat = __TS__ParseFloat,
  __TS__ParseInt = __TS__ParseInt,
  __TS__Promise = __TS__Promise,
  __TS__PromiseAll = __TS__PromiseAll,
  __TS__PromiseAllSettled = __TS__PromiseAllSettled,
  __TS__PromiseAny = __TS__PromiseAny,
  __TS__PromiseRace = __TS__PromiseRace,
  Set = Set,
  __TS__SetDescriptor = __TS__SetDescriptor,
  __TS__SparseArrayNew = __TS__SparseArrayNew,
  __TS__SparseArrayPush = __TS__SparseArrayPush,
  __TS__SparseArraySpread = __TS__SparseArraySpread,
  WeakMap = WeakMap,
  WeakSet = WeakSet,
  __TS__SourceMapTraceBack = __TS__SourceMapTraceBack,
  __TS__Spread = __TS__Spread,
  __TS__StringAccess = __TS__StringAccess,
  __TS__StringCharAt = __TS__StringCharAt,
  __TS__StringCharCodeAt = __TS__StringCharCodeAt,
  __TS__StringEndsWith = __TS__StringEndsWith,
  __TS__StringIncludes = __TS__StringIncludes,
  __TS__StringPadEnd = __TS__StringPadEnd,
  __TS__StringPadStart = __TS__StringPadStart,
  __TS__StringReplace = __TS__StringReplace,
  __TS__StringReplaceAll = __TS__StringReplaceAll,
  __TS__StringSlice = __TS__StringSlice,
  __TS__StringSplit = __TS__StringSplit,
  __TS__StringStartsWith = __TS__StringStartsWith,
  __TS__StringSubstr = __TS__StringSubstr,
  __TS__StringSubstring = __TS__StringSubstring,
  __TS__StringTrim = __TS__StringTrim,
  __TS__StringTrimEnd = __TS__StringTrimEnd,
  __TS__StringTrimStart = __TS__StringTrimStart,
  __TS__Symbol = __TS__Symbol,
  Symbol = Symbol,
  __TS__SymbolRegistryFor = __TS__SymbolRegistryFor,
  __TS__SymbolRegistryKeyFor = __TS__SymbolRegistryKeyFor,
  __TS__TypeOf = __TS__TypeOf,
  __TS__Unpack = __TS__Unpack,
  __TS__Using = __TS__Using,
  __TS__UsingAsync = __TS__UsingAsync
}
 end,
["data.types.common"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.types.equipment"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.types.numeric"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.types.units"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.types.waves"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.types.gameData"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["data.indexes"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local ____exports = {}
--- 配方索引键：线 + 起始档
function ____exports.recipeKey(self, line, fromTier)
    return (line .. ":") .. tostring(fromTier)
end
local function indexBy(self, items, key)
    return __TS__New(
        Map,
        __TS__ArrayMap(
            items,
            function(____, item) return {
                key(nil, item),
                item
            } end
        )
    )
end
function ____exports.buildIndex(self, data)
    return {
        hero = indexBy(
            nil,
            data.heroes,
            function(____, h) return h.id end
        ),
        skill = indexBy(
            nil,
            data.skills,
            function(____, s) return s.id end
        ),
        monster = indexBy(
            nil,
            data.monsters,
            function(____, m) return m.id end
        ),
        template = indexBy(
            nil,
            data.waveTemplates,
            function(____, t) return t.id end
        ),
        event = indexBy(
            nil,
            data.events,
            function(____, e) return e.id end
        ),
        material = indexBy(
            nil,
            data.materials,
            function(____, m) return m.id end
        ),
        equipment = indexBy(
            nil,
            data.equipment,
            function(____, e) return e.id end
        ),
        affix = indexBy(
            nil,
            data.affixes,
            function(____, a) return a.id end
        ),
        quality = indexBy(
            nil,
            data.qualities,
            function(____, q) return q.id end
        ),
        recipe = indexBy(
            nil,
            data.recipes,
            function(____, r) return ____exports.recipeKey(nil, r.line, r.fromTier) end
        ),
        tierArmorK = indexBy(
            nil,
            data.tierArmorK,
            function(____, t) return t.tier end
        ),
        eCurve = indexBy(
            nil,
            data.eCurve,
            function(____, e) return e.tier end
        ),
        interval = indexBy(
            nil,
            data.intervals,
            function(____, i) return i.id end
        ),
        rank = indexBy(
            nil,
            data.ranks,
            function(____, r) return r.id end
        ),
        node = indexBy(
            nil,
            data.nodes,
            function(____, n) return n.id end
        ),
        population = indexBy(
            nil,
            data.population.table,
            function(____, p) return p.n end
        ),
        drop = indexBy(
            nil,
            data.drops,
            function(____, d) return d.source end
        )
    }
end
return ____exports
 end,
["data.tables.drops"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 掉落表（主文档 附录 C.2）。
-- 
-- M1 仅登记实际会遇到的来源：小怪 / 精英 / 锚点 BOSS。
-- `materialChance = -1` 表示沿用 economy 的按幕递减基础掉率（数值文档 §8.3）。
____exports.drops = {{
    source = "minion",
    goldBase = {1, 3},
    goldMul = 1,
    spiritFlat = 0,
    materialChance = -1,
    materialPool = {"bat_wing_shard"}
}, {
    source = "elite",
    goldBase = {1, 3},
    goldMul = 5,
    spiritFlat = 3,
    materialChance = -1,
    materialPool = {"bat_wing_shard"}
}, {
    source = "anchorBoss",
    goldBase = {1, 3},
    goldMul = 20,
    spiritFlat = 80,
    materialChance = 1,
    materialPool = {"bat_wing_shard"}
}}
return ____exports
 end,
["data.tables.equipment"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 品质分级（数值文档 §7.4）
____exports.qualities = {{id = "lower", name = "下品", statMul = 1, affixCount = 1}, {id = "middle", name = "中品", statMul = 1.15, affixCount = 2}, {id = "upper", name = "上品", statMul = 1.3, affixCount = 3}}
--- 词条池（M1 仅法宝线，数值文档 §7.5 / 主文档 附录 C.5）
____exports.affixes = {{id = "affix_weapon_atk", line = "weapon", name = "攻伐", effect = {kind = "statMod", stat = "atk", mode = "percent", value = 0.06}}, {id = "affix_weapon_sp", line = "weapon", name = "术法", effect = {kind = "statMod", stat = "sp", mode = "percent", value = 0.06}}, {id = "affix_weapon_crit", line = "weapon", name = "会心", effect = {kind = "statMod", stat = "crit", mode = "flat", value = 6}}, {id = "affix_weapon_lifesteal", line = "weapon", name = "噬魂", effect = {kind = "lifesteal", percent = 0.04}}}
--- 合成材料（M1 仅法宝线 T1→T2，主文档 附录 C.3）
____exports.materials = {{
    id = "bat_wing_shard",
    name = "蝠翼碎片",
    fromTier = 1,
    toTier = 2,
    line = "weapon",
    stage = "act1"
}}
--- 升档配方（M1 仅一条，数值文档 §8.2 / 主文档 附录 C.4）
____exports.recipes = {{
    line = "weapon",
    fromTier = 1,
    toTier = 2,
    gold = 25,
    spirit = 0,
    materialId = "bat_wing_shard",
    materialCount = 2,
    requiresSourceItem = true
}}
--- 装备定义（中品基线主属性，数值文档 §7.3）
____exports.equipment = {{
    id = "weapon_t1",
    line = "weapon",
    tier = 1,
    name = "凡铁剑",
    mainStats = {{stat = "atk", mode = "percent", value = 0}}
}, {
    id = "weapon_t2",
    line = "weapon",
    tier = 2,
    name = "蝠翼灵剑",
    mainStats = {{stat = "atk", mode = "percent", value = 0.163}}
}}
return ____exports
 end,
["data.tables.heroes"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 英雄表（M1 仅张小凡，主文档 附录 A.1）。
-- 数值口径：数值文档 §2.3 N1 开局（1 人基准）。
____exports.heroes = {{
    id = "zhangxiaofan",
    name = "张小凡",
    role = "front",
    base = {
        hp = 800,
        mp = 200,
        atk = 45,
        sp = 45,
        def = 12,
        spd = 300,
        dodge = 0,
        crit = 5,
        critDmg = 1.5
    },
    startTier = 1,
    skills = {Q = "zxf_q", W = "zxf_w", E = "zxf_e", R = "zxf_r"}
}}
return ____exports
 end,
["data.tables.monsters"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 怪物表（主文档 附录 B.1 / D.2）。
-- 
-- 小怪仅登记「相对区间基线的系数」：实际 HP/ATK 由波次导演按 L3 区间插值
-- （数值文档 §5.1）+ L4 人数缩放（§6.2）算出，避免把强度绑死波号。
____exports.monsters = {
    {
        id = "wolf",
        name = "狼妖",
        class = "minion",
        mul = {hp = 1, atk = 1, def = 1, spd = 1},
        attackSpeed = 1,
        range = 0.9
    },
    {
        id = "boar",
        name = "野猪",
        class = "minion",
        mul = {hp = 1.3, atk = 1.1, def = 1.1, spd = 0.8},
        attackSpeed = 0.9,
        range = 0.9
    },
    {
        id = "bat",
        name = "嗜血蝠",
        class = "minion",
        mul = {hp = 0.6, atk = 0.8, def = 0.8, spd = 1.4},
        attackSpeed = 1.2,
        range = 0.8,
        flying = true
    },
    {
        id = "elite_bat",
        name = "妖化蝙蝠",
        class = "elite",
        mul = {hp = 6, atk = 2.2, def = 1.5, spd = 1.2},
        attackSpeed = 1.1,
        range = 0.9,
        flying = true
    },
    {
        id = "small_snake",
        name = "小玄蛇",
        class = "minion",
        mul = {hp = 12, atk = 1.1, def = 1, spd = 1.1},
        attackSpeed = 1,
        range = 0.9
    },
    {
        id = "heishui_xuanshe",
        name = "黑水玄蛇",
        class = "anchorBoss",
        mul = {hp = 1, atk = 6, def = 1.5, spd = 0.8},
        attackSpeed = 0.8,
        range = 1.6,
        mechanism = "mid",
        mechanismType = {"phase", "summon"},
        targetHp4p = 11000,
        tierOverride = 1,
        armorKMult = 1.2,
        skills = {"hx_breath", "hx_coil", "hx_rage"}
    }
}
return ____exports
 end,
["data.tables.numeric"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- L0 阶段锚点节点（数值文档 §2.3，1 人基准）
____exports.nodes = {
    {
        id = "N1",
        name = "开局",
        tier = 1,
        heroHp = 800,
        heroAtk = 45,
        heroDef = 12,
        minionHp = 32,
        minionAtk = 18,
        minionDef = 7,
        eliteHp = 190,
        eliteAtk = 40
    },
    {
        id = "N2",
        name = "一锚前",
        tier = 2,
        heroHp = 1200,
        heroAtk = 70,
        heroDef = 20,
        minionHp = 58,
        minionAtk = 26,
        minionDef = 12,
        eliteHp = 350,
        eliteAtk = 57,
        anchorBossHp4p = 11000
    },
    {
        id = "N3",
        name = "一锚后",
        tier = 3,
        heroHp = 1800,
        heroAtk = 108,
        heroDef = 35,
        minionHp = 100,
        minionAtk = 38,
        minionDef = 21,
        eliteHp = 600,
        eliteAtk = 84
    },
    {
        id = "N4",
        name = "二锚前",
        tier = 4,
        heroHp = 2700,
        heroAtk = 168,
        heroDef = 60,
        minionHp = 175,
        minionAtk = 55,
        minionDef = 36,
        eliteHp = 1050,
        eliteAtk = 121,
        anchorBossHp4p = 27000
    },
    {
        id = "N5",
        name = "二锚后",
        tier = 5,
        heroHp = 4050,
        heroAtk = 260,
        heroDef = 100,
        minionHp = 300,
        minionAtk = 80,
        minionDef = 60,
        eliteHp = 1800,
        eliteAtk = 176
    },
    {
        id = "N6",
        name = "终局",
        tier = 6,
        heroHp = 6000,
        heroAtk = 400,
        heroDef = 160,
        minionHp = 470,
        minionAtk = 116,
        minionDef = 96,
        eliteHp = 2800,
        eliteAtk = 255,
        anchorBossHp4p = 63000
    }
}
--- 减伤系数 K 挂档位（数值文档 §3.3）
____exports.tierArmorK = {
    {tier = 1, standardDef = 12, k = 28},
    {tier = 2, standardDef = 20, k = 47},
    {tier = 3, standardDef = 35, k = 82},
    {tier = 4, standardDef = 60, k = 140},
    {tier = 5, standardDef = 100, k = 233},
    {tier = 6, standardDef = 160, k = 373}
}
--- 强度区间（数值文档 §5.1，端点为 L0 锚点；护甲档 = 节点序号）
____exports.intervals = {{
    id = "I",
    act = "act1",
    hp = {32, 58},
    atk = {18, 26},
    armorTier = {1, 2}
}, {
    id = "II",
    act = "act2",
    hp = {58, 175},
    atk = {26, 55},
    armorTier = {2, 4}
}, {
    id = "III",
    act = "act3",
    hp = {175, 470},
    atk = {55, 116},
    armorTier = {4, 6}
}}
--- 派生关系（数值文档 §2.4）
____exports.derivation = {
    heroAttackSpeed = 1.3,
    skillCoefficient = 1.15,
    partyEfficiency = 0.7,
    minion = {spd = 220, attackSpeed = 1, range = 0.9, defRatio = 0.6},
    eliteMul = {hp = 6, atk = 2.2, def = 1.5},
    waveBossHpMul = 25,
    anchorBossTtk = 40,
    wildBossHpRatio = {0.3, 0.35}
}
--- 人数缩放（数值文档 §6.3，α = 0.42）
____exports.population = {alpha = 0.42, maxOnScreen = 40, table = {
    {
        n = 1,
        hpMul = 1,
        countMul = 1,
        bossMul = 1,
        dmgMul = 1
    },
    {
        n = 2,
        hpMul = 1.49,
        countMul = 1.34,
        bossMul = 2,
        dmgMul = 1
    },
    {
        n = 3,
        hpMul = 1.89,
        countMul = 1.59,
        bossMul = 3,
        dmgMul = 1
    },
    {
        n = 4,
        hpMul = 2.23,
        countMul = 1.8,
        bossMul = 4,
        dmgMul = 1
    },
    {
        n = 5,
        hpMul = 2.53,
        countMul = 1.98,
        bossMul = 5,
        dmgMul = 1
    },
    {
        n = 6,
        hpMul = 2.82,
        countMul = 2.14,
        bossMul = 6,
        dmgMul = 1
    }
}}
--- 等级曲线（数值文档 §4.4，递减式增幅）
____exports.level = {maxLevel = 25, segments = {{fromLevel = 1, toLevel = 10, perLevelPct = 0.065}, {fromLevel = 10, toLevel = 20, perLevelPct = 0.035}, {fromLevel = 20, toLevel = 25, perLevelPct = 0.015}}, totalMul = 2.677, skillPointEvery = 2}
--- 境界曲线（数值文档 §4.5）
____exports.ranks = {{
    id = "yuqing",
    name = "玉清",
    hpMul = 1,
    atkMul = 1,
    unlocks = {}
}, {
    id = "shangqing",
    name = "上清",
    hpMul = 1.25,
    atkMul = 1.25,
    unlocks = {"R"}
}, {
    id = "taiqing",
    name = "太清",
    hpMul = 1.5625,
    atkMul = 1.5625,
    unlocks = {}
}}
--- 装备倍率曲线 E（数值文档 §4.6/§7.1）
____exports.eCurve = {
    {tier = 1, hpMul = 1, atkMul = 1},
    {tier = 2, hpMul = 1.127, atkMul = 1.163},
    {tier = 3, hpMul = 1.269, atkMul = 1.352},
    {tier = 4, hpMul = 1.431, atkMul = 1.572},
    {tier = 5, hpMul = 1.612, atkMul = 1.827},
    {tier = 6, hpMul = 1.816, atkMul = 2.125}
}
--- 机制档 → HP 乘数（数值文档 §5.4）
____exports.mechanismMul = {none = 1, light = 0.9, mid = 0.8, heavy = 0.7}
--- 护栏硬上限（数值文档 §9.1）
____exports.limits = {
    defRedMax = 0.75,
    dodgeMax = 0.25,
    critMax = 0.6,
    critDmgMax = 2.5,
    dmgMultMin = 0.5,
    dmgMultMax = 2.5,
    maxOnScreenMinions = 40,
    materialStorageCap = 20,
    maxT6PerRun = 2
}
--- 经济模型（数值文档 §8）
____exports.economy = {
    goldPerWave = {act1 = 30, act2 = 55, act3 = 85},
    spirit = {elite = 3, waveBoss = 12, anchorBoss = 80},
    xp = {minionBase = 4, perTier = 2, eliteMul = 5, bossMul = 20},
    levelNeed = {base = 30, growth = 1.2},
    materialDropChance = {act1 = 0.15, act2 = 0.11, act3 = 0.08},
    softGateActs = 1,
    storageCap = 20
}
return ____exports
 end,
["data.tables.skills"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 技能表（主文档 附录 A.1 + B.1）。
-- 
-- 全部走 Modifier 效果原语组合，不写特殊逻辑（主文档 §6.7）。
____exports.skills = {
    {
        id = "zxf_q",
        owner = "zhangxiaofan",
        key = "Q",
        name = "嗜血珠 · 血刃",
        damageType = "physical",
        rate = 1,
        cooldown = 5,
        mpCost = 20,
        shape = "single",
        range = 1,
        effects = {{kind = "lifesteal", percent = 0.15}}
    },
    {
        id = "zxf_w",
        owner = "zhangxiaofan",
        key = "W",
        name = "大梵般若 · 佛掌",
        damageType = "physical",
        rate = 0.9,
        cooldown = 10,
        mpCost = 35,
        shape = "cone",
        radius = 2.5,
        range = 2.5,
        effects = {{kind = "knockback", distance = 2}}
    },
    {
        id = "zxf_e",
        owner = "zhangxiaofan",
        key = "E",
        name = "佛魔护体",
        cooldown = 18,
        mpCost = 40,
        shape = "self",
        effects = {{kind = "shield", percentOfMaxHp = 0.2, duration = 5}, {kind = "damageTakenMul", value = 0.92, duration = 5}}
    },
    {
        id = "zxf_r",
        owner = "zhangxiaofan",
        key = "R",
        name = "三修 · 诛魔",
        damageType = "physical",
        rate = 1.6,
        cooldown = 60,
        mpCost = 80,
        shape = "aoeSelf",
        radius = 3.5,
        effects = {{
            kind = "stackDamage",
            stackId = "moqi",
            perStack = 0.03,
            maxStacks = 5,
            duration = 8
        }},
        requiresRank = "shangqing",
        upgrades = {{rank = "taiqing", rate = 2, extraEffects = {{kind = "heal", percentOfMaxHp = 0.02}}}}
    },
    {
        id = "hx_breath",
        owner = "heishui_xuanshe",
        name = "玄水吐息",
        damageType = "magic",
        rate = 1.5,
        cooldown = 8,
        mpCost = 0,
        shape = "cone",
        radius = 2.5,
        range = 2.5,
        effects = {{
            kind = "statMod",
            stat = "spd",
            mode = "percent",
            value = -0.2,
            duration = 2
        }}
    },
    {
        id = "hx_coil",
        owner = "heishui_xuanshe",
        name = "蛇身缠绕",
        cooldown = 15,
        mpCost = 0,
        shape = "aoeSelf",
        radius = 2.5,
        effects = {{kind = "root", duration = 1.5}}
    },
    {
        id = "hx_rage",
        owner = "heishui_xuanshe",
        name = "阶段转换 · 暴走",
        cooldown = 0,
        mpCost = 0,
        shape = "self",
        effects = {{kind = "statMod", stat = "spd", mode = "percent", value = 0.3}, {kind = "statMod", stat = "atk", mode = "percent", value = 0.25}, {kind = "summon", monsterId = "small_snake", count = 2}},
        trigger = "phase",
        triggerThreshold = 0.5
    }
}
return ____exports
 end,
["data.tables.waves"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 波次模板表（M1 小池 3 个，主文档 附录 D.2）。
-- 数量为 1 人基准，实战按 L4 countMul 缩放（数值文档 §6.3）。
____exports.waveTemplates = {{
    id = "E1",
    layer = "act1",
    name = "狼妖来袭",
    groups = {{monsterId = "wolf", count = 8}},
    route = "main",
    eventHooks = {"beast_timing"},
    waveBossPool = {},
    note = "教学波"
}, {
    id = "E2",
    layer = "act1",
    name = "狼妖与野猪",
    groups = {{monsterId = "wolf", count = 8}, {monsterId = "boar", count = 2}},
    route = "main",
    eventHooks = {"beast_timing"},
    waveBossPool = {}
}, {
    id = "E3",
    layer = "act1",
    name = "蝙蝠群",
    groups = {{monsterId = "bat", count = 10}},
    route = "main",
    elite = {min = 0, max = 1, monsterId = "elite_bat"},
    eventHooks = {"beast_timing"},
    waveBossPool = {},
    note = "空袭预演"
}}
--- 事件表（M1 仅「兽潮提前 / 滞后」，主文档 附录 E.2）
____exports.events = {{
    id = "beast_timing",
    name = "兽潮提前 / 滞后",
    rarity = "common",
    weight = 12,
    cooldown = 6,
    minAct = "act1",
    effect = {kind = "waveTiming", earlySeconds = 30, lateSeconds = 45}
}}
return ____exports
 end,
["data.tables.index"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____drops = require("data.tables.drops")
local drops = ____drops.drops
local ____equipment = require("data.tables.equipment")
local affixes = ____equipment.affixes
local equipment = ____equipment.equipment
local materials = ____equipment.materials
local qualities = ____equipment.qualities
local recipes = ____equipment.recipes
local ____heroes = require("data.tables.heroes")
local heroes = ____heroes.heroes
local ____monsters = require("data.tables.monsters")
local monsters = ____monsters.monsters
local ____numeric = require("data.tables.numeric")
local derivation = ____numeric.derivation
local eCurve = ____numeric.eCurve
local economy = ____numeric.economy
local intervals = ____numeric.intervals
local level = ____numeric.level
local limits = ____numeric.limits
local mechanismMul = ____numeric.mechanismMul
local nodes = ____numeric.nodes
local population = ____numeric.population
local ranks = ____numeric.ranks
local tierArmorK = ____numeric.tierArmorK
local ____skills = require("data.tables.skills")
local skills = ____skills.skills
local ____waves = require("data.tables.waves")
local events = ____waves.events
local waveTemplates = ____waves.waveTemplates
--- 装配 M1 子集配置。
-- 
-- 这里**不做校验**：校验统一发生在 `loadGameData()`，保证「装配」与「校验」解耦，
-- 测试可以注入损坏数据来验证 fail fast 行为。
function ____exports.buildGameData(self)
    return {
        version = "M1",
        sim = {fixedDt = 1 / 30, defaultSeed = 20261013},
        limits = limits,
        mechanismMul = mechanismMul,
        nodes = nodes,
        tierArmorK = tierArmorK,
        intervals = intervals,
        derivation = derivation,
        population = population,
        level = level,
        ranks = ranks,
        eCurve = eCurve,
        economy = economy,
        qualities = qualities,
        affixes = affixes,
        materials = materials,
        recipes = recipes,
        equipment = equipment,
        drops = drops,
        heroes = heroes,
        skills = skills,
        monsters = monsters,
        waveTemplates = waveTemplates,
        events = events
    }
end
return ____exports
 end,
["data.validate.issues"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
____exports.ConfigError = __TS__Class()
local ConfigError = ____exports.ConfigError
ConfigError.name = "ConfigError"
__TS__ClassExtends(ConfigError, Error)
function ConfigError.prototype.____constructor(self, issues)
    Error.prototype.____constructor(
        self,
        (("配置校验失败（" .. tostring(#issues)) .. " 项）:\n") .. table.concat(
            __TS__ArrayMap(
                issues,
                function(____, issue) return (("  · [" .. issue.rule) .. "] ") .. issue.message end
            ),
            "\n"
        )
    )
    self.name = "ConfigError"
    self.issues = issues
end
function ____exports.addError(self, issues, rule, message)
    issues[#issues + 1] = {rule = rule, severity = "error", message = message}
end
function ____exports.addWarn(self, issues, rule, message)
    issues[#issues + 1] = {rule = rule, severity = "warn", message = message}
end
--- 断言辅助：条件不成立时压入一条 error
function ____exports.expectTrue(self, issues, rule, condition, message)
    if not condition then
        ____exports.addError(nil, issues, rule, message)
    end
    return condition
end
--- 相对偏差（|actual − expected| / expected）
function ____exports.relError(self, actual, expected)
    if expected == 0 then
        return actual == 0 and 0 or math.huge
    end
    return math.abs(actual - expected) / math.abs(expected)
end
return ____exports
 end,
["data.validate.economy"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local ____exports = {}
local checkXpAlignment, levelFromXp, WAVES_PER_ACT, TARGET_LEVEL
local ____issues = require("data.validate.issues")
local addError = ____issues.addError
local addWarn = ____issues.addWarn
local expectTrue = ____issues.expectTrue
local relError = ____issues.relError
function checkXpAlignment(self, data, issues)
    local templates = __TS__ArrayFilter(
        data.waveTemplates,
        function(____, t) return t.layer == "act1" end
    )
    if #templates == 0 then
        return
    end
    local avgMinions = __TS__ArrayReduce(
        templates,
        function(____, sum, t) return sum + __TS__ArrayReduce(
            t.groups,
            function(____, s, g) return s + g.count end,
            0
        ) end,
        0
    ) / #templates
    local totalMinions = math.floor(avgMinions * WAVES_PER_ACT + 0.5)
    local xpPerMinion = data.economy.xp.minionBase + data.economy.xp.perTier * 1
    local totalXp = totalMinions * xpPerMinion
    local level = levelFromXp(nil, totalXp, data)
    local target = TARGET_LEVEL.anchor1
    if math.abs(level - target) > 2 then
        addWarn(
            nil,
            issues,
            "economy.xpAlignment",
            (((((((("幕一 XP 产出 " .. tostring(totalXp)) .. "（约 ") .. tostring(totalMinions)) .. " 只小怪 × ") .. tostring(xpPerMinion)) .. "）推算等级 L") .. tostring(level)) .. "，") .. ((("与锚点一目标 L" .. tostring(target)) .. " 偏差 ") .. tostring(math.abs(level - target))) .. " 级（容差 2 级）"
        )
    end
    local nodes = data.nodes
    do
        local i = 1
        while i < #nodes do
            do
                local prevNode = nodes[i]
                local node = nodes[i + 1]
                if not prevNode or not node then
                    goto __continue18
                end
                local heroHpGain = node.heroHp / prevNode.heroHp
                local minionAtkGain = node.minionAtk / prevNode.minionAtk
                if minionAtkGain > heroHpGain then
                    addError(
                        nil,
                        issues,
                        "economy.tempoDir",
                        (((((((("节点 " .. prevNode.id) .. "→") .. node.id) .. "：小怪 ATK 增速 ") .. __TS__NumberToFixed(minionAtkGain, 3)) .. " 快于英雄 HP 增速 ") .. __TS__NumberToFixed(heroHpGain, 3)) .. "，") .. "会破坏「玩家越打越硬」的成长手感（数值文档 §2.4）"
                    )
                end
            end
            ::__continue18::
            i = i + 1
        end
    end
end
function levelFromXp(self, totalXp, data)
    local ____data_economy_levelNeed_1 = data.economy.levelNeed
    local base = ____data_economy_levelNeed_1.base
    local growth = ____data_economy_levelNeed_1.growth
    local cumulative = 0
    local level = 1
    while level < data.level.maxLevel do
        local need = base * growth ^ (level - 1)
        if cumulative + need > totalXp then
            break
        end
        cumulative = cumulative + need
        level = level + 1
    end
    return level
end
--- 幕次序号（用于软门控「提前一幕」判定）
local ACT_ORDER = {act1 = 1, act2 = 2, act3 = 3}
local ACT_BY_ORDER = {[1] = "act1", [2] = "act2", [3] = "act3"}
WAVES_PER_ACT = 10
--- 各材料目标幕次 = 该升档解锁幕（主文档 附录 C.3）
local TARGET_ACT_OF_TIER = {
    [1] = "act1",
    [2] = "act1",
    [3] = "act2",
    [4] = "act2",
    [5] = "act3",
    [6] = "act3"
}
TARGET_LEVEL = {anchor1 = 7, anchor2 = 15, final = 25}
--- 经济与掉率校验（数值文档 §8 / 校验规则 14–16）。
-- 
-- 收入-成本守恒与软门控为 error；经验对齐为 warn（调参类偏差，对齐 §9.5）。
function ____exports.checkEconomy(self, data, issues)
    local ____data_0 = data
    local economy = ____data_0.economy
    for ____, act in ipairs({"act1", "act2", "act3"}) do
        local revenue = economy.goldPerWave[act] * WAVES_PER_ACT
        local cost = __TS__ArrayReduce(
            __TS__ArrayFilter(
                data.recipes,
                function(____, r) return TARGET_ACT_OF_TIER[r.toTier] == act end
            ),
            function(____, sum, r) return sum + r.gold end,
            0
        )
        expectTrue(
            nil,
            issues,
            "economy.coverage",
            revenue >= cost,
            ((((("幕「" .. act) .. "」金币收入 ") .. tostring(revenue)) .. " 低于该幕单线合成成本 ") .. tostring(cost)) .. "，会出现卡进度"
        )
    end
    local prev = math.huge
    for ____, act in ipairs({"act1", "act2", "act3"}) do
        local chance = economy.materialDropChance[act]
        expectTrue(
            nil,
            issues,
            "economy.dropRateBand",
            chance >= 0.08 and chance <= 0.15,
            ((("幕「" .. act) .. "」材料掉率 ") .. tostring(chance)) .. " 越界（应 ∈ [0.08, 0.15]）"
        )
        expectTrue(
            nil,
            issues,
            "economy.dropRateMonotonic",
            chance <= prev,
            (((("材料掉率随幕次递增：" .. act) .. " 为 ") .. tostring(chance)) .. "，高于前幕 ") .. tostring(prev)
        )
        prev = chance
    end
    for ____, material in ipairs(data.materials) do
        local targetOrder = ACT_ORDER[TARGET_ACT_OF_TIER[material.toTier]]
        local minimunOrder = math.max(1, targetOrder - economy.softGateActs)
        local stageOrder = ACT_ORDER[material.stage]
        local allowed = stageOrder >= minimunOrder and stageOrder <= targetOrder
        expectTrue(
            nil,
            issues,
            "economy.softGate",
            allowed,
            (((((((("材料「" .. material.id) .. "」（T") .. tostring(material.fromTier)) .. "→T") .. tostring(material.toTier)) .. "）登记掉落幕为「") .. material.stage) .. "」，") .. ((((("但软门控只允许 " .. tostring(ACT_BY_ORDER[minimunOrder])) .. "–") .. tostring(ACT_BY_ORDER[targetOrder])) .. "（最多提前 ") .. tostring(economy.softGateActs)) .. " 幕）"
        )
    end
    expectTrue(
        nil,
        issues,
        "economy.storageCap",
        economy.storageCap == data.limits.materialStorageCap,
        ((("economy.storageCap " .. tostring(economy.storageCap)) .. " 与 limits.materialStorageCap ") .. tostring(data.limits.materialStorageCap)) .. " 不一致"
    )
    checkXpAlignment(nil, data, issues)
end
--- 保留给后续：断言收入盈余不超过目标成本 1.5×（数值文档 §8.5，需全量配方集）
function ____exports.checkEconomySurplus(self, data, issues)
    local totalRevenue = (data.economy.goldPerWave.act1 + data.economy.goldPerWave.act2 + data.economy.goldPerWave.act3) * WAVES_PER_ACT
    local totalCost = __TS__ArrayReduce(
        data.recipes,
        function(____, sum, r) return sum + r.gold end,
        0
    )
    if totalCost == 0 then
        return
    end
    expectTrue(
        nil,
        issues,
        "economy.surplus",
        relError(nil, totalRevenue, totalCost) <= 1.5,
        (("终局金币盈余偏离目标成本过大：收入 " .. tostring(totalRevenue)) .. " / 成本 ") .. tostring(totalCost)
    )
end
return ____exports
 end,
["data.validate.numeric"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local __TS__ArrayJoin = ____lualib.__TS__ArrayJoin
local __TS__NumberIsInteger = ____lualib.__TS__NumberIsInteger
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local Set = ____lualib.Set
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____issues = require("data.validate.issues")
local addError = ____issues.addError
local expectTrue = ____issues.expectTrue
local relError = ____issues.relError
local ALL_TIERS = {
    1,
    2,
    3,
    4,
    5,
    6
}
--- 区间 → 端点节点 id（数值文档 §5.1：Ⅰ=N1→N2，Ⅱ=N2→N4，Ⅲ=N4→N6）
local INTERVAL_NODES = {I = {"N1", "N2"}, II = {"N2", "N4"}, III = {"N4", "N6"}}
--- 校验规则 2：档位 K 表完整
function ____exports.checkTierArmorKComplete(self, data, issues)
    for ____, tier in ipairs(ALL_TIERS) do
        expectTrue(
            nil,
            issues,
            "k.complete",
            #__TS__ArrayFilter(
                data.tierArmorK,
                function(____, r) return r.tier == tier end
            ) == 1,
            ("档位 K 表缺少或多出 T" .. tostring(tier)) .. " 行"
        )
    end
end
--- 校验规则 1：K = 2.33 × 标准 DEF，且同档互殴减伤率 ∈ [25%, 35%]
function ____exports.checkArmorKDerivation(self, data, issues)
    for ____, row in ipairs(data.tierArmorK) do
        local ratio = row.k / row.standardDef
        expectTrue(
            nil,
            issues,
            "k.derivation",
            relError(nil, ratio, 2.33) <= 0.03,
            ((((((("T" .. tostring(row.tier)) .. " 的 K(") .. tostring(row.k)) .. ") / 标准DEF(") .. tostring(row.standardDef)) .. ") = ") .. __TS__NumberToFixed(ratio, 3)) .. "，应约为 2.33"
        )
        local defRed = row.standardDef / (row.standardDef + row.k)
        expectTrue(
            nil,
            issues,
            "k.defRedBand",
            defRed >= 0.25 and defRed <= 0.35,
            ((("T" .. tostring(row.tier)) .. " 同档互殴减伤率 ") .. __TS__NumberToFixed(defRed * 100, 1)) .. "% 越界（应 ∈ [25%, 35%]）"
        )
    end
end
--- 校验规则 3：节点派生式一致性（英雄 DEF = 标准 DEF；小怪 DEF = 标准 DEF × 比例；精英 = 小怪 × 系数）
function ____exports.checkNodeDerivation(self, data, index, issues)
    local ____data_derivation_0 = data.derivation
    local eliteMul = ____data_derivation_0.eliteMul
    local minion = ____data_derivation_0.minion
    for ____, node in ipairs(data.nodes) do
        do
            local tierRow = index.tierArmorK:get(node.tier)
            if not tierRow then
                goto __continue10
            end
            expectTrue(
                nil,
                issues,
                "node.heroDef",
                node.heroDef == tierRow.standardDef,
                ((((((("节点 " .. node.id) .. " 英雄 DEF ") .. tostring(node.heroDef)) .. " ≠ 标准 DEF ") .. tostring(tierRow.standardDef)) .. "（") .. tostring(node.tier)) .. " 档）"
            )
            local expectMinionDef = math.floor(tierRow.standardDef * minion.defRatio + 0.5)
            expectTrue(
                nil,
                issues,
                "node.minionDef",
                math.abs(node.minionDef - expectMinionDef) <= 1,
                ((((("节点 " .. node.id) .. " 小怪 DEF ") .. tostring(node.minionDef)) .. " 与 标准DEF×比例 的期望 ") .. tostring(expectMinionDef)) .. " 偏差过大"
            )
            expectTrue(
                nil,
                issues,
                "node.eliteHp",
                relError(nil, node.eliteHp, node.minionHp * eliteMul.hp) <= 0.15,
                ((((((("节点 " .. node.id) .. " 精英 HP ") .. tostring(node.eliteHp)) .. " 与 小怪×") .. tostring(eliteMul.hp)) .. " 的期望 ") .. __TS__NumberToFixed(node.minionHp * eliteMul.hp, 0)) .. " 偏差 > 15%"
            )
            expectTrue(
                nil,
                issues,
                "node.eliteAtk",
                relError(nil, node.eliteAtk, node.minionAtk * eliteMul.atk) <= 0.15,
                ((((((("节点 " .. node.id) .. " 精英 ATK ") .. tostring(node.eliteAtk)) .. " 与 小怪×") .. tostring(eliteMul.atk)) .. " 的期望 ") .. __TS__NumberToFixed(node.minionAtk * eliteMul.atk, 0)) .. " 偏差 > 15%"
            )
        end
        ::__continue10::
    end
end
--- 校验规则 8：区间起止严格对齐 L0 锚点，护甲档与节点一致
function ____exports.checkIntervalConsistency(self, data, index, issues)
    for ____, interval in ipairs(data.intervals) do
        do
            local nodeIds = INTERVAL_NODES[interval.id]
            if not nodeIds then
                addError(nil, issues, "interval.unknown", ("区间「" .. interval.id) .. "」未登记端点节点映射")
                goto __continue14
            end
            local start = index.node:get(nodeIds[1])
            local ____end = index.node:get(nodeIds[2])
            if not start or not ____end then
                addError(
                    nil,
                    issues,
                    "interval.missingNode",
                    ((("区间「" .. interval.id) .. "」的端点节点 ") .. __TS__ArrayJoin(nodeIds, "/")) .. " 缺失"
                )
                goto __continue14
            end
            expectTrue(
                nil,
                issues,
                "interval.hpEndpoint",
                interval.hp[1] == start.minionHp and interval.hp[2] == ____end.minionHp,
                ((((((((("区间「" .. interval.id) .. "」HP 端点 [") .. __TS__ArrayJoin(interval.hp, ", ")) .. "] 与节点 ") .. __TS__ArrayJoin(nodeIds, "→")) .. " 的 [") .. tostring(start.minionHp)) .. ", ") .. tostring(____end.minionHp)) .. "] 不一致"
            )
            expectTrue(
                nil,
                issues,
                "interval.atkEndpoint",
                interval.atk[1] == start.minionAtk and interval.atk[2] == ____end.minionAtk,
                ((((((((("区间「" .. interval.id) .. "」ATK 端点 [") .. __TS__ArrayJoin(interval.atk, ", ")) .. "] 与节点 ") .. __TS__ArrayJoin(nodeIds, "→")) .. " 的 [") .. tostring(start.minionAtk)) .. ", ") .. tostring(____end.minionAtk)) .. "] 不一致"
            )
            expectTrue(
                nil,
                issues,
                "interval.armorTier",
                interval.armorTier[1] == start.tier and interval.armorTier[2] == ____end.tier,
                ((((((("区间「" .. interval.id) .. "」护甲档 [") .. __TS__ArrayJoin(interval.armorTier, ", ")) .. "] 与节点档位 [") .. tostring(start.tier)) .. ", ") .. tostring(____end.tier)) .. "] 不一致"
            )
        end
        ::__continue14::
    end
end
--- 硬上限（数值文档 §3.4 / §9.1）与数值形态
function ____exports.checkHardLimits(self, data, issues)
    local ____data_1 = data
    local limits = ____data_1.limits
    expectTrue(
        nil,
        issues,
        "limits.values",
        limits.defRedMax == 0.75 and limits.critMax == 0.6 and limits.dodgeMax == 0.25 and limits.critDmgMax == 2.5,
        (((((("护卫常量被改动：defRedMax=" .. tostring(limits.defRedMax)) .. " critMax=") .. tostring(limits.critMax)) .. " dodgeMax=") .. tostring(limits.dodgeMax)) .. " critDmgMax=") .. tostring(limits.critDmgMax)
    )
    for ____, hero in ipairs(data.heroes) do
        expectTrue(
            nil,
            issues,
            "limits.heroCrit",
            hero.base.crit / 100 <= limits.critMax,
            ((((("英雄「" .. hero.id) .. "」会心 ") .. tostring(hero.base.crit)) .. "% 超过上限 ") .. tostring(limits.critMax * 100)) .. "%"
        )
        expectTrue(
            nil,
            issues,
            "limits.heroDodge",
            hero.base.dodge / 100 <= limits.dodgeMax,
            ((((("英雄「" .. hero.id) .. "」闪避 ") .. tostring(hero.base.dodge)) .. "% 超过上限 ") .. tostring(limits.dodgeMax * 100)) .. "%"
        )
        expectTrue(
            nil,
            issues,
            "limits.heroCritDmg",
            hero.base.critDmg <= limits.critDmgMax,
            (((("英雄「" .. hero.id) .. "」暴击伤害 ") .. tostring(hero.base.critDmg)) .. " 超过上限 ") .. tostring(limits.critDmgMax)
        )
    end
end
--- 数值非负且主要属性为整数（校验规则 5）
function ____exports.checkNumericShape(self, data, issues)
    for ____, hero in ipairs(data.heroes) do
        local b = hero.base
        expectTrue(
            nil,
            issues,
            "numeric.heroBase",
            __TS__ArrayEvery(
                {
                    b.hp,
                    b.mp,
                    b.atk,
                    b.sp,
                    b.def,
                    b.spd
                },
                function(____, v) return __TS__NumberIsInteger(v) and v >= 0 end
            ),
            ("英雄「" .. hero.id) .. "」的 HP/MP/ATK/SP/DEF/SPD 必须为非负整数"
        )
        expectTrue(
            nil,
            issues,
            "numeric.heroRange",
            __TS__ArrayEvery(
                {b.dodge, b.crit, b.critDmg},
                function(____, v) return v >= 0 end
            ),
            ("英雄「" .. hero.id) .. "」的闪避/会心/暴伤必须为非负"
        )
    end
    for ____, monster in ipairs(data.monsters) do
        local mul = monster.mul
        expectTrue(
            nil,
            issues,
            "numeric.monsterMul",
            __TS__ArrayEvery(
                {mul.hp, mul.atk, mul.def, mul.spd},
                function(____, v) return v > 0 end
            ),
            ("怪物「" .. monster.id) .. "」的属性系数必须为正数"
        )
        expectTrue(
            nil,
            issues,
            "numeric.monsterAtkSpeed",
            monster.attackSpeed > 0,
            ("怪物「" .. monster.id) .. "」攻击速度必须为正数"
        )
        if monster.class == "anchorBoss" then
            expectTrue(
                nil,
                issues,
                "numeric.bossHp",
                type(monster.targetHp4p) == "number" and monster.targetHp4p > 0,
                ("锚点 BOSS「" .. monster.id) .. "」缺少有效的 targetHp4p"
            )
        end
    end
end
--- 校验规则 6：成长线乘法（L(25) × R(太清) × E(T6) = L0 端点倍率）＋ 三线单调不减
function ____exports.checkGrowthMultipliers(self, data, index, issues)
    local first = index.node:get("N1")
    local last = index.node:get("N6")
    local taiqing = index.rank:get("taiqing")
    local e6 = index.eCurve:get(6)
    if not first or not last or not taiqing or not e6 then
        addError(nil, issues, "growth.missing", "成长校验缺少 N1/N6/太清/T6 定义")
        return
    end
    local segments = __TS__ArraySort(
        {table.unpack(data.level.segments)},
        function(____, a, b) return a.fromLevel - b.fromLevel end
    )
    local product = 1
    for ____, seg in ipairs(segments) do
        product = product * (1 + seg.perLevelPct) ^ (seg.toLevel - seg.fromLevel)
    end
    expectTrue(
        nil,
        issues,
        "growth.levelCurve",
        relError(nil, product, data.level.totalMul) <= 0.02,
        ((("等级分段累计倍率 " .. __TS__NumberToFixed(product, 4)) .. " 与登记的 totalMul ") .. tostring(data.level.totalMul)) .. " 偏差 > 2%"
    )
    do
        local i = 0
        while i < #segments do
            do
                local seg = segments[i + 1]
                local next = segments[i + 1 + 1]
                if not seg then
                    goto __continue36
                end
                if next then
                    expectTrue(
                        nil,
                        issues,
                        "growth.levelContinuous",
                        seg.toLevel == next.fromLevel,
                        (((((("等级分段不连续：" .. tostring(seg.fromLevel)) .. "-") .. tostring(seg.toLevel)) .. " 与 ") .. tostring(next.fromLevel)) .. "-") .. tostring(next.toLevel)
                    )
                    expectTrue(
                        nil,
                        issues,
                        "growth.levelDecel",
                        next.perLevelPct <= seg.perLevelPct,
                        (((((("等级增幅未递减：段 " .. tostring(next.fromLevel)) .. "-") .. tostring(next.toLevel)) .. " 增幅 ") .. tostring(next.perLevelPct)) .. " > 上段 ") .. tostring(seg.perLevelPct)
                    )
                end
            end
            ::__continue36::
            i = i + 1
        end
    end
    local l = data.level.totalMul
    local hpTotal = l * taiqing.hpMul * e6.hpMul
    local atkTotal = l * taiqing.atkMul * e6.atkMul
    expectTrue(
        nil,
        issues,
        "growth.hpProduct",
        relError(nil, hpTotal, last.heroHp / first.heroHp) <= 0.05,
        ((("L×R×E(HP) = " .. __TS__NumberToFixed(hpTotal, 3)) .. "，L0 端点 HP 倍率 ") .. __TS__NumberToFixed(last.heroHp / first.heroHp, 3)) .. "，偏差 > 5%"
    )
    expectTrue(
        nil,
        issues,
        "growth.atkProduct",
        relError(nil, atkTotal, last.heroAtk / first.heroAtk) <= 0.05,
        ((("L×R×E(ATK) = " .. __TS__NumberToFixed(atkTotal, 3)) .. "，L0 端点 ATK 倍率 ") .. __TS__NumberToFixed(last.heroAtk / first.heroAtk, 3)) .. "，偏差 > 5%"
    )
    local prevRank = 0
    for ____, rank in ipairs(data.ranks) do
        expectTrue(
            nil,
            issues,
            "growth.rankMonotonic",
            rank.hpMul >= prevRank,
            (((("境界「" .. rank.id) .. "」HP 倍率 ") .. tostring(rank.hpMul)) .. " 低于前一境界 ") .. tostring(prevRank)
        )
        prevRank = rank.hpMul
    end
    local prevHp = 0
    local prevAtk = 0
    for ____, tier in ipairs(ALL_TIERS) do
        do
            local row = index.eCurve:get(tier)
            if not row then
                goto __continue41
            end
            expectTrue(
                nil,
                issues,
                "growth.eMonotonic",
                row.hpMul >= prevHp and row.atkMul >= prevAtk,
                ((((("装备曲线 T" .. tostring(tier)) .. " 非单调不减（HP ") .. tostring(row.hpMul)) .. " / ATK ") .. tostring(row.atkMul)) .. "）"
            )
            prevHp = row.hpMul
            prevAtk = row.atkMul
        end
        ::__continue41::
    end
end
--- 校验规则 11：装备主属性 = E 曲线 − 1（法宝线承担 E_ATK）
function ____exports.checkECurveAlignment(self, data, index, issues)
    for ____, item in ipairs(data.equipment) do
        do
            if item.line ~= "weapon" then
                goto __continue45
            end
            local curve = index.eCurve:get(item.tier)
            if not curve then
                addError(
                    nil,
                    issues,
                    "eCurve.missingRow",
                    ((("装备「" .. item.id) .. "」档位 T") .. tostring(item.tier)) .. " 无 E 曲线行"
                )
                goto __continue45
            end
            local atkStat = __TS__ArrayFind(
                item.mainStats,
                function(____, s) return s.stat == "atk" end
            )
            if not atkStat or atkStat.mode ~= "percent" then
                addError(nil, issues, "eCurve.weaponStat", ("法宝「" .. item.id) .. "」缺少百分比形式的攻击主属性")
                goto __continue45
            end
            expectTrue(
                nil,
                issues,
                "eCurve.alignment",
                relError(nil, atkStat.value, curve.atkMul - 1) <= 0.03,
                ((((((("法宝「" .. item.id) .. "」攻击加成 ") .. __TS__NumberToFixed(atkStat.value * 100, 1)) .. "% 应等于 E_ATK(T") .. tostring(item.tier)) .. ") − 1 = ") .. __TS__NumberToFixed((curve.atkMul - 1) * 100, 1)) .. "%"
            )
        end
        ::__continue45::
    end
end
--- 校验规则 10：人数缩放自洽
function ____exports.checkPopulationSelfConsistency(self, data, issues)
    local ____data_2 = data
    local population = ____data_2.population
    local limits = ____data_2.limits
    for ____, n in ipairs({
        1,
        2,
        3,
        4,
        5,
        6
    }) do
        do
            local row = __TS__ArrayFind(
                population.table,
                function(____, r) return r.n == n end
            )
            if not row then
                addError(
                    nil,
                    issues,
                    "population.missing",
                    ("人数缩放表缺少 N=" .. tostring(n)) .. " 行"
                )
                goto __continue52
            end
            expectTrue(
                nil,
                issues,
                "population.product",
                relError(nil, row.hpMul * row.countMul, n) <= 0.05,
                (((("N=" .. tostring(n)) .. " 时 hpMul×countMul = ") .. __TS__NumberToFixed(row.hpMul * row.countMul, 3)) .. "，应约为 ") .. tostring(n)
            )
            expectTrue(
                nil,
                issues,
                "population.dmgConstant",
                row.dmgMul == 1,
                (("N=" .. tostring(n)) .. " 伤害乘数应为恒定 1.0，实际 ") .. tostring(row.dmgMul)
            )
        end
        ::__continue52::
    end
    local six = __TS__ArrayFind(
        population.table,
        function(____, r) return r.n == 6 end
    )
    if six then
        expectTrue(
            nil,
            issues,
            "population.countCap",
            six.countMul <= 2.2,
            ("N=6 数量乘数 " .. tostring(six.countMul)) .. " 超过护栏 2.2"
        )
    end
    local one = __TS__ArrayFind(
        population.table,
        function(____, r) return r.n == 1 end
    )
    if one then
        expectTrue(
            nil,
            issues,
            "population.baseline",
            one.hpMul == 1 and one.countMul == 1 and one.bossMul == 1,
            (((("N=1 应为基准行（hpMul/countMul/bossMul 全为 1），实际 " .. tostring(one.hpMul)) .. "/") .. tostring(one.countMul)) .. "/") .. tostring(one.bossMul)
        )
    end
    expectTrue(
        nil,
        issues,
        "population.screenCap",
        population.maxOnScreen <= limits.maxOnScreenMinions,
        (("population.maxOnScreen " .. tostring(population.maxOnScreen)) .. " 超过 limits.maxOnScreenMinions ") .. tostring(limits.maxOnScreenMinions)
    )
end
--- 品质表数值域（数值文档 §7.4）
function ____exports.checkQualityTable(self, data, issues)
    local expected = {lower = {1, 1}, middle = {1.15, 2}, upper = {1.3, 3}}
    for ____, quality in ipairs(data.qualities) do
        do
            local exp = expected[quality.id]
            if not exp then
                addError(nil, issues, "quality.unknown", ("未知品质 id「" .. quality.id) .. "」")
                goto __continue61
            end
            expectTrue(
                nil,
                issues,
                "quality.statMul",
                quality.statMul == exp[1],
                (((("品质「" .. quality.id) .. "」数值系数应为 ") .. tostring(exp[1])) .. "，实际 ") .. tostring(quality.statMul)
            )
            expectTrue(
                nil,
                issues,
                "quality.affixCount",
                quality.affixCount == exp[2],
                (((("品质「" .. quality.id) .. "」词条数应为 ") .. tostring(exp[2])) .. "，实际 ") .. tostring(quality.affixCount)
            )
        end
        ::__continue61::
    end
    for ____, id in ipairs({"lower", "middle", "upper"}) do
        expectTrue(
            nil,
            issues,
            "quality.complete",
            __TS__ArraySome(
                data.qualities,
                function(____, q) return q.id == id end
            ),
            ("品质表缺少「" .. id) .. "」行"
        )
    end
end
--- 词条池非空且与装备线匹配（M1 仅法宝线）
function ____exports.checkAffixPools(self, data, issues)
    local maxAffixes = math.max(table.unpack(__TS__ArrayMap(
        data.qualities,
        function(____, q) return q.affixCount end
    )))
    for ____, line in __TS__Iterator(__TS__New(
        Set,
        __TS__ArrayMap(
            data.equipment,
            function(____, e) return e.line end
        )
    )) do
        local pool = __TS__ArrayFilter(
            data.affixes,
            function(____, a) return a.line == line end
        )
        expectTrue(
            nil,
            issues,
            "affix.poolSize",
            #pool >= maxAffixes,
            ((((("装备线「" .. line) .. "」的词条池只有 ") .. tostring(#pool)) .. " 条，不足以支撑最高品质的 ") .. tostring(maxAffixes)) .. " 条词条"
        )
    end
end
return ____exports
 end,
["data.validate.reference"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFlatMap = ____lualib.__TS__ArrayFlatMap
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local Set = ____lualib.Set
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local Map = ____lualib.Map
local ____exports = {}
local ____issues = require("data.validate.issues")
local addError = ____issues.addError
local expectTrue = ____issues.expectTrue
--- 工具：收集所有效果原语（含境界强化的附加效果）
local function collectEffects(self, effects, extras)
    local ____array_0 = __TS__SparseArrayNew(table.unpack(effects))
    __TS__SparseArrayPush(
        ____array_0,
        table.unpack(__TS__ArrayFlatMap(
            extras or ({}),
            function(____, e) return e end
        ))
    )
    return {__TS__SparseArraySpread(____array_0)}
end
local function assertUniqueIds(self, issues, rule, ____table, ids)
    local seen = __TS__New(Set)
    for ____, id in ipairs(ids) do
        if seen:has(id) then
            addError(nil, issues, rule, ((____table .. " 存在重复 id「") .. id) .. "」")
        end
        seen:add(id)
    end
end
--- 各表主键唯一
function ____exports.checkUniqueIds(self, data, issues)
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "heroes",
        __TS__ArrayMap(
            data.heroes,
            function(____, h) return h.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "skills",
        __TS__ArrayMap(
            data.skills,
            function(____, s) return s.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "monsters",
        __TS__ArrayMap(
            data.monsters,
            function(____, m) return m.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "waveTemplates",
        __TS__ArrayMap(
            data.waveTemplates,
            function(____, t) return t.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "events",
        __TS__ArrayMap(
            data.events,
            function(____, e) return e.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "materials",
        __TS__ArrayMap(
            data.materials,
            function(____, m) return m.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "equipment",
        __TS__ArrayMap(
            data.equipment,
            function(____, e) return e.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "affixes",
        __TS__ArrayMap(
            data.affixes,
            function(____, a) return a.id end
        )
    )
    assertUniqueIds(
        nil,
        issues,
        "ref.uniqueId",
        "nodes",
        __TS__ArrayMap(
            data.nodes,
            function(____, n) return n.id end
        )
    )
end
--- 引用完整性（数值文档 校验规则 的「引用完整性」项）
function ____exports.checkReferences(self, data, index, issues)
    for ____, skill in ipairs(data.skills) do
        if not index.hero:has(skill.owner) and not index.monster:has(skill.owner) then
            addError(nil, issues, "ref.skillOwner", ((("技能「" .. skill.id) .. "」的 owner「") .. skill.owner) .. "」既不是英雄也不是怪物")
        end
    end
    for ____, hero in ipairs(data.heroes) do
        for ____, key in ipairs(__TS__ObjectKeys(hero.skills)) do
            do
                local skillId = hero.skills[key]
                local skill = index.skill:get(skillId)
                if not skill then
                    addError(nil, issues, "ref.heroSkill", ((((("英雄「" .. hero.id) .. "」的 ") .. key) .. " 指向不存在的技能「") .. skillId) .. "」")
                    goto __continue23
                end
                if skill.owner ~= hero.id then
                    addError(nil, issues, "ref.heroSkill", ((((((("英雄「" .. hero.id) .. "」的 ") .. key) .. " 技能「") .. skillId) .. "」owner 为「") .. skill.owner) .. "」，不一致")
                end
                if skill.key ~= key then
                    addError(
                        nil,
                        issues,
                        "ref.heroSkill",
                        ((((((("英雄「" .. hero.id) .. "」的 ") .. key) .. " 技能「") .. skillId) .. "」标注键位为「") .. tostring(skill.key)) .. "」，不一致"
                    )
                end
            end
            ::__continue23::
        end
    end
    for ____, monster in ipairs(data.monsters) do
        for ____, skillId in ipairs(monster.skills or ({})) do
            local skill = index.skill:get(skillId)
            if not skill then
                addError(nil, issues, "ref.monsterSkill", ((("怪物「" .. monster.id) .. "」引用了不存在的技能「") .. skillId) .. "」")
            elseif skill.owner ~= monster.id then
                addError(nil, issues, "ref.monsterSkill", ((((("怪物「" .. monster.id) .. "」的技能「") .. skillId) .. "」owner 为「") .. skill.owner) .. "」，不一致")
            end
        end
    end
    for ____, template in ipairs(data.waveTemplates) do
        for ____, group in ipairs(template.groups) do
            expectTrue(
                nil,
                issues,
                "ref.waveGroup",
                index.monster:has(group.monsterId),
                ((("模板「" .. template.id) .. "」引用了不存在的怪物「") .. group.monsterId) .. "」"
            )
        end
        if template.elite then
            expectTrue(
                nil,
                issues,
                "ref.waveElite",
                index.monster:has(template.elite.monsterId),
                ((("模板「" .. template.id) .. "」的精英引用了不存在的怪物「") .. template.elite.monsterId) .. "」"
            )
        end
        for ____, eventId in ipairs(template.eventHooks) do
            expectTrue(
                nil,
                issues,
                "ref.eventHook",
                index.event:has(eventId),
                ((("模板「" .. template.id) .. "」挂载了不存在的事件「") .. eventId) .. "」"
            )
        end
        for ____, monsterId in ipairs(template.waveBossPool) do
            expectTrue(
                nil,
                issues,
                "ref.waveBossPool",
                index.monster:has(monsterId),
                ((("模板「" .. template.id) .. "」的波次 BOSS 池含不存在的怪物「") .. monsterId) .. "」"
            )
        end
    end
    for ____, recipe in ipairs(data.recipes) do
        expectTrue(
            nil,
            issues,
            "ref.recipeMaterial",
            index.material:has(recipe.materialId),
            ((((((("配方 " .. recipe.line) .. " T") .. tostring(recipe.fromTier)) .. "→T") .. tostring(recipe.toTier)) .. " 引用了不存在的材料「") .. recipe.materialId) .. "」"
        )
        if recipe.scrollId then
            addError(
                nil,
                issues,
                "ref.recipeScroll",
                ((((((("配方 " .. recipe.line) .. " T") .. tostring(recipe.fromTier)) .. "→T") .. tostring(recipe.toTier)) .. " 声明了卷轴「") .. recipe.scrollId) .. "」，但 M1 未定义卷轴表"
            )
        end
    end
    for ____, row in ipairs(data.drops) do
        for ____, materialId in ipairs(row.materialPool) do
            expectTrue(
                nil,
                issues,
                "ref.dropMaterial",
                index.material:has(materialId),
                ((("掉落来源「" .. row.source) .. "」的材料池含不存在的材料「") .. materialId) .. "」"
            )
        end
    end
    local summoners = {}
    for ____, skill in ipairs(data.skills) do
        for ____, effect in ipairs(collectEffects(
            nil,
            skill.effects,
            __TS__ArrayMap(
                skill.upgrades or ({}),
                function(____, u) return u.extraEffects or ({}) end
            )
        )) do
            summoners[#summoners + 1] = {owner = ("技能「" .. skill.id) .. "」", effect = effect}
        end
    end
    for ____, affix in ipairs(data.affixes) do
        summoners[#summoners + 1] = {owner = ("词条「" .. affix.id) .. "」", effect = affix.effect}
    end
    for ____, ____value in ipairs(summoners) do
        local owner = ____value.owner
        local effect = ____value.effect
        if effect.kind == "summon" then
            expectTrue(
                nil,
                issues,
                "ref.summonTarget",
                index.monster:has(effect.monsterId),
                ((owner .. " 召唤了不存在的怪物「") .. effect.monsterId) .. "」"
            )
        end
    end
end
--- 配方无环（数值文档 校验规则 / 主文档 §6.13）
function ____exports.checkRecipeAcyclic(self, data, index, issues)
    local seen = __TS__New(Set)
    for ____, recipe in ipairs(data.recipes) do
        expectTrue(
            nil,
            issues,
            "recipe.tierOrder",
            recipe.fromTier < recipe.toTier,
            ((((("配方 " .. recipe.line) .. " T") .. tostring(recipe.fromTier)) .. "→T") .. tostring(recipe.toTier)) .. " 档位未递增（fromTier 必须 < toTier）"
        )
        local key = (recipe.line .. ":") .. tostring(recipe.fromTier)
        if seen:has(key) then
            addError(nil, issues, "recipe.duplicate", "同线同起始档存在重复配方：" .. key)
        end
        seen:add(key)
        local material = index.material:get(recipe.materialId)
        if material and material.line and material.line ~= recipe.line then
            addError(nil, issues, "recipe.materialLine", ((((("配方 " .. key) .. " 使用材料「") .. material.id) .. "」（") .. material.line) .. " 线），与配方线不一致")
        end
        if material and material.toTier ~= recipe.toTier then
            addError(
                nil,
                issues,
                "recipe.materialTier",
                (((((("配方 " .. key) .. " 目标档 T") .. tostring(recipe.toTier)) .. "，但材料「") .. material.id) .. "」的目标档为 T") .. tostring(material.toTier)
            )
        end
    end
end
--- 机制分组不重复 + BOSS 必登记机制（主文档 附录 B 配置约束）
function ____exports.checkMechanismGrouping(self, data, index, issues)
    for ____, monster in ipairs(data.monsters) do
        if monster.class == "waveBoss" or monster.class == "anchorBoss" then
            expectTrue(
                nil,
                issues,
                "mechanism.bossRegistered",
                monster.mechanism ~= nil and monster.mechanism ~= "none",
                ("BOSS「" .. monster.id) .. "」未登记机制档位（主文档 附录 B 要求每只 BOSS 至少命中一种机制）"
            )
            local ____expectTrue_4 = expectTrue
            local ____issues_3 = issues
            local ____opt_1 = monster.mechanismType
            ____expectTrue_4(
                nil,
                ____issues_3,
                "mechanism.bossTypes",
                (____opt_1 and #____opt_1 or 0) > 0,
                ("BOSS「" .. monster.id) .. "」未登记机制类型标签（mechanismType）"
            )
        end
    end
    for ____, template in ipairs(data.waveTemplates) do
        local ____array_5 = __TS__SparseArrayNew(table.unpack(__TS__ArrayMap(
            template.groups,
            function(____, g) return g.monsterId end
        )))
        __TS__SparseArrayPush(
            ____array_5,
            table.unpack(template.elite and ({template.elite.monsterId}) or ({}))
        )
        __TS__SparseArrayPush(
            ____array_5,
            table.unpack(template.waveBossPool)
        )
        local ids = {__TS__SparseArraySpread(____array_5)}
        local used = __TS__New(Map)
        for ____, id in ipairs(ids) do
            local monster = index.monster:get(id)
            for ____, tag in ipairs(monster and monster.mechanismType or ({})) do
                local previous = used:get(tag)
                if previous then
                    addError(nil, issues, "mechanism.duplicate", (((((("模板「" .. template.id) .. "」内机制「") .. tag) .. "」重复：") .. previous) .. " 与 ") .. id)
                else
                    used:set(tag, id)
                end
            end
        end
    end
end
return ____exports
 end,
["data.validate.index"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local ____exports = {}
local ____indexes = require("data.indexes")
local buildIndex = ____indexes.buildIndex
local ____economy = require("data.validate.economy")
local checkEconomy = ____economy.checkEconomy
local ____numeric = require("data.validate.numeric")
local checkAffixPools = ____numeric.checkAffixPools
local checkArmorKDerivation = ____numeric.checkArmorKDerivation
local checkECurveAlignment = ____numeric.checkECurveAlignment
local checkGrowthMultipliers = ____numeric.checkGrowthMultipliers
local checkHardLimits = ____numeric.checkHardLimits
local checkIntervalConsistency = ____numeric.checkIntervalConsistency
local checkNodeDerivation = ____numeric.checkNodeDerivation
local checkNumericShape = ____numeric.checkNumericShape
local checkPopulationSelfConsistency = ____numeric.checkPopulationSelfConsistency
local checkQualityTable = ____numeric.checkQualityTable
local checkTierArmorKComplete = ____numeric.checkTierArmorKComplete
local ____reference = require("data.validate.reference")
local checkMechanismGrouping = ____reference.checkMechanismGrouping
local checkRecipeAcyclic = ____reference.checkRecipeAcyclic
local checkReferences = ____reference.checkReferences
local checkUniqueIds = ____reference.checkUniqueIds
--- 依次执行全部启动校验规则，按 severity 分流为 error / warning。
-- 
-- 顺序刻意「由结构到数值」：先引用完整性、再数值形态与派生，便于错误按层级阅读。
-- 规则实现分文件（reference / numeric / economy），本函数只做编排，不承载具体判断。
function ____exports.validateGameData(self, data, index)
    local resolved = index or buildIndex(nil, data)
    local issues = {}
    checkUniqueIds(nil, data, issues)
    checkReferences(nil, data, resolved, issues)
    checkRecipeAcyclic(nil, data, resolved, issues)
    checkMechanismGrouping(nil, data, resolved, issues)
    checkTierArmorKComplete(nil, data, issues)
    checkArmorKDerivation(nil, data, issues)
    checkNodeDerivation(nil, data, resolved, issues)
    checkIntervalConsistency(nil, data, resolved, issues)
    checkHardLimits(nil, data, issues)
    checkNumericShape(nil, data, issues)
    checkGrowthMultipliers(nil, data, resolved, issues)
    checkECurveAlignment(nil, data, resolved, issues)
    checkPopulationSelfConsistency(nil, data, issues)
    checkQualityTable(nil, data, issues)
    checkAffixPools(nil, data, issues)
    checkEconomy(nil, data, issues)
    return {
        errors = __TS__ArrayFilter(
            issues,
            function(____, issue) return issue.severity == "error" end
        ),
        warnings = __TS__ArrayFilter(
            issues,
            function(____, issue) return issue.severity == "warn" end
        )
    }
end
return ____exports
 end,
["data.load"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____indexes = require("data.indexes")
local buildIndex = ____indexes.buildIndex
local ____tables = require("data.tables.index")
local buildGameData = ____tables.buildGameData
local ____validate = require("data.validate.index")
local validateGameData = ____validate.validateGameData
local ____issues = require("data.validate.issues")
local ConfigError = ____issues.ConfigError
--- data 层唯一入口：装配 M1 子集配置 → 建索引 → 启动校验。
-- 
-- 校验规则中 `error`（结构 / 引用 / 硬上限越界）fail fast 直接抛 `ConfigError`；
-- `warn`（节奏带 / 经验对齐等调参偏差）仅随结果返回，不阻断启动。
-- 
-- @param data 允许注入自定义配置（测试用于构造损坏数据验证 fail fast）
function ____exports.loadGameData(self, data)
    if data == nil then
        data = buildGameData(nil)
    end
    local index = buildIndex(nil, data)
    local ____validateGameData_result_0 = validateGameData(nil, data, index)
    local errors = ____validateGameData_result_0.errors
    local warnings = ____validateGameData_result_0.warnings
    if #errors > 0 then
        error(
            __TS__New(ConfigError, errors),
            0
        )
    end
    return {data = data, index = index, warnings = warnings}
end
return ____exports
 end,
["logic.core.rng"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local ____exports = {}
--- 32 位回绕原语。
-- 
-- 为什么不用 `>>> / | / & / ^ / Math.imul`：这些写法依赖 JS 的 ToUint32 / ToInt32 语义，
-- 而 **TSTL 在 `luaTarget: 5.3` 下把 `>>>` 直接编译成 Lua 原生 `>>`**（64 位算术右移），
-- 且 Lua 5.3 没有 `bit32` 库——于是 `x >>> 0` 在 Lua 里退化成恒等，状态不再回绕，
-- `next()` 会越界返回 >1 的值。`Math.imul` 更是直接被 TSTL 判为 unsupported。
-- 
-- 因此这里改用**只依赖 `+ - * / %` 与取整**的等价写法：mulberry32 的全部运算只要求
-- 「按 2^32 取模后的位模式」，而这些写法在 JS（IEEE double，值域 ≤ 2^33，精确）与
-- Lua（64 位整数，同值域精确）下**逐位一致**，从而 vitest 与地图内跑出同一条随机流。
local UINT32_RANGE = 4294967296
--- 折到 [0, 2^32)：JS `x >>> 0` 的等价物，且对负数也安全
local function toUint32(self, x)
    return math.floor((x % UINT32_RANGE + UINT32_RANGE) % UINT32_RANGE)
end
--- 逻辑右移：输入按无符号解释（非负），除以 2 的幂是精确运算
local function shiftRight(self, x, bits)
    return math.floor(x / 2 ^ bits)
end
--- 按位异或（输入输出均按无符号 32 位解释）
local function xor32(self, a, b)
    return toUint32(nil, a ~ b)
end
--- 按位或（输入输出均按无符号 32 位解释）
local function or32(self, a, b)
    return toUint32(nil, a | b)
end
--- 32 位乘法（等价 `Math.imul` 的位模式）：16 位拆分，避免乘积溢出精确整数范围
local function mul32(self, a, b)
    local aLow = a % 65536
    local aHigh = math.floor(a / 65536) % 65536
    local bLow = b % 65536
    local bHigh = math.floor(b / 65536) % 65536
    local low = aLow * bLow
    local cross = (aHigh * bLow + aLow * bHigh) % 65536
    return toUint32(nil, low + cross * 65536)
end
--- 整数混合，用于把 seed 与 salt 揉成一个新 seed
local function mixSeed(self, seed, salt)
    local h = xor32(
        nil,
        seed,
        mul32(
            nil,
            toUint32(nil, salt + 1),
            2654435769
        )
    )
    h = mul32(
        nil,
        xor32(
            nil,
            h,
            shiftRight(nil, h, 16)
        ),
        2246822507
    )
    h = mul32(
        nil,
        xor32(
            nil,
            h,
            shiftRight(nil, h, 13)
        ),
        3266489909
    )
    return xor32(
        nil,
        h,
        shiftRight(nil, h, 16)
    )
end
____exports.Rng = __TS__Class()
local Rng = ____exports.Rng
Rng.name = "Rng"
function Rng.prototype.____constructor(self, seed)
    self.seed = toUint32(nil, seed)
    self.state = self.seed
end
function Rng.prototype.nextUint(self)
    self.state = toUint32(nil, self.state + 1831565813)
    local t = self.state
    t = mul32(
        nil,
        xor32(
            nil,
            t,
            shiftRight(nil, t, 15)
        ),
        or32(nil, t, 1)
    )
    t = xor32(
        nil,
        t,
        toUint32(
            nil,
            t + mul32(
                nil,
                xor32(
                    nil,
                    t,
                    shiftRight(nil, t, 7)
                ),
                or32(nil, t, 61)
            )
        )
    )
    return xor32(
        nil,
        t,
        shiftRight(nil, t, 14)
    )
end
function Rng.prototype.next(self)
    return self:nextUint() / 4294967296
end
function Rng.prototype.int(self, min, max)
    return min + math.floor(self:next() * (max - min + 1))
end
function Rng.prototype.range(self, min, max)
    return min + self:next() * (max - min)
end
function Rng.prototype.chance(self, p)
    return self:next() < p
end
function Rng.prototype.pick(self, items)
    if #items == 0 then
        error(
            __TS__New(Error, "Rng.pick: 不能从空数组中抽取"),
            0
        )
    end
    return items[math.floor(self:next() * #items) + 1]
end
function Rng.prototype.weighted(self, entries)
    local total = __TS__ArrayReduce(
        entries,
        function(____, sum, ____bindingPattern0)
            local w
            w = ____bindingPattern0[2]
            return sum + math.max(0, w)
        end,
        0
    )
    if total <= 0 then
        error(
            __TS__New(Error, "Rng.weighted: 总权重必须为正数"),
            0
        )
    end
    local roll = self:next() * total
    for ____, ____value in ipairs(entries) do
        local item = ____value[1]
        local weight = ____value[2]
        roll = roll - math.max(0, weight)
        if roll < 0 then
            return item
        end
    end
    do
        local i = #entries - 1
        while i >= 0 do
            local entry = entries[i + 1]
            if entry[2] > 0 then
                return entry[1]
            end
            i = i - 1
        end
    end
    error(
        __TS__New(Error, "Rng.weighted: 无可选正权重项"),
        0
    )
end
function Rng.prototype.fork(self, salt)
    return __TS__New(
        ____exports.Rng,
        mixSeed(nil, self.seed, salt)
    )
end
return ____exports
 end,
["logic.crafting.craftEngine"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local ____exports = {}
local ____indexes = require("data.indexes")
local recipeKey = ____indexes.recipeKey
--- 品质掉落权重（主文档 C.1 / 数值文档 §7.4）：下品 60% / 中品 30% / 上品 10%
____exports.QUALITY_DROP_WEIGHTS = {lower = 0.6, middle = 0.3, upper = 0.1}
____exports.CraftEngine = __TS__Class()
local CraftEngine = ____exports.CraftEngine
CraftEngine.name = "CraftEngine"
function CraftEngine.prototype.____constructor(self, data, index)
    self.data = data
    self.index = index
end
function CraftEngine.prototype.canCraft(self, recipe, bag)
    if not self.index.recipe:has(recipeKey(nil, recipe.line, recipe.fromTier)) then
        return "unknownRecipe"
    end
    if not self:findEquipment(recipe.line, recipe.toTier) then
        return "noRecipeTarget"
    end
    if bag.gold < recipe.gold then
        return "gold"
    end
    if bag.spirit < recipe.spirit then
        return "spirit"
    end
    if (bag.materials:get(recipe.materialId) or 0) < recipe.materialCount then
        return "material"
    end
    if recipe.requiresSourceItem and not self:hasSourceItem(recipe.line, recipe.fromTier, bag) then
        return "sourceItem"
    end
    return nil
end
function CraftEngine.prototype.craft(self, recipe, bag, rng)
    local rejection = self:canCraft(recipe, bag)
    if rejection ~= nil then
        return {ok = false, reason = rejection}
    end
    local target = self:findEquipment(recipe.line, recipe.toTier)
    if not target then
        return {ok = false, reason = "noRecipeTarget"}
    end
    local quality = self:rollQuality(rng)
    local ____opt_0 = self.index.quality:get(quality)
    local affixCount = ____opt_0 and ____opt_0.affixCount or 0
    local affixes = self:rollAffixes(recipe.line, affixCount, rng)
    local materials = __TS__New(Map, bag.materials)
    materials:set(
        recipe.materialId,
        (materials:get(recipe.materialId) or 0) - recipe.materialCount
    )
    local items = {table.unpack(bag.items)}
    if recipe.requiresSourceItem then
        local source = self:findEquipment(recipe.line, recipe.fromTier)
        local sourceAt = source and __TS__ArrayIndexOf(items, source.id) or -1
        if sourceAt >= 0 then
            __TS__ArraySplice(items, sourceAt, 1)
        end
    end
    return {ok = true, item = {
        defId = target.id,
        line = target.line,
        tier = target.tier,
        quality = quality,
        affixes = affixes
    }, bag = {gold = bag.gold - recipe.gold, spirit = bag.spirit - recipe.spirit, materials = materials, items = items}}
end
function CraftEngine.prototype.rollQuality(self, rng)
    local lower = ____exports.QUALITY_DROP_WEIGHTS.lower
    local middle = ____exports.QUALITY_DROP_WEIGHTS.middle
    local roll = rng:next()
    if roll < lower then
        return "lower"
    end
    if roll < lower + middle then
        return "middle"
    end
    return "upper"
end
function CraftEngine.prototype.rollAffixes(self, line, count, rng)
    if count <= 0 then
        return {}
    end
    local remaining = __TS__ArrayMap(
        __TS__ArrayFilter(
            self.data.affixes,
            function(____, a) return a.line == line end
        ),
        function(____, a) return a.id end
    )
    local picked = {}
    while #picked < count and #remaining > 0 do
        local chosen = rng:pick(remaining)
        __TS__ArraySplice(
            remaining,
            __TS__ArrayIndexOf(remaining, chosen),
            1
        )
        picked[#picked + 1] = chosen
    end
    return picked
end
function CraftEngine.prototype.findEquipment(self, line, tier)
    return __TS__ArrayFind(
        self.data.equipment,
        function(____, e) return e.line == line and e.tier == tier end
    )
end
function CraftEngine.prototype.hasSourceItem(self, line, fromTier, bag)
    local source = self:findEquipment(line, fromTier)
    return source ~= nil and __TS__ArrayIncludes(bag.items, source.id)
end
return ____exports
 end,
["logic.economy.economy"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
--- 双货币钱包：金币（∝ 人数）+ 灵石（全局掉落）。
-- 
-- 余额对外**只读暴露**（`gold` / `spirit` getter），变更只能经 `addGold` /
-- `addSpirit` / `spend` 三个受控入口，避免外部随意改账。
____exports.Wallet = __TS__Class()
local Wallet = ____exports.Wallet
Wallet.name = "Wallet"
function Wallet.prototype.____constructor(self, init)
    if init == nil then
        init = {}
    end
    self.goldAmount = init.gold or 0
    self.spiritAmount = init.spirit or 0
end
function Wallet.prototype.addGold(self, amount)
    self.goldAmount = self.goldAmount + amount
    return self.goldAmount
end
function Wallet.prototype.addSpirit(self, amount)
    self.spiritAmount = self.spiritAmount + amount
    return self.spiritAmount
end
function Wallet.prototype.canAfford(self, gold, spirit)
    return self.goldAmount >= gold and self.spiritAmount >= spirit
end
function Wallet.prototype.spend(self, gold, spirit)
    if not self:canAfford(gold, spirit) then
        return false
    end
    self.goldAmount = self.goldAmount - gold
    self.spiritAmount = self.spiritAmount - spirit
    return true
end
__TS__SetDescriptor(
    Wallet.prototype,
    "gold",
    {get = function(self)
        return self.goldAmount
    end},
    true
)
__TS__SetDescriptor(
    Wallet.prototype,
    "spirit",
    {get = function(self)
        return self.spiritAmount
    end},
    true
)
--- 等级追踪器：维护当前等级与经验，按 §8.4 曲线逐级结算。
-- 
-- 每级需求 `need(L) = floor(base × growth^(L−1))`（数值文档 §8.4：need(L)=30×1.2^(L−1)）。
____exports.LevelTracker = __TS__Class()
local LevelTracker = ____exports.LevelTracker
LevelTracker.name = "LevelTracker"
function LevelTracker.prototype.____constructor(self, need, maxLevel)
    self.need = need
    self.maxLevel = maxLevel
    self.currentLevel = 1
    self.currentXp = 0
end
function LevelTracker.prototype.gainXp(self, amount)
    if amount <= 0 or self.currentLevel >= self.maxLevel then
        return 0
    end
    self.currentXp = self.currentXp + amount
    local gained = 0
    while self.currentLevel < self.maxLevel and self.currentXp >= self.xpToNext do
        self.currentXp = self.currentXp - self.xpToNext
        self.currentLevel = self.currentLevel + 1
        gained = gained + 1
    end
    if self.currentLevel >= self.maxLevel then
        self.currentXp = 0
    end
    return gained
end
__TS__SetDescriptor(
    LevelTracker.prototype,
    "level",
    {get = function(self)
        return self.currentLevel
    end},
    true
)
__TS__SetDescriptor(
    LevelTracker.prototype,
    "xp",
    {get = function(self)
        return self.currentXp
    end},
    true
)
__TS__SetDescriptor(
    LevelTracker.prototype,
    "xpToNext",
    {get = function(self)
        return math.floor(self.need.base * self.need.growth ^ (self.currentLevel - 1))
    end},
    true
)
--- 小怪经验：`XP = minionBase + tier × perTier`（数值文档 §8.4 / 附录 C.1）
function ____exports.minionXp(self, tier, xp)
    return xp.minionBase + tier * xp.perTier
end
--- 按掉落来源折算经验：小怪 ×1 / 精英 ×eliteMul / BOSS ×bossMul
-- （数值文档 §8.4：精英 ×5、BOSS ×20；波次 BOSS 与锚点 BOSS 同乘 bossMul）。
function ____exports.sourceXp(self, source, tier, xpRule)
    local base = ____exports.minionXp(nil, tier, xpRule)
    repeat
        local ____switch20 = source
        local ____cond20 = ____switch20 == "minion"
        if ____cond20 then
            return base
        end
        ____cond20 = ____cond20 or ____switch20 == "elite"
        if ____cond20 then
            return base * xpRule.eliteMul
        end
        ____cond20 = ____cond20 or (____switch20 == "waveBoss" or ____switch20 == "anchorBoss")
        if ____cond20 then
            return base * xpRule.bossMul
        end
    until true
end
--- 单波金币收入（按幕阶跃，数值文档 §8.1）
function ____exports.waveGold(self, act, economy)
    return economy.goldPerWave[act]
end
--- 单次掉落金币：`int(goldBase) × goldMul × players`
-- （主文档 附录 C.1：小怪基础 1–3 且 ∝ 人数，倍率按来源递增）。
function ____exports.dropGold(self, row, players, rng)
    return rng:int(row.goldBase[1], row.goldBase[2]) * row.goldMul * players
end
--- 材料掉率：`row.materialChance >= 0` 时用行内覆盖值，否则（-1）沿用
-- `economy.materialDropChance` 的按幕递减基础掉率（数值文档 §8.3）。
function ____exports.materialDropChance(self, row, act, economy)
    return row.materialChance >= 0 and row.materialChance or economy.materialDropChance[act]
end
--- 材料掉落 roll：按 `materialDropChance` 判定命中后，从 `row.materialPool`
-- 等概率取一个材料 id，否则返回 null。
-- 
-- 退化处理：`materialPool` 为空时无可掉之物，直接返回 null（且不消耗随机数），
-- 避免 `rng.pick` 对空数组抛错——配置层应保证非空池，此处仅作防御。
function ____exports.rollMaterial(self, row, act, economy, rng)
    if #row.materialPool == 0 then
        return nil
    end
    if not rng:chance(____exports.materialDropChance(nil, row, act, economy)) then
        return nil
    end
    return rng:pick(row.materialPool)
end
return ____exports
 end,
["logic.events.eventDirector"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local ____exports = {}
--- 幕次先后序（用于 minAct 门控比较）
local ACT_ORDER = {"act1", "act2", "act3"}
--- 参与保底加权的稀有度
local PITY_RARITIES = {"rare", "epic"}
--- 默认参数：act2 取 act1/act3 的线性插值
____exports.DEFAULT_EVENT_CONFIG = {injectionChance = {act1 = 0.35, act2 = 0.425, act3 = 0.5}, pityWaves = 3, pityStep = 0.5, pityMaxMul = 2}
____exports.EventDirector = __TS__Class()
local EventDirector = ____exports.EventDirector
EventDirector.name = "EventDirector"
function EventDirector.prototype.____constructor(self, index, config)
    if config == nil then
        config = ____exports.DEFAULT_EVENT_CONFIG
    end
    self.index = index
    self.wave = 0
    self.lastFired = __TS__New(Map)
    self.config = config
end
function EventDirector.prototype.roll(self, templateId, act, rng)
    self.wave = self.wave + 1
    local chance = self.config.injectionChance[act] or 0
    if rng:next() >= chance then
        return {event = nil, timingDelta = 0}
    end
    local pool = self:available(templateId, act)
    if #pool == 0 then
        return {event = nil, timingDelta = 0}
    end
    local event = self:select(pool, rng)
    self.lastFired:set(event.id, self.wave)
    local ____event_effect_0 = event.effect
    local earlySeconds = ____event_effect_0.earlySeconds
    local lateSeconds = ____event_effect_0.lateSeconds
    local timingDelta = rng:next() < 0.5 and -earlySeconds or lateSeconds
    return {event = event, timingDelta = timingDelta}
end
function EventDirector.prototype.available(self, templateId, act)
    local template = self.index.template:get(templateId)
    if not template then
        return {}
    end
    return __TS__ArrayFilter(
        __TS__ArrayMap(
            template.eventHooks,
            function(____, id) return self.index.event:get(id) end
        ),
        function(____, event) return event ~= nil and self:isAvailable(event, act) end
    )
end
function EventDirector.prototype.effectiveWeight(self, event)
    if not __TS__ArrayIncludes(PITY_RARITIES, event.rarity) then
        return event.weight
    end
    local last = self.lastFired:get(event.id) or 0
    local steps = math.floor((self.wave - last) / self.config.pityWaves)
    local mul = math.min(1 + steps * self.config.pityStep, self.config.pityMaxMul)
    return event.weight * mul
end
function EventDirector.prototype.isAvailable(self, event, act)
    if __TS__ArrayIndexOf(ACT_ORDER, event.minAct) > __TS__ArrayIndexOf(ACT_ORDER, act) then
        return false
    end
    local last = self.lastFired:get(event.id)
    return last == nil or self.wave - last > event.cooldown
end
function EventDirector.prototype.select(self, pool, rng)
    local entries = __TS__ArrayMap(
        pool,
        function(____, event) return {
            event,
            self:effectiveWeight(event)
        } end
    )
    local total = __TS__ArrayReduce(
        entries,
        function(____, sum, ____bindingPattern0)
            local weight
            weight = ____bindingPattern0[2]
            return sum + weight
        end,
        0
    )
    local roll = rng:next() * total
    for ____, ____value in ipairs(entries) do
        local event = ____value[1]
        local weight = ____value[2]
        roll = roll - weight
        if roll < 0 then
            return event
        end
    end
    return entries[#entries][1]
end
return ____exports
 end,
["logic.growth.growth"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
--- 等级倍率：从 1 级升到 `level` 级的累计增幅。
-- 
-- 分段递增为**递减式**（§4.4）：早期升级快、后期慢；超出 maxLevel 后封顶，
-- 低于 1 级按 1 级处理（保证恒 ≥ 1）。
function ____exports.levelMultiplier(self, level, levelDef)
    local target = math.min(
        math.max(
            1,
            math.floor(level)
        ),
        levelDef.maxLevel
    )
    local mul = 1
    do
        local step = 1
        while step < target do
            local segment = __TS__ArrayFind(
                levelDef.segments,
                function(____, s) return step >= s.fromLevel and step < s.toLevel end
            )
            mul = mul * (1 + (segment and segment.perLevelPct or 0))
            step = step + 1
        end
    end
    return mul
end
--- 技能点：每 `skillPointEvery` 级 1 点（§4.4）
function ____exports.skillPointsFor(self, level, levelDef)
    local target = math.min(
        math.max(
            1,
            math.floor(level)
        ),
        levelDef.maxLevel
    )
    return math.floor(target / levelDef.skillPointEvery)
end
--- 结算成长后属性：HP / ATK / SP 乘 L×R，其余属性保持基线。
-- 
-- 结果向下取整（对齐「属性显示向下取整」的数值口径）。
-- 装备与临时修饰由 `ModifierSet.resolveStats()` 在此基础上叠加。
function ____exports.resolveGrowthStats(self, base, level, levelDef, rank)
    local mul = ____exports.levelMultiplier(nil, level, levelDef)
    local stats = __TS__ObjectAssign({}, base)
    stats.hp = math.floor(base.hp * mul * rank.hpMul)
    stats.atk = math.floor(base.atk * mul * rank.atkMul)
    stats.sp = math.floor(base.sp * mul * rank.atkMul)
    return stats
end
return ____exports
 end,
["logic.objective.anchorChallenge"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
____exports.AnchorChallenge = __TS__Class()
local AnchorChallenge = ____exports.AnchorChallenge
AnchorChallenge.name = "AnchorChallenge"
function AnchorChallenge.prototype.____constructor(self)
    self.state = "idle"
    self.bossHpValue = 0
    self.remainingValue = 0
end
function AnchorChallenge.prototype.start(self, limitSeconds, bossMaxHp)
    self.state = "active"
    self.bossHpValue = bossMaxHp
    self.remainingValue = limitSeconds
end
function AnchorChallenge.prototype.damageBoss(self, amount)
    if self.state ~= "active" then
        return
    end
    self.bossHpValue = math.max(0, self.bossHpValue - amount)
    if self.bossHpValue <= 0 then
        self.state = "cleared"
    end
end
function AnchorChallenge.prototype.tick(self, dt)
    if self.state ~= "active" or dt <= 0 then
        return
    end
    self.remainingValue = self.remainingValue - dt
    if self.remainingValue <= 0 then
        self.state = "failed"
    end
end
__TS__SetDescriptor(
    AnchorChallenge.prototype,
    "status",
    {get = function(self)
        return self.state
    end},
    true
)
__TS__SetDescriptor(
    AnchorChallenge.prototype,
    "bossHp",
    {get = function(self)
        return self.bossHpValue
    end},
    true
)
__TS__SetDescriptor(
    AnchorChallenge.prototype,
    "remaining",
    {get = function(self)
        return self.remainingValue
    end},
    true
)
return ____exports
 end,
["logic.objective.coreTarget"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
--- 守护剑阵核心：一局的常规失败条件（设计文档 §二「守护目标 / 胜负规则」）。
-- 
-- 只维护耐久值与「是否被击破」两个事实，不决定耐久上限——`maxHp` 一律由组装层传入
-- （数值层不在此臆造数值）。纯逻辑，不 import Phaser，可确定性步进。
____exports.CoreTarget = __TS__Class()
local CoreTarget = ____exports.CoreTarget
CoreTarget.name = "CoreTarget"
function CoreTarget.prototype.____constructor(self, maxHp)
    self.maxHp = maxHp
    self.hpValue = maxHp
end
function CoreTarget.prototype.takeDamage(self, amount)
    self.hpValue = math.max(0, self.hpValue - amount)
end
__TS__SetDescriptor(
    CoreTarget.prototype,
    "hp",
    {get = function(self)
        return self.hpValue
    end},
    true
)
__TS__SetDescriptor(
    CoreTarget.prototype,
    "destroyed",
    {get = function(self)
        return self.hpValue <= 0
    end},
    true
)
return ____exports
 end,
["logic.objective.heroLife"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
--- 英雄生命：死亡与复活计时（设计文档 §二「英雄死亡」）。
-- 
-- 阵亡后进入 `deathTimer` 倒计时，归零自动复活并累计复活次数；复活秒数由调用方传入
-- （队友救援 / 碧瑶复活技等外部机制后续可复用），模块内不臆造默认值。
-- 纯逻辑，不 import Phaser。
____exports.HeroLife = __TS__Class()
local HeroLife = ____exports.HeroLife
HeroLife.name = "HeroLife"
function HeroLife.prototype.____constructor(self, reviveSeconds)
    self.alive = true
    self.deathTimerValue = 0
    self.reviveCount = 0
    self.reviveSeconds = reviveSeconds
end
function HeroLife.prototype.kill(self)
    if not self.alive then
        return
    end
    self.alive = false
    self.deathTimerValue = self.reviveSeconds
end
function HeroLife.prototype.tick(self, dt)
    if self.alive or dt <= 0 then
        return
    end
    self.deathTimerValue = self.deathTimerValue - dt
    if self.deathTimerValue <= 0 then
        self.deathTimerValue = 0
        self.alive = true
        self.reviveCount = self.reviveCount + 1
    end
end
__TS__SetDescriptor(
    HeroLife.prototype,
    "isAlive",
    {get = function(self)
        return self.alive
    end},
    true
)
__TS__SetDescriptor(
    HeroLife.prototype,
    "deathTimer",
    {get = function(self)
        return self.deathTimerValue
    end},
    true
)
__TS__SetDescriptor(
    HeroLife.prototype,
    "revives",
    {get = function(self)
        return self.reviveCount
    end},
    true
)
return ____exports
 end,
["logic.modifier.effects"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
function ____exports.isInstantEffect(self, spec)
    return spec.kind == "heal" or spec.kind == "knockback" or spec.kind == "summon"
end
--- 按类型拆分效果列表，保持各自原顺序
function ____exports.partitionEffects(self, specs)
    local persistent = {}
    local instant = {}
    for ____, spec in ipairs(specs) do
        if ____exports.isInstantEffect(nil, spec) then
            instant[#instant + 1] = spec
        else
            persistent[#persistent + 1] = spec
        end
    end
    return {persistent = persistent, instant = instant}
end
--- 判定效果极性。
-- 
-- 采用「由数值符号反推」的约定，不新增配置字段：
--  - statMod：value > 0 增益 / < 0 减益
--  - damageTakenMul：> 1 易伤（减益）/ < 1 减伤（增益）
--  - damageDealtMul：> 1 增伤（增益）/ < 1 削弱（减益）
--  - stackDamage：perStack > 0 增益 / < 0 减益
--  - root 恒为减益；lifesteal / shield / heal 恒为增益
--  - knockback / summon 为中立（位移与召唤本身不构成正负 buff）
function ____exports.effectPolarity(self, spec)
    repeat
        local ____switch9 = spec.kind
        local ____cond9 = ____switch9 == "statMod"
        if ____cond9 then
            return spec.value > 0 and "buff" or (spec.value < 0 and "debuff" or "neutral")
        end
        ____cond9 = ____cond9 or ____switch9 == "damageTakenMul"
        if ____cond9 then
            return spec.value > 1 and "debuff" or (spec.value < 1 and "buff" or "neutral")
        end
        ____cond9 = ____cond9 or ____switch9 == "damageDealtMul"
        if ____cond9 then
            return spec.value > 1 and "buff" or (spec.value < 1 and "debuff" or "neutral")
        end
        ____cond9 = ____cond9 or ____switch9 == "stackDamage"
        if ____cond9 then
            return spec.perStack > 0 and "buff" or (spec.perStack < 0 and "debuff" or "neutral")
        end
        ____cond9 = ____cond9 or ____switch9 == "root"
        if ____cond9 then
            return "debuff"
        end
        ____cond9 = ____cond9 or (____switch9 == "lifesteal" or ____switch9 == "shield" or ____switch9 == "heal")
        if ____cond9 then
            return "buff"
        end
        ____cond9 = ____cond9 or (____switch9 == "knockback" or ____switch9 == "summon")
        if ____cond9 then
            return "neutral"
        end
    until true
end
return ____exports
 end,
["logic.skills.skillState"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
____exports.SkillState = __TS__Class()
local SkillState = ____exports.SkillState
SkillState.name = "SkillState"
function SkillState.prototype.____constructor(self, init)
    self.cooldowns = __TS__New(Map)
    self.mp = init.mp
    self.maxMp = init.maxMp
end
function SkillState.prototype.cooldownRemaining(self, skillId)
    return self.cooldowns:get(skillId) or 0
end
function SkillState.prototype.isReady(self, skillId)
    return self:cooldownRemaining(skillId) <= 0
end
function SkillState.prototype.setCooldown(self, skillId, seconds)
    if seconds > 0 then
        self.cooldowns:set(skillId, seconds)
    end
end
function SkillState.prototype.tick(self, dt)
    if dt <= 0 then
        return
    end
    for ____, ____value in __TS__Iterator(self.cooldowns) do
        local skillId = ____value[1]
        local remaining = ____value[2]
        local next = remaining - dt
        if next <= 0 then
            self.cooldowns:delete(skillId)
        else
            self.cooldowns:set(skillId, next)
        end
    end
end
function SkillState.prototype.spend(self, cost)
    if self.mp < cost then
        return false
    end
    self.mp = self.mp - cost
    return true
end
function SkillState.prototype.restore(self, amount)
    self.mp = math.min(self.maxMp, self.mp + amount)
end
return ____exports
 end,
["logic.skills.skillEngine"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local ____exports = {}
local ____effects = require("logic.modifier.effects")
local partitionEffects = ____effects.partitionEffects
____exports.SkillEngine = __TS__Class()
local SkillEngine = ____exports.SkillEngine
SkillEngine.name = "SkillEngine"
function SkillEngine.prototype.____constructor(self, index)
    self.index = index
end
function SkillEngine.prototype.isUnlocked(self, skillId, rank)
    local skill = self.index.skill:get(skillId)
    if not skill then
        return false
    end
    return self:meetsRank(skill, rank)
end
function SkillEngine.prototype.resolve(self, skillId, rank)
    local skill = self.index.skill:get(skillId)
    if not skill then
        error(
            __TS__New(Error, ("技能引擎：未知技能「" .. skillId) .. "」"),
            0
        )
    end
    local ____opt_0 = skill.upgrades
    local upgrade = ____opt_0 and __TS__ArrayFind(
        skill.upgrades,
        function(____, u) return u.rank == rank end
    )
    local ____array_4 = __TS__SparseArrayNew(table.unpack(skill.effects))
    __TS__SparseArrayPush(
        ____array_4,
        table.unpack(upgrade and upgrade.extraEffects or ({}))
    )
    local effects = {__TS__SparseArraySpread(____array_4)}
    local ____partitionEffects_result_5 = partitionEffects(nil, effects)
    local persistent = ____partitionEffects_result_5.persistent
    local instant = ____partitionEffects_result_5.instant
    return {
        skill = skill,
        rate = upgrade and upgrade.rate or skill.rate or 1,
        effects = effects,
        persistent = persistent,
        instant = instant,
        shape = skill.shape,
        radius = skill.radius,
        range = skill.range,
        damageType = skill.damageType,
        mpCost = skill.mpCost,
        cooldown = skill.cooldown
    }
end
function SkillEngine.prototype.canCast(self, skillId, state, rank)
    local skill = self.index.skill:get(skillId)
    if not skill then
        return "unknown"
    end
    if not self:meetsRank(skill, rank) then
        return "rank"
    end
    if not state:isReady(skillId) then
        return "cooldown"
    end
    if state.mp < skill.mpCost then
        return "mp"
    end
    return nil
end
function SkillEngine.prototype.cast(self, skillId, state, rank)
    local skill = self.index.skill:get(skillId)
    if not skill then
        return {ok = false, reason = "unknown"}
    end
    if not self:meetsRank(skill, rank) then
        return {ok = false, reason = "rank"}
    end
    if not state:isReady(skillId) then
        return {ok = false, reason = "cooldown"}
    end
    if not state:spend(skill.mpCost) then
        return {ok = false, reason = "mp"}
    end
    state:setCooldown(skillId, skill.cooldown)
    return {
        ok = true,
        outcome = self:resolve(skillId, rank)
    }
end
function SkillEngine.prototype.meetsRank(self, skill, rank)
    if not skill.requiresRank then
        return true
    end
    local order = {__TS__Spread(self.index.rank:keys())}
    local current = __TS__ArrayIndexOf(order, rank)
    local required = __TS__ArrayIndexOf(order, skill.requiresRank)
    return current >= 0 and required >= 0 and current >= required
end
return ____exports
 end,
["logic.waves.waveDirector"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local ____exports = {}
local clamp01
function clamp01(self, value)
    return math.min(
        math.max(value, 0),
        1
    )
end
--- 锚点 BOSS / 野区 BOSS 的 HP 以「全队 4 人等效」为基准（数值文档 §6.1）
____exports.ANCHOR_REFERENCE_PLAYERS = 4
--- 区间内按几何插值取小怪 HP / ATK（端点严格落在 L0 锚点）
function ____exports.intervalStatsAt(self, interval, u)
    local t = clamp01(nil, u)
    return {hp = interval.hp[1] * (interval.hp[2] / interval.hp[1]) ^ t, atk = interval.atk[1] * (interval.atk[2] / interval.atk[1]) ^ t}
end
--- 区间内就近取档：区间Ⅰ恒 T1；后半段逐级上移，终点即锚点档位（数值文档 §5.1）
function ____exports.tierAt(self, interval, u)
    --- 区间起止的**护甲档**（= L0 节点序号，决定标准 DEF 与 K 表引用）。
    -- 
    -- 注意：数值文档 §5.1 表格里的「档位」是**内容/装备档**（另一套刻度，§4.7 用），
    -- 与护甲档不同源；本字段专用于 DEF / K 推导，避免两套刻度混用。
    local from, to = table.unpack(interval.armorTier, 1, 2)
    local tier = from + math.floor(clamp01(nil, u) * (to - from))
    return math.min(tier, to)
end
____exports.WaveDirector = __TS__Class()
local WaveDirector = ____exports.WaveDirector
WaveDirector.name = "WaveDirector"
function WaveDirector.prototype.____constructor(self, data, index)
    self.data = data
    self.index = index
    self.maxPlayers = math.max(__TS__Spread(index.population:keys()))
end
function WaveDirector.prototype.pickTemplate(self, act, rng, exclude)
    local pool = __TS__ArrayFilter(
        self.data.waveTemplates,
        function(____, t) return t.layer == act end
    )
    if #pool == 0 then
        error(
            __TS__New(Error, ("波次导演：幕「" .. act) .. "」没有可用模板"),
            0
        )
    end
    local candidates = __TS__ArrayFilter(
        pool,
        function(____, t) return t.id ~= exclude end
    )
    return rng:pick(#candidates > 0 and candidates or pool).id
end
function WaveDirector.prototype.plan(self, request)
    local template = self.index.template:get(request.templateId)
    if not template then
        error(
            __TS__New(Error, ("波次导演：未知模板「" .. request.templateId) .. "」"),
            0
        )
    end
    if template.layer ~= request.act then
        error(
            __TS__New(Error, ((((("波次导演：模板「" .. template.id) .. "」属于 ") .. template.layer) .. "，与幕「") .. request.act) .. "」不符"),
            0
        )
    end
    local interval = self:intervalForAct(request.act)
    local players = self:clampPlayers(request.players)
    local pop = self:populationRow(players)
    local base = ____exports.intervalStatsAt(nil, interval, request.progress)
    local tier = ____exports.tierAt(nil, interval, request.progress)
    local groups = {}
    local totalCount = 0
    for ____, group in ipairs(template.groups) do
        local monster = self:requireMonster(group.monsterId)
        local count = math.max(
            1,
            math.floor(group.count * pop.countMul + 0.5)
        )
        local hp = base.hp * monster.mul.hp * pop.hpMul
        local atk = base.atk * monster.mul.atk
        groups[#groups + 1] = self:spawnGroup(
            monster,
            count,
            hp,
            atk,
            tier,
            false,
            false
        )
        totalCount = totalCount + count
    end
    if template.elite then
        local ____template_elite_0 = template.elite
        local min = ____template_elite_0.min
        local max = ____template_elite_0.max
        local monsterId = ____template_elite_0.monsterId
        local monster = self:requireMonster(monsterId)
        local rolled = request.rng and request.rng:int(min, max) or min
        local count = math.floor(rolled * pop.countMul + 0.5)
        if count > 0 then
            local hp = base.hp * monster.mul.hp * pop.hpMul
            local atk = base.atk * monster.mul.atk
            groups[#groups + 1] = self:spawnGroup(
                monster,
                count,
                hp,
                atk,
                tier,
                true,
                false
            )
            totalCount = totalCount + count
        end
    end
    return {
        templateId = template.id,
        interval = interval.id,
        tier = tier,
        progress = clamp01(nil, request.progress),
        players = players,
        groups = groups,
        totalCount = totalCount
    }
end
function WaveDirector.prototype.spawn(self, monsterId, request)
    local monster = self:requireMonster(monsterId)
    local interval = self:intervalForAct(request.act)
    local pop = self:populationRow(self:clampPlayers(request.players))
    local base = ____exports.intervalStatsAt(nil, interval, request.progress)
    local tier = request.tier or ____exports.tierAt(nil, interval, request.progress)
    local count = math.max(
        1,
        math.floor((request.count or 1) * pop.countMul + 0.5)
    )
    local hp = base.hp * monster.mul.hp * pop.hpMul
    local atk = base.atk * monster.mul.atk
    local ____self_spawnGroup_3 = self.spawnGroup
    local ____request_isElite_1 = request.isElite
    if ____request_isElite_1 == nil then
        ____request_isElite_1 = false
    end
    local ____request_isBoss_2 = request.isBoss
    if ____request_isBoss_2 == nil then
        ____request_isBoss_2 = false
    end
    return ____self_spawnGroup_3(
        self,
        monster,
        count,
        hp,
        atk,
        tier,
        ____request_isElite_1,
        ____request_isBoss_2
    )
end
function WaveDirector.prototype.anchorBoss(self, monsterId, players, act)
    if act == nil then
        act = "act1"
    end
    local monster = self:requireMonster(monsterId)
    if monster.class ~= "anchorBoss" or monster.targetHp4p == nil then
        error(
            __TS__New(Error, ("波次导演：怪物「" .. monsterId) .. "」不是已登记 targetHp4p 的锚点 BOSS"),
            0
        )
    end
    local interval = self:intervalForAct(act)
    local pop = self:populationRow(self:clampPlayers(players))
    local base = ____exports.intervalStatsAt(nil, interval, 1)
    local tier = monster.tierOverride or ____exports.tierAt(nil, interval, 1)
    local mechanism = self.data.mechanismMul[monster.mechanism or "none"]
    local hp = monster.targetHp4p / ____exports.ANCHOR_REFERENCE_PLAYERS * pop.bossMul * mechanism
    local atk = base.atk * monster.mul.atk
    return self:spawnGroup(
        monster,
        1,
        hp,
        atk,
        tier,
        false,
        true
    )
end
function WaveDirector.prototype.spawnGroup(self, monster, count, hp, atk, tier, isElite, isBoss)
    local minionDef = self:tierArmorK(tier).standardDef * self.data.derivation.minion.defRatio
    local stats = {
        hp = hp,
        mp = 0,
        atk = atk,
        sp = atk,
        def = minionDef * monster.mul.def,
        spd = self.data.derivation.minion.spd * monster.mul.spd,
        dodge = 0,
        crit = 0,
        critDmg = 1
    }
    local ____monster_id_5 = monster.id
    local ____monster_name_6 = monster.name
    local ____count_7 = count
    local ____isElite_8 = isElite
    local ____isBoss_9 = isBoss
    local ____stats_10 = stats
    local ____tier_11 = tier
    local ____temp_12 = monster.armorKMult or 1
    local ____monster_attackSpeed_13 = monster.attackSpeed
    local ____monster_range_14 = monster.range
    local ____monster_flying_4 = monster.flying
    if ____monster_flying_4 == nil then
        ____monster_flying_4 = false
    end
    return {
        monsterId = ____monster_id_5,
        name = ____monster_name_6,
        count = ____count_7,
        isElite = ____isElite_8,
        isBoss = ____isBoss_9,
        stats = ____stats_10,
        tier = ____tier_11,
        armorKMult = ____temp_12,
        attackSpeed = ____monster_attackSpeed_13,
        range = ____monster_range_14,
        flying = ____monster_flying_4
    }
end
function WaveDirector.prototype.intervalForAct(self, act)
    local interval = __TS__ArrayFind(
        self.data.intervals,
        function(____, i) return i.act == act end
    )
    if not interval then
        error(
            __TS__New(Error, ("波次导演：幕「" .. act) .. "」没有对应的强度区间"),
            0
        )
    end
    return interval
end
function WaveDirector.prototype.populationRow(self, players)
    local row = self.index.population:get(players)
    if not row then
        error(
            __TS__New(
                Error,
                ("波次导演：人数缩放表缺少 N=" .. tostring(players)) .. " 行"
            ),
            0
        )
    end
    return row
end
function WaveDirector.prototype.tierArmorK(self, tier)
    local row = self.index.tierArmorK:get(tier)
    if not row then
        error(
            __TS__New(
                Error,
                ("波次导演：缺少档位 T" .. tostring(tier)) .. " 的护甲 K 定义"
            ),
            0
        )
    end
    return row
end
function WaveDirector.prototype.requireMonster(self, monsterId)
    local monster = self.index.monster:get(monsterId)
    if not monster then
        error(
            __TS__New(Error, ("波次导演：未知怪物「" .. monsterId) .. "」"),
            0
        )
    end
    return monster
end
function WaveDirector.prototype.clampPlayers(self, players)
    local n = math.floor(players + 0.5)
    return math.min(
        math.max(1, n),
        self.maxPlayers
    )
end
return ____exports
 end,
["logic.modifier.modifierSet"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ArrayFindIndex = ____lualib.__TS__ArrayFindIndex
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
local durationOf, shieldAmount, instanceKey, PERMANENT
local ____effects = require("logic.modifier.effects")
local effectPolarity = ____effects.effectPolarity
local isInstantEffect = ____effects.isInstantEffect
function durationOf(self, spec)
    repeat
        local ____switch82 = spec.kind
        local ____cond82 = ____switch82 == "statMod"
        if ____cond82 then
            return spec.duration or PERMANENT
        end
        ____cond82 = ____cond82 or ____switch82 == "lifesteal"
        if ____cond82 then
            return PERMANENT
        end
        ____cond82 = ____cond82 or (____switch82 == "damageTakenMul" or ____switch82 == "damageDealtMul" or ____switch82 == "stackDamage" or ____switch82 == "root" or ____switch82 == "shield")
        if ____cond82 then
            return spec.duration
        end
    until true
end
function shieldAmount(self, spec, maxHp)
    return (spec.percentOfMaxHp or 0) * maxHp + (spec.flat or 0)
end
function instanceKey(self, spec, source)
    repeat
        local ____switch85 = spec.kind
        local ____cond85 = ____switch85 == "statMod"
        if ____cond85 then
            return (((("statMod|" .. source) .. "|") .. spec.stat) .. "|") .. spec.mode
        end
        ____cond85 = ____cond85 or ____switch85 == "stackDamage"
        if ____cond85 then
            return "stackDamage|" .. spec.stackId
        end
        ____cond85 = ____cond85 or (____switch85 == "damageTakenMul" or ____switch85 == "damageDealtMul" or ____switch85 == "root" or ____switch85 == "lifesteal")
        if ____cond85 then
            return (spec.kind .. "|") .. source
        end
        ____cond85 = ____cond85 or ____switch85 == "shield"
        if ____cond85 then
            return nil
        end
    until true
end
--- 全部属性键（运行时遍历用，顺序与数值文档 §2.1 一致）
____exports.STAT_KEYS = {
    "hp",
    "mp",
    "atk",
    "sp",
    "def",
    "spd",
    "dodge",
    "crit",
    "critDmg"
}
PERMANENT = math.huge
--- 属性结算：`final = base × (1 + Σpercent) + Σflat`。
-- 
-- 与数值文档 §7.1 一致：HP / ATK / SP 走百分比（`Σ装备% = E − 1`），
-- 护甲 / 会心 / 闪避 / 移速 / 真气走固定值（不入 E 曲线）。
function ____exports.applyStatBonuses(self, base, bonuses)
    local result = __TS__ObjectAssign({}, base)
    for ____, key in ipairs(____exports.STAT_KEYS) do
        local percent = bonuses.percent[key] or 0
        local flat = bonuses.flat[key] or 0
        result[key] = base[key] * (1 + percent) + flat
    end
    return result
end
____exports.ModifierSet = __TS__Class()
local ModifierSet = ____exports.ModifierSet
ModifierSet.name = "ModifierSet"
function ModifierSet.prototype.____constructor(self)
    self.instances = {}
    self.byKey = __TS__New(Map)
    self.keyById = __TS__New(Map)
    self.shieldPool = __TS__New(Map)
    self.nextId = 0
end
function ModifierSet.prototype.add(self, spec, source, options)
    if source == nil then
        source = "unknown"
    end
    if options == nil then
        options = {}
    end
    if isInstantEffect(nil, spec) then
        error(
            __TS__New(Error, ("ModifierSet.add: " .. spec.kind) .. " 为瞬时效果，请先经 partitionEffects 交由引擎即时结算"),
            0
        )
    end
    local key = instanceKey(nil, spec, source)
    if key ~= nil then
        local existing = self.byKey:get(key)
        if existing then
            return self:refresh(existing, spec)
        end
    end
    local ____self_0, ____nextId_1 = self, "nextId"
    local ____self_nextId_2 = ____self_0[____nextId_1] + 1
    ____self_0[____nextId_1] = ____self_nextId_2
    local instance = {
        id = ____self_nextId_2,
        spec = spec,
        source = source,
        remaining = durationOf(nil, spec),
        stacks = 1,
        polarity = effectPolarity(nil, spec)
    }
    local ____self_instances_3 = self.instances
    ____self_instances_3[#____self_instances_3 + 1] = instance
    if key ~= nil then
        self.byKey:set(key, instance)
        self.keyById:set(instance.id, key)
    end
    if spec.kind == "shield" then
        self.shieldPool:set(
            instance.id,
            shieldAmount(nil, spec, options.maxHp or 0)
        )
    end
    return instance
end
function ModifierSet.prototype.addAll(self, specs, source, options)
    if source == nil then
        source = "unknown"
    end
    if options == nil then
        options = {}
    end
    for ____, spec in ipairs(specs) do
        if not isInstantEffect(nil, spec) then
            self:add(spec, source, options)
        end
    end
end
function ModifierSet.prototype.tick(self, dt)
    if dt == 0 then
        return
    end
    do
        local i = #self.instances - 1
        while i >= 0 do
            do
                local instance = self.instances[i + 1]
                if not instance or instance.remaining == PERMANENT then
                    goto __continue19
                end
                instance.remaining = instance.remaining - dt
                if instance.remaining <= 0 then
                    self:removeAt(i)
                end
            end
            ::__continue19::
            i = i - 1
        end
    end
end
function ModifierSet.prototype.remove(self, id)
    local index = __TS__ArrayFindIndex(
        self.instances,
        function(____, instance) return instance.id == id end
    )
    if index < 0 then
        return false
    end
    self:removeAt(index)
    return true
end
function ModifierSet.prototype.removeBySource(self, source)
    local removed = 0
    do
        local i = #self.instances - 1
        while i >= 0 do
            local ____opt_4 = self.instances[i + 1]
            if (____opt_4 and ____opt_4.source) == source then
                self:removeAt(i)
                removed = removed + 1
            end
            i = i - 1
        end
    end
    return removed
end
function ModifierSet.prototype.dispel(self, polarity, maxCount)
    if maxCount == nil then
        maxCount = math.huge
    end
    local removed = {}
    do
        local i = 0
        while i < #self.instances and #removed < maxCount do
            local instance = self.instances[i + 1]
            if instance and instance.polarity == polarity then
                removed[#removed + 1] = instance
                self:removeAt(i)
            else
                i = i + 1
            end
        end
    end
    return removed
end
function ModifierSet.prototype.clear(self)
    __TS__ArraySetLength(self.instances, 0)
    self.byKey:clear()
    self.keyById:clear()
    self.shieldPool:clear()
end
function ModifierSet.prototype.statBonuses(self)
    local flat = {}
    local percent = {}
    for ____, instance in ipairs(self.instances) do
        do
            local spec = instance.spec
            if spec.kind ~= "statMod" then
                goto __continue36
            end
            local bucket = spec.mode == "flat" and flat or percent
            bucket[spec.stat] = (bucket[spec.stat] or 0) + spec.value
        end
        ::__continue36::
    end
    return {flat = flat, percent = percent}
end
function ModifierSet.prototype.resolveStats(self, base)
    return ____exports.applyStatBonuses(
        nil,
        base,
        self:statBonuses()
    )
end
function ModifierSet.prototype.outgoingBonus(self)
    local sum = 0
    for ____, instance in ipairs(self.instances) do
        if instance.spec.kind == "damageDealtMul" then
            sum = sum + (instance.spec.value - 1)
        end
    end
    return sum
end
function ModifierSet.prototype.incomingReduction(self)
    local sum = 0
    for ____, instance in ipairs(self.instances) do
        if instance.spec.kind == "damageTakenMul" then
            sum = sum + (1 - instance.spec.value)
        end
    end
    return sum
end
function ModifierSet.prototype.damageMultiplier(self)
    return 1 + self:outgoingBonus() - self:incomingReduction()
end
function ModifierSet.prototype.lifestealPercent(self)
    local sum = 0
    for ____, instance in ipairs(self.instances) do
        if instance.spec.kind == "lifesteal" then
            sum = sum + instance.spec.percent
        end
    end
    return sum
end
function ModifierSet.prototype.stacksOf(self, stackId)
    for ____, instance in ipairs(self.instances) do
        if instance.spec.kind == "stackDamage" and instance.spec.stackId == stackId then
            return instance.stacks
        end
    end
    return 0
end
function ModifierSet.prototype.stackDamageBonus(self)
    local sum = 0
    for ____, instance in ipairs(self.instances) do
        if instance.spec.kind == "stackDamage" then
            sum = sum + instance.spec.perStack * instance.stacks
        end
    end
    return sum
end
function ModifierSet.prototype.isRooted(self)
    return __TS__ArraySome(
        self.instances,
        function(____, instance) return instance.spec.kind == "root" end
    )
end
function ModifierSet.prototype.shieldTotal(self)
    local sum = 0
    for ____, remaining in __TS__Iterator(self.shieldPool:values()) do
        sum = sum + remaining
    end
    return sum
end
function ModifierSet.prototype.absorb(self, damage)
    local remaining = math.max(0, damage)
    local absorbed = 0
    local shieldIds = __TS__ArrayMap(
        __TS__ArrayFilter(
            self.instances,
            function(____, instance) return instance.spec.kind == "shield" end
        ),
        function(____, instance) return instance.id end
    )
    for ____, id in ipairs(shieldIds) do
        if remaining <= 0 then
            break
        end
        local pool = self.shieldPool:get(id) or 0
        local take = math.min(pool, remaining)
        absorbed = absorbed + take
        remaining = remaining - take
        if pool - take <= 0 then
            self:remove(id)
        else
            self.shieldPool:set(id, pool - take)
        end
    end
    return {absorbed = absorbed, overflow = remaining}
end
function ModifierSet.prototype.refresh(self, existing, spec)
    if spec.kind == "stackDamage" and existing.spec.kind == "stackDamage" then
        existing.stacks = math.min(existing.stacks + 1, spec.maxStacks)
    end
    existing.spec = spec
    existing.remaining = durationOf(nil, spec)
    existing.polarity = effectPolarity(nil, spec)
    return existing
end
function ModifierSet.prototype.removeAt(self, index)
    local instance = self.instances[index + 1]
    if not instance then
        return
    end
    __TS__ArraySplice(self.instances, index, 1)
    self.shieldPool:delete(instance.id)
    local key = self.keyById:get(instance.id)
    if key ~= nil then
        if self.byKey:get(key) == instance then
            self.byKey:delete(key)
        end
        self.keyById:delete(instance.id)
    end
end
__TS__SetDescriptor(
    ModifierSet.prototype,
    "active",
    {get = function(self)
        return self.instances
    end},
    true
)
return ____exports
 end,
["logic.combat.damage"] = function(...) 
local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local computeDefRed, clamp
function computeDefRed(self, defender, damageType, armorK, limits)
    if damageType == "real" then
        return 0
    end
    local entry = armorK:get(defender.tier)
    if not entry then
        error(
            __TS__New(
                Error,
                ("伤害引擎：缺少档位 T" .. tostring(defender.tier)) .. " 的护甲 K 定义"
            ),
            0
        )
    end
    local def = math.max(0, defender.stats.def)
    local k = entry.k * (defender.armorKMult or 1)
    return math.min(def / (def + k), limits.defRedMax)
end
function clamp(self, value, min, max)
    return math.min(
        math.max(value, min),
        max
    )
end
function ____exports.computeDamage(self, params)
    local ____params_0 = params
    local attacker = ____params_0.attacker
    local defender = ____params_0.defender
    local damageType = ____params_0.damageType
    local rate = ____params_0.rate
    local rng = ____params_0.rng
    local armorK = ____params_0.armorK
    local limits = ____params_0.limits
    local base = (damageType == "magic" and attacker.stats.sp or attacker.stats.atk) * rate
    local dmgMult = clamp(
        nil,
        1 + attacker.modifiers:outgoingBonus() + attacker.modifiers:stackDamageBonus() - defender.modifiers:incomingReduction(),
        limits.dmgMultMin,
        limits.dmgMultMax
    )
    local defRed = computeDefRed(
        nil,
        defender,
        damageType,
        armorK,
        limits
    )
    local dodgeChance = clamp(nil, defender.stats.dodge / 100, 0, limits.dodgeMax)
    if rng:chance(dodgeChance) then
        return {
            dodged = true,
            crit = false,
            critMult = 1,
            base = base,
            dmgMult = dmgMult,
            defRed = defRed,
            damage = 0
        }
    end
    local critChance = clamp(nil, attacker.stats.crit / 100, 0, limits.critMax)
    local crit = rng:chance(critChance)
    local critMult = crit and math.min(attacker.stats.critDmg, limits.critDmgMax) or 1
    local damage = math.max(
        1,
        math.floor(base * dmgMult * critMult * (1 - defRed))
    )
    return {
        dodged = false,
        crit = crit,
        critMult = critMult,
        base = base,
        dmgMult = dmgMult,
        defRed = defRed,
        damage = damage
    }
end
return ____exports
 end,
["logic.battle.spatial"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- 欧氏距离。
-- 
-- 不用 `Math.hypot`：TSTL 无该内建实现（编译报 unsupported）。逻辑层以「格」为单位，
-- 坐标量级小、无溢出风险，故用 `sqrt(x²+y²)` 等价替代——同样保持确定性。
local function hypot(self, x, y)
    return math.sqrt(x * x + y * y)
end
function ____exports.distance(self, a, b)
    return hypot(nil, a.x - b.x, a.y - b.y)
end
--- 归一化为单位向量；零向量返回零向量（避免 NaN）
function ____exports.normalize(self, v)
    local len = hypot(nil, v.x, v.y)
    if len == 0 then
        return {x = 0, y = 0}
    end
    return {x = v.x / len, y = v.y / len}
end
--- 沿 `dir`（不要求已归一化）移动 `dist` 距离后的落点
function ____exports.offset(self, from, dir, dist)
    local d = ____exports.normalize(nil, dir)
    return {x = from.x + d.x * dist, y = from.y + d.y * dist}
end
--- 朝 `target` 移动至多 `maxStep`：未达则精确落点，超过则走满步长。
-- 步长非正或已重合时不动。
function ____exports.stepToward(self, from, target, maxStep)
    if maxStep <= 0 then
        return {x = from.x, y = from.y}
    end
    local dist = ____exports.distance(nil, from, target)
    if dist <= maxStep then
        return {x = target.x, y = target.y}
    end
    return ____exports.offset(nil, from, {x = target.x - from.x, y = target.y - from.y}, maxStep)
end
--- 距离是否 ≤ range（含边界）
function ____exports.inRange(self, a, b, range)
    return ____exports.distance(nil, a, b) <= range
end
--- 把点钳入矩形边界
function ____exports.clampToBounds(self, p, bounds)
    return {
        x = math.min(
            math.max(p.x, bounds.min.x),
            bounds.max.x
        ),
        y = math.min(
            math.max(p.y, bounds.min.y),
            bounds.max.y
        )
    }
end
--- 扇形命中判定：目标位于 `origin` 沿 `facing` 方向、张角 `±halfAngleDeg`、半径 `range` 的扇内。
-- 目标与原点重合（距离 0）视为命中。
function ____exports.inCone(self, origin, facing, target, range, halfAngleDeg)
    local toTarget = {x = target.x - origin.x, y = target.y - origin.y}
    local dist = hypot(nil, toTarget.x, toTarget.y)
    if dist > range then
        return false
    end
    if dist == 0 then
        return true
    end
    local dir = ____exports.normalize(nil, facing)
    if dir.x == 0 and dir.y == 0 then
        return false
    end
    local cos = (toTarget.x * dir.x + toTarget.y * dir.y) / dist
    local clamped = math.min(
        1,
        math.max(-1, cos)
    )
    return math.acos(clamped) <= halfAngleDeg * math.pi / 180
end
return ____exports
 end,
["logic.battle.unit"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__New = ____lualib.__TS__New
local Set = ____lualib.Set
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
local ____modifierSet = require("logic.modifier.modifierSet")
local ModifierSet = ____modifierSet.ModifierSet
local ____skillState = require("logic.skills.skillState")
local SkillState = ____skillState.SkillState
local ____spatial = require("logic.battle.spatial")
local clampToBounds = ____spatial.clampToBounds
local offset = ____spatial.offset
local stepToward = ____spatial.stepToward
--- 移速换算：`spd`（速度单位 / 秒）→ 格 / 秒。
-- 
-- 数值层 `spd`（英雄 300 / 小怪 220）与空间层「格」是两套刻度，此处给出换算比例。
-- 关键：移速随 `statMod` 百分比（减速 / 加速）联动，故用 getter 从 `stats.spd` 取。
____exports.SPEED_UNITS_PER_GRID = 100
____exports.Unit = __TS__Class()
local Unit = ____exports.Unit
Unit.name = "Unit"
function Unit.prototype.____constructor(self, init)
    self.facing = {x = 1, y = 0}
    self.modifiers = __TS__New(ModifierSet)
    self.alive = true
    self.attackTimer = 0
    self.phaseTriggered = __TS__New(Set)
    self.id = init.id
    self.kind = init.kind
    self.defId = init.defId
    self.name = init.name
    self.baseStats = __TS__ObjectAssign({}, init.baseStats)
    self.position = __TS__ObjectAssign({}, init.position)
    self.tier = init.tier
    self.armorKMult = init.armorKMult or 1
    local ____init_flying_0 = init.flying
    if ____init_flying_0 == nil then
        ____init_flying_0 = false
    end
    self.flying = ____init_flying_0
    self.attackRange = init.attackRange
    self.damageType = init.damageType
    self.attackInterval = 1 / init.attackSpeed
    self.skillIds = init.skillIds or ({})
    self.level = init.level or 1
    self.rank = init.rank or "yuqing"
    local maxMp = init.maxMp or init.baseStats.mp
    self.skillState = __TS__New(SkillState, {mp = init.mp or maxMp, maxMp = maxMp})
    self.hp = self.maxHp
end
function Unit.prototype.setBaseStats(self, next)
    local ratio = self.maxHp > 0 and self.hp / self.maxHp or 1
    self.baseStats = __TS__ObjectAssign({}, next)
    self.hp = self.maxHp * ratio
end
function Unit.prototype.moveToward(self, target, maxStep, bounds)
    self:face(target)
    self.position = clampToBounds(
        nil,
        stepToward(nil, self.position, target, maxStep),
        bounds
    )
end
function Unit.prototype.moveBy(self, direction, distance, bounds)
    local from = self.position
    local target = {x = from.x + direction.x, y = from.y + direction.y}
    self.position = clampToBounds(
        nil,
        stepToward(nil, from, target, distance),
        bounds
    )
end
function Unit.prototype.displaceAway(self, from, dist, bounds)
    local dir = {x = self.position.x - from.x, y = self.position.y - from.y}
    self.position = clampToBounds(
        nil,
        offset(nil, self.position, dir, dist),
        bounds
    )
end
function Unit.prototype.face(self, target)
    local dx = target.x - self.position.x
    local dy = target.y - self.position.y
    if dx ~= 0 or dy ~= 0 then
        self.facing = {x = dx, y = dy}
    end
end
function Unit.prototype.heal(self, amount)
    self.hp = math.min(self.maxHp, self.hp + amount)
end
function Unit.prototype.tick(self, dt)
    self.modifiers:tick(dt)
    self.skillState:tick(dt)
    if self.attackTimer > 0 then
        self.attackTimer = math.max(0, self.attackTimer - dt)
    end
end
__TS__SetDescriptor(
    Unit.prototype,
    "stats",
    {get = function(self)
        return self.modifiers:resolveStats(self.baseStats)
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "maxHp",
    {get = function(self)
        return self.stats.hp
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "moveSpeed",
    {get = function(self)
        return self.stats.spd / ____exports.SPEED_UNITS_PER_GRID
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "isBoss",
    {get = function(self)
        return self.kind == "boss"
    end},
    true
)
__TS__SetDescriptor(
    Unit.prototype,
    "isElite",
    {get = function(self)
        return self.kind == "elite"
    end},
    true
)
return ____exports
 end,
["logic.battle.combat"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local ____exports = {}
local ____damage = require("logic.combat.damage")
local computeDamage = ____damage.computeDamage
local ____effects = require("logic.modifier.effects")
local effectPolarity = ____effects.effectPolarity
local ____spatial = require("logic.battle.spatial")
local distance = ____spatial.distance
local inCone = ____spatial.inCone
local inRange = ____spatial.inRange
local offset = ____spatial.offset
--- 扇形半张角（度）：总张角 60° 的前方扇（M1 原型参数，待手感调优）
____exports.CONE_HALF_ANGLE_DEG = 30
--- 一次伤害的完整落地：公式结算 → 护盾吸收 → 扣气血 → 击杀判定 → 吸血回复。
-- 
-- @param rate 技能倍率（普攻传 1）；`damageType` 缺省取攻击者自身伤害类型
function ____exports.resolveAttack(self, attacker, defender, ctx, rate, damageType)
    if rate == nil then
        rate = 1
    end
    local breakdown = computeDamage(nil, {
        attacker = {stats = attacker.stats, modifiers = attacker.modifiers},
        defender = {stats = defender.stats, modifiers = defender.modifiers, tier = defender.tier, armorKMult = defender.armorKMult},
        damageType = damageType or attacker.damageType,
        rate = rate,
        rng = ctx.rng,
        armorK = ctx.armorK,
        limits = ctx.limits
    })
    local ____temp_0 = defender.modifiers:absorb(breakdown.damage)
    local absorbed = ____temp_0.absorbed
    local overflow = ____temp_0.overflow
    local before = defender.hp
    defender.hp = math.max(0, before - overflow)
    local dealt = before - defender.hp
    if defender.hp <= 0 then
        defender.alive = false
    end
    local lifesteal = 0
    local percent = attacker.modifiers:lifestealPercent()
    if percent > 0 and dealt > 0 then
        lifesteal = dealt * percent
        attacker:heal(lifesteal)
    end
    return {
        breakdown = breakdown,
        absorbed = absorbed,
        dealt = dealt,
        lifesteal = lifesteal,
        killed = not defender.alive
    }
end
--- 距 `origin` 最近的存活单位（距离相同取 id 字典序最小，保证确定性）
function ____exports.nearestUnit(self, origin, units)
    local best = nil
    local bestDist = math.huge
    for ____, unit in ipairs(units) do
        do
            if not unit.alive then
                goto __continue6
            end
            local d = distance(nil, unit.position, origin)
            if d < bestDist or d == bestDist and best ~= nil and unit.id < best.id then
                best = unit
                bestDist = d
            end
        end
        ::__continue6::
    end
    return best
end
--- 按技能形态选取伤害目标；`aim` 仅地面范围（aoeGround）形态需要
function ____exports.selectTargets(self, caster, resolved, enemies, aim)
    repeat
        local ____switch11 = resolved.shape
        local ____cond11 = ____switch11 == "self"
        if ____cond11 then
            return {}
        end
        ____cond11 = ____cond11 or ____switch11 == "single"
        if ____cond11 then
            do
                local range = resolved.range or caster.attackRange
                local inReach = __TS__ArrayFilter(
                    enemies,
                    function(____, e) return e.alive and inRange(nil, caster.position, e.position, range) end
                )
                local nearest = ____exports.nearestUnit(nil, caster.position, inReach)
                return nearest and ({nearest}) or ({})
            end
        end
        ____cond11 = ____cond11 or ____switch11 == "cone"
        if ____cond11 then
            do
                local radius = resolved.radius or resolved.range or caster.attackRange
                return __TS__ArrayFilter(
                    enemies,
                    function(____, e) return e.alive and inCone(
                        nil,
                        caster.position,
                        caster.facing,
                        e.position,
                        radius,
                        ____exports.CONE_HALF_ANGLE_DEG
                    ) end
                )
            end
        end
        ____cond11 = ____cond11 or ____switch11 == "aoeSelf"
        if ____cond11 then
            do
                local radius = resolved.radius or caster.attackRange
                return __TS__ArrayFilter(
                    enemies,
                    function(____, e) return e.alive and inRange(nil, caster.position, e.position, radius) end
                )
            end
        end
        ____cond11 = ____cond11 or ____switch11 == "aoeGround"
        if ____cond11 then
            do
                if not aim then
                    return {}
                end
                local radius = resolved.radius or caster.attackRange
                return __TS__ArrayFilter(
                    enemies,
                    function(____, e) return e.alive and inRange(nil, aim, e.position, radius) end
                )
            end
        end
    until true
end
--- 释放技能：选取目标 → 逐个结算伤害 → 分发效果。
-- 
-- 效果分发规则（与 `effects.ts` 极性判定一致，不写特殊逻辑）：
--  - 持久·增益 → 施法者自身；持久·减益 → 每个命中目标；
--  - 瞬时·治疗 → 施法者；瞬时·击退 → 每个命中目标；瞬时·召唤 → 环绕施法者生成。
function ____exports.applySkill(self, caster, resolved, ctx, enemies, hooks, aim)
    local targets = ____exports.selectTargets(
        nil,
        caster,
        resolved,
        enemies,
        aim
    )
    local source = resolved.skill.id
    local hits = {}
    if resolved.damageType then
        for ____, target in ipairs(targets) do
            hits[#hits + 1] = {
                target = target,
                outcome = ____exports.resolveAttack(
                    nil,
                    caster,
                    target,
                    ctx,
                    resolved.rate,
                    resolved.damageType
                )
            }
        end
    end
    for ____, spec in ipairs(resolved.persistent) do
        local polarity = effectPolarity(nil, spec)
        if polarity == "buff" then
            caster.modifiers:addAll({spec}, source, {maxHp = caster.maxHp})
        elseif polarity == "debuff" then
            for ____, target in ipairs(targets) do
                target.modifiers:addAll({spec}, source, {maxHp = target.maxHp})
            end
        end
    end
    local summons = {}
    for ____, spec in ipairs(resolved.instant) do
        repeat
            local ____switch32 = spec.kind
            local ____cond32 = ____switch32 == "heal"
            if ____cond32 then
                caster:heal(spec.flat or (spec.percentOfMaxHp or 0) * caster.maxHp)
                break
            end
            ____cond32 = ____cond32 or ____switch32 == "knockback"
            if ____cond32 then
                for ____, target in ipairs(targets) do
                    target:displaceAway(caster.position, spec.distance, ctx.bounds)
                end
                break
            end
            ____cond32 = ____cond32 or ____switch32 == "summon"
            if ____cond32 then
                do
                    local i = 0
                    while i < spec.count do
                        local angle = 2 * math.pi * i / math.max(1, spec.count)
                        local at = offset(
                            nil,
                            caster.position,
                            {
                                x = math.cos(angle),
                                y = math.sin(angle)
                            },
                            0.6
                        )
                        summons[#summons + 1] = {
                            monsterId = spec.monsterId,
                            unit = hooks:spawn(spec.monsterId, at)
                        }
                        i = i + 1
                    end
                end
                break
            end
            do
                break
            end
        until true
    end
    return {hits = hits, summons = summons}
end
return ____exports
 end,
["logic.battle.waveScheduler"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
local ____economy = require("logic.economy.economy")
local waveGold = ____economy.waveGold
____exports.WaveScheduler = __TS__Class()
local WaveScheduler = ____exports.WaveScheduler
WaveScheduler.name = "WaveScheduler"
function WaveScheduler.prototype.____constructor(self, deps)
    self.deps = deps
    self.phaseValue = "prep"
    self.wave = 0
    self.prep = 0
    self.templateId = ""
    self.eventValue = nil
    self.timingDeltaValue = 0
    self:enterPrep()
end
function WaveScheduler.prototype.progress(self, totalKills)
    local ____self_deps_config_0 = self.deps.config
    local anchorKillThreshold = ____self_deps_config_0.anchorKillThreshold
    local raw = anchorKillThreshold > 0 and totalKills / anchorKillThreshold or 1
    return math.min(
        1,
        math.max(0, raw)
    )
end
function WaveScheduler.prototype.step(self, dt, state)
    repeat
        local ____switch5 = self.phaseValue
        local ____cond5 = ____switch5 == "prep"
        if ____cond5 then
            return self:stepPrep(dt, state)
        end
        ____cond5 = ____cond5 or ____switch5 == "combat"
        if ____cond5 then
            return self:stepCombat(state)
        end
        ____cond5 = ____cond5 or ____switch5 == "anchorPrep"
        if ____cond5 then
            return self:stepAnchorPrep(dt)
        end
        ____cond5 = ____cond5 or (____switch5 == "anchor" or ____switch5 == "done")
        if ____cond5 then
            return {}
        end
    until true
end
function WaveScheduler.prototype.resolveAnchor(self)
    self.phaseValue = "done"
end
function WaveScheduler.prototype.stepPrep(self, dt, state)
    self.prep = self.prep - dt
    if self.prep > 0 then
        return {}
    end
    local plan = self.deps.director:plan({
        templateId = self.templateId,
        act = self.deps.act,
        progress = self:progress(state.totalKills),
        players = self.deps.config.players,
        rng = self.deps.rng
    })
    self.phaseValue = "combat"
    return {
        {kind = "spawn", plan = plan},
        {
            kind = "gold",
            amount = waveGold(nil, self.deps.act, self.deps.data.economy)
        }
    }
end
function WaveScheduler.prototype.stepCombat(self, state)
    if state.enemiesAlive > 0 then
        return {}
    end
    if state.totalKills >= self.deps.config.anchorKillThreshold then
        self.phaseValue = "anchorPrep"
        self.prep = self.deps.config.anchorPrepSeconds
        return {}
    end
    self:enterPrep()
    return {}
end
function WaveScheduler.prototype.stepAnchorPrep(self, dt)
    self.prep = self.prep - dt
    if self.prep > 0 then
        return {}
    end
    local group = self.deps.director:anchorBoss(self.deps.config.anchorBossId, self.deps.config.players, self.deps.act)
    self.phaseValue = "anchor"
    return {{kind = "anchorSpawn", group = group, windowSeconds = self.deps.config.anchorWindowSeconds}}
end
function WaveScheduler.prototype.enterPrep(self)
    self.wave = self.wave + 1
    self.phaseValue = "prep"
    local ____self_4 = self.deps.director
    local ____self_4_pickTemplate_5 = ____self_4.pickTemplate
    local ____self_deps_act_2 = self.deps.act
    local ____self_deps_rng_3 = self.deps.rng
    local ____temp_1
    if self.templateId == "" then
        ____temp_1 = nil
    else
        ____temp_1 = self.templateId
    end
    self.templateId = ____self_4_pickTemplate_5(____self_4, ____self_deps_act_2, ____self_deps_rng_3, ____temp_1)
    local roll = self.deps.events:roll(self.templateId, self.deps.act, self.deps.rng)
    self.eventValue = roll.event
    self.timingDeltaValue = roll.timingDelta
    self.prep = math.max(self.deps.config.minPrepSeconds, self.deps.config.prepSeconds + roll.timingDelta)
end
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "phase",
    {get = function(self)
        return self.phaseValue
    end},
    true
)
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "waveNumber",
    {get = function(self)
        return self.wave
    end},
    true
)
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "prepRemaining",
    {get = function(self)
        return self.prep
    end},
    true
)
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "currentEvent",
    {get = function(self)
        return self.eventValue
    end},
    true
)
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "currentTimingDelta",
    {get = function(self)
        return self.timingDeltaValue
    end},
    true
)
__TS__SetDescriptor(
    WaveScheduler.prototype,
    "currentTemplateId",
    {get = function(self)
        return self.templateId
    end},
    true
)
return ____exports
 end,
["logic.battle.config"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
--- M1 纵向切片默认参数
____exports.DEFAULT_BATTLE_CONFIG = {
    seed = 20261013,
    players = 1,
    dt = 1 / 30,
    act = "act1",
    heroId = "zhangxiaofan",
    field = {bounds = {min = {x = 0, y = 0}, max = {x = 24, y = 12}}, spawn = {x = 21, y = 6}, core = {x = 2, y = 6}, heroSpawn = {x = 9, y = 6}},
    coreMaxHp = 3000,
    heroReviveSeconds = 5,
    heroAttackRange = 1,
    heroMpRegenPerSecond = 5,
    aggroBonus = 2.5,
    spawnSpread = 1.2,
    wave = {
        prepSeconds = 60,
        minPrepSeconds = 15,
        anchorPrepSeconds = 90,
        anchorWindowSeconds = 90,
        anchorKillThreshold = 70,
        anchorBossId = "heishui_xuanshe"
    }
}
return ____exports
 end,
["logic.battle.battle"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local Map = ____lualib.Map
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__ArrayPush = ____lualib.__TS__ArrayPush
local __TS__ArrayFindIndex = ____lualib.__TS__ArrayFindIndex
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
local ____rng = require("logic.core.rng")
local Rng = ____rng.Rng
local ____craftEngine = require("logic.crafting.craftEngine")
local CraftEngine = ____craftEngine.CraftEngine
local ____economy = require("logic.economy.economy")
local dropGold = ____economy.dropGold
local LevelTracker = ____economy.LevelTracker
local rollMaterial = ____economy.rollMaterial
local sourceXp = ____economy.sourceXp
local ____eventDirector = require("logic.events.eventDirector")
local EventDirector = ____eventDirector.EventDirector
local ____growth = require("logic.growth.growth")
local resolveGrowthStats = ____growth.resolveGrowthStats
local ____anchorChallenge = require("logic.objective.anchorChallenge")
local AnchorChallenge = ____anchorChallenge.AnchorChallenge
local ____coreTarget = require("logic.objective.coreTarget")
local CoreTarget = ____coreTarget.CoreTarget
local ____heroLife = require("logic.objective.heroLife")
local HeroLife = ____heroLife.HeroLife
local ____skillEngine = require("logic.skills.skillEngine")
local SkillEngine = ____skillEngine.SkillEngine
local ____waveDirector = require("logic.waves.waveDirector")
local WaveDirector = ____waveDirector.WaveDirector
local ____combat = require("logic.battle.combat")
local applySkill = ____combat.applySkill
local nearestUnit = ____combat.nearestUnit
local resolveAttack = ____combat.resolveAttack
local ____spatial = require("logic.battle.spatial")
local clampToBounds = ____spatial.clampToBounds
local inRange = ____spatial.inRange
local offset = ____spatial.offset
local ____unit = require("logic.battle.unit")
local Unit = ____unit.Unit
local ____waveScheduler = require("logic.battle.waveScheduler")
local WaveScheduler = ____waveScheduler.WaveScheduler
____exports.Battle = __TS__Class()
local Battle = ____exports.Battle
Battle.name = "Battle"
function Battle.prototype.____constructor(self, deps)
    self.gold = 0
    self.spirit = 0
    self.materials = __TS__New(Map)
    self.items = {}
    self.unitList = {}
    self.eventBuffer = {}
    self.statusValue = "running"
    self.killsValue = 0
    self.timeValue = 0
    self.nextUnitId = 0
    self.anchorBossUnitId = nil
    self.pendingBreakthrough = false
    self.data = deps.data
    self.index = deps.index
    self.config = deps.config
    self.bounds = deps.config.field.bounds
    self.skillEngine = __TS__New(SkillEngine, deps.index)
    self.craftEngine = __TS__New(CraftEngine, deps.data, deps.index)
    self.director = __TS__New(WaveDirector, deps.data, deps.index)
    self.levelTracker = __TS__New(LevelTracker, deps.data.economy.levelNeed, deps.data.level.maxLevel)
    local root = __TS__New(Rng, deps.config.seed)
    self.damageRng = root:fork(1)
    self.lootRng = root:fork(2)
    self.spawnRng = root:fork(3)
    self.scheduler = __TS__New(
        WaveScheduler,
        {
            data = deps.data,
            director = self.director,
            events = deps.events or __TS__New(EventDirector, deps.index),
            rng = root,
            config = __TS__ObjectAssign({players = deps.config.players}, deps.config.wave),
            act = deps.config.act
        }
    )
    self.core = __TS__New(CoreTarget, deps.config.coreMaxHp)
    self.heroLife = __TS__New(HeroLife, deps.config.heroReviveSeconds)
    self.challenge = __TS__New(AnchorChallenge)
    self.heroDef = self:requireHero(deps.config.heroId)
    self.hero = self:createHero()
    self:equipStartingGear()
end
function Battle.prototype.step(self, dt, intent)
    if intent == nil then
        intent = {}
    end
    __TS__ArraySetLength(self.eventBuffer, 0)
    if self.statusValue ~= "running" then
        return self.eventBuffer
    end
    self.timeValue = self.timeValue + dt
    self.hero:tick(dt)
    for ____, monster in ipairs(self.unitList) do
        monster:tick(dt)
    end
    self:updateHero(dt, intent)
    for ____, monster in ipairs({table.unpack(self.unitList)}) do
        self:updateMonster(monster, dt)
    end
    self:resolveDeaths()
    self:runScheduler(dt)
    self:updateAnchor(dt)
    self:checkDefeat()
    return self.eventBuffer
end
function Battle.prototype.canCraft(self, recipe)
    return self.craftEngine:canCraft(
        recipe,
        self:bag()
    ) == nil
end
function Battle.prototype.craftAndEquip(self, recipe)
    local result = self.craftEngine:craft(
        recipe,
        self:bag(),
        self.lootRng
    )
    if not result.ok then
        return false
    end
    self.gold = result.bag.gold
    self.spirit = result.bag.spirit
    self.materials:clear()
    for ____, ____value in __TS__Iterator(result.bag.materials) do
        local id = ____value[1]
        local count = ____value[2]
        self.materials:set(id, count)
    end
    __TS__ArraySetLength(self.items, 0)
    local ____self_items_1 = self.items
    local ____array_0 = __TS__SparseArrayNew(table.unpack(result.bag.items))
    __TS__SparseArrayPush(____array_0, result.item.defId)
    __TS__ArrayPush(
        ____self_items_1,
        __TS__SparseArraySpread(____array_0)
    )
    self:equipItem(result.item)
    local ____self_eventBuffer_2 = self.eventBuffer
    ____self_eventBuffer_2[#____self_eventBuffer_2 + 1] = {kind = "craft", defId = result.item.defId, quality = result.item.quality}
    return true
end
function Battle.prototype.canBreakthrough(self)
    return self.pendingBreakthrough and self:nextRank(self.hero.rank) ~= nil
end
function Battle.prototype.breakthrough(self)
    local next = self:nextRank(self.hero.rank)
    if not self.pendingBreakthrough or next == nil then
        return false
    end
    self.pendingBreakthrough = false
    self.hero.rank = next
    self:refreshHeroGrowth()
    local ____self_eventBuffer_3 = self.eventBuffer
    ____self_eventBuffer_3[#____self_eventBuffer_3 + 1] = {kind = "breakthrough", rank = next}
    return true
end
function Battle.prototype.updateHero(self, dt, intent)
    if not self.heroLife.isAlive then
        self.heroLife:tick(dt)
        if self.heroLife.isAlive then
            self:reviveHero()
        end
        return
    end
    self.hero.skillState:restore(self.config.heroMpRegenPerSecond * dt)
    if intent.moveDir and not self.hero.modifiers:isRooted() then
        self.hero:moveBy(intent.moveDir, self.hero.moveSpeed * dt, self.bounds)
    end
    if intent.cast ~= nil then
        self:castHeroSkill(intent.cast, intent.aim)
    end
    self:heroAutoAttack()
end
function Battle.prototype.heroAutoAttack(self)
    if self.hero.attackTimer > 0 then
        return
    end
    local target = nearestUnit(nil, self.hero.position, self.unitList)
    if not target or not inRange(nil, self.hero.position, target.position, self.hero.attackRange) then
        return
    end
    self.hero:face(target.position)
    local outcome = resolveAttack(
        nil,
        self.hero,
        target,
        self:combatContext()
    )
    self.hero.attackTimer = self.hero.attackInterval
    self:noteAttack(self.hero, target, outcome)
end
function Battle.prototype.castHeroSkill(self, key, aim)
    local skillId = self.heroDef.skills[key]
    local result = self.skillEngine:cast(skillId, self.hero.skillState, self.hero.rank)
    if not result.ok then
        return
    end
    local enemies = self.hero.alive and self.unitList or ({})
    self:resolveCast(self.hero, result.outcome, enemies, aim)
end
function Battle.prototype.reviveHero(self)
    self.hero.alive = true
    self.hero.hp = self.hero.maxHp
    self.hero.position = __TS__ObjectAssign({}, self.config.field.heroSpawn)
    local ____self_eventBuffer_4 = self.eventBuffer
    ____self_eventBuffer_4[#____self_eventBuffer_4 + 1] = {kind = "heroRevive"}
end
function Battle.prototype.updateMonster(self, monster, dt)
    if not monster.alive then
        return
    end
    self:updateMonsterSkills(monster)
    local hero = self.hero.alive and self.hero or nil
    if hero and inRange(nil, monster.position, hero.position, monster.attackRange) then
        monster:face(hero.position)
        if monster.attackTimer <= 0 then
            local outcome = resolveAttack(
                nil,
                monster,
                hero,
                self:combatContext()
            )
            monster.attackTimer = monster.attackInterval
            self:noteAttack(monster, hero, outcome)
        end
        return
    end
    if hero and inRange(nil, monster.position, hero.position, monster.attackRange + self.config.aggroBonus) then
        if not monster.modifiers:isRooted() then
            monster:moveToward(hero.position, monster.moveSpeed * dt, self.bounds)
        end
        return
    end
    local core = self.config.field.core
    monster:face(core)
    if inRange(nil, monster.position, core, monster.attackRange) then
        if monster.attackTimer <= 0 then
            self:damageCore(math.floor(monster.stats.atk))
            monster.attackTimer = monster.attackInterval
        end
        return
    end
    if not monster.modifiers:isRooted() then
        monster:moveToward(core, monster.moveSpeed * dt, self.bounds)
    end
end
function Battle.prototype.updateMonsterSkills(self, monster)
    local def = self.index.monster:get(monster.defId)
    if not (def and def.skills) then
        return
    end
    for ____, skillId in ipairs(def.skills) do
        do
            local skill = self.index.skill:get(skillId)
            if not skill then
                goto __continue39
            end
            if skill.trigger == "phase" then
                if monster.phaseTriggered:has(skillId) then
                    goto __continue39
                end
                local threshold = skill.triggerThreshold or 0
                if monster.maxHp > 0 and monster.hp / monster.maxHp > threshold then
                    goto __continue39
                end
                monster.phaseTriggered:add(skillId)
                self:castMonsterSkill(monster, skillId)
                goto __continue39
            end
            local reach = skill.range or skill.radius or 0
            if not self.hero.alive or not inRange(nil, monster.position, self.hero.position, reach) then
                goto __continue39
            end
            if self.skillEngine:canCast(skillId, monster.skillState, monster.rank) == nil then
                self:castMonsterSkill(monster, skillId)
            end
        end
        ::__continue39::
    end
end
function Battle.prototype.castMonsterSkill(self, monster, skillId)
    local result = self.skillEngine:cast(skillId, monster.skillState, monster.rank)
    if not result.ok then
        return
    end
    local enemies = self.hero.alive and ({self.hero}) or ({})
    self:resolveCast(monster, result.outcome, enemies)
end
function Battle.prototype.resolveCast(self, caster, resolved, enemies, aim)
    local ____self_eventBuffer_7 = self.eventBuffer
    ____self_eventBuffer_7[#____self_eventBuffer_7 + 1] = {kind = "cast", casterId = caster.id, skillId = resolved.skill.id}
    local result = applySkill(
        nil,
        caster,
        resolved,
        self:combatContext(),
        enemies,
        {spawn = function(____, monsterId, position) return self:spawnSummon(monsterId, position) end},
        aim
    )
    for ____, hit in ipairs(result.hits) do
        self:noteAttack(caster, hit.target, hit.outcome)
    end
end
function Battle.prototype.noteAttack(self, attacker, target, outcome)
    local ____self_eventBuffer_8 = self.eventBuffer
    ____self_eventBuffer_8[#____self_eventBuffer_8 + 1] = {
        kind = "damage",
        sourceId = attacker.id,
        targetId = target.id,
        amount = outcome.dealt,
        crit = outcome.breakdown.crit,
        dodged = outcome.breakdown.dodged
    }
    if target.id == self.anchorBossUnitId then
        self.challenge:damageBoss(outcome.dealt)
    end
end
function Battle.prototype.damageCore(self, amount)
    self.core:takeDamage(amount)
    local ____self_eventBuffer_9 = self.eventBuffer
    ____self_eventBuffer_9[#____self_eventBuffer_9 + 1] = {kind = "coreDamage", amount = amount, hp = self.core.hp}
end
function Battle.prototype.resolveDeaths(self)
    if not self.hero.alive and self.heroLife.isAlive then
        self.heroLife:kill()
        local ____self_eventBuffer_10 = self.eventBuffer
        ____self_eventBuffer_10[#____self_eventBuffer_10 + 1] = {kind = "heroDeath"}
    end
    local writeIndex = 0
    for ____, unit in ipairs(self.unitList) do
        do
            if unit.alive then
                self.unitList[writeIndex + 1] = unit
                writeIndex = writeIndex + 1
                goto __continue58
            end
            self.killsValue = self.killsValue + 1
            self:grantDrops(unit)
        end
        ::__continue58::
    end
    __TS__ArraySetLength(self.unitList, writeIndex)
end
function Battle.prototype.grantDrops(self, unit)
    local source = self:dropSourceOf(unit)
    local row = self.index.drop:get(source)
    if not row then
        return
    end
    local gold = dropGold(nil, row, self.config.players, self.lootRng)
    self.gold = self.gold + gold
    self.spirit = self.spirit + row.spiritFlat
    local material = rollMaterial(
        nil,
        row,
        self.config.act,
        self.data.economy,
        self.lootRng
    )
    if material then
        self:addMaterial(material, 1)
    end
    local gained = self.levelTracker:gainXp(sourceXp(nil, source, unit.tier, self.data.economy.xp))
    if gained > 0 then
        self.hero.level = self.levelTracker.level
        self:refreshHeroGrowth()
    end
    local ____self_eventBuffer_11 = self.eventBuffer
    ____self_eventBuffer_11[#____self_eventBuffer_11 + 1] = {
        kind = "kill",
        unitId = unit.id,
        defId = unit.defId,
        gold = gold,
        material = material
    }
end
function Battle.prototype.dropSourceOf(self, unit)
    if unit.kind == "boss" then
        return unit.id == self.anchorBossUnitId and "anchorBoss" or "waveBoss"
    end
    return unit.kind == "elite" and "elite" or "minion"
end
function Battle.prototype.addMaterial(self, materialId, count)
    local cap = self.data.limits.materialStorageCap
    local current = self.materials:get(materialId) or 0
    self.materials:set(
        materialId,
        math.min(cap, current + count)
    )
end
function Battle.prototype.runScheduler(self, dt)
    local commands = self.scheduler:step(dt, {enemiesAlive = #self.unitList, totalKills = self.killsValue})
    for ____, command in ipairs(commands) do
        repeat
            local ____switch70 = command.kind
            local ____cond70 = ____switch70 == "spawn"
            if ____cond70 then
                self:spawnPlan(command.plan)
                break
            end
            ____cond70 = ____cond70 or ____switch70 == "gold"
            if ____cond70 then
                self.gold = self.gold + command.amount
                local ____self_eventBuffer_12 = self.eventBuffer
                ____self_eventBuffer_12[#____self_eventBuffer_12 + 1] = {kind = "gold", amount = command.amount}
                break
            end
            ____cond70 = ____cond70 or ____switch70 == "anchorSpawn"
            if ____cond70 then
                self:startAnchor(command.group, command.windowSeconds)
                break
            end
        until true
    end
end
function Battle.prototype.spawnPlan(self, plan)
    for ____, group in ipairs(plan.groups) do
        do
            local i = 0
            while i < group.count do
                self:spawnMonster(
                    group,
                    self:spawnPosition()
                )
                i = i + 1
            end
        end
    end
end
function Battle.prototype.spawnSummon(self, monsterId, position)
    local group = self.director:spawn(
        monsterId,
        {
            act = self.config.act,
            progress = self:progress(),
            players = self.config.players,
            count = 1
        }
    )
    return self:spawnMonster(group, position)
end
function Battle.prototype.spawnMonster(self, group, position)
    local monster = self:createMonster(group, position)
    local ____self_unitList_13 = self.unitList
    ____self_unitList_13[#____self_unitList_13 + 1] = monster
    local ____self_eventBuffer_14 = self.eventBuffer
    ____self_eventBuffer_14[#____self_eventBuffer_14 + 1] = {kind = "spawn", unitId = monster.id}
    return monster
end
function Battle.prototype.startAnchor(self, group, windowSeconds)
    local boss = self:spawnMonster(
        group,
        self:spawnPosition()
    )
    self.anchorBossUnitId = boss.id
    self.challenge:start(windowSeconds, boss.maxHp)
    local ____self_eventBuffer_15 = self.eventBuffer
    ____self_eventBuffer_15[#____self_eventBuffer_15 + 1] = {kind = "anchorStart"}
end
function Battle.prototype.updateAnchor(self, dt)
    local status = self.challenge.status
    if status == "cleared" then
        self:onAnchorCleared()
        return
    end
    if status ~= "active" then
        return
    end
    self.challenge:tick(dt)
    if self.challenge.status == "failed" then
        self:onAnchorFailed()
    end
end
function Battle.prototype.onAnchorCleared(self)
    if self.statusValue ~= "running" then
        return
    end
    self.statusValue = "anchorCleared"
    self.pendingBreakthrough = true
    self.scheduler:resolveAnchor()
    local ____self_eventBuffer_16 = self.eventBuffer
    ____self_eventBuffer_16[#____self_eventBuffer_16 + 1] = {kind = "anchorCleared"}
end
function Battle.prototype.onAnchorFailed(self)
    if self.statusValue ~= "running" then
        return
    end
    self:damageCore(math.floor(self.core.maxHp * 0.5))
    self:removeAnchorBoss()
    self.scheduler:resolveAnchor()
    self.statusValue = self.core.destroyed and "defeat" or "anchorFailed"
    local ____self_eventBuffer_17 = self.eventBuffer
    ____self_eventBuffer_17[#____self_eventBuffer_17 + 1] = {kind = "anchorFailed"}
end
function Battle.prototype.removeAnchorBoss(self)
    local index = __TS__ArrayFindIndex(
        self.unitList,
        function(____, unit) return unit.id == self.anchorBossUnitId end
    )
    if index >= 0 then
        __TS__ArraySplice(self.unitList, index, 1)
    end
    self.anchorBossUnitId = nil
end
function Battle.prototype.checkDefeat(self)
    if self.core.destroyed and self.statusValue == "running" then
        self.statusValue = "defeat"
    end
end
function Battle.prototype.createHero(self)
    local stats = resolveGrowthStats(
        nil,
        self.heroDef.base,
        1,
        self.data.level,
        self:rankDef("yuqing")
    )
    return __TS__New(
        Unit,
        {
            id = "hero",
            kind = "hero",
            defId = self.heroDef.id,
            name = self.heroDef.name,
            baseStats = stats,
            position = __TS__ObjectAssign({}, self.config.field.heroSpawn),
            tier = self.heroDef.startTier,
            attackSpeed = self.data.derivation.heroAttackSpeed,
            attackRange = self.config.heroAttackRange,
            damageType = "physical",
            armorKMult = self.heroDef.armorKMult,
            maxMp = self.heroDef.base.mp,
            mp = self.heroDef.base.mp,
            level = 1,
            rank = "yuqing"
        }
    )
end
function Battle.prototype.equipStartingGear(self)
    local start = __TS__ArrayFind(
        self.data.equipment,
        function(____, e) return e.line == "weapon" and e.tier == self.heroDef.startTier end
    )
    if not start then
        return
    end
    local item = {
        defId = start.id,
        line = start.line,
        tier = start.tier,
        quality = "lower",
        affixes = {}
    }
    local ____self_items_18 = self.items
    ____self_items_18[#____self_items_18 + 1] = start.id
    self:equipItem(item)
end
function Battle.prototype.equipItem(self, item)
    local source = "equip:" .. item.line
    self.hero.modifiers:removeBySource(source)
    local def = self.index.equipment:get(item.defId)
    local ____opt_19 = self.index.quality:get(item.quality)
    local statMul = ____opt_19 and ____opt_19.statMul or 1
    if def then
        local specs = __TS__ArrayMap(
            def.mainStats,
            function(____, main) return {kind = "statMod", stat = main.stat, mode = main.mode, value = main.value * statMul} end
        )
        self.hero.modifiers:addAll(specs, source, {maxHp = self.hero.maxHp})
    end
    for ____, affixId in ipairs(item.affixes) do
        local affix = self.index.affix:get(affixId)
        if affix then
            self.hero.modifiers:add(affix.effect, "affix:" .. affixId, {maxHp = self.hero.maxHp})
        end
    end
end
function Battle.prototype.refreshHeroGrowth(self)
    local stats = resolveGrowthStats(
        nil,
        self.heroDef.base,
        self.hero.level,
        self.data.level,
        self:rankDef(self.hero.rank)
    )
    self.hero:setBaseStats(stats)
end
function Battle.prototype.createMonster(self, group, position)
    local def = self.index.monster:get(group.monsterId)
    local kind = group.isBoss and "boss" or (group.isElite and "elite" or "minion")
    self.nextUnitId = self.nextUnitId + 1
    return __TS__New(
        Unit,
        {
            id = "m" .. tostring(self.nextUnitId),
            kind = kind,
            defId = group.monsterId,
            name = group.name,
            baseStats = __TS__ObjectAssign({}, group.stats),
            position = __TS__ObjectAssign({}, position),
            tier = group.tier,
            attackSpeed = group.attackSpeed,
            attackRange = group.range,
            damageType = "physical",
            armorKMult = group.armorKMult,
            flying = group.flying,
            skillIds = def and def.skills or ({}),
            maxMp = 0,
            mp = 0,
            level = 1,
            rank = "yuqing"
        }
    )
end
function Battle.prototype.spawnPosition(self)
    local angle = self.spawnRng:range(0, math.pi * 2)
    local radius = self.spawnRng:range(0, self.config.spawnSpread)
    local dir = {
        x = math.cos(angle),
        y = math.sin(angle)
    }
    return clampToBounds(
        nil,
        offset(nil, self.config.field.spawn, dir, radius),
        self.bounds
    )
end
function Battle.prototype.progress(self)
    return self.scheduler:progress(self.killsValue)
end
function Battle.prototype.combatContext(self)
    return {armorK = self.index.tierArmorK, limits = self.data.limits, rng = self.damageRng, bounds = self.bounds}
end
function Battle.prototype.bag(self)
    return {
        gold = self.gold,
        spirit = self.spirit,
        materials = __TS__New(Map, self.materials),
        items = {table.unpack(self.items)}
    }
end
function Battle.prototype.nextRank(self, rank)
    local order = {__TS__Spread(self.index.rank:keys())}
    local at = __TS__ArrayIndexOf(order, rank)
    if at < 0 then
        return nil
    end
    return order[at + 1 + 1] or nil
end
function Battle.prototype.rankDef(self, rank)
    local def = self.index.rank:get(rank)
    if not def then
        error(
            __TS__New(Error, ("战斗编排：缺少境界「" .. rank) .. "」定义"),
            0
        )
    end
    return def
end
function Battle.prototype.requireHero(self, heroId)
    local def = self.index.hero:get(heroId)
    if not def then
        error(
            __TS__New(Error, ("战斗编排：未知英雄「" .. heroId) .. "」"),
            0
        )
    end
    return def
end
__TS__SetDescriptor(
    Battle.prototype,
    "units",
    {get = function(self)
        return self.unitList
    end},
    true
)
__TS__SetDescriptor(
    Battle.prototype,
    "kills",
    {get = function(self)
        return self.killsValue
    end},
    true
)
__TS__SetDescriptor(
    Battle.prototype,
    "status",
    {get = function(self)
        return self.statusValue
    end},
    true
)
__TS__SetDescriptor(
    Battle.prototype,
    "time",
    {get = function(self)
        return self.timeValue
    end},
    true
)
__TS__SetDescriptor(
    Battle.prototype,
    "events",
    {get = function(self)
        return self.eventBuffer
    end},
    true
)
return ____exports
 end,
["logic.battle.heroAi"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local chooseSkill, readySkill, inReach, chooseMove, OFFENSIVE_ORDER
local ____skillEngine = require("logic.skills.skillEngine")
local SkillEngine = ____skillEngine.SkillEngine
local ____combat = require("logic.battle.combat")
local CONE_HALF_ANGLE_DEG = ____combat.CONE_HALF_ANGLE_DEG
local nearestUnit = ____combat.nearestUnit
local ____spatial = require("logic.battle.spatial")
local distance = ____spatial.distance
local inCone = ____spatial.inCone
local inRange = ____spatial.inRange
local normalize = ____spatial.normalize
function chooseSkill(self, engine, heroDef, hero, target, guardHpRatio)
    if hero.maxHp > 0 and hero.hp / hero.maxHp <= guardHpRatio then
        if readySkill(
            nil,
            engine,
            heroDef,
            hero,
            "E"
        ) then
            return {key = "E"}
        end
    end
    if not target then
        return nil
    end
    for ____, key in ipairs(OFFENSIVE_ORDER) do
        local resolved = readySkill(
            nil,
            engine,
            heroDef,
            hero,
            key
        )
        if resolved and inReach(nil, hero, resolved, target) then
            return resolved.shape == "aoeGround" and ({key = key, aim = {x = target.position.x, y = target.position.y}}) or ({key = key})
        end
    end
    return nil
end
function readySkill(self, engine, heroDef, hero, key)
    local skillId = heroDef.skills[key]
    return engine:canCast(skillId, hero.skillState, hero.rank) == nil and engine:resolve(skillId, hero.rank) or nil
end
function inReach(self, caster, resolved, target)
    repeat
        local ____switch16 = resolved.shape
        local ____cond16 = ____switch16 == "self"
        if ____cond16 then
            return false
        end
        ____cond16 = ____cond16 or ____switch16 == "single"
        if ____cond16 then
            return inRange(nil, caster.position, target.position, resolved.range or caster.attackRange)
        end
        ____cond16 = ____cond16 or ____switch16 == "cone"
        if ____cond16 then
            return inCone(
                nil,
                caster.position,
                caster.facing,
                target.position,
                resolved.radius or resolved.range or caster.attackRange,
                CONE_HALF_ANGLE_DEG
            )
        end
        ____cond16 = ____cond16 or ____switch16 == "aoeSelf"
        if ____cond16 then
            return inRange(nil, caster.position, target.position, resolved.radius or caster.attackRange)
        end
        ____cond16 = ____cond16 or ____switch16 == "aoeGround"
        if ____cond16 then
            return true
        end
    until true
end
function chooseMove(self, from, target, guard, stopRange)
    local to = target and target.position or guard
    local stop = target and stopRange or 0
    if distance(nil, from, to) <= stop then
        return nil
    end
    return normalize(nil, {x = to.x - from.x, y = to.y - from.y})
end
--- 默认自保阈值：气血比例 ≤ 50% 时优先施放护体技
____exports.DEFAULT_GUARD_HP_RATIO = 0.5
OFFENSIVE_ORDER = {"R", "W", "Q"}
--- 本帧英雄意图：`battle` 只读视图 + `index` 技能定义 → `HeroIntent`
function ____exports.decideHeroIntent(self, battle, index, options)
    if options == nil then
        options = {}
    end
    local hero = battle.hero
    local heroDef = index.hero:get(battle.config.heroId)
    if not hero.alive or not heroDef then
        return {}
    end
    local engine = __TS__New(SkillEngine, index)
    local target = nearestUnit(nil, hero.position, battle.units)
    local guardHpRatio = options.guardHpRatio or ____exports.DEFAULT_GUARD_HP_RATIO
    local intent = {}
    local choice = chooseSkill(
        nil,
        engine,
        heroDef,
        hero,
        target,
        guardHpRatio
    )
    if choice then
        intent.cast = choice.key
        if choice.aim then
            intent.aim = choice.aim
        end
    end
    local move = chooseMove(
        nil,
        hero.position,
        target,
        battle.config.field.heroSpawn,
        hero.attackRange
    )
    if move then
        intent.moveDir = move
    end
    return intent
end
return ____exports
 end,
["logic.core.fixedStep"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__NumberIsInteger = ____lualib.__TS__NumberIsInteger
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local ____exports = {}
--- 浮点取整补偿，1 纳秒，远小于任何有意义的逻辑时长
local EPSILON = 1e-9
____exports.FixedStepController = __TS__Class()
local FixedStepController = ____exports.FixedStepController
FixedStepController.name = "FixedStepController"
function FixedStepController.prototype.____constructor(self, dt, maxStepsPerFrame)
    if maxStepsPerFrame == nil then
        maxStepsPerFrame = 5
    end
    self.acc = 0
    if not (dt > 0) then
        error(
            __TS__New(
                Error,
                "FixedStepController: dt 必须为正数，收到 " .. tostring(dt)
            ),
            0
        )
    end
    if not __TS__NumberIsInteger(maxStepsPerFrame) or maxStepsPerFrame < 1 then
        error(
            __TS__New(
                Error,
                "FixedStepController: maxStepsPerFrame 必须为正整数，收到 " .. tostring(maxStepsPerFrame)
            ),
            0
        )
    end
    self.dt = dt
    self.maxStepsPerFrame = maxStepsPerFrame
end
function FixedStepController.prototype.accumulate(self, realDeltaSeconds)
    if realDeltaSeconds > 0 then
        self.acc = self.acc + realDeltaSeconds
    end
    self.acc = math.min(self.acc, self.dt * self.maxStepsPerFrame)
    local steps = math.floor((self.acc + EPSILON) / self.dt)
    if steps > 0 then
        self.acc = math.max(0, self.acc - steps * self.dt)
    end
    return {steps = steps, alpha = self.alpha}
end
function FixedStepController.prototype.reset(self)
    self.acc = 0
end
__TS__SetDescriptor(
    FixedStepController.prototype,
    "accumulator",
    {get = function(self)
        return self.acc
    end},
    true
)
__TS__SetDescriptor(
    FixedStepController.prototype,
    "alpha",
    {get = function(self)
        return self.acc / self.dt
    end},
    true
)
return ____exports
 end,
["logic.simulation.guardrail"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Spread = ____lualib.__TS__Spread
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____waveDirector = require("logic.waves.waveDirector")
local intervalStatsAt = ____waveDirector.intervalStatsAt
local tierAt = ____waveDirector.tierAt
local ____numeric = require("data.tables.numeric")
local limits = ____numeric.limits
--- 围殴基准数量：§2.2「英雄 TTL（6 只同阶小怪围殴）」
____exports.MINION_GANG_COUNT = 6
--- 区间内取样点：取中段（u = 0.5）作为该区间的代表强度（§5.2 中段取样锚）
local INTERVAL_SAMPLE_U = 0.5
--- 减伤率：`DEF / (DEF + K)`，硬上限 `limits.defRedMax`（§3.1 第 5 步 / §3.4）。
-- 与 damage.ts 私有实现同源；K 由调用方按档位给出。
local function defRed(self, def, k)
    local safeDef = math.max(0, def)
    return math.min(safeDef / (safeDef + k), limits.defRedMax)
end
--- 英雄单体击杀单只小怪所需时间（秒）
function ____exports.minionTtk(self, params)
    local ____params_0 = params
    local minionHp = ____params_0.minionHp
    local heroAtk = ____params_0.heroAtk
    local heroAttackSpeed = ____params_0.heroAttackSpeed
    local minionDef = ____params_0.minionDef
    local k = ____params_0.k
    local dps = heroAtk * heroAttackSpeed * (1 - defRed(nil, minionDef, k))
    return minionHp / dps
end
--- 英雄被 `minionCount` 只小怪围殴时的存活时间（秒）
function ____exports.heroTtl(self, params)
    local ____params_1 = params
    local heroHp = ____params_1.heroHp
    local minionAtk = ____params_1.minionAtk
    local minionCount = ____params_1.minionCount
    local heroDef = ____params_1.heroDef
    local k = ____params_1.k
    local incomingDps = minionCount * minionAtk * (1 - defRed(nil, heroDef, k))
    return heroHp / incomingDps
end
--- §9.2 目标节奏带 + 容差（可校验区间的常量表）
____exports.RHYTHM_BANDS = {
    minion = {target = {0.65, 1}, tolerance = 0.2},
    elite = {target = {3, 4}, tolerance = 0.25},
    waveBoss = {target = {12, 20}, tolerance = 0.25},
    wildBoss = {target = {20, 40}, tolerance = 0.3},
    anchorBoss = {target = {40, 40}, tolerance = 0.2},
    heroTtlMinions = {target = {10, 12}, tolerance = 0.2},
    heroTtlAnchor = {target = {3, 5}, tolerance = 0.25}
}
--- 判定取值是否落在节奏带内。
-- 容差按相对比例扩展区间端点：`[target₀×(1−tol), target₁×(1+tol)]`，边界含。
function ____exports.classify(self, value, band)
    local lower = band.target[1] * (1 - band.tolerance)
    local upper = band.target[2] * (1 + band.tolerance)
    return value >= lower and value <= upper and "in" or "out"
end
--- 遍历「6 节点 × 3 区间 × N∈1..6」（=108 行）产出节奏报告。
-- 
-- - 英雄取该节点（AnchorNodeDef 的 heroHp / heroAtk / heroDef）；
-- - 怪物取该区间中段（`intervalStatsAt(u=0.5)`），档位用 `tierAt(u=0.5)`；
-- - 群怪 HP 随人数 `hpMul(N)` 缩放、英雄方按 N 人平摊输出（口径见模块头注释）。
function ____exports.buildGuardrailReport(self, data, index)
    local rows = {}
    local maxPlayers = math.max(__TS__Spread(index.population:keys()))
    for ____, node in ipairs(data.nodes) do
        for ____, interval in ipairs(data.intervals) do
            local mid = intervalStatsAt(nil, interval, INTERVAL_SAMPLE_U)
            local tier = tierAt(nil, interval, INTERVAL_SAMPLE_U)
            local armor = index.tierArmorK:get(tier)
            if not armor then
                error(
                    __TS__New(
                        Error,
                        ("护栏模拟：缺少档位 T" .. tostring(tier)) .. " 的护甲 K 定义"
                    ),
                    0
                )
            end
            local minionDef = armor.standardDef * data.derivation.minion.defRatio
            local heroSingleDps = node.heroAtk * data.derivation.heroAttackSpeed * (1 - defRed(nil, minionDef, armor.k))
            local ttl = ____exports.heroTtl(nil, {
                heroHp = node.heroHp,
                minionAtk = mid.atk,
                minionCount = ____exports.MINION_GANG_COUNT,
                heroDef = node.heroDef,
                k = armor.k
            })
            do
                local n = 1
                while n <= maxPlayers do
                    local pop = index.population:get(n)
                    if not pop then
                        error(
                            __TS__New(
                                Error,
                                ("护栏模拟：人数缩放表缺少 N=" .. tostring(n)) .. " 行"
                            ),
                            0
                        )
                    end
                    local teamTtk = mid.hp * pop.hpMul / (n * heroSingleDps)
                    rows[#rows + 1] = {
                        nodeId = node.id,
                        intervalId = interval.id,
                        players = n,
                        minionTtk = teamTtk,
                        heroTtl = ttl
                    }
                    n = n + 1
                end
            end
        end
    end
    return rows
end
return ____exports
 end,
["war3.api"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["war3.bridge.driver"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
____exports.BattleRunner = __TS__Class()
local BattleRunner = ____exports.BattleRunner
BattleRunner.name = "BattleRunner"
function BattleRunner.prototype.____constructor(self, battle, deps)
    self.battle = battle
    self.deps = deps
end
function BattleRunner.prototype.tick(self, dt)
    if self.battle.status ~= "running" then
        return false
    end
    if self.battle.time >= (self.deps.maxSeconds or math.huge) then
        return false
    end
    local ____self_3 = self.battle
    local ____self_3_step_4 = ____self_3.step
    local ____dt_2 = dt
    local ____this_1
    ____this_1 = self.deps
    local ____opt_0 = ____this_1.intent
    local events = ____self_3_step_4(
        ____self_3,
        ____dt_2,
        ____opt_0 and ____opt_0(____this_1) or ({})
    )
    self.deps:onEvents(events)
    return self.battle.status == "running"
end
--- 注册驱动循环；返回句柄用于停表
function ____exports.startLoop(self, api, periodSeconds, onTick)
    return api:startPeriodicTimer(periodSeconds, onTick)
end
return ____exports
 end,
["war3.projection"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
--- 以战场中心对齐世界原点求 origin（地图未定稿时的默认装配）
function ____exports.centeredOrigin(self, bounds, scale)
    return {originX = -(bounds.max.x - bounds.min.x) * scale / 2, originY = -(bounds.max.y - bounds.min.y) * scale / 2}
end
____exports.MapProjection = __TS__Class()
local MapProjection = ____exports.MapProjection
MapProjection.name = "MapProjection"
function MapProjection.prototype.____constructor(self, bounds, cfg)
    self.bounds = bounds
    self.cfg = cfg
end
function MapProjection.prototype.toWorld(self, p)
    return {x = self.cfg.originX + (p.x - self.bounds.min.x) * self.cfg.scale, y = self.cfg.originY + (p.y - self.bounds.min.y) * self.cfg.scale}
end
return ____exports
 end,
["war3.bridge.eventBridge"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
____exports.EventBridge = __TS__Class()
local EventBridge = ____exports.EventBridge
EventBridge.name = "EventBridge"
function EventBridge.prototype.____constructor(self, api, projection, cfg)
    self.api = api
    self.projection = projection
    self.cfg = cfg
end
function EventBridge.prototype.play(self, events)
    for ____, event in ipairs(events) do
        repeat
            local ____switch5 = event.kind
            local ____cond5 = ____switch5 == "spawn"
            if ____cond5 then
                self:effectAt(self.cfg.effectModels.spawn, event.unitId)
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "cast"
            if ____cond5 then
                self:effectAt(self.cfg.effectModels.cast, event.casterId)
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "kill"
            if ____cond5 then
                self:effectAt(self.cfg.effectModels.kill, event.unitId)
                self:text((((("击杀 " .. event.defId) .. "：+") .. tostring(event.gold)) .. " 金") .. (event.material and ("，材料 " .. event.material) .. " +1" or ""))
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "gold"
            if ____cond5 then
                self:text(("波次收入：+" .. tostring(event.amount)) .. " 金")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "heroDeath"
            if ____cond5 then
                self:text("英雄阵亡，复活中……")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "heroRevive"
            if ____cond5 then
                self:text("英雄已复活")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "anchorStart"
            if ____cond5 then
                self:text("剧情锚点开启：限时击杀 BOSS！")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "anchorCleared"
            if ____cond5 then
                self:text("锚点通关！可以渡劫突破了")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "anchorFailed"
            if ____cond5 then
                self:text("锚点失守！")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "craft"
            if ____cond5 then
                self:text(((("合成成功：" .. event.defId) .. "（") .. event.quality) .. "）")
                break
            end
            ____cond5 = ____cond5 or ____switch5 == "breakthrough"
            if ____cond5 then
                self:text(("突破成功：进入 " .. event.rank) .. " 境")
                break
            end
            ____cond5 = ____cond5 or (____switch5 == "damage" or ____switch5 == "coreDamage")
            if ____cond5 then
                break
            end
        until true
    end
end
function EventBridge.prototype.effectAt(self, model, unitId)
    local pos = self.cfg:positionOf(unitId)
    if not pos then
        return
    end
    local world = self.projection:toWorld(pos)
    self.api:spawnEffect(model, world.x, world.y)
end
function EventBridge.prototype.text(self, message)
    self.api:showText(message)
end
return ____exports
 end,
["war3.bridge.heroControl"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local Set = ____lualib.Set
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____spatial = require("logic.battle.spatial")
local normalize = ____spatial.normalize
--- 方向键 → 逻辑格方向（未归一化，readIntent 统一归一化）
local MOVE_DIRS = {UP = {x = 0, y = 1}, DOWN = {x = 0, y = -1}, LEFT = {x = -1, y = 0}, RIGHT = {x = 1, y = 0}}
local function isCastKey(self, key)
    return key == "Q" or key == "W" or key == "E" or key == "R"
end
____exports.KeyState = __TS__Class()
local KeyState = ____exports.KeyState
KeyState.name = "KeyState"
function KeyState.prototype.____constructor(self, api)
    self.pressed = __TS__New(Set)
    self.pendingCast = nil
    local ____array_0 = __TS__SparseArrayNew(table.unpack(__TS__ObjectKeys(MOVE_DIRS)))
    __TS__SparseArrayPush(
        ____array_0,
        "Q",
        "W",
        "E",
        "R"
    )
    for ____, key in ipairs({__TS__SparseArraySpread(____array_0)}) do
        api:registerKey(
            key,
            function()
                self.pressed:add(key)
                if isCastKey(nil, key) then
                    self.pendingCast = key
                end
            end,
            function()
                self.pressed:delete(key)
            end
        )
    end
end
function KeyState.prototype.readIntent(self)
    local dir = {x = 0, y = 0}
    for ____, key in __TS__Iterator(self.pressed) do
        local move = MOVE_DIRS[key]
        if move then
            dir.x = dir.x + move.x
            dir.y = dir.y + move.y
        end
    end
    local moveDir = (dir.x ~= 0 or dir.y ~= 0) and normalize(nil, dir) or nil
    local cast = self.pendingCast or nil
    self.pendingCast = nil
    return {moveDir = moveDir, cast = cast}
end
return ____exports
 end,
["war3.bridge.unitBridge"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local Set = ____lualib.Set
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local ____exports = {}
local function angleDeg(self, v)
    return math.atan(v.y, v.x) * 180 / math.pi
end
local function samePoint(self, a, b)
    return a.x == b.x and a.y == b.y
end
____exports.UnitBridge = __TS__Class()
local UnitBridge = ____exports.UnitBridge
UnitBridge.name = "UnitBridge"
function UnitBridge.prototype.____constructor(self, api, projection, cfg)
    self.api = api
    self.projection = projection
    self.cfg = cfg
    self.tracked = __TS__New(Map)
    self.corpses = {}
    self.lastPositions = __TS__New(Map)
end
function UnitBridge.prototype.sync(self, hero, monsters)
    for ____, handle in ipairs(self.corpses) do
        self.api:removeUnit(handle)
    end
    __TS__ArraySetLength(self.corpses, 0)
    local present = __TS__New(Set)
    for ____, unit in ipairs({
        hero,
        table.unpack(monsters)
    }) do
        do
            present:add(unit.id)
            self.lastPositions:set(
                unit.id,
                __TS__ObjectAssign({}, unit.position)
            )
            local tracked = self.tracked:get(unit.id)
            if not tracked then
                self:create(unit)
                goto __continue8
            end
            self:deltaSync(tracked, unit)
        end
        ::__continue8::
    end
    for ____, ____value in __TS__Iterator(self.tracked) do
        local id = ____value[1]
        local tracked = ____value[2]
        if not present:has(id) then
            self.api:killUnit(tracked.handle)
            local ____self_corpses_0 = self.corpses
            ____self_corpses_0[#____self_corpses_0 + 1] = tracked.handle
            self.tracked:delete(id)
        end
    end
end
function UnitBridge.prototype.positionOf(self, unitId)
    local pos = self.lastPositions:get(unitId)
    return pos and __TS__ObjectAssign({}, pos) or nil
end
function UnitBridge.prototype.create(self, unit)
    local playerIndex = unit.kind == "hero" and self.cfg.players.hero or self.cfg.players.enemy
    local ____self_2 = self.api
    local ____self_2_createUnit_3 = ____self_2.createUnit
    local ____array_1 = __TS__SparseArrayNew(
        playerIndex,
        self.cfg.unitCodeByKind[unit.kind],
        table.unpack(self:worldOf(unit.position))
    )
    __TS__SparseArrayPush(
        ____array_1,
        angleDeg(nil, unit.facing)
    )
    local handle = ____self_2_createUnit_3(
        ____self_2,
        __TS__SparseArraySpread(____array_1)
    )
    if not handle then
        return
    end
    self.api:setUnitMaxLife(handle, unit.maxHp)
    self.api:setUnitLife(handle, unit.hp)
    local ____opt_4 = self.cfg.scaleByKind
    local scale = ____opt_4 and ____opt_4[unit.kind]
    if scale ~= nil and scale ~= 1 then
        self.api:setUnitScale(handle, scale)
    end
    self.tracked:set(
        unit.id,
        {
            handle = handle,
            dead = not unit.alive,
            pos = __TS__ObjectAssign({}, unit.position),
            facing = __TS__ObjectAssign({}, unit.facing),
            hp = unit.hp,
            maxHp = unit.maxHp
        }
    )
end
function UnitBridge.prototype.deltaSync(self, tracked, unit)
    local isDead = not unit.alive
    if isDead ~= tracked.dead then
        if isDead then
            self.api:killUnit(tracked.handle)
        else
            self.api:reviveHero(
                tracked.handle,
                table.unpack(self:worldOf(unit.position))
            )
            tracked.hp = unit.hp
        end
        tracked.dead = isDead
        return
    end
    if tracked.dead then
        return
    end
    if unit.maxHp ~= tracked.maxHp then
        self.api:setUnitMaxLife(tracked.handle, unit.maxHp)
        tracked.maxHp = unit.maxHp
        self.api:setUnitLife(tracked.handle, unit.hp)
        tracked.hp = unit.hp
    elseif unit.hp ~= tracked.hp then
        self.api:setUnitLife(tracked.handle, unit.hp)
        tracked.hp = unit.hp
    end
    if not samePoint(nil, unit.position, tracked.pos) then
        self.api:setUnitPosition(
            tracked.handle,
            table.unpack(self:worldOf(unit.position))
        )
        tracked.pos = __TS__ObjectAssign({}, unit.position)
    end
    if not samePoint(nil, unit.facing, tracked.facing) then
        self.api:setUnitFacing(
            tracked.handle,
            angleDeg(nil, unit.facing)
        )
        tracked.facing = __TS__ObjectAssign({}, unit.facing)
    end
end
function UnitBridge.prototype.worldOf(self, p)
    local world = self.projection:toWorld(p)
    return {world.x, world.y}
end
return ____exports
 end,
["war3.reforged"] = function(...) 
local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
--- 英雄所属玩家（War3 红方）与敌方玩家（蓝方）索引
local HERO_PLAYER_INDEX = 0
local ENEMY_PLAYER_INDEX = 1
local KEY_OSKEY = {
    UP = OSKEY_UP,
    DOWN = OSKEY_DOWN,
    LEFT = OSKEY_LEFT,
    RIGHT = OSKEY_RIGHT,
    Q = OSKEY_Q,
    W = OSKEY_W,
    E = OSKEY_E,
    R = OSKEY_R
}
local function playerOf(index)
    local p = Player(index)
    if not p then
        error(
            __TS__New(
                Error,
                ("War3 adapter：玩家槽位 " .. tostring(index)) .. " 不存在"
            ),
            0
        )
    end
    return p
end
local function asUnit(handle)
    return handle
end
local function asEffect(handle)
    return handle
end
function ____exports.createReforgedApi()
    return {
        createUnit = function(self, playerIndex, code, x, y, faceDeg)
            local rawcode = FourCC(code)
            local created = CreateUnit(
                playerOf(playerIndex == HERO_PLAYER_INDEX and HERO_PLAYER_INDEX or ENEMY_PLAYER_INDEX),
                rawcode,
                x,
                y,
                faceDeg
            )
            return created ~= nil and created or nil
        end,
        setUnitPosition = function(self, handle, x, y)
            SetUnitX(
                asUnit(handle),
                x
            )
            SetUnitY(
                asUnit(handle),
                y
            )
        end,
        setUnitFacing = function(self, handle, faceDeg)
            SetUnitFacing(
                asUnit(handle),
                faceDeg
            )
        end,
        setUnitLife = function(self, handle, hp)
            SetUnitState(
                asUnit(handle),
                UNIT_STATE_LIFE,
                hp
            )
        end,
        setUnitMaxLife = function(self, handle, max)
            SetUnitState(
                asUnit(handle),
                UNIT_STATE_MAX_LIFE,
                max
            )
        end,
        setUnitScale = function(self, handle, scale)
            SetUnitScale(
                asUnit(handle),
                scale,
                scale,
                scale
            )
        end,
        killUnit = function(self, handle)
            KillUnit(asUnit(handle))
        end,
        removeUnit = function(self, handle)
            RemoveUnit(asUnit(handle))
        end,
        reviveHero = function(self, handle, x, y)
            ReviveHero(
                asUnit(handle),
                x,
                y,
                true
            )
        end,
        showText = function(self, message)
            DisplayTimedTextToPlayer(
                playerOf(HERO_PLAYER_INDEX),
                0,
                0,
                5,
                message
            )
        end,
        spawnEffect = function(self, model, x, y)
            local created = AddSpecialEffect(model, x, y)
            return created ~= nil and created or nil
        end,
        destroyEffect = function(self, handle)
            DestroyEffect(asEffect(handle))
        end,
        startPeriodicTimer = function(self, periodSeconds, onTick)
            local timer = CreateTimer()
            TimerStart(timer, periodSeconds, true, onTick)
            return {stop = function(self)
                PauseTimer(timer)
            end}
        end,
        registerKey = function(self, key, onKeyDown, onKeyUp)
            local oskey = KEY_OSKEY[key]
            local localPlayer = playerOf(HERO_PLAYER_INDEX)
            local downTrigger = CreateTrigger()
            BlzTriggerRegisterPlayerKeyEvent(
                downTrigger,
                localPlayer,
                oskey,
                0,
                true
            )
            TriggerAddAction(downTrigger, onKeyDown)
            local upTrigger = CreateTrigger()
            BlzTriggerRegisterPlayerKeyEvent(
                upTrigger,
                localPlayer,
                oskey,
                0,
                false
            )
            TriggerAddAction(upTrigger, onKeyUp)
        end
    }
end
return ____exports
 end,
["war3.main"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local ____exports = {}
local ____load = require("data.load")
local loadGameData = ____load.loadGameData
local ____battle = require("logic.battle.battle")
local Battle = ____battle.Battle
local ____config = require("logic.battle.config")
local DEFAULT_BATTLE_CONFIG = ____config.DEFAULT_BATTLE_CONFIG
local ____driver = require("war3.bridge.driver")
local BattleRunner = ____driver.BattleRunner
local startLoop = ____driver.startLoop
local ____eventBridge = require("war3.bridge.eventBridge")
local EventBridge = ____eventBridge.EventBridge
local ____heroControl = require("war3.bridge.heroControl")
local KeyState = ____heroControl.KeyState
local ____unitBridge = require("war3.bridge.unitBridge")
local UnitBridge = ____unitBridge.UnitBridge
local ____projection = require("war3.projection")
local centeredOrigin = ____projection.centeredOrigin
local MapProjection = ____projection.MapProjection
local ____reforged = require("war3.reforged")
local createReforgedApi = ____reforged.createReforgedApi
--- 定时器周期（秒），与逻辑固定步长（`DEFAULT_BATTLE_CONFIG.dt`）解耦
local TICK_SECONDS = 0.03
--- 冒烟时长（模拟秒）：覆盖「准备 → 第一波刷怪 → 交战」，与 Node 侧 golden 场景对齐
local SMOKE_SECONDS = 90
--- 每逻辑格的世界单位数（War3 大格标准）
local WORLD_SCALE = 128
--- 占位单位码：地图未定稿前用标准种族单位，建图后替换为自定义单位
local UNIT_CODES = {hero = "Hpal", minion = "hfoo", elite = "hknight", boss = "Udea"}
--- 各 kind 模型缩放（1 = 原始大小不调原生）
local UNIT_SCALES = {hero = 1.1, minion = 1, elite = 1.3, boss = 2}
--- 特效模型路径（占位值）：路径无效时 War3 只是无表现、不报错，
-- 试跑后按需要替换为可用的内置特效或自定义模型。
local EFFECT_MODELS = {spawn = "Abilities\\Spells\\Orc\\FeralSpirit\\feralspiritdone.mdl", kill = "Abilities\\Weapons\\Bolt\\BoltImpact.mdl", cast = "Abilities\\Spells\\Human\\HolyBolt\\HolyBoltSpecialArt.mdl"}
--- 地图加载时启动。
local function boot()
    local ____loadGameData_result_0 = loadGameData(nil)
    local data = ____loadGameData_result_0.data
    local index = ____loadGameData_result_0.index
    local warnings = ____loadGameData_result_0.warnings
    BJDebugMsg(((((((("[阶段1] 配置装配完成：英雄 " .. tostring(#data.heroes)) .. " / 怪物 ") .. tostring(#data.monsters)) .. " / 波次模板 ") .. tostring(#data.waveTemplates)) .. "，校验告警 ") .. tostring(#warnings)) .. " 条")
    local battle = __TS__New(Battle, {data = data, index = index, config = DEFAULT_BATTLE_CONFIG})
    BJDebugMsg((("[阶段1] 建局完成：seed " .. tostring(DEFAULT_BATTLE_CONFIG.seed)) .. "，核心耐久 ") .. tostring(battle.core.maxHp))
    local api = createReforgedApi()
    local bounds = DEFAULT_BATTLE_CONFIG.field.bounds
    local projection = __TS__New(
        MapProjection,
        bounds,
        __TS__ObjectAssign(
            {scale = WORLD_SCALE},
            centeredOrigin(nil, bounds, WORLD_SCALE)
        )
    )
    local unitBridge = __TS__New(UnitBridge, api, projection, {unitCodeByKind = UNIT_CODES, players = {hero = 0, enemy = 1}, scaleByKind = UNIT_SCALES})
    local eventBridge = __TS__New(
        EventBridge,
        api,
        projection,
        {
            effectModels = EFFECT_MODELS,
            positionOf = function(____, unitId) return unitBridge:positionOf(unitId) end
        }
    )
    local keys = __TS__New(KeyState, api)
    local frameEvents = {}
    local runner = __TS__New(
        BattleRunner,
        battle,
        {
            intent = function() return keys:readIntent() end,
            onEvents = function(____, events)
                frameEvents = events
            end,
            maxSeconds = SMOKE_SECONDS
        }
    )
    local loop
    loop = startLoop(
        nil,
        api,
        TICK_SECONDS,
        function()
            if not runner:tick(TICK_SECONDS) then
                loop:stop()
                BJDebugMsg((((((((("[阶段1] 停表：t=" .. __TS__NumberToFixed(battle.time, 1)) .. "s，击杀 ") .. tostring(battle.kills)) .. "，存活单位 ") .. tostring(#battle.units)) .. "，核心 ") .. tostring(math.floor(battle.core.hp + 0.5))) .. "，状态 ") .. battle.status)
                return
            end
            unitBridge:sync(battle.hero, battle.units)
            eventBridge:play(frameEvents)
        end
    )
end
boot()
return ____exports
 end,
}
local ____entry = require("war3.main", ...)
return ____entry
