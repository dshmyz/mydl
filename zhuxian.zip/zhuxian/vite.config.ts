import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vitest/config'

export default defineConfig({
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  test: {
    // 逻辑层为纯 TS，无 DOM 依赖，可在 node 环境 headless 运行
    environment: 'node',
    include: ['src/**/*.test.ts'],
  },
})
